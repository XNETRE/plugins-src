package cloud.commandframework.meta;

import org.apiguardian.api.*;
import java.util.function.*;
import java.lang.reflect.*;
import io.leangen.geantyref.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class SimpleKey<V> implements CommandMeta.Key<V>
{
    public SimpleKey(final TypeToken<V> valueType, final String name, final Function<CommandMeta, V> derivationFunction) {
        this.valueType = valueType;
        this.name = name;
        this.derivationFunction = derivationFunction;
    }
    
    @Override
    public TypeToken<V> getValueType() {
        return this.valueType;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public Function<CommandMeta, V> getFallbackDerivation() {
        return this.derivationFunction;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final SimpleKey simpleKey = (SimpleKey)o;
        return this.valueType.equals(simpleKey.valueType) && this.name.equals(simpleKey.name);
    }
    
    @Override
    public int hashCode() {
        final int n = 7;
        final AnnotatedType[] array = { null };
        "\u679d\u6576\u654e\u6acc\u58fe".length();
        "\u5a9b\u69a3\u6ff1\u6015".length();
        "\u64f7\u5580\u65c1\u6550\u5f77".length();
        "\u50b0\u665e\u683d\u6e2b\u601d".length();
        array[0] = this.valueType.getAnnotatedType();
        return ColonialObfuscator_\u5dce\u705b\u5b7d\u5e4b\u5182\u6e11\u6b1b\u5076\u6c62\u6901\u5db5\u5be8\u63b9\u5f8d\u50c7\u59ed\u563a\u5fec\u6dd4\u6ba9\u5d5e\u543b\u62df\u4f75\u6dd7\u6a65\u5739\u5323\u5222\u5d74\u5f0e\u55a0\u5c8e\u6801\u50cc\u6dea\u5cf3\u5bf7\u5301\u6377\u6244(n * GenericTypeReflector.hashCode(array), 31 * this.name.hashCode());
    }
    
    public static int ColonialObfuscator_\u5dce\u705b\u5b7d\u5e4b\u5182\u6e11\u6b1b\u5076\u6c62\u6901\u5db5\u5be8\u63b9\u5f8d\u50c7\u59ed\u563a\u5fec\u6dd4\u6ba9\u5d5e\u543b\u62df\u4f75\u6dd7\u6a65\u5739\u5323\u5222\u5d74\u5f0e\u55a0\u5c8e\u6801\u50cc\u6dea\u5cf3\u5bf7\u5301\u6377\u6244(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
