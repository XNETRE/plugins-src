package cloud.commandframework.meta;

import org.apiguardian.api.*;
import io.leangen.geantyref.*;
import java.lang.reflect.*;
import java.util.stream.*;
import java.util.function.*;
import java.util.*;

@API(status = API.Status.STABLE)
public class SimpleCommandMeta extends CommandMeta
{
    @Deprecated
    public SimpleCommandMeta(final Map<String, String> m) {
        this.metaMap = Collections.unmodifiableMap((Map<? extends String, ?>)m);
    }
    
    public SimpleCommandMeta(final SimpleCommandMeta simpleCommandMeta) {
        this.metaMap = simpleCommandMeta.metaMap;
    }
    
    public SimpleCommandMeta(final Map<String, Object> m, final boolean b) {
        this.metaMap = Collections.unmodifiableMap((Map<? extends String, ?>)m);
    }
    
    @Deprecated
    @Override
    public final Optional<String> getValue(final String str) {
        final String value = this.metaMap.get(str);
        if (value != null && !(value instanceof String)) {
            "\u6704\u6da7\u51a7\u699c\u6cb1".length();
            "\u4fde\u544d\u5e24\u6ec0\u6a21".length();
            "\u55b0".length();
            "\u6074\u6065".length();
            final IllegalArgumentException ex = new IllegalArgumentException(\u6a18\u5ba9\u5bf3\u6ec3\u6cd7\u627c\u5d75\u5022\u6bfb\u61ef\u6561\u50af\u554d\u6a5b\u6d99\u7008\u6001\u676b\u4fb6\u57af\u5905\u6501\u56c9\u5f3a\u665e\u57c2\u6d2b\u5ffd\u543c\u5593\u69b9\u6780\u6a3c\u56ec\u5ca4\u6c24\u526c\u6c80\u67ad\u5ec3\u5a93(538001223, 907953591, "\u9c4f\u9c4c\u9c50\u9c0b\u9c32", -406483684, -1407226965) + str + \u6a18\u5ba9\u5bf3\u6ec3\u6cd7\u627c\u5d75\u5022\u6bfb\u61ef\u6561\u50af\u554d\u6a5b\u6d99\u7008\u6001\u676b\u4fb6\u57af\u5905\u6501\u56c9\u5f3a\u665e\u57c2\u6d2b\u5ffd\u543c\u5593\u69b9\u6780\u6a3c\u56ec\u5ca4\u6c24\u526c\u6c80\u67ad\u5ec3\u5a93(280500450, -1885220140, "\u0f01\u0f29\u0f63\u0f66\u0f74\u0f23\u0f68\u0f65\u0f47\u0f62\u0f29\u0f50\u0f51\u0f54\u0f56\u0f00\u0f5c\u0f4b\u0f7a\u56b5\u6549\u5cd8\u622d\u66d4\u5a45\u5215\u550b\u5181\u6255\u5a9c\u6602\u5d87\u5769\u52e7\u6991\u7fdf\u5265\u6c27\u5b0a\u531c\u5ec8\u6b31\u5ebe\u6879\u5226\u6853\u5368\u5550\u549b\u5d80\u53c5\u5450\u6ef1\u6874\u6e15\u620a\u55b1\u6eca\u6326\u64c6\u4009\u6ecf\u6bb1\u65f9\u6e59\u5b97\u607b\u501d\u5429\u5321\u52bf\u5161\u56b3\u627c\u5289\u621b\u5a60", 619838293, -628933114));
            "\u690c\u4e48\u542b".length();
            "\u62ce\u56d2\u6cb8".length();
            "\u5432\u6089\u6791\u6c7c\u6b60".length();
            throw ex;
        }
        return Optional.ofNullable(value);
    }
    
    @Deprecated
    @Override
    public final String getOrDefault(final String s, final String other) {
        return this.getValue(s).orElse(other);
    }
    
    @Override
    public final <V> Optional<V> get(final Key<V> key) {
        final Object value = this.metaMap.get(key.getName());
        if (value == null) {
            if (key.getFallbackDerivation() != null) {
                return Optional.ofNullable(key.getFallbackDerivation().apply(this));
            }
            return Optional.empty();
        }
        else {
            if (!GenericTypeReflector.isSuperType(key.getValueType().getType(), value.getClass())) {
                "\u62c1\u6774\u56a1\u675f".length();
                "\u6505\u57a0".length();
                "\u5da7\u5a9d\u6333\u656b\u5248".length();
                "\u673c".length();
                "\u6616\u6f90\u6a77\u5b70\u6b23".length();
                final IllegalArgumentException ex = new IllegalArgumentException(\u6a18\u5ba9\u5bf3\u6ec3\u6cd7\u627c\u5d75\u5022\u6bfb\u61ef\u6561\u50af\u554d\u6a5b\u6d99\u7008\u6001\u676b\u4fb6\u57af\u5905\u6501\u56c9\u5f3a\u665e\u57c2\u6d2b\u5ffd\u543c\u5593\u69b9\u6780\u6a3c\u56ec\u5ca4\u6c24\u526c\u6c80\u67ad\u5ec3\u5a93(-734635200, -727491823, "\u57f4\u57f7\u57f4\u57f8\u57f2\u57f3\u57f0\u57f5\u57ca\u57e3\u57ef\u57bc\u57fa\u57fa\u57ec\u57e4\u57e6\u57f0\u57d7\u0e58\u3db1\u0435\u3a83\u3e00\u0296\u0a87\u0d9e\u0943\u3a99\u0254\u3ec8\u0513\u0fbe\u0a37\u310d\u2700\u0ab8\u34e9\u0397\u0b89\u061d\u33e5\u066e\u3001\u0a50\u306d\u0b1f", -1760673495, 1607734924) + key.getValueType().getType().getTypeName() + \u6a18\u5ba9\u5bf3\u6ec3\u6cd7\u627c\u5d75\u5022\u6bfb\u61ef\u6561\u50af\u554d\u6a5b\u6d99\u7008\u6001\u676b\u4fb6\u57af\u5905\u6501\u56c9\u5f3a\u665e\u57c2\u6d2b\u5ffd\u543c\u5593\u69b9\u6780\u6a3c\u56ec\u5ca4\u6c24\u526c\u6c80\u67ad\u5ec3\u5a93(-38559044, 564636704, "\u8439\u8457\u845a\u8454\u8410\u8442\u845c\u8463\u8458\u8466\u8426\u8466\u846c\u8476\u8460\u843f\u846a\u847d\u8417", -1680715623, -1319118241) + value.getClass());
                "\u503e".length();
                "\u6557\u6595\u5484".length();
                throw ex;
            }
            return Optional.of(value);
        }
    }
    
    @Override
    public final <V> V getOrDefault(final Key<V> key, final V other) {
        return this.get(key).orElse(other);
    }
    
    @Deprecated
    @Override
    public final Map<String, String> getAll() {
        return this.metaMap.entrySet().stream().filter(entry -> entry.getValue() instanceof String).collect(Collectors.toMap((Function<? super Object, ? extends String>)Map.Entry::getKey, entry2 -> entry2.getValue().toString()));
    }
    
    @Override
    public final Map<String, ?> getAllValues() {
        "\u68f8\u52a6\u4eef".length();
        "\u4eab\u6434\u69b0\u630b\u5344".length();
        "\u63ef".length();
        return new HashMap<String, Object>(this.metaMap);
    }
    
    @Override
    public final boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && Objects.equals(this.metaMap, ((SimpleCommandMeta)o).metaMap));
    }
    
    @Override
    public final int hashCode() {
        return Objects.hashCode(this.metaMap);
    }
    
    public static int ColonialObfuscator_\u70d8\u5258\u5194\u5719\u6d19\u6397\u5b86\u5537\u5939\u61be\u5e9d\u574c\u50e3\u618e\u6704\u5184\u7059\u526d\u6234\u63ea\u646c\u5629\u5ef6\u4ebc\u69c6\u5584\u5375\u6ae2\u5f1e\u5e79\u5b11\u6877\u5ced\u69f7\u4f0c\u618e\u6586\u68f5\u653f\u57f3\u5b3e(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
