package cloud.commandframework.meta;

import org.apiguardian.api.*;
import cloud.commandframework.keys.*;
import java.lang.reflect.*;
import java.util.*;
import io.leangen.geantyref.*;
import java.util.function.*;

@API(status = API.Status.STABLE)
public abstract class CommandMeta
{
    @Override
    public final String toString() {
        return \u6f1e\u50c9\u7012\u6e06\u4f6e\u56a3\u5cad\u6953\u6418\u6e17\u5b02\u6d39\u6d5c\u6a6f\u628e\u5831\u5d4d\u4fe7\u6134\u68eb\u6fbd\u4e66\u501c\u7012\u5d3b\u6501\u650b\u52c3\u5149\u6860\u4f75\u56f6\u53af\u5a60\u5a99\u520c\u5557\u6a40\u4ece\u524f\u6a16(-475465339, 567882135, "", -1224884538, 432490916);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.3.0")
    public abstract Optional<String> getValue(final String p0);
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.3.0")
    public abstract String getOrDefault(final String p0, final String p1);
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public abstract <V> Optional<V> get(final Key<V> p0);
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public abstract <V> V getOrDefault(final Key<V> p0, final V p1);
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.3.0")
    public abstract Map<String, String> getAll();
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public abstract Map<String, ?> getAllValues();
    
    public static int ColonialObfuscator_\u6033\u61f8\u574e\u4fbf\u587c\u56bf\u5300\u50cb\u69fb\u709e\u5e6f\u63a2\u5cbf\u6981\u5d98\u523e\u65bc\u5525\u572f\u69e3\u6eae\u567c\u4f32\u521f\u52ab\u697b\u5cc2\u6716\u6377\u5aa3\u60f4\u5b7f\u5b65\u687b\u6b11\u4f55\u55e2\u5928\u5a8f\u5c69\u67d3(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
