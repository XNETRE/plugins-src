package cloud.commandframework.paper;

import cloud.commandframework.execution.*;
import org.bukkit.command.*;
import java.util.function.*;
import cloud.commandframework.bukkit.*;
import cloud.commandframework.*;
import org.bukkit.*;
import org.bukkit.event.*;
import cloud.commandframework.brigadier.*;
import org.bukkit.plugin.*;

public class PaperCommandManager<C> extends BukkitCommandManager<C>
{
    public PaperCommandManager(final Plugin plugin, final Function<CommandTree<C>, CommandExecutionCoordinator<C>> function, final Function<CommandSender, C> function2, final Function<C, CommandSender> function3) throws Exception {
        super(plugin, function, function2, function3);
        this.paperBrigadierListener = null;
    }
    
    @Override
    public void registerBrigadier() throws BrigadierFailureException {
        this.requireState(RegistrationState.BEFORE_REGISTRATION);
        this.checkBrigadierCompatibility();
        if (!this.hasCapability(CloudBukkitCapabilities.NATIVE_BRIGADIER)) {
            super.registerBrigadier();
        }
        else {
            try {
                "\u5f33".length();
                "\u528b\u57f9".length();
                this.paperBrigadierListener = new PaperBrigadierListener<C>(this);
                Bukkit.getPluginManager().registerEvents((Listener)this.paperBrigadierListener, this.getOwningPlugin());
            }
            catch (Throwable t) {
                "\u587a".length();
                "\u6c6b\u69a6\u57d5\u6149\u65d2".length();
                final BrigadierFailureException ex = new BrigadierFailureException(BrigadierFailureReason.PAPER_BRIGADIER_INITIALIZATION_FAILURE, t);
                "\u5e0c\u66a4\u672c".length();
                "\u5731\u5ca5\u65d4".length();
                "\u55fd\u595e\u7083".length();
                throw ex;
            }
        }
    }
    
    @Override
    public CloudBrigadierManager<C, ?> brigadierManager() {
        if (this.paperBrigadierListener != null) {
            return this.paperBrigadierListener.brigadierManager();
        }
        return super.brigadierManager();
    }
    
    public void registerAsynchronousCompletions() throws IllegalStateException {
        this.requireState(RegistrationState.BEFORE_REGISTRATION);
        if (!this.hasCapability(CloudBukkitCapabilities.ASYNCHRONOUS_COMPLETION)) {
            "\u6c58\u7050\u51d0\u5841".length();
            "\u6506\u547c\u6452\u5754".length();
            final IllegalStateException ex = new IllegalStateException(\u670d\u55bb\u6687\u4eb5\u60f8\u6b2f\u602b\u68fd\u4fc6\u5b9c\u5763\u555a\u6809\u6c9f\u6aa1\u5f3c\u69c1\u5891\u6053\u522b\u68c4\u65ca\u5af1\u4f20\u68d6\u5c05\u5a8b\u6ce2\u5cf0\u5d7f\u66cd\u6d26\u5712\u5579\u625e\u6ce6\u5fd9\u5079\u67ec\u6280\u5b90(836053317, 1329833850, "\u3d55\u3d41\u3d4b\u3d4e\u3d47\u3d46\u3d0b\u3d51\u3d68\u3d05\u3d52\u3d55\u3d50\u3d49\u3d50\u3d41\u3d4a\u3d7f\u3d01\u559c\u65df\u5416\u6145\u6bcc\u727f\u5ad0\u54f9\u502e\u6c67\u6b46\u53d5\u513a\u6bd4\u4dfa\u53cf\u6e21\u6fee\u5dee\u5a7a\u53dd\u51f5\u6712\u6975\u6666\u5e37\u4dec\u606b\u5ba3\u6801\u6c56\u681e\u6671\u50d6\u5897\u5062\u72c7\u6f32\u501f\u5af0\u7379", 1513163599, -639256544));
            "\u68b8\u6068\u6bc1".length();
            throw ex;
        }
        final PluginManager pluginManager = Bukkit.getServer().getPluginManager();
        "\u58b7\u5b72\u59fd\u58a6\u5280".length();
        "\u54a3\u6262\u6e47\u6993".length();
        pluginManager.registerEvents((Listener)new AsyncCommandSuggestionsListener((PaperCommandManager<Object>)this), this.getOwningPlugin());
    }
    
    public static int ColonialObfuscator_\u6bc7\u579a\u6990\u6c35\u64e4\u509d\u6446\u6947\u667e\u7068\u6de3\u50ff\u5375\u59fb\u544a\u6d18\u62b0\u6acb\u6368\u62d1\u65f5\u51c3\u5359\u5b55\u6c82\u5c9b\u59ca\u50dc\u5cb4\u52bf\u5340\u6c2d\u54fe\u502b\u5d23\u60e6\u6275\u6641\u578a\u6ebe\u5668(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
