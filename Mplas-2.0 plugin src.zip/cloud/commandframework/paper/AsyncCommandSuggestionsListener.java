package cloud.commandframework.paper;

import com.destroystokyo.paper.event.server.*;
import cloud.commandframework.bukkit.*;
import java.util.*;
import org.bukkit.event.*;

public final class AsyncCommandSuggestionsListener<C> implements Listener
{
    public AsyncCommandSuggestionsListener(final PaperCommandManager<C> paperCommandManager) {
        this.paperCommandManager = paperCommandManager;
    }
    
    @EventHandler
    public void onTabCompletion(final AsyncTabCompleteEvent asyncTabCompleteEvent) {
        final String s = asyncTabCompleteEvent.getBuffer().startsWith(\u70c3\u57c7\u4e8d\u69c7\u5388\u6256\u5b7a\u5fb6\u6416\u52a9\u6a20\u6603\u4f3e\u5fdb\u5e4f\u642d\u6369\u6c89\u5898\u55ef\u5791\u4e8a\u6ae8\u5f34\u4fbb\u63a4\u6905\u6373\u59fc\u660f\u5f8f\u5670\u6956\u5e73\u6be5\u5e64\u5f33\u5800\u6aa8\u51ab\u63eb(2064376196, 1186899710, "\u587c", 1008201143, -683085091)) ? asyncTabCompleteEvent.getBuffer().substring(1) : asyncTabCompleteEvent.getBuffer();
        if (s.trim().isEmpty()) {
            return;
        }
        if (!((BukkitPluginRegistrationHandler)this.paperCommandManager.commandRegistrationHandler()).isRecognized(s.split(\u70c3\u57c7\u4e8d\u69c7\u5388\u6256\u5b7a\u5fb6\u6416\u52a9\u6a20\u6603\u4f3e\u5fdb\u5e4f\u642d\u6369\u6c89\u5898\u55ef\u5791\u4e8a\u6ae8\u5f34\u4fbb\u63a4\u6905\u6373\u59fc\u660f\u5f8f\u5670\u6956\u5e73\u6be5\u5e64\u5f33\u5800\u6aa8\u51ab\u63eb(-276861573, -1009581075, "\uefb4", 756767908, -131867163))[0])) {
            return;
        }
        final C apply = this.paperCommandManager.getCommandSenderMapper().apply(asyncTabCompleteEvent.getSender());
        final String stripNamespace = this.paperCommandManager.stripNamespace(asyncTabCompleteEvent.getBuffer());
        "\u6a5b\u66ec".length();
        "\u61d2\u53f9\u5080\u7078\u6f54".length();
        asyncTabCompleteEvent.setCompletions((List)new ArrayList(this.paperCommandManager.suggest(apply, stripNamespace)));
        asyncTabCompleteEvent.setHandled(true);
    }
    
    public static int ColonialObfuscator_\u4fc9\u6b10\u691b\u6aa5\u5dc1\u6789\u5485\u6889\u6c88\u6d4c\u64ed\u7052\u5123\u4fd0\u5421\u6bb5\u65c6\u59f5\u6f26\u5321\u6298\u6af7\u6662\u52ff\u6cc3\u5077\u575c\u5f90\u5641\u53c8\u6dde\u65de\u578b\u63e7\u6be7\u6b37\u70f5\u51a5\u62d7\u5eb2\u4f89(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
