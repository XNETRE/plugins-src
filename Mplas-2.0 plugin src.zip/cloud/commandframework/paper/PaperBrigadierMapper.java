package cloud.commandframework.paper;

import cloud.commandframework.bukkit.*;
import cloud.commandframework.bukkit.internal.*;
import org.bukkit.*;
import io.leangen.geantyref.*;
import cloud.commandframework.paper.argument.*;
import cloud.commandframework.arguments.parser.*;

public final class PaperBrigadierMapper<C>
{
    public PaperBrigadierMapper(final BukkitBrigadierMapper<C> bukkitBrigadierMapper) {
        this.registerMappings(bukkitBrigadierMapper);
    }
    
    public void registerMappings(final BukkitBrigadierMapper<C> bukkitBrigadierMapper) {
        final Class<?> class1 = CraftBukkitReflection.findClass(\u4f02\u573d\u6d34\u67a6\u6f34\u70c8\u5476\u5684\u65a3\u5b5a\u5c83\u4ed2\u6168\u5ef2\u6c7f\u66c3\u5af7\u5c11\u4fe9\u56fa\u4f12\u518b\u5c62\u61aa\u712b\u5812\u6458\u70fc\u63ea\u6a10\u5378\u68f3\u4e7b\u5a05\u53b5\u6869\u6e40\u53d7\u671b\u5e19\u4edf(-158351889, -41645146, "\u193d\u190b\u191c\u1955\u1919\u1936\u1921\u192f\u190f\u1938\u1967\u1912\u193b\u1938\u1927\u1930", 17501467, -1222565309));
        if (class1 != null && class1.isAssignableFrom(World.class)) {
            "\u5910".length();
            "\u5f23\u63d1\u6567".length();
            bukkitBrigadierMapper.mapSimpleNMS((TypeToken<ArgumentParser>)new TypeToken<KeyedWorldArgument.Parser<C>>(), \u4f02\u573d\u6d34\u67a6\u6f34\u70c8\u5476\u5684\u65a3\u5b5a\u5c83\u4ed2\u6168\u5ef2\u6c7f\u66c3\u5af7\u5c11\u4fe9\u56fa\u4f12\u518b\u5c62\u61aa\u712b\u5812\u6458\u70fc\u63ea\u6a10\u5378\u68f3\u4e7b\u5a05\u53b5\u6869\u6e40\u53d7\u671b\u5e19\u4edf(-774149543, -1457827997, "\u0add\u0ae1\u0af5\u0ae9\u0af3\u0afc\u0ae4\u0aec\u0af4\u0aed\u0aeb\u0af7\u0af2\u0ae8\u0af6\u0ae6\u0afd", -1104303101, -994212907), true);
        }
    }
    
    public static int ColonialObfuscator_\u56c7\u6be3\u4e37\u5130\u6a2d\u5901\u6458\u50a2\u6058\u55ad\u63c5\u5292\u667a\u5160\u610c\u51f2\u68de\u66ef\u6ddb\u6e9b\u7048\u68f8\u58f5\u4fe3\u5c10\u5f77\u6cb4\u5494\u5bcb\u61df\u6761\u58bd\u5934\u5a75\u64e0\u59e4\u67e6\u56d3\u5a07\u70b4\u6b98(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
