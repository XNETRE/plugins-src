package cloud.commandframework.paper.argument;

import cloud.commandframework.arguments.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.bukkit.internal.*;
import cloud.commandframework.bukkit.parsers.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.exceptions.parsing.*;
import org.bukkit.*;
import java.util.*;

public final class KeyedWorldArgument<C> extends CommandArgument<C, World>
{
    public KeyedWorldArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new Parser<C>(), s2, World.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u5472\u6cb4\u66ae\u61b8\u4eb2\u6f83\u63a8\u6105\u6a41\u613a\u6f0f\u5a2f\u6f51\u567c\u5d57\u5f8a\u6be8\u595a\u5733\u50ee\u5343\u5452\u5be5\u6dd4\u6281\u52f5\u6dd8\u64cc\u4e63\u6f85\u5d2d\u58ae\u6315\u6d08\u4eb7\u5e84\u5221\u54d3\u4e37\u56ea\u7090(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
