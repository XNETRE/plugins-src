package cloud.commandframework.paper;

import java.lang.reflect.*;
import cloud.commandframework.brigadier.*;
import com.destroystokyo.paper.brigadier.*;
import cloud.commandframework.context.*;
import org.bukkit.*;
import cloud.commandframework.bukkit.*;
import cloud.commandframework.bukkit.internal.*;
import java.util.function.*;
import com.destroystokyo.paper.event.brigadier.*;
import org.bukkit.command.*;
import java.util.regex.*;
import com.mojang.brigadier.tree.*;
import com.mojang.brigadier.suggestion.*;
import com.mojang.brigadier.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.*;
import org.bukkit.event.*;
import cloud.commandframework.permission.*;

public class PaperBrigadierListener<C> implements Listener
{
    public PaperBrigadierListener(final PaperCommandManager<C> paperCommandManager) {
        this.paperCommandManager = paperCommandManager;
        final CommandContext<Object> commandContext;
        this.brigadierManager = new CloudBrigadierManager<C, BukkitBrigadierCommandSource>((CommandManager<C>)this.paperCommandManager, () -> {
            // new(cloud.commandframework.context.CommandContext.class)
            "\u65f5\u5e16\u5966\u6163\u6c86".length();
            "\u6eb5".length();
            new CommandContext(this.paperCommandManager.getCommandSenderMapper().apply((CommandSender)Bukkit.getConsoleSender()), (CommandManager<Object>)this.paperCommandManager);
            return commandContext;
        });
        this.brigadierManager.brigadierSenderMapper(bukkitBrigadierCommandSource -> this.paperCommandManager.getCommandSenderMapper().apply(bukkitBrigadierCommandSource.getBukkitSender()));
        new PaperBrigadierMapper(new BukkitBrigadierMapper<C>(this.paperCommandManager, this.brigadierManager));
        this.brigadierManager.backwardsBrigadierSenderMapper(new BukkitBackwardsBrigadierSenderMapper<C, BukkitBrigadierCommandSource>(this.paperCommandManager));
    }
    
    public CloudBrigadierManager<C, BukkitBrigadierCommandSource> brigadierManager() {
        return this.brigadierManager;
    }
    
    @EventHandler
    public void onCommandRegister(final CommandRegisteredEvent<BukkitBrigadierCommandSource> obj) {
        if (!(obj.getCommand() instanceof PluginIdentifiableCommand)) {
            return;
        }
        if (!((PluginIdentifiableCommand)obj.getCommand()).getPlugin().equals(this.paperCommandManager.getOwningPlugin())) {
            return;
        }
        final CommandTree<C> commandTree = this.paperCommandManager.commandTree();
        String commandLabel;
        if (obj.getCommandLabel().contains(\u59af\u6847\u68fa\u56f1\u6a56\u64ea\u5701\u70f3\u5a34\u5e04\u5942\u65f6\u4fd4\u5bc3\u4e7d\u53b9\u6e85\u583d\u5f55\u55d1\u5dc2\u5be8\u5bb8\u51ed\u5208\u64e1\u5a14\u57c6\u59e5\u5495\u6f96\u5bee\u6635\u6daa\u65ab\u6b9a\u58f0\u66c0\u6d46\u5d66\u55ef(-531309776, -1546789430, "\u6b60", -1118378702, 375163089))) {
            commandLabel = obj.getCommandLabel().split(Pattern.quote(\u59af\u6847\u68fa\u56f1\u6a56\u64ea\u5701\u70f3\u5a34\u5e04\u5942\u65f6\u4fd4\u5bc3\u4e7d\u53b9\u6e85\u583d\u5f55\u55d1\u5dc2\u5be8\u5bb8\u51ed\u5208\u64e1\u5a14\u57c6\u59e5\u5495\u6f96\u5bee\u6635\u6daa\u65ab\u6b9a\u58f0\u66c0\u6d46\u5d66\u55ef(153035341, -470630516, "\ueb7b", 514765340, -861551393)))[1];
        }
        else {
            commandLabel = obj.getCommandLabel();
        }
        final CommandTree.Node<CommandArgument<C, ?>> namedNode = commandTree.getNamedNode(commandLabel);
        if (namedNode == null) {
            return;
        }
        obj.setLiteral((LiteralCommandNode)this.brigadierManager.createLiteralCommandNode(namedNode, (com.mojang.brigadier.tree.LiteralCommandNode<BukkitBrigadierCommandSource>)obj.getLiteral(), (com.mojang.brigadier.suggestion.SuggestionProvider<BukkitBrigadierCommandSource>)obj.getBrigadierCommand(), (com.mojang.brigadier.Command<BukkitBrigadierCommandSource>)obj.getBrigadierCommand(), (bukkitBrigadierCommandSource, commandPermission) -> {
            if (commandTree.getNamedNode(commandLabel) == null) {
                return false;
            }
            else {
                return this.paperCommandManager.hasPermission(this.paperCommandManager.getCommandSenderMapper().apply(bukkitBrigadierCommandSource.getBukkitSender()), commandPermission);
            }
        }));
        if (PaperBrigadierListener.SET_RAW != null) {
            try {
                final Method set_RAW = PaperBrigadierListener.SET_RAW;
                final Object[] args = { null };
                "\u6340\u686d\u6134\u6e35\u4f30".length();
                args[0] = true;
                set_RAW.invoke(obj, args);
                "\u5f36\u6b3d\u5dc2\u5819".length();
                "\u502e".length();
                "\u4f56\u52a0\u5d17".length();
                "\u5e27".length();
            }
            catch (ReflectiveOperationException cause) {
                "\u711a\u6dda".length();
                "\u6717\u66cf\u4e4b\u61b5\u5587".length();
                final RuntimeException ex = new RuntimeException(cause);
                "\u62ac\u5b47\u53e1\u5182\u5ac3".length();
                "\u5d02\u6a75".length();
                throw ex;
            }
        }
    }
    
    public static int ColonialObfuscator_\u6b40\u4fef\u6384\u68c6\u6014\u5e04\u69dc\u5f8a\u5af5\u60da\u6979\u4fcb\u5b61\u56bd\u5e6d\u5635\u6ab3\u5f76\u6785\u56fb\u6f00\u6cd1\u6bf9\u6911\u6e74\u572c\u6b17\u4ea5\u6cff\u6c32\u6c2b\u6d7f\u6d70\u5577\u50a0\u525f\u6bd0\u505a\u5c90\u4f1a\u5cec(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
