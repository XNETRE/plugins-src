package cloud.commandframework.internal;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class CommandInputTokenizer
{
    public CommandInputTokenizer(final String input) {
        this.stringTokenizerFactory = new StringTokenizerFactory(null);
        this.input = input;
    }
    
    public LinkedList<String> tokenize() {
        final StringTokenizer access$100 = this.stringTokenizerFactory.createStringTokenizer();
        "\u65b1\u5d44\u6396".length();
        "\u6ff1\u5207\u55a1\u6c44".length();
        "\u66cf\u57b2\u5a84\u5fd8".length();
        final LinkedList<String> list = new LinkedList<String>();
        while (access$100.hasMoreElements()) {
            list.add(access$100.nextToken());
            "\u54d4\u54d9\u6d70\u64cc\u702b".length();
            "\u5444\u61af\u55d1\u64cc".length();
            "\u5955\u550f\u661a\u6dea".length();
        }
        if (this.input.endsWith(\u4efb\u6337\u5f7b\u6c8f\u554f\u6444\u6b5d\u5b33\u6f41\u5ad0\u63b3\u5031\u5f4c\u591f\u592d\u629f\u52fe\u65cf\u660c\u6298\u600f\u6ad0\u59e2\u589d\u5d2f\u699d\u5408\u651a\u6592\u4e3b\u5bf8\u624c\u5d79\u4ef8\u5ef1\u5490\u6f50\u697b\u6988\u4ecf\u5ef6(562323438, 1220724949, "\u23cd", -2034693993, -575685630))) {
            list.add(\u4efb\u6337\u5f7b\u6c8f\u554f\u6444\u6b5d\u5b33\u6f41\u5ad0\u63b3\u5031\u5f4c\u591f\u592d\u629f\u52fe\u65cf\u660c\u6298\u600f\u6ad0\u59e2\u589d\u5d2f\u699d\u5408\u651a\u6592\u4e3b\u5bf8\u624c\u5d79\u4ef8\u5ef1\u5490\u6f50\u697b\u6988\u4ecf\u5ef6(-236528923, -1659458504, "", -305814875, 1416761493));
            "\u54d1\u6710\u6e3b\u5cf5".length();
        }
        return list;
    }
    
    public static int ColonialObfuscator_\u58e0\u704c\u61fb\u5976\u5877\u5745\u6208\u55f6\u513d\u66fe\u6bce\u4fa2\u62e8\u6a4f\u561e\u6e5f\u5a2c\u640d\u5f07\u524d\u63f5\u5c4c\u60bb\u611b\u695c\u65ed\u5712\u5b89\u6a33\u6797\u4fc9\u5c61\u6819\u6320\u6791\u5509\u687d\u5bd5\u5392\u61c6\u59f6(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
