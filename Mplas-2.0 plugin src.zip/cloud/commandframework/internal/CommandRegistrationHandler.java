package cloud.commandframework.internal;

import org.apiguardian.api.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.*;

@FunctionalInterface
@API(status = API.Status.STABLE)
public interface CommandRegistrationHandler
{
    boolean registerCommand(final Command<?> p0);
    
    default void unregisterRootCommand(final StaticArgument<?> staticArgument) {
    }
}
