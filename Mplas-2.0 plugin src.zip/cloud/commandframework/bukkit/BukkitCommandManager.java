package cloud.commandframework.bukkit;

import org.bukkit.plugin.*;
import org.bukkit.command.*;
import cloud.commandframework.internal.*;
import cloud.commandframework.execution.*;
import cloud.commandframework.*;
import cloud.commandframework.execution.preprocessor.*;
import io.leangen.geantyref.*;
import org.bukkit.entity.*;
import org.bukkit.enchantments.*;
import org.bukkit.*;
import cloud.commandframework.bukkit.parsers.location.*;
import cloud.commandframework.bukkit.data.*;
import cloud.commandframework.bukkit.arguments.selector.*;
import cloud.commandframework.bukkit.parsers.selector.*;
import cloud.commandframework.bukkit.internal.*;
import cloud.commandframework.bukkit.argument.*;
import cloud.commandframework.bukkit.annotation.specifier.*;
import cloud.commandframework.bukkit.parsers.*;
import org.bukkit.event.*;
import cloud.commandframework.captions.*;
import java.util.function.*;
import cloud.commandframework.tasks.*;
import org.apiguardian.api.*;
import java.util.*;
import cloud.commandframework.brigadier.*;
import java.lang.reflect.*;
import cloud.commandframework.meta.*;
import cloud.commandframework.arguments.parser.*;

public class BukkitCommandManager<C> extends CommandManager<C> implements BrigadierManagerHolder<C>
{
    public BukkitCommandManager(final Plugin owningPlugin, final Function<CommandTree<C>, CommandExecutionCoordinator<C>> function, final Function<CommandSender, C> commandSenderMapper, final Function<C, CommandSender> backwardsCommandSenderMapper) throws Exception {
        super(function, new BukkitPluginRegistrationHandler<Object>());
        this.splitAliases = false;
        ((BukkitPluginRegistrationHandler)this.commandRegistrationHandler()).initialize(this);
        this.owningPlugin = owningPlugin;
        this.commandSenderMapper = commandSenderMapper;
        this.backwardsCommandSenderMapper = backwardsCommandSenderMapper;
        this.taskFactory = new TaskFactory(new BukkitSynchronizer(owningPlugin));
        this.commandSuggestionProcessor(new FilteringCommandSuggestionProcessor<C>((FilteringCommandSuggestionProcessor.Filter<C>)FilteringCommandSuggestionProcessor.Filter.startsWith(true).andTrimBeforeLastSpace()));
        CloudBukkitCapabilities.CAPABLE.forEach(cloudCapability -> this.registerCapability(cloudCapability));
        this.registerCapability(CloudCapability.StandardCapabilities.ROOT_COMMAND_DELETION);
        this.registerCommandPreProcessor(new BukkitCommandPreprocessor<C>(this));
        final Object o;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)World.class), p0 -> {
            // new(cloud.commandframework.bukkit.parsers.WorldArgument.WorldParser.class)
            "\u4f66\u6b74".length();
            "\u5ffe".length();
            "\u5df1\u5b15\u618c\u6774".length();
            "\u7078\u595c\u6fcc\u6b03".length();
            "\u60e5\u6b59\u58f1\u5ae5\u5c20".length();
            new WorldArgument.WorldParser();
            return o;
        });
        final Object o2;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)Material.class), p0 -> {
            // new(cloud.commandframework.bukkit.parsers.MaterialArgument.MaterialParser.class)
            "\u53d8".length();
            "\u70cf\u5955\u545c\u5220".length();
            new MaterialArgument.MaterialParser();
            return o2;
        });
        final Object o3;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)Player.class), p0 -> {
            // new(cloud.commandframework.bukkit.parsers.PlayerArgument.PlayerParser.class)
            "\u6ead\u552c".length();
            "\u6ec4\u5c47".length();
            "\u653e\u4f1a\u50da".length();
            new PlayerArgument.PlayerParser();
            return o3;
        });
        final Object o4;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)OfflinePlayer.class), p0 -> {
            // new(cloud.commandframework.bukkit.parsers.OfflinePlayerArgument.OfflinePlayerParser.class)
            "\u518b".length();
            "\u5282\u4ec0\u6ccf\u62a1\u6862".length();
            new OfflinePlayerArgument.OfflinePlayerParser();
            return o4;
        });
        final Object o5;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)Enchantment.class), p0 -> {
            // new(cloud.commandframework.bukkit.parsers.EnchantmentArgument.EnchantmentParser.class)
            "\u5897\u651f".length();
            "\u6a7b\u645a".length();
            "\u6166\u5011\u5791\u6162\u6299".length();
            new EnchantmentArgument.EnchantmentParser();
            return o5;
        });
        final Object o6;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)Location.class), p0 -> {
            // new(cloud.commandframework.bukkit.parsers.location.LocationArgument.LocationParser.class)
            "\u5c65\u6eb8\u541c\u6170\u4f03".length();
            "\u50e9\u5269\u54c8\u6dcd".length();
            "\u5c4e\u6e64\u6cf9\u4ece\u59c7".length();
            new LocationArgument.LocationParser();
            return o6;
        });
        final Object o7;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)Location2D.class), p0 -> {
            // new(cloud.commandframework.bukkit.parsers.location.Location2DArgument.Location2DParser.class)
            "\u5a18\u5fa9\u5e5d\u6a99\u6799".length();
            "\u6d48\u5235".length();
            new Location2DArgument.Location2DParser();
            return o7;
        });
        final Object o8;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)ProtoItemStack.class), p0 -> {
            // new(cloud.commandframework.bukkit.parsers.ItemStackArgument.Parser.class)
            "\u5e2e\u638a".length();
            "\u6395\u6644\u5f36\u6a0a\u6dc9".length();
            "\u4f4f\u59ff\u6c73".length();
            "\u7126\u604b\u6f91\u704f\u6d49".length();
            new ItemStackArgument.Parser();
            return o8;
        });
        final Object o9;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)SingleEntitySelector.class), p0 -> {
            // new(cloud.commandframework.bukkit.parsers.selector.SingleEntitySelectorArgument.SingleEntitySelectorParser.class)
            "\u5041\u5ed5\u5706".length();
            new SingleEntitySelectorArgument.SingleEntitySelectorParser();
            return o9;
        });
        final Object o10;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)SinglePlayerSelector.class), p0 -> {
            // new(cloud.commandframework.bukkit.parsers.selector.SinglePlayerSelectorArgument.SinglePlayerSelectorParser.class)
            "\u511b\u6bdd\u711f\u5061\u6831".length();
            "\u670b".length();
            new SinglePlayerSelectorArgument.SinglePlayerSelectorParser();
            return o10;
        });
        this.parserRegistry().registerAnnotationMapper(AllowEmptySelection.class, (allowEmptySelection, p1) -> ParserParameters.single(BukkitParserParameters.ALLOW_EMPTY_SELECTOR_RESULT, allowEmptySelection.value()));
        final Object o11;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)MultipleEntitySelector.class), parserParameters -> {
            // new(cloud.commandframework.bukkit.parsers.selector.MultipleEntitySelectorArgument.MultipleEntitySelectorParser.class)
            "\u6ab1\u583e".length();
            "\u6dfc\u54ae\u5804\u6d3c".length();
            new MultipleEntitySelectorArgument.MultipleEntitySelectorParser(parserParameters.get(BukkitParserParameters.ALLOW_EMPTY_SELECTOR_RESULT, true));
            return (ArgumentParser<C, ?>)o11;
        });
        final Object o12;
        this.parserRegistry().registerParserSupplier((TypeToken<Object>)TypeToken.get((Class<T>)MultiplePlayerSelector.class), parserParameters2 -> {
            // new(cloud.commandframework.bukkit.parsers.selector.MultiplePlayerSelectorArgument.MultiplePlayerSelectorParser.class)
            "\u561d\u57a8\u5d9e\u5cd6\u51e3".length();
            "\u5751\u5e6f\u5f65\u5703".length();
            "\u5e90\u6c47".length();
            "\u5690".length();
            "\u5e32\u6b91\u7056".length();
            new MultiplePlayerSelectorArgument.MultiplePlayerSelectorParser(parserParameters2.get(BukkitParserParameters.ALLOW_EMPTY_SELECTOR_RESULT, true));
            return (ArgumentParser<C, ?>)o12;
        });
        if (CraftBukkitReflection.classExists(\u59bd\u6942\u6a4a\u6190\u6e9b\u50ed\u6db6\u6c1b\u5169\u5a9b\u5323\u576b\u60f7\u632b\u60e8\u6547\u51a8\u640a\u6b5a\u5fd9\u6b74\u5edc\u6a0a\u6f94\u58fb\u5d05\u6caa\u6e0b\u69d2\u567b\u4ffe\u4e2e\u52d5\u6427\u6771\u5910\u6605\u6877\u5f63\u54c7\u6cb6(790706142, 1760041205, "\u117a\u1148\u115f\u1112\u115e\u114d\u115a\u1158\u1178\u114b\u1114\u1160\u1148\u1157\u115c\u1140\u1159\u1156\u1178\u785d\u7bf7\u47af\u4425\u4bf0", 600213153, -1460553508))) {
            this.registerParserSupplierFor(NamespacedKeyArgument.class);
            this.parserRegistry().registerAnnotationMapper(RequireExplicitNamespace.class, (p0, p1) -> ParserParameters.single(BukkitParserParameters.REQUIRE_EXPLICIT_NAMESPACE, true));
            this.parserRegistry().registerAnnotationMapper(DefaultNamespace.class, (defaultNamespace, p1) -> ParserParameters.single(BukkitParserParameters.DEFAULT_NAMESPACE, defaultNamespace.value()));
        }
        if (this.hasCapability(CloudBukkitCapabilities.BRIGADIER)) {
            this.registerParserSupplierFor(ItemStackPredicateArgument.class);
            this.registerParserSupplierFor(BlockPredicateArgument.class);
        }
        this.owningPlugin.getServer().getPluginManager().registerEvents((Listener)new CloudBukkitListener((BukkitCommandManager<Object>)this), this.owningPlugin);
        this.captionRegistry(new BukkitCaptionRegistryFactory().create());
    }
    
    public TaskRecipe taskRecipe() {
        return this.taskFactory.recipe();
    }
    
    public Plugin getOwningPlugin() {
        return this.owningPlugin;
    }
    
    @Override
    public BukkitCommandMeta createDefaultCommandMeta() {
        return BukkitCommandMetaBuilder.builder().withDescription(\u59bd\u6942\u6a4a\u6190\u6e9b\u50ed\u6db6\u6c1b\u5169\u5a9b\u5323\u576b\u60f7\u632b\u60e8\u6547\u51a8\u640a\u6b5a\u5fd9\u6b74\u5edc\u6a0a\u6f94\u58fb\u5d05\u6caa\u6e0b\u69d2\u567b\u4ffe\u4e2e\u52d5\u6427\u6771\u5910\u6605\u6877\u5f63\u54c7\u6cb6(-1006075300, 341082255, "", -1456701294, 1259011744)).build();
    }
    
    public final Function<CommandSender, C> getCommandSenderMapper() {
        return this.commandSenderMapper;
    }
    
    @Override
    public final boolean hasPermission(final C c, final String s) {
        return s.isEmpty() || this.backwardsCommandSenderMapper.apply(c).hasPermission(s);
    }
    
    public final boolean getSplitAliases() {
        return this.splitAliases;
    }
    
    public final void setSplitAliases(final boolean splitAliases) {
        this.requireState(RegistrationState.BEFORE_REGISTRATION);
        this.splitAliases = splitAliases;
    }
    
    public final void checkBrigadierCompatibility() throws BrigadierFailureException {
        if (!this.hasCapability(CloudBukkitCapabilities.BRIGADIER)) {
            "\u53d1\u6dc6\u5d62\u6b68".length();
            final BrigadierFailureReason version_TOO_LOW = BrigadierFailureReason.VERSION_TOO_LOW;
            "\u55ee\u5e58\u5847".length();
            "\u5f92\u5e28\u5d42\u5284\u60f5".length();
            final BrigadierFailureException ex = new BrigadierFailureException(version_TOO_LOW, new IllegalArgumentException(\u59bd\u6942\u6a4a\u6190\u6e9b\u50ed\u6db6\u6c1b\u5169\u5a9b\u5323\u576b\u60f7\u632b\u60e8\u6547\u51a8\u640a\u6b5a\u5fd9\u6b74\u5edc\u6a0a\u6f94\u58fb\u5d05\u6caa\u6e0b\u69d2\u567b\u4ffe\u4e2e\u52d5\u6427\u6771\u5910\u6605\u6877\u5f63\u54c7\u6cb6(1727978846, 314537744, "\ue8c8\ue8d5\ue8ce\ue8c2\ue8c2\ue8c1\ue8c7\ue8c7\ue8ec\ue892\ue8d1\ue8c8\ue8c3\ue8c4\ue896\ue8cc\ue8d9\ue8de\ue8a4\u81c0\u827c\ube09\ubdba\ub279\u9802\ubcc4\ub9cd\u8260\u8b3a\u835b\ub0f9\ubea2\u891c\ubdb1\u8dc7\uba77\ubc96\ub446\ub9ed\u85cd\u8373\u8553\u8a6c\u8a68\u8362\ub7dc\ub893\ube7a\u980f\u8696\u8b35\u8a1a\u98e3\u8189\ube76\ub386\u8a52\u809c\ubfc3\u8df1\ua7b4\u8207\u8df3\u843e\ub1a6\ub25d\u8ae5\ub427\ub1c3\ub5c6\ub65b\ub06f\ub21b\ub306\ua6b0\u8ee7\u8b7b\ub339\ub389\ubae5\u8952\ub55f\ub426\u8dd1\ua6c2\ua7ec\u824d\ub5c2\ubca5\u8b01\u993b\u8033\u8776\u9911\ubd0c\ubdcf\u8509\u80fb\ubf09\ub18e\u8921\ub35f\ua6b9\u8a3f\u8acd\u80b2\ubddf\u8ac7\u8dfb\ua704\u8255\u89ad\u8f4b\u8c23\u8036\ub769\u81b3\ubff8\u850a\ubd9f\ue86c\ue80f\ue840\ue84b\ue80b\ue860\ue84f\ue844\ue863\ue849\ue85f\ue85e\ue858\ue85b\ue80e\ue812\ue87c\ue850\ue865\u814e\u82e5\ube95\ubd3e\ub2f5\u98fa\ubc3c\ub928\u8284\u8bc2\u83a8\ub009\ube0a\u8988\ubd2e\u8d47\ubae9\ubc15\ub4d4\ub974\u8501\u83a4\u85cc\u8aba\u8aa4\u83a3\ub70f\ub81a\ubeb2\u98d2\u860d\u8ba1\u8a93\u9825\u811b\ubef7\ub300\u8aaf\u8024\ubf27\u8d09", -29364952, 359968687)));
            "\u6451\u6d60\u5df0\u6d88".length();
            throw ex;
        }
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public final boolean queryCapability(final CloudBukkitCapabilities cloudBukkitCapabilities) {
        return cloudBukkitCapabilities.capable();
    }
    
    public final Set<CloudBukkitCapabilities> queryCapabilities() {
        return CloudBukkitCapabilities.CAPABLE;
    }
    
    public void registerBrigadier() throws BrigadierFailureException {
        this.requireState(RegistrationState.BEFORE_REGISTRATION);
        this.checkBrigadierCompatibility();
        if (!this.hasCapability(CloudBukkitCapabilities.COMMODORE_BRIGADIER)) {
            "\u588f\u64c7".length();
            "\u5817\u6d7e\u5761\u6cfb".length();
            final BrigadierFailureException ex = new BrigadierFailureException(BrigadierFailureReason.VERSION_TOO_HIGH);
            "\u544f\u54ff".length();
            "\u6826\u5883".length();
            throw ex;
        }
        try {
            "\u6b96\u4e62\u5f9f\u5ae1".length();
            final CloudCommodoreManager cloudCommodoreManager = new CloudCommodoreManager((BukkitCommandManager<C>)this);
            cloudCommodoreManager.initialize(this);
            this.commandRegistrationHandler(cloudCommodoreManager);
            this.setSplitAliases(true);
        }
        catch (Throwable t) {
            "\u52a7\u6add\u6f70".length();
            "\u5272".length();
            "\u6909\u5ace\u691e\u53df".length();
            "\u5c82\u6008".length();
            final BrigadierFailureException ex2 = new BrigadierFailureException(BrigadierFailureReason.COMMODORE_NOT_PRESENT, t);
            "\u5e74\u5c41\u5164\u5b7a\u57a4".length();
            "\u4e5b\u5d16\u54dd".length();
            "\u647c".length();
            "\u6b83\u5619\u6295".length();
            throw ex2;
        }
    }
    
    @Override
    public CloudBrigadierManager<C, ?> brigadierManager() {
        if (this.commandRegistrationHandler() instanceof CloudCommodoreManager) {
            return (CloudBrigadierManager<C, ?>)((CloudCommodoreManager)this.commandRegistrationHandler()).brigadierManager();
        }
        return null;
    }
    
    public final String stripNamespace(final String s) {
        String s2;
        if (s.charAt(0) == '/') {
            s2 = s.substring(1);
        }
        else {
            s2 = s;
        }
        final String \u59bd\u6942\u6a4a\u6190\u6e9b\u50ed\u6db6\u6c1b\u5169\u5a9b\u5323\u576b\u60f7\u632b\u60e8\u6547\u51a8\u640a\u6b5a\u5fd9\u6b74\u5edc\u6a0a\u6f94\u58fb\u5d05\u6caa\u6e0b\u69d2\u567b\u4ffe\u4e2e\u52d5\u6427\u6771\u5910\u6605\u6877\u5f63\u54c7\u6cb6 = \u59bd\u6942\u6a4a\u6190\u6e9b\u50ed\u6db6\u6c1b\u5169\u5a9b\u5323\u576b\u60f7\u632b\u60e8\u6547\u51a8\u640a\u6b5a\u5fd9\u6b74\u5edc\u6a0a\u6f94\u58fb\u5d05\u6caa\u6e0b\u69d2\u567b\u4ffe\u4e2e\u52d5\u6427\u6771\u5910\u6605\u6877\u5f63\u54c7\u6cb6(729665011, -481487476, "\u4cb3\u4cca\u4c81", -1596339059, 632117287);
        final Object[] args = { null };
        "\u5c73".length();
        "\u68ac".length();
        "\u5815\u54bb\u5abf\u6138".length();
        "\u5ad5".length();
        "\u6009".length();
        args[0] = this.getOwningPlugin().getName().toLowerCase();
        final String format = String.format(\u59bd\u6942\u6a4a\u6190\u6e9b\u50ed\u6db6\u6c1b\u5169\u5a9b\u5323\u576b\u60f7\u632b\u60e8\u6547\u51a8\u640a\u6b5a\u5fd9\u6b74\u5edc\u6a0a\u6f94\u58fb\u5d05\u6caa\u6e0b\u69d2\u567b\u4ffe\u4e2e\u52d5\u6427\u6771\u5910\u6605\u6877\u5f63\u54c7\u6cb6, args);
        if (s2.startsWith(format)) {
            s2 = s2.substring(format.length());
        }
        return s2;
    }
    
    public final Function<C, CommandSender> getBackwardsCommandSenderMapper() {
        return this.backwardsCommandSenderMapper;
    }
    
    public void registerParserSupplierFor(final Class<?> clazz) {
        try {
            final String \u59bd\u6942\u6a4a\u6190\u6e9b\u50ed\u6db6\u6c1b\u5169\u5a9b\u5323\u576b\u60f7\u632b\u60e8\u6547\u51a8\u640a\u6b5a\u5fd9\u6b74\u5edc\u6a0a\u6f94\u58fb\u5d05\u6caa\u6e0b\u69d2\u567b\u4ffe\u4e2e\u52d5\u6427\u6771\u5910\u6605\u6877\u5f63\u54c7\u6cb6 = \u59bd\u6942\u6a4a\u6190\u6e9b\u50ed\u6db6\u6c1b\u5169\u5a9b\u5323\u576b\u60f7\u632b\u60e8\u6547\u51a8\u640a\u6b5a\u5fd9\u6b74\u5edc\u6a0a\u6f94\u58fb\u5d05\u6caa\u6e0b\u69d2\u567b\u4ffe\u4e2e\u52d5\u6427\u6771\u5910\u6605\u6877\u5f63\u54c7\u6cb6(1063024938, 599737471, "\u12e6\u12dc\u12de\u12d2\u12ce\u12cf\u12d5\u12ce\u12d0\u12cd\u12d9\u12ca\u12dd\u12db\u12fb\u12c9\u12d8\u12c4\u12f6\u7bd6\u7877\u4415", 70894856, -2029983094);
            final Class[] parameterTypes = { null };
            "\u64e0".length();
            parameterTypes[0] = BukkitCommandManager.class;
            final Method declaredMethod = clazz.getDeclaredMethod(\u59bd\u6942\u6a4a\u6190\u6e9b\u50ed\u6db6\u6c1b\u5169\u5a9b\u5323\u576b\u60f7\u632b\u60e8\u6547\u51a8\u640a\u6b5a\u5fd9\u6b74\u5edc\u6a0a\u6f94\u58fb\u5d05\u6caa\u6e0b\u69d2\u567b\u4ffe\u4e2e\u52d5\u6427\u6771\u5910\u6605\u6877\u5f63\u54c7\u6cb6, (Class[])parameterTypes);
            declaredMethod.setAccessible(true);
            final Method method = declaredMethod;
            final Object obj = null;
            final Object[] args = { null };
            "\u673e\u587f\u6e36".length();
            "\u6571".length();
            "\u5def\u5048\u6dbd\u6347".length();
            args[0] = this;
            method.invoke(obj, args);
            "\u5a55\u6141\u6a83".length();
            "\u6afa\u4e7b\u52fd\u6a49\u5b29".length();
            "\u6b9c\u68a2".length();
            "\u6167\u5b4c".length();
        }
        catch (ReflectiveOperationException cause) {
            "\u6705\u5226\u622a\u5458\u6953".length();
            "\u5521\u6cb7\u50e9\u50f8\u70f3".length();
            final RuntimeException ex = new RuntimeException(cause);
            "\u6eb4".length();
            "\u6760\u517c\u62e7\u5511\u7107".length();
            "\u6fb1".length();
            throw ex;
        }
    }
    
    public final void lockIfBrigadierCapable() {
        if (this.hasCapability(CloudBukkitCapabilities.BRIGADIER)) {
            this.lockRegistration();
        }
    }
    
    public static int ColonialObfuscator_\u6f10\u510d\u5251\u5ff7\u6f0f\u5113\u65d3\u702c\u5756\u5d19\u63bd\u64c2\u6dec\u60ad\u57b8\u686b\u5d05\u4e28\u579b\u5288\u6fb0\u56c7\u6e00\u5db8\u53a7\u6bae\u7020\u5e02\u6344\u62f9\u5059\u61b4\u6ee6\u68dd\u6973\u6618\u609f\u6cc0\u632b\u5cdd\u7059(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
