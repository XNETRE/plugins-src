package cloud.commandframework.bukkit;

import org.bukkit.entity.*;
import org.bukkit.command.*;

@Deprecated
public final class BukkitPlayerSender extends BukkitCommandSender
{
    public BukkitPlayerSender(final Player player) {
        super((CommandSender)player);
    }
    
    @Override
    public boolean isPlayer() {
        return true;
    }
    
    @Override
    public Player asPlayer() {
        return (Player)this.getInternalSender();
    }
    
    public static int ColonialObfuscator_\u6c6a\u64c9\u57ac\u5957\u530a\u5147\u5121\u69c1\u4f38\u67a1\u617f\u6bc3\u55c0\u70e2\u6d10\u5059\u6f5f\u64fb\u5915\u5bcd\u6a31\u6718\u6929\u6595\u61d5\u6e49\u6fbd\u5e18\u6081\u6812\u70fc\u5cbb\u6171\u574d\u4edd\u6c32\u5a79\u6ad4\u640f\u5a3e\u6c14(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
