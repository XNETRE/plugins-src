package cloud.commandframework.bukkit;

import org.bukkit.command.*;
import java.util.*;
import io.leangen.geantyref.*;
import cloud.commandframework.keys.*;

public final class BukkitCommandContextKeys
{
    public static int ColonialObfuscator_\u5c08\u6c53\u64d5\u5fc3\u5004\u51e8\u6344\u55b0\u5349\u5e3d\u617c\u60c5\u557f\u6388\u57d9\u554a\u5437\u58df\u6e11\u4e65\u58e8\u643d\u65f3\u6a49\u5c82\u6721\u582b\u6fe2\u6e52\u6387\u605f\u6dd8\u51ac\u707f\u5d05\u629b\u5995\u5ced\u59be\u5a0d\u566b(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
