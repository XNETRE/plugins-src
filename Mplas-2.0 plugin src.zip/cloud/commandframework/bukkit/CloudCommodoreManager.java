package cloud.commandframework.bukkit;

import cloud.commandframework.brigadier.*;
import me.lucko.commodore.*;
import cloud.commandframework.context.*;
import org.bukkit.*;
import org.bukkit.command.*;
import cloud.commandframework.bukkit.internal.*;
import java.util.function.*;
import cloud.commandframework.*;
import com.mojang.brigadier.tree.*;
import com.mojang.brigadier.*;
import java.lang.reflect.*;
import java.util.*;
import com.mojang.brigadier.exceptions.*;
import cloud.commandframework.permission.*;

public class CloudCommodoreManager<C> extends BukkitPluginRegistrationHandler<C>
{
    public CloudCommodoreManager(final BukkitCommandManager<C> commandManager) throws BukkitCommandManager.BrigadierFailureException {
        if (!CommodoreProvider.isSupported()) {
            throw new BukkitCommandManager.BrigadierFailureException(BukkitCommandManager.BrigadierFailureReason.COMMODORE_NOT_PRESENT);
        }
        this.commandManager = commandManager;
        this.commodore = CommodoreProvider.getCommodore(commandManager.getOwningPlugin());
        final CommandContext<C> commandContext;
        this.brigadierManager = new CloudBrigadierManager<C, Object>(commandManager, () -> {
            // new(cloud.commandframework.context.CommandContext.class)
            "\u6326".length();
            "\u5a10\u53a2\u58d4".length();
            "\u70d5\u6e9f\u6123\u6f1b".length();
            new CommandContext(commandManager.getCommandSenderMapper().apply((CommandSender)Bukkit.getConsoleSender()), commandManager);
            return commandContext;
        });
        this.brigadierManager.brigadierSenderMapper(o -> this.commandManager.getCommandSenderMapper().apply(getBukkitSender(o)));
        new BukkitBrigadierMapper(this.commandManager, this.brigadierManager);
        this.brigadierManager.backwardsBrigadierSenderMapper(new BukkitBackwardsBrigadierSenderMapper<C, Object>(this.commandManager));
    }
    
    @Override
    public void registerExternal(final String s, final Command<?> command, final BukkitCommand<C> bukkitCommand) {
        this.registerWithCommodore(s, (Command<C>)command);
    }
    
    @Override
    public void unregisterExternal(final String s) {
        this.unregisterWithCommodore(s);
    }
    
    public CloudBrigadierManager brigadierManager() {
        return this.brigadierManager;
    }
    
    public void registerWithCommodore(final String o, final Command<C> command) {
        final com.mojang.brigadier.tree.LiteralCommandNode<Object> literalCommandNode = this.brigadierManager.createLiteralCommandNode(o, command, (o2, commandPermission) -> {
            if (this.commandManager.commandTree().getNamedNode(o) == null) {
                return false;
            }
            else {
                return this.commandManager.hasPermission(this.commandManager.getCommandSenderMapper().apply(getBukkitSender(o2)), commandPermission);
            }
        }, false, (com.mojang.brigadier.Command<Object>)(commandContext -> 1));
        final CommandNode node = this.getDispatcher().findNode((Collection)Collections.singletonList(o));
        if (node != null) {
            this.mergeChildren((CommandNode<?>)node, (CommandNode<?>)literalCommandNode);
        }
        else {
            this.commodore.register((LiteralCommandNode)literalCommandNode);
        }
    }
    
    public void unregisterWithCommodore(final String o) {
        final CommandDispatcher<?> dispatcher = this.getDispatcher();
        final CommandNode node = dispatcher.findNode((Collection)Collections.singletonList(o));
        if (node == null) {
            return;
        }
        try {
            final Class<? extends Commodore> class1 = this.commodore.getClass();
            Method method;
            try {
                final Class<? extends Commodore> clazz = class1;
                final String \u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c = \u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c(1531652858, 1287207270, "\u0f3c\u0f04\u0f0e\u0f08\u0f11\u0f06\u0f29\u0f30\u0f13\u0f38\u0f35", -883651303, -77164152);
                final Class[] parameterTypes = new Class[2];
                "\u6132\u5746\u5131\u6d78\u56b2".length();
                "\u6b19\u63e8\u6dd5\u5dd8\u6678".length();
                parameterTypes[0] = RootCommandNode.class;
                "\u690d\u6a06\u560a\u6eab\u5a8f".length();
                "\u6b66\u646d\u55df".length();
                parameterTypes[1] = String.class;
                method = clazz.getDeclaredMethod(\u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c, (Class<?>[])parameterTypes);
            }
            catch (NoSuchMethodException ex2) {
                final Class<? super Commodore> superclass = class1.getSuperclass();
                final String \u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c2 = \u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c(1579609931, 383183517, "\u5180\u51b4\u51be\u51bc\u51a5\u51b6\u5199\u51bc\u519f\u51a8\u51a5", 539580551, -2143023904);
                final Class[] parameterTypes2 = new Class[2];
                "\u54f7\u67a0\u4fd5".length();
                parameterTypes2[0] = RootCommandNode.class;
                "\u67e0\u5f66\u5275".length();
                "\u6770\u6a69\u6867\u4f6b\u6e7a".length();
                "\u6d21\u6ac6".length();
                "\u67ad\u6975\u6e9f\u5a99\u5196".length();
                parameterTypes2[1] = String.class;
                method = superclass.getDeclaredMethod(\u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c2, (Class[])parameterTypes2);
            }
            method.setAccessible(true);
            final Method method2 = method;
            final Object obj = null;
            final Object[] args = new Object[2];
            "\u699c".length();
            "\u6eec\u69bd\u55d8\u6a4f".length();
            "\u4e58".length();
            args[0] = dispatcher.getRoot();
            "\u549a\u592b\u652f\u6a02\u6fb9".length();
            "\u5ef5\u54cb\u6a7a\u646f\u70fd".length();
            args[1] = node.getName();
            method2.invoke(obj, args);
            "\u6698".length();
            "\u712f".length();
            "\u58a0".length();
            "\u6d68".length();
            final Field declaredField = class1.getDeclaredField(\u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c(241285525, -1815359731, "\u0516\u052e\u052e\u051c\u0506\u0505\u051d\u0500\u0535\u051a\u0535\u0508\u0504\u0516\u0503", 806232797, -921153182));
            declaredField.setAccessible(true);
            ((List)declaredField.get(this.commodore)).remove(node);
            "\u6bf5\u5589\u56b6".length();
        }
        catch (Exception cause) {
            "\u6a7b\u5430\u5851\u66ae".length();
            "\u6bd6\u56f4".length();
            final String \u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c3 = \u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c(-1169932607, -612466595, "\u94ee\u94e6\u94ec\u94ed\u94e4\u94e1\u94ac\u94ea\u94d3\u94b2\u94e2\u94ed\u94f6\u94f2\u94f3\u94e7\u94e7\u94fe\u94c3\ufea0\uc761\uc63a\uff64\ufabf\uc810\uca4d\uf7ce\uf4aa\uc0ac\uf351\ufac0\uce2c\uf2d6\uc33b\uf661\ucfcd\ucbc6\uff4e\uc5ea\uc8d9\uf79e\ucb03\uc856\uca2a\uc89d\uc444\ufd99\uf543", -1811634775, -1919381538);
            final Object[] args2 = { null };
            "\u63a8\u6051\u68e1\u664f".length();
            args2[0] = o;
            final RuntimeException ex = new RuntimeException(String.format(\u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c3, args2), cause);
            "\u50da".length();
            "\u5bac\u5b68".length();
            "\u5398\u703e\u6227".length();
            "\u6cb5\u674d\u5873\u6357\u6b67".length();
            throw ex;
        }
    }
    
    public void mergeChildren(final CommandNode<?> commandNode, final CommandNode<?> commandNode2) {
        for (final CommandNode commandNode3 : commandNode2.getChildren()) {
            final CommandNode child = commandNode.getChild(commandNode3.getName());
            if (child == null) {
                commandNode.addChild(commandNode3);
            }
            else {
                this.mergeChildren((CommandNode<?>)child, (CommandNode<?>)commandNode3);
            }
        }
    }
    
    public CommandDispatcher<?> getDispatcher() {
        try {
            final Method declaredMethod = this.commodore.getClass().getDeclaredMethod(\u58a8\u5c9b\u5235\u5f45\u56bf\u6dda\u66fb\u7133\u527a\u6c06\u6a07\u5fd2\u57bd\u64ea\u5a93\u56ed\u66f7\u69aa\u5d51\u5f5f\u5438\u573f\u65c7\u6b00\u6140\u69da\u689e\u70d1\u59a6\u5689\u60d7\u5856\u6f7d\u5407\u5cf5\u5d4c\u4f0b\u59c6\u6bd3\u697c\u542c(-98351439, -1736917735, "\ub66e\ub641\ub654\ub666\ub649\ub655\ub651\ub64c\ub679\ub642\ub64a\ub655\ub647", -1222862254, 1511380912), (Class<?>[])new Class[0]);
            declaredMethod.setAccessible(true);
            return (CommandDispatcher<?>)declaredMethod.invoke(this.commodore, new Object[0]);
        }
        catch (ReflectiveOperationException cause) {
            "\u63c5".length();
            "\u5390\u5e5b\u5316\u55af\u61d4".length();
            "\u68cc\u5794".length();
            "\u6c5f".length();
            "\u5548\u659d\u5fb0".length();
            final RuntimeException ex = new RuntimeException(cause);
            "\u6fd3\u63a6\u68cf".length();
            "\u6da4\u67bf\u5a5b".length();
            "\u67a6\u584f\u5aa2\u5a57\u51c2".length();
            throw ex;
        }
    }
    
    public static int ColonialObfuscator_\u51f3\u6677\u5deb\u5f34\u6d48\u5ef7\u5b0f\u648f\u5d64\u6a49\u7099\u5f09\u68c2\u5d92\u603c\u5331\u6fd2\u5a7c\u6116\u710c\u6e37\u5d41\u597c\u6f34\u5b08\u5350\u6176\u5069\u54d5\u66e9\u5bdc\u6e75\u6cc6\u6f79\u5bb5\u64a4\u5779\u6a11\u530d\u4e46\u51eb(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
