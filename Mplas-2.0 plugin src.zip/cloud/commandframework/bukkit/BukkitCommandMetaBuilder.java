package cloud.commandframework.bukkit;

import cloud.commandframework.meta.*;

@Deprecated
public final class BukkitCommandMetaBuilder
{
    public static int ColonialObfuscator_\u5f91\u5b93\u5365\u596d\u5253\u5972\u60dc\u6927\u6847\u50dc\u4e33\u50d9\u6425\u5f0e\u6eb4\u6c05\u6abd\u4fa4\u566b\u5632\u5aca\u5afa\u5050\u65f4\u608e\u6294\u6003\u4f3d\u5b53\u620f\u5e04\u5144\u6221\u700c\u537c\u5278\u6510\u55f2\u6c8b\u5bd6\u55fc(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
