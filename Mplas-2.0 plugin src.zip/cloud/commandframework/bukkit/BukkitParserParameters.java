package cloud.commandframework.bukkit;

import org.apiguardian.api.*;
import cloud.commandframework.arguments.parser.*;
import io.leangen.geantyref.*;

@API(status = API.Status.STABLE, since = "1.7.0")
public final class BukkitParserParameters
{
    public static int ColonialObfuscator_\u68e1\u7131\u62d0\u58bb\u5012\u56ca\u5fd6\u6465\u5450\u5b52\u598e\u5521\u5a24\u61a6\u5bc9\u6b16\u67d1\u708c\u6e2e\u54ed\u587a\u7016\u5e92\u5c28\u6ce5\u5d69\u5b18\u6de8\u5024\u6d1e\u692e\u69e4\u5372\u63f1\u56f7\u6525\u5f67\u5215\u5f0d\u6485\u6f33(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
