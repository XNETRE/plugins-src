package cloud.commandframework.bukkit;

import cloud.commandframework.captions.*;
import org.apiguardian.api.*;
import java.util.*;

public final class BukkitCaptionKeys
{
    public static int ColonialObfuscator_\u6ac9\u6c5b\u6203\u5397\u5f24\u6c3a\u5d70\u5097\u6830\u70c9\u6609\u68f2\u6a2b\u5280\u51f0\u5bee\u5b4f\u5713\u6543\u7101\u6d1e\u530c\u5f13\u6d86\u5cd1\u4e69\u6601\u64d1\u5edf\u4fb2\u621b\u6fc1\u6387\u6790\u646a\u62dc\u666e\u5685\u6d0d\u629a\u592c(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
