package cloud.commandframework.bukkit.arguments.selector;

import org.bukkit.entity.*;
import java.util.*;

public abstract class EntitySelector
{
    public EntitySelector(final String selector, final List<Entity> entities) {
        this.selector = selector;
        this.entities = entities;
    }
    
    public List<Entity> getEntities() {
        return Collections.unmodifiableList((List<? extends Entity>)this.entities);
    }
    
    public String getSelector() {
        return this.selector;
    }
    
    public boolean hasAny() {
        return !this.entities.isEmpty();
    }
    
    public static int ColonialObfuscator_\u4ed8\u6592\u6bc9\u57dd\u5104\u5f2f\u5f51\u5b37\u54f9\u6dc6\u56db\u65dc\u53a4\u52cb\u5feb\u4ff1\u697d\u6800\u6519\u5c19\u638e\u536d\u4e23\u6dc8\u54fb\u5f97\u4e4d\u4f5a\u5dbb\u6ac8\u61dd\u6b8f\u5228\u6fe5\u6d1e\u50bd\u6191\u61b9\u62d5\u66d9\u63bf(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
