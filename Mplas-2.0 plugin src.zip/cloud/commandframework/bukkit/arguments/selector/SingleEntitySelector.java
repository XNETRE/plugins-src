package cloud.commandframework.bukkit.arguments.selector;

import java.util.*;
import org.bukkit.entity.*;

public final class SingleEntitySelector extends MultipleEntitySelector
{
    public SingleEntitySelector(final String s, final List<Entity> list) {
        super(s, list);
        if (list.size() > 1) {
            throw new IllegalArgumentException(\u5d9e\u6f9f\u59da\u6608\u5f2b\u533b\u6e4f\u6d12\u64a6\u6283\u70c1\u5682\u6858\u6b51\u50ac\u6759\u5624\u7018\u6a40\u658b\u4f72\u5400\u4f5e\u52e3\u54ff\u5208\u52a0\u6bd8\u6d91\u6b34\u54f2\u59d5\u5c1b\u4ff8\u65c4\u5bdd\u703f\u5adc\u5daa\u57ca\u514b(276883016, -625378707, "\u3029\u3028\u3037\u3020\u3065\u3031\u3024\u3023\u300e\u3052\u3046\u3047\u3005\u3019\u3000\u300b\u300c\u3013\u3066\u6e3e\u5aa8\u7ebe\u5763\u5629\u50aa\u59cb\u6cbc\u58a3\u5a33\u620f\u53af\u5e73\u7fc3\u6c81\u408c\u5487\u5412\u52df\u5307\u55a5\u6f7f\u65cd\u5ecd\u5819\u6836\u565f\u6db5\u6bbd\u6600\u570d\u6387\u6a27\u567d\u64ca", -792793193, -705281131));
        }
    }
    
    public Entity getEntity() {
        if (this.getEntities().isEmpty()) {
            return null;
        }
        return this.getEntities().get(0);
    }
    
    public static int ColonialObfuscator_\u6ece\u5573\u6c65\u6063\u5d6c\u6eb7\u4f93\u5526\u5239\u5c32\u4f00\u5678\u5dec\u56ed\u53a7\u612b\u6e19\u5cff\u5312\u55bc\u5fb6\u6df5\u5f84\u60f8\u6d21\u5e94\u6e71\u6837\u66ba\u5ceb\u56c3\u61ed\u510e\u63b7\u68bf\u6617\u63af\u6ef7\u5b40\u6c39\u5fae(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
