package cloud.commandframework.bukkit.arguments.selector;

import java.util.*;
import org.bukkit.entity.*;

public final class SinglePlayerSelector extends MultiplePlayerSelector
{
    public SinglePlayerSelector(final String s, final List<Entity> list) {
        super(s, list);
        if (this.getPlayers().size() > 1) {
            throw new IllegalArgumentException(\u62f9\u6f54\u6f06\u57f6\u6dfe\u64cc\u50db\u54ad\u4efc\u5ecd\u6b81\u5368\u5fc7\u4f6e\u6863\u64b6\u54c4\u6e5c\u587c\u6459\u6fa5\u5048\u70c8\u587a\u568c\u70fa\u51a0\u5fea\u625f\u59aa\u5da1\u557e\u50bc\u61a5\u5332\u6eff\u586c\u5f03\u6fad\u6b3f\u6674(2143857906, 1227262393, "\udb05\udb0c\udb13\udb04\udb41\udb1d\udb08\udb0f\udb22\udb46\udb52\udb53\udb04\udb37\udb39\udb37\udb31\udb3c\udb42\u8078\u8cc5\ub4b8\ubadb\ube5e\ub0a9\ub382\u959e\ub555\ub99c\u801d\ubf20\ubcef\u8998\ub49d\u8c5d\ub082\ub2ae\ub9ce\ub98b\u8f00\ub1d8\uab0f\ub028\u86e5\u851d\ubcce\ub1fd\ubf5e\u8532\ubb2f\ub991\u845f\ub469\ubc20", -545177709, 1624687059));
        }
    }
    
    public Player getPlayer() {
        if (this.getPlayers().isEmpty()) {
            return null;
        }
        return this.getPlayers().get(0);
    }
    
    public static int ColonialObfuscator_\u66ca\u67b8\u564a\u60ee\u54b0\u6229\u5e15\u5857\u4e36\u6f5b\u5f6a\u4ee3\u66b1\u5d77\u5635\u5a86\u5379\u6f76\u6100\u6dc7\u4f36\u68cb\u56ee\u54bf\u6102\u5cb2\u6772\u5962\u52e4\u7050\u58a0\u6754\u5938\u5870\u5bf7\u5e28\u4faa\u69fd\u5e3e\u69e5\u6009(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
