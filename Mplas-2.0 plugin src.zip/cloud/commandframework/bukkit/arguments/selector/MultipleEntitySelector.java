package cloud.commandframework.bukkit.arguments.selector;

import java.util.*;
import org.bukkit.entity.*;

public class MultipleEntitySelector extends EntitySelector
{
    public MultipleEntitySelector(final String s, final List<Entity> list) {
        super(s, list);
    }
    
    public static int ColonialObfuscator_\u6b2d\u6e01\u509b\u62a8\u5c06\u5200\u5e62\u58a0\u5a3e\u6722\u6313\u6cbb\u6d94\u6653\u6a1c\u6439\u5eaf\u5f9d\u67e3\u6d05\u5901\u64d2\u633b\u6433\u688c\u59aa\u5127\u5c77\u5905\u685f\u531b\u6e0d\u6826\u5a60\u678f\u4fdd\u533c\u66bd\u68e3\u5bc1\u5198(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
