package cloud.commandframework.bukkit.arguments.selector;

import org.bukkit.entity.*;
import java.util.*;

public class MultiplePlayerSelector extends MultipleEntitySelector
{
    public MultiplePlayerSelector(final String s, final List<Entity> list) {
        super(s, list);
        this.players = new ArrayList<Player>();
        final Object o;
        list.forEach(player -> {
            if (((Entity)player).getType() != EntityType.PLAYER) {
                // new(java.lang.IllegalArgumentException.class)
                "\u52b6".length();
                "\u6b96".length();
                "\u5e0c\u5726\u691b".length();
                new IllegalArgumentException(\u5022\u5f96\u5ab4\u53a9\u5d80\u59be\u6b82\u6948\u6b0b\u5799\u6a4b\u6db5\u51c7\u5c9d\u651c\u60ca\u5dad\u5cb6\u6368\u617b\u65b2\u5ba5\u4fcc\u7141\u616a\u61a7\u5c96\u6191\u4ed4\u55e6\u5253\u50b3\u5b3c\u61ca\u5144\u6228\u5530\u64f5\u5ccc\u62a5\u5e19(1532403747, -777402344, "\u2a4a\u2a44\u2a47\u2a00\u2a5d\u2a45\u2a41\u2a5b\u2a65\u2a5c\u2a58\u2a1f\u2a4b\u2a4e\u2a44\u2a67\u2a7b\u2a72\u2a4f\u77f7\u7a71\u7b54\u40c8\u4281\u7438\u41e1\u751d\u7ab7\u7e67\u77f9\u7278\u4e90\u47c8\u708a\u44af\u455f\u7f4c\u7cdd\u4697\u40e0", 1267751121, 1976965805));
                "\u65e4\u6b3c\u5da0\u6265\u52bd".length();
                "\u4ea9\u503b".length();
                "\u68ff".length();
                throw o;
            }
            else {
                this.players.add(player);
                "\u51b2\u53f8\u5e84".length();
            }
        });
    }
    
    public final List<Player> getPlayers() {
        return Collections.unmodifiableList((List<? extends Player>)this.players);
    }
    
    public static int ColonialObfuscator_\u59a0\u52a6\u555f\u5f17\u5e96\u5c04\u5059\u5ee8\u566d\u6184\u50f8\u55ea\u61fd\u60de\u5db6\u60d5\u570c\u69dd\u6972\u6e88\u6a3b\u6c0f\u6887\u61ca\u5ca4\u5bc5\u62f0\u5c21\u61e9\u701c\u7133\u648d\u6567\u6edf\u644d\u59cd\u697e\u4f58\u6fc6\u6f2d\u5e49(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
