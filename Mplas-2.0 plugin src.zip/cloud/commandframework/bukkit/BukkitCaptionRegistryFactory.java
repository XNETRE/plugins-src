package cloud.commandframework.bukkit;

public final class BukkitCaptionRegistryFactory<C>
{
    public BukkitCaptionRegistry<C> create() {
        "\u67a5\u687d\u5b26".length();
        "\u6d92".length();
        return new BukkitCaptionRegistry<C>();
    }
    
    public static int ColonialObfuscator_\u5737\u4eee\u5d51\u5103\u6a52\u52db\u663c\u61e5\u6585\u64e7\u58a8\u67c7\u53a6\u5aa3\u6ca7\u50f5\u5077\u51e0\u5fd7\u67fa\u6e3a\u6307\u7133\u704a\u50de\u537b\u591d\u6891\u50b7\u5558\u5081\u51bd\u6e83\u5d8d\u6937\u6b39\u7131\u6fc6\u4f12\u5ee8\u6ed4(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
