package cloud.commandframework.bukkit.parsers;

import cloud.commandframework.arguments.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import org.apiguardian.api.*;
import java.util.*;
import cloud.commandframework.arguments.parser.*;
import org.bukkit.*;
import java.util.function.*;
import java.util.stream.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.bukkit.*;
import cloud.commandframework.captions.*;

public class WorldArgument<C> extends CommandArgument<C, World>
{
    public WorldArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new WorldParser<C>(), s2, World.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u609b\u524a\u6d8e\u5d04\u5e04\u57f9\u64a5\u54e7\u5c66\u6887\u68d2\u4f38\u57b2\u6a5f\u5351\u511b\u6fbf\u6ff0\u6d2b\u691b\u69cc\u7139\u6095\u5f15\u5fc9\u52bd\u69dd\u70e6\u6aea\u6d9c\u512e\u7131\u618e\u600e\u58ee\u5d55\u5e8e\u6f7e\u64af\u6140\u6bf1(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
