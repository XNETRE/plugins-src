package cloud.commandframework.bukkit.parsers;

import cloud.commandframework.arguments.*;
import cloud.commandframework.bukkit.data.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.bukkit.*;
import io.leangen.geantyref.*;
import java.lang.reflect.*;
import com.mojang.brigadier.arguments.*;
import cloud.commandframework.brigadier.argument.*;
import java.util.function.*;
import cloud.commandframework.arguments.parser.*;
import java.util.*;
import org.bukkit.*;
import cloud.commandframework.bukkit.internal.*;
import org.bukkit.block.*;

public final class BlockPredicateArgument<C> extends CommandArgument<C, BlockPredicate>
{
    public BlockPredicateArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new Parser<C>(), s2, BlockPredicate.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u62c0\u5e7d\u57ea\u60d3\u6340\u61e6\u6fb5\u5234\u6a35\u60d9\u5d4e\u5e86\u4fc7\u517c\u6d7d\u65bc\u663f\u5742\u6e02\u60dd\u6b63\u4ed8\u4fb7\u6247\u653e\u4eb0\u515e\u54bd\u5c4f\u53b0\u5a73\u5ef0\u5675\u6f42\u7129\u5392\u4ef9\u51a9\u6bba\u7106\u658d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
