package cloud.commandframework.bukkit.parsers;

import cloud.commandframework.arguments.*;
import org.bukkit.entity.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import org.apiguardian.api.*;
import cloud.commandframework.arguments.parser.*;
import org.bukkit.*;
import org.bukkit.command.*;
import java.util.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.bukkit.*;
import cloud.commandframework.captions.*;

public final class PlayerArgument<C> extends CommandArgument<C, Player>
{
    public PlayerArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new PlayerParser<C>(), s2, Player.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u6d09\u5ad9\u6bf5\u6dda\u5666\u6fc4\u5872\u5cd3\u6895\u51d2\u61a6\u6a06\u6f80\u50bf\u5d49\u64ff\u60c0\u5a74\u5b10\u6db7\u6d4a\u5916\u5535\u5f7a\u4f0c\u6945\u5a8f\u649a\u6b22\u6ab0\u535d\u4f97\u6439\u70e6\u6519\u5335\u5448\u5333\u5986\u6878\u6d39(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
