package cloud.commandframework.bukkit.parsers;

import cloud.commandframework.arguments.*;
import cloud.commandframework.bukkit.data.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.bukkit.*;
import io.leangen.geantyref.*;
import com.mojang.brigadier.arguments.*;
import cloud.commandframework.brigadier.argument.*;
import java.util.function.*;
import cloud.commandframework.arguments.parser.*;
import java.lang.reflect.*;
import com.mojang.brigadier.context.*;
import com.mojang.brigadier.tree.*;
import com.mojang.brigadier.*;
import java.util.*;
import org.bukkit.*;
import cloud.commandframework.bukkit.internal.*;
import org.bukkit.inventory.*;

public final class ItemStackPredicateArgument<C> extends CommandArgument<C, ItemStackPredicate>
{
    public ItemStackPredicateArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new Parser<C>(), s2, ItemStackPredicate.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u50a3\u505d\u56c2\u6c1f\u4e59\u62fe\u6a6f\u667e\u64f9\u6e8f\u6346\u67f5\u5e82\u65f3\u6b74\u61f9\u6fb6\u6916\u5dba\u5c0a\u60be\u5076\u62d0\u62b4\u662d\u5d5a\u5283\u7114\u6bef\u6d6b\u6bb5\u4fd5\u6abf\u639f\u5bd3\u64a4\u61c9\u4fae\u55d7\u709d\u65dc(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
