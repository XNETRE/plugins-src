package cloud.commandframework.bukkit.parsers.selector;

import cloud.commandframework.arguments.*;
import cloud.commandframework.bukkit.arguments.selector.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import org.apiguardian.api.*;
import java.util.*;
import cloud.commandframework.arguments.parser.*;

public final class SingleEntitySelectorArgument<C> extends CommandArgument<C, SingleEntitySelector>
{
    public SingleEntitySelectorArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, (ArgumentParser<C, SingleEntitySelector>)new SingleEntitySelectorParser(), s2, SingleEntitySelector.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u61ce\u5148\u66e8\u5401\u571c\u639f\u707f\u6019\u5452\u5a69\u561b\u6f8e\u68a6\u6d4f\u6659\u5a8e\u5015\u5222\u6604\u6a41\u65df\u6845\u4e28\u70dc\u57e7\u66ed\u679b\u6d02\u54c8\u64ef\u5f0c\u70dc\u6b1b\u63dd\u4ee6\u582f\u6ba3\u6820\u516a\u5352\u5d66(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
