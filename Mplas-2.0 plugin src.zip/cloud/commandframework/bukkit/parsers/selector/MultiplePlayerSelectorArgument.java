package cloud.commandframework.bukkit.parsers.selector;

import cloud.commandframework.arguments.*;
import cloud.commandframework.bukkit.arguments.selector.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import org.apiguardian.api.*;
import org.bukkit.entity.*;
import java.util.*;
import cloud.commandframework.arguments.parser.*;
import org.bukkit.*;
import cloud.commandframework.bukkit.parsers.*;
import com.google.common.collect.*;

public final class MultiplePlayerSelectorArgument<C> extends CommandArgument<C, MultiplePlayerSelector>
{
    public MultiplePlayerSelectorArgument(final boolean b, final boolean b2, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b2, s, (ArgumentParser<C, MultiplePlayerSelector>)new MultiplePlayerSelectorParser(b), s2, MultiplePlayerSelector.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u6fe6\u637b\u5af2\u5a64\u6406\u5b72\u5747\u5ee4\u4fe1\u6f7e\u6df2\u6052\u7099\u6ddc\u658c\u6210\u6850\u658c\u5235\u5f3f\u70d1\u5b71\u5c35\u5bc9\u5bc4\u61bc\u55de\u6909\u5660\u585a\u518e\u7012\u5b47\u57fb\u65ea\u4e87\u5c34\u6fe4\u5ca7\u63e1\u57bc(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
