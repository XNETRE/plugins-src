package cloud.commandframework.bukkit.parsers.selector;

import cloud.commandframework.arguments.*;
import cloud.commandframework.bukkit.arguments.selector.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import org.apiguardian.api.*;
import java.util.*;
import cloud.commandframework.arguments.parser.*;
import org.bukkit.*;
import cloud.commandframework.bukkit.parsers.*;
import com.google.common.collect.*;
import org.bukkit.entity.*;

public final class SinglePlayerSelectorArgument<C> extends CommandArgument<C, SinglePlayerSelector>
{
    public SinglePlayerSelectorArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, (ArgumentParser<C, SinglePlayerSelector>)new SinglePlayerSelectorParser(), s2, SinglePlayerSelector.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u5dc6\u661f\u4ff4\u70fe\u63e2\u69f2\u6732\u710d\u610d\u53a0\u5be9\u6440\u6868\u6381\u69ea\u6555\u69ad\u6d13\u5cf5\u51df\u545d\u6a7a\u5c50\u5548\u5ff9\u64cf\u5eb8\u4f62\u6d9e\u4ea3\u698a\u51d6\u4e3a\u5aa1\u5a12\u5fa8\u6139\u528a\u56dd\u6516\u5596(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
