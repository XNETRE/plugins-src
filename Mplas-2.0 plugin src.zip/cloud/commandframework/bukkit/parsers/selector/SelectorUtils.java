package cloud.commandframework.bukkit.parsers.selector;

import cloud.commandframework.brigadier.argument.*;
import com.mojang.brigadier.arguments.*;
import cloud.commandframework.bukkit.internal.*;
import cloud.commandframework.context.*;
import org.bukkit.entity.*;
import java.util.stream.*;
import io.leangen.geantyref.*;
import com.mojang.brigadier.*;
import cloud.commandframework.arguments.parser.*;
import java.lang.reflect.*;
import org.bukkit.*;
import org.bukkit.command.*;
import cloud.commandframework.bukkit.*;
import java.util.*;
import com.mojang.brigadier.exceptions.*;
import java.util.function.*;
import com.google.common.base.*;

public final class SelectorUtils
{
    public static int ColonialObfuscator_\u64cc\u70b4\u711f\u530a\u6207\u6314\u6abb\u7016\u56e5\u587b\u61dd\u53f6\u5638\u5215\u64c6\u5a4e\u5bd7\u5d04\u55e7\u68b0\u58a3\u64b8\u6e05\u4e42\u571b\u65b2\u57c2\u54d6\u6e20\u570c\u6902\u6e4f\u6ee7\u549b\u6bd8\u6391\u6a65\u5f36\u6b3d\u6b67\u66c6(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
