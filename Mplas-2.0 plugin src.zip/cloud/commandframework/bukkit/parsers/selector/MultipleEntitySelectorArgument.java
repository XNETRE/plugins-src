package cloud.commandframework.bukkit.parsers.selector;

import cloud.commandframework.arguments.*;
import cloud.commandframework.bukkit.arguments.selector.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import org.apiguardian.api.*;
import org.bukkit.entity.*;
import java.util.*;
import cloud.commandframework.arguments.parser.*;

public final class MultipleEntitySelectorArgument<C> extends CommandArgument<C, MultipleEntitySelector>
{
    public MultipleEntitySelectorArgument(final boolean b, final boolean b2, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b2, s, (ArgumentParser<C, MultipleEntitySelector>)new MultipleEntitySelectorParser(b), s2, MultipleEntitySelector.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u6891\u6aad\u5acf\u64e8\u6d3b\u60fa\u652f\u533c\u5aab\u6324\u4f90\u610c\u5bc5\u5956\u6c54\u6a5f\u4f52\u66e7\u57c0\u6e8b\u60ab\u68b5\u51f1\u6447\u55f7\u65b3\u6354\u558f\u5a52\u5465\u5b5e\u5fe9\u65f6\u67b2\u6439\u6d09\u5d7a\u5ce1\u4f31\u6503\u6b4e(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
