package cloud.commandframework.bukkit.parsers.selector;

import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.context.*;
import org.apiguardian.api.*;
import cloud.commandframework.captions.*;
import cloud.commandframework.bukkit.*;

public final class SelectorParseException extends ParserException
{
    public SelectorParseException(final String input, final CommandContext<?> commandContext, final FailureReason reason, final Class<?> clazz) {
        super(clazz, commandContext, reason.getCaption(), new CaptionVariable[] { CaptionVariable.of(\u6b8b\u5cad\u593e\u5542\u6b9b\u61a5\u70cb\u6cdb\u627f\u56a6\u666c\u5af2\u559d\u5504\u5a83\u6881\u6305\u5c2f\u5c3b\u600b\u611a\u6ab9\u703d\u5687\u5b35\u55d0\u5214\u5eb8\u6c51\u6783\u6f2d\u52bf\u60c7\u52be\u6669\u630a\u5a82\u5e36\u5d65\u4ef5\u5bfb(-2127231650, -1909035749, "\ud9f8\ud9d0\ud9cc\ud9cd\ud9cc", -1483715351, -1714029186), input) });
        this.reason = reason;
        this.input = input;
    }
    
    public String getInput() {
        return this.input;
    }
    
    public FailureReason getFailureReason() {
        return this.reason;
    }
    
    public static int ColonialObfuscator_\u60ea\u6dc7\u5af3\u601f\u52dc\u6914\u70ec\u6539\u5c92\u54f9\u6973\u6cbc\u65a3\u531c\u593c\u57b0\u6e10\u5b95\u665a\u6e61\u50fc\u5c45\u55fb\u6f1f\u6b21\u5ba8\u51da\u6c53\u611e\u6d49\u64be\u4e22\u62d0\u6e12\u612e\u61e1\u6c99\u68c1\u613e\u616f\u6b3f(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
