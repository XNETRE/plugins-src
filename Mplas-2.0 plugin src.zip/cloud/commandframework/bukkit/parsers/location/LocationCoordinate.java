package cloud.commandframework.bukkit.parsers.location;

import java.util.*;

public final class LocationCoordinate
{
    public LocationCoordinate(final LocationCoordinateType type, final double coordinate) {
        this.type = type;
        this.coordinate = coordinate;
    }
    
    public LocationCoordinateType getType() {
        return this.type;
    }
    
    public double getCoordinate() {
        return this.coordinate;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final LocationCoordinate locationCoordinate = (LocationCoordinate)o;
        return Double.compare(locationCoordinate.coordinate, this.coordinate) == 0 && this.type == locationCoordinate.type;
    }
    
    @Override
    public int hashCode() {
        final Object[] values = new Object[2];
        "\u593e\u6937\u5397".length();
        values[0] = this.type;
        "\u68f3\u4fb2\u701f\u710a\u5fcd".length();
        "\u6349".length();
        "\u4eed\u6e46\u51c8\u5e3e\u5b42".length();
        values[1] = this.coordinate;
        return Objects.hash(values);
    }
    
    @Override
    public String toString() {
        final String \u5a38\u6d74\u5306\u706d\u5b00\u6695\u5125\u5401\u6bb5\u6827\u6f12\u5e91\u56e4\u640c\u5055\u69fc\u53bd\u5794\u6808\u5127\u6ac1\u6e6a\u59fe\u711a\u5185\u5660\u559b\u6f69\u5e51\u5c93\u56f7\u69bf\u682b\u6678\u5f34\u5792\u70b2\u5906\u5a85\u5ae1\u607f = \u5a38\u6d74\u5306\u706d\u5b00\u6695\u5125\u5401\u6bb5\u6827\u6f12\u5e91\u56e4\u640c\u5055\u69fc\u53bd\u5794\u6808\u5127\u6ac1\u6e6a\u59fe\u711a\u5185\u5660\u559b\u6f69\u5e51\u5c93\u56f7\u69bf\u682b\u6678\u5f34\u5792\u70b2\u5906\u5a85\u5ae1\u607f(-3787239, 1648793021, "\u65bd\u65b5\u65bb\u65b9\u65ac\u65b9\u65b6\u65b9\u65b6\u65b0\u65b5\u65b8\u65a9\u65ab\u65af\u65b6\u65b9\u65b2\u6580\u3eb8\u3f93\u3c09\u3949\u0650\u0d47\u0e3a\u3ef0\u3a0f\u1565\u3943\u0aab\u092b\u0217\u0f92\u01b3\u0de9\u0957\u0126\u0e74\u31bb\u0e38\u3e0e", 2088163459, 1653022357);
        final Object[] args = new Object[2];
        "\u6d8a\u6ce0\u5f64\u702a\u6d0f".length();
        "\u5615\u4fc1".length();
        "\u6d9f\u5e91\u56ea\u6660\u54c0".length();
        args[0] = this.type.name().toLowerCase();
        "\u51b8".length();
        "\u70aa\u69cc".length();
        args[1] = this.coordinate;
        return String.format(\u5a38\u6d74\u5306\u706d\u5b00\u6695\u5125\u5401\u6bb5\u6827\u6f12\u5e91\u56e4\u640c\u5055\u69fc\u53bd\u5794\u6808\u5127\u6ac1\u6e6a\u59fe\u711a\u5185\u5660\u559b\u6f69\u5e51\u5c93\u56f7\u69bf\u682b\u6678\u5f34\u5792\u70b2\u5906\u5a85\u5ae1\u607f, args);
    }
    
    public static int ColonialObfuscator_\u4fc8\u530a\u562f\u6ba0\u6e48\u5986\u6e2e\u5f74\u5ca4\u5ace\u4f67\u52d3\u67a2\u507b\u501a\u58df\u4eab\u67bc\u58d1\u696a\u6cea\u6f13\u6405\u524e\u6cfb\u6675\u68bd\u6825\u6162\u5a9f\u5337\u67ac\u51cd\u4e61\u5fd9\u547a\u6949\u635c\u4f79\u5fbb\u6d0b(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
