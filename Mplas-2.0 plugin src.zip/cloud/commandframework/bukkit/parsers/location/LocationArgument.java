package cloud.commandframework.bukkit.parsers.location;

import cloud.commandframework.arguments.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import io.leangen.geantyref.*;
import cloud.commandframework.arguments.parser.*;
import org.apiguardian.api.*;
import java.util.*;
import java.util.function.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.bukkit.util.*;
import cloud.commandframework.arguments.standard.*;
import java.util.stream.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.captions.*;
import cloud.commandframework.bukkit.*;

public final class LocationArgument<C> extends CommandArgument<C, Location>
{
    public LocationArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription, final Collection<BiFunction<CommandContext<C>, Queue<String>, ArgumentParseResult<Boolean>>> collection) {
        super(b, s, new LocationParser<C>(), s2, TypeToken.get(Location.class), biFunction, argumentDescription, collection);
    }
    
    public static int ColonialObfuscator_\u678c\u5d0a\u596a\u54d5\u58fa\u54e9\u6a79\u61e0\u52d5\u6a3f\u537a\u6876\u5757\u5ef5\u6458\u5528\u6243\u6516\u4e46\u54ea\u64d8\u59aa\u5ef0\u647a\u5501\u5d10\u5102\u5ad1\u7109\u57c5\u6549\u59ec\u54d7\u6c35\u69fb\u5585\u6ed8\u6854\u59d1\u648f\u6103(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
