package cloud.commandframework.bukkit.parsers.location;

public enum LocationCoordinateType
{
    ABSOLUTE, 
    RELATIVE, 
    LOCAL;
    
    public static int ColonialObfuscator_\u5332\u6d1c\u6344\u6c5d\u5186\u55ac\u528f\u6ecc\u5d1e\u568c\u6eb9\u6e1f\u671b\u6cd6\u5785\u6f69\u6e57\u649f\u5334\u6b3b\u6dd8\u5ca0\u5827\u51cc\u61a1\u67e2\u70d1\u5d9d\u6ab4\u6494\u56f1\u6f94\u68d7\u6745\u520a\u63bf\u5df3\u5a34\u7092\u64f5\u6fcf(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
