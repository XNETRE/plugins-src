package cloud.commandframework.bukkit.parsers.location;

import cloud.commandframework.arguments.*;
import cloud.commandframework.*;
import cloud.commandframework.context.*;
import io.leangen.geantyref.*;
import cloud.commandframework.arguments.parser.*;
import org.apiguardian.api.*;
import java.util.*;
import java.util.function.*;
import cloud.commandframework.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.bukkit.util.*;

public final class Location2DArgument<C> extends CommandArgument<C, Location2D>
{
    public Location2DArgument(final boolean b, final String s, final String s2, final ArgumentDescription argumentDescription, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final Collection<BiFunction<CommandContext<C>, Queue<String>, ArgumentParseResult<Boolean>>> collection) {
        super(b, s, new Location2DParser<C>(), s2, TypeToken.get(Location2D.class), biFunction, argumentDescription, collection);
    }
    
    public static int ColonialObfuscator_\u6e59\u6e8d\u674f\u58f5\u5414\u6f76\u50f4\u5d67\u5e12\u6311\u68f1\u65df\u6701\u616c\u5ad0\u5dc9\u6ad2\u68f4\u4f9e\u5ae4\u5011\u6a16\u6a0d\u7011\u6b6c\u5033\u4fca\u50a8\u6280\u68be\u56ad\u59bd\u692f\u5b20\u553b\u5b9b\u6ef9\u5a48\u6279\u58c4\u6cad(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
