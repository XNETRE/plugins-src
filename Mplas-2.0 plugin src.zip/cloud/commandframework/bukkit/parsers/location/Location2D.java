package cloud.commandframework.bukkit.parsers.location;

import org.bukkit.*;

public class Location2D extends Location
{
    public Location2D(final World world, final double n, final double n2) {
        super(world, n, 0.0, n2);
    }
    
    public static int ColonialObfuscator_\u6a07\u59c6\u5c19\u6b96\u5643\u632f\u5139\u51bd\u5d2b\u6e8c\u62d1\u620a\u59a5\u6ca2\u607d\u61b4\u6a96\u6138\u6e6c\u54a6\u60b9\u676e\u5594\u63ba\u6a3b\u5dd9\u605e\u4fec\u57ae\u5986\u5ec7\u70a1\u6667\u696b\u572e\u6176\u6095\u5a67\u6296\u5f83\u5675(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
