package cloud.commandframework.bukkit.parsers.location;

import cloud.commandframework.context.*;
import java.util.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.bukkit.parsers.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.arguments.standard.*;

public final class LocationCoordinateParser<C> implements ArgumentParser<C, LocationCoordinate>
{
    @Override
    public ArgumentParseResult<LocationCoordinate> parse(final CommandContext<C> commandContext, final Queue<String> queue) {
        String s = queue.peek();
        if (s == null) {
            "\u6223\u6d7d\u5833\u6c1f".length();
            "\u5eed\u50ae\u6646".length();
            return ArgumentParseResult.failure(new NoInputProvidedException(PlayerArgument.PlayerParser.class, commandContext));
        }
        LocationCoordinateType locationCoordinateType;
        if (s.startsWith(\u6951\u57af\u6e9c\u6e0e\u5f2d\u56a6\u50ef\u5af2\u524e\u5ee2\u6327\u502a\u685b\u6ed2\u4fa7\u6497\u4f0e\u5cd6\u576d\u53f9\u50f5\u6cdf\u5381\u5da5\u4f86\u6a20\u64b5\u5b6d\u6c97\u63c2\u665d\u6cbc\u7044\u6901\u53e6\u5605\u6bdf\u57a4\u67e7\u61e4\u5822(1394751352, -489375335, "\u372a", 1738088807, -119891791))) {
            locationCoordinateType = LocationCoordinateType.LOCAL;
            s = s.substring(1);
        }
        else if (s.startsWith(\u6951\u57af\u6e9c\u6e0e\u5f2d\u56a6\u50ef\u5af2\u524e\u5ee2\u6327\u502a\u685b\u6ed2\u4fa7\u6497\u4f0e\u5cd6\u576d\u53f9\u50f5\u6cdf\u5381\u5da5\u4f86\u6a20\u64b5\u5b6d\u6c97\u63c2\u665d\u6cbc\u7044\u6901\u53e6\u5605\u6bdf\u57a4\u67e7\u61e4\u5822(-1305737263, 1211864261, "\ucdf3", 1117157405, -2017909049))) {
            locationCoordinateType = LocationCoordinateType.RELATIVE;
            s = s.substring(1);
        }
        else {
            locationCoordinateType = LocationCoordinateType.ABSOLUTE;
        }
        double n;
        try {
            n = (s.isEmpty() ? 0.0 : Double.parseDouble(s));
        }
        catch (Exception ex) {
            "\u62cc\u4f0c\u60dc\u5cda".length();
            "\u50cc\u5995".length();
            final String s2 = s;
            "\u56be\u705e\u65a9".length();
            "\u7071\u689c\u6b5a\u653f\u6da9".length();
            return (ArgumentParseResult<LocationCoordinate>)ArgumentParseResult.failure(new DoubleArgument.DoubleParseException(s2, new DoubleArgument.DoubleParser<Object>(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY), commandContext));
        }
        queue.remove();
        "\u713b".length();
        "\u67fb".length();
        "\u52a5\u5a66".length();
        return ArgumentParseResult.success(LocationCoordinate.of(locationCoordinateType, n));
    }
    
    public static int ColonialObfuscator_\u66ca\u5227\u59f8\u4f72\u6f27\u5074\u69b2\u5fb5\u54ad\u6cc1\u5c90\u55e0\u6da6\u681c\u608b\u51cc\u5804\u697e\u6bd7\u4ed1\u6061\u5ec2\u5894\u5f43\u62bf\u5551\u5419\u5476\u6dca\u5777\u6d3d\u4f49\u63dd\u5b87\u5bdd\u5ccb\u5d7b\u67b4\u6518\u6dbf\u67a4(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
