package cloud.commandframework.bukkit.parsers;

import cloud.commandframework.arguments.*;
import cloud.commandframework.bukkit.data.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import com.mojang.brigadier.arguments.*;
import cloud.commandframework.brigadier.argument.*;
import cloud.commandframework.bukkit.internal.*;
import org.bukkit.*;
import org.bukkit.inventory.*;
import com.mojang.brigadier.exceptions.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.stream.*;

public final class ItemStackArgument<C> extends CommandArgument<C, ProtoItemStack>
{
    public ItemStackArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new Parser<C>(), s2, ProtoItemStack.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u5668\u70ec\u4ef8\u5746\u6dec\u6b8b\u5bc0\u5a49\u4f78\u4f78\u61a7\u6819\u6c0a\u5c93\u67ec\u4fa4\u5891\u6e04\u6dfe\u5732\u593a\u4e7b\u64ec\u52cc\u52b2\u4e22\u5b90\u61c2\u629f\u5948\u63bd\u5d50\u6578\u7096\u6033\u4eab\u5203\u6569\u6a47\u4ffc\u6019(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
