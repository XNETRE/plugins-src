package cloud.commandframework.bukkit.parsers;

import cloud.commandframework.arguments.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import org.apiguardian.api.*;
import cloud.commandframework.arguments.parser.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.command.*;
import java.util.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.bukkit.*;
import cloud.commandframework.captions.*;

public final class OfflinePlayerArgument<C> extends CommandArgument<C, OfflinePlayer>
{
    public OfflinePlayerArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new OfflinePlayerParser<C>(), s2, OfflinePlayer.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u6b18\u5f5c\u6746\u6ba7\u652d\u5db6\u709a\u5f2f\u6f61\u59f0\u632c\u571e\u605f\u6e79\u6e55\u6fcc\u5648\u6b82\u636d\u70c6\u617b\u5061\u6471\u6242\u6ffa\u711f\u5efd\u5b93\u63d3\u5111\u51de\u5709\u5c00\u6e35\u6459\u69d8\u5a23\u5c21\u6549\u5f81\u6dcb(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
