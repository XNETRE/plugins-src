package cloud.commandframework.bukkit.parsers;

import cloud.commandframework.arguments.*;
import org.bukkit.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import org.apiguardian.api.*;
import cloud.commandframework.arguments.parser.*;
import java.util.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.bukkit.*;
import cloud.commandframework.captions.*;

public class MaterialArgument<C> extends CommandArgument<C, Material>
{
    public MaterialArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new MaterialParser<C>(), s2, Material.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u52ba\u5dfc\u6437\u5fa0\u684c\u6a59\u5237\u5593\u695e\u6711\u535b\u5a52\u4f2c\u5e4d\u563d\u54fc\u675c\u600b\u6368\u55a1\u4fe6\u5ae3\u4e58\u52fd\u6d37\u6ba9\u66f4\u69a4\u4f20\u57cc\u66b0\u6ad9\u55a8\u66f7\u6601\u63ca\u6279\u5b5d\u710e\u63a6\u6f67(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
