package cloud.commandframework.bukkit.parsers;

import cloud.commandframework.arguments.*;
import org.bukkit.enchantments.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import org.apiguardian.api.*;
import cloud.commandframework.arguments.parser.*;
import org.bukkit.*;
import java.util.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.bukkit.*;
import cloud.commandframework.captions.*;

public class EnchantmentArgument<C> extends CommandArgument<C, Enchantment>
{
    public EnchantmentArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new EnchantmentParser<C>(), s2, Enchantment.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u5ce8\u618f\u6f2a\u616a\u5b9b\u6352\u56b0\u4fc1\u52cd\u6806\u55ac\u5433\u5758\u58f0\u4e20\u6569\u5fd4\u5ca8\u7024\u65dc\u5581\u632f\u505c\u6247\u664a\u623b\u533f\u5ee3\u5040\u67a2\u5aea\u66e3\u5a70\u5933\u6a78\u6bc6\u5868\u50f2\u6344\u6840\u6863(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
