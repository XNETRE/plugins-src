package cloud.commandframework.bukkit;

import org.bukkit.plugin.*;
import java.util.concurrent.*;
import cloud.commandframework.tasks.*;

public final class BukkitSynchronizer implements TaskSynchronizer
{
    public BukkitSynchronizer(final Plugin plugin) {
        this.plugin = plugin;
    }
    
    @Override
    public <I> CompletableFuture<Void> runSynchronous(final I n, final TaskConsumer<I> taskConsumer) {
        "\u5aaa\u50d0\u6c32\u559c\u5225".length();
        "\u54cc\u5608\u517b".length();
        final CompletableFuture<Void> completableFuture = new CompletableFuture<Void>();
        final CompletableFuture<Object> completableFuture2;
        this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
            taskConsumer.accept(n);
            completableFuture2.complete(null);
            "\u65f4\u7068\u6a6a\u50ce".length();
            return;
        });
        "\u5d60\u68b7".length();
        "\u6cc0".length();
        "\u5f31\u6aa7\u6170\u5ff6".length();
        return completableFuture;
    }
    
    @Override
    public <I, O> CompletableFuture<O> runSynchronous(final I n, final TaskFunction<I, O> taskFunction) {
        "\u53f5\u5682\u5e13\u5bab\u50bc".length();
        "\u6ec4".length();
        "\u6efd\u5d88\u590f\u546b".length();
        final CompletableFuture<O> completableFuture = new CompletableFuture<O>();
        this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
            completableFuture.complete(taskFunction.apply(n));
            "\u6719\u6907\u5ec3\u5c26\u69ed".length();
            "\u5c6e\u5de5\u5c05\u6c11\u6b4f".length();
            "\u51d8".length();
            return;
        });
        "\u5584\u5fce".length();
        "\u5d02".length();
        "\u52f1\u5fde".length();
        return completableFuture;
    }
    
    @Override
    public <I> CompletableFuture<Void> runAsynchronous(final I n, final TaskConsumer<I> taskConsumer) {
        "\u5472\u5e0e\u5145\u5ab1".length();
        "\u5275\u605f".length();
        "\u5cce\u6701\u66d4".length();
        final CompletableFuture<Void> completableFuture = new CompletableFuture<Void>();
        final CompletableFuture<Object> completableFuture2;
        this.plugin.getServer().getScheduler().runTaskAsynchronously(this.plugin, () -> {
            taskConsumer.accept(n);
            completableFuture2.complete(null);
            "\u4e30\u6e8f\u5292\u54bb\u63de".length();
            return;
        });
        "\u6dbc\u6c5d".length();
        "\u6205".length();
        "\u58b3".length();
        "\u5323\u6682\u6ded\u5886\u4e44".length();
        return completableFuture;
    }
    
    @Override
    public <I, O> CompletableFuture<O> runAsynchronous(final I n, final TaskFunction<I, O> taskFunction) {
        "\u6e2f".length();
        "\u6a9d\u550e".length();
        final CompletableFuture<O> completableFuture = new CompletableFuture<O>();
        this.plugin.getServer().getScheduler().runTaskAsynchronously(this.plugin, () -> {
            completableFuture.complete(taskFunction.apply(n));
            "\u64bd\u5af5\u7037\u674a\u503c".length();
            "\u64df\u6f9b\u64cb".length();
            "\u5bdf\u6370\u6521".length();
            "\u55ea\u5d05\u67cc\u6b38".length();
            return;
        });
        "\u5e3e\u62ad\u4f46\u70de".length();
        "\u5422\u6124\u6363".length();
        "\u5e65\u5aee\u647e\u64e8\u60d7".length();
        return completableFuture;
    }
    
    public static int ColonialObfuscator_\u61ef\u58df\u6a95\u5d08\u6a2e\u696e\u6de4\u5a15\u692c\u5023\u6b39\u6759\u5d22\u6cf7\u69f4\u679c\u65b4\u634a\u655e\u57a7\u602d\u6cc6\u51c6\u56aa\u6b7d\u6230\u6555\u5df8\u5844\u6495\u5e71\u62bf\u60c4\u6b9b\u51b7\u6cca\u5bf0\u6537\u5867\u6211\u6223(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
