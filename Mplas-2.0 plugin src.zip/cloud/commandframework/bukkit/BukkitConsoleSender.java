package cloud.commandframework.bukkit;

import org.bukkit.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;

@Deprecated
public final class BukkitConsoleSender extends BukkitCommandSender
{
    public BukkitConsoleSender() {
        super((CommandSender)Bukkit.getConsoleSender());
    }
    
    @Override
    public boolean isPlayer() {
        return false;
    }
    
    @Override
    public Player asPlayer() {
        "\u6c9f\u5de0".length();
        "\u60e2".length();
        "\u6fc0\u61e1\u59ff".length();
        "\u4f31\u52df\u6173".length();
        final UnsupportedOperationException ex = new UnsupportedOperationException(\u5df5\u6a36\u6b13\u6f1a\u6eb1\u5a4b\u689e\u5d07\u684d\u621e\u5f1c\u6626\u608c\u4fc9\u5dc1\u4fc8\u51a2\u664e\u6bcb\u6fd6\u5338\u51bf\u5822\u5162\u5810\u6e6e\u6110\u562a\u6569\u5f29\u6982\u6cf1\u507f\u5ba3\u6bf9\u58f3\u5cbe\u5db8\u61ed\u5d70\u6ee2(-45313348, 1894292718, "\uc351\uc35e\uc36d\uc36f\uc36c\uc371\uc32a\uc365\uc349\uc364\uc377\uc376\uc364\uc373\uc322\uc375\uc361\uc37c\uc353\ua06f\ua528\u9731\u8cf1\u9505\u95ae\u92d4\ub3dd\ub22b\ua76e\u960f\u9ac1\ub305", 377182942, 274372573));
        "\u5ef7".length();
        "\u4eef\u5397\u5854\u5a3d\u6950".length();
        "\u6648\u5741".length();
        "\u5259\u637f".length();
        "\u540c\u69b7\u6f84\u6373".length();
        throw ex;
    }
    
    public static int ColonialObfuscator_\u59aa\u5533\u6334\u58c6\u5a46\u5b5a\u643d\u4f41\u6d51\u5d86\u51fc\u501c\u5ccf\u6123\u5664\u5aa2\u6616\u6b16\u613b\u556d\u55b4\u63a7\u5dc3\u700e\u6533\u56b7\u6d5a\u5e6c\u52de\u534d\u63e7\u5797\u5777\u65cf\u6e75\u5428\u5066\u6f42\u5c4d\u6072\u538c(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
