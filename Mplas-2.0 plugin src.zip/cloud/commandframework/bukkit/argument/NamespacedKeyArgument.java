package cloud.commandframework.bukkit.argument;

import cloud.commandframework.arguments.*;
import org.bukkit.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import io.leangen.geantyref.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.bukkit.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.captions.*;
import java.util.*;

public final class NamespacedKeyArgument<C> extends CommandArgument<C, NamespacedKey>
{
    public NamespacedKeyArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription, final boolean b2, final String s3) {
        super(b, s, new Parser<C>(b2, s3), s2, NamespacedKey.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u5e0f\u6e2a\u5f13\u675f\u4f31\u6587\u6c71\u6b56\u696c\u5af7\u6872\u5a67\u51a8\u5fcd\u587d\u6d85\u624c\u66b3\u51ab\u60a0\u5034\u5199\u5a45\u5b75\u5b1d\u62ca\u599a\u5ec5\u5880\u6647\u56f3\u554e\u6c7e\u69d8\u65c5\u661f\u5401\u713d\u655e\u4e57\u585d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
