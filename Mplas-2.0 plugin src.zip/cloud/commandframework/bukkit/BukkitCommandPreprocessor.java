package cloud.commandframework.bukkit;

import cloud.commandframework.bukkit.internal.*;
import cloud.commandframework.*;
import cloud.commandframework.execution.preprocessor.*;
import org.bukkit.command.*;

public final class BukkitCommandPreprocessor<C> implements CommandPreprocessor<C>
{
    public BukkitCommandPreprocessor(final BukkitCommandManager<C> commandManager) {
        this.commandManager = commandManager;
        if (this.commandManager.hasCapability(CloudBukkitCapabilities.BRIGADIER)) {
            this.mapper = new BukkitBackwardsBrigadierSenderMapper<C, Object>(this.commandManager);
        }
        else {
            this.mapper = null;
        }
    }
    
    @Override
    public void accept(final CommandPreprocessingContext<C> commandPreprocessingContext) {
        if (this.mapper != null && !commandPreprocessingContext.getCommandContext().contains(\u6ca7\u60ce\u6053\u5869\u66c4\u68b8\u6cd1\u5a94\u5557\u517b\u5b94\u642b\u64ef\u5965\u63cb\u6538\u5a6b\u52bf\u6881\u6ec9\u5e7d\u5a30\u5c28\u5d15\u4ef4\u5575\u6755\u582f\u5cd8\u5b40\u6c33\u502a\u5fef\u5193\u69cf\u6500\u59ad\u5c8b\u5a53\u54f7\u57b2(1337346923, 424456380, "\u492b\u493a\u4935\u4934\u4928\u493f\u490f\u493e\u4912\u4925\u492c\u4938\u493c\u4920\u492d\u492e\u4917\u493a\u491b\u255a\u1245\u120e\u2453\u1a51\u2193\u10b3\u28b5\u1791\u2653\u1acb", 2092580104, -560295960))) {
            commandPreprocessingContext.getCommandContext().store(\u6ca7\u60ce\u6053\u5869\u66c4\u68b8\u6cd1\u5a94\u5557\u517b\u5b94\u642b\u64ef\u5965\u63cb\u6538\u5a6b\u52bf\u6881\u6ec9\u5e7d\u5a30\u5c28\u5d15\u4ef4\u5575\u6755\u582f\u5cd8\u5b40\u6c33\u502a\u5fef\u5193\u69cf\u6500\u59ad\u5c8b\u5a53\u54f7\u57b2(735034958, -829871650, "\ue645\ue652\ue65f\ue65c\ue646\ue65f\ue66d\ue65e\ue66c\ue65d\ue656\ue640\ue642\ue660\ue66f\ue66e\ue659\ue672\ue651\u8a12\ubd0b\ubd4e\u8b11\ub511\u8eed\ubfcb\u87cf\ub8e9\u892d\ub5ab", 956605075, 2115621722), this.mapper.apply(commandPreprocessingContext.getCommandContext().getSender()));
        }
        commandPreprocessingContext.getCommandContext().store(BukkitCommandContextKeys.BUKKIT_COMMAND_SENDER, this.commandManager.getBackwardsCommandSenderMapper().apply(commandPreprocessingContext.getCommandContext().getSender()));
        commandPreprocessingContext.getCommandContext().store(BukkitCommandContextKeys.CLOUD_BUKKIT_CAPABILITIES, this.commandManager.queryCapabilities());
    }
    
    public static int ColonialObfuscator_\u552a\u69ee\u5b10\u5b30\u6288\u5d2b\u66fd\u66f4\u62b1\u5ff6\u6bee\u513c\u5f65\u673c\u6a52\u70ff\u623e\u6360\u552b\u56a2\u5338\u5f66\u558b\u6123\u5a32\u5039\u5c90\u622e\u650d\u5d8f\u5a4e\u6ecc\u6e3f\u6961\u6c3c\u58c2\u66b0\u5c64\u64e1\u509a\u61e7(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
