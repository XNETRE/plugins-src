package cloud.commandframework.bukkit;

import cloud.commandframework.meta.*;

@Deprecated
public class BukkitCommandMeta extends SimpleCommandMeta
{
    public BukkitCommandMeta(final SimpleCommandMeta simpleCommandMeta) {
        super(simpleCommandMeta);
    }
    
    public static int ColonialObfuscator_\u6e60\u671e\u6e37\u6fb9\u53ff\u50a9\u5c4c\u66f5\u5d19\u5faa\u5122\u5d71\u4e2b\u60c4\u6c01\u53c0\u6680\u6ffe\u5597\u4f27\u5d28\u535e\u52cb\u68ea\u69f1\u5b34\u6d77\u5770\u56b0\u64cb\u5384\u51f6\u5d06\u5db7\u5406\u65b2\u702a\u5f63\u5ef7\u530d\u6770(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
