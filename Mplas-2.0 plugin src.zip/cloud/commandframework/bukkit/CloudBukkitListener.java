package cloud.commandframework.bukkit;

import org.bukkit.event.player.*;
import org.bukkit.event.*;
import org.bukkit.event.server.*;
import java.util.function.*;
import java.util.*;

public final class CloudBukkitListener<C> implements Listener
{
    public CloudBukkitListener(final BukkitCommandManager<C> bukkitCommandManager) {
        this.bukkitCommandManager = bukkitCommandManager;
    }
    
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerLogin(final PlayerLoginEvent playerLoginEvent) {
        this.bukkitCommandManager.lockIfBrigadierCapable();
    }
    
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPluginDisable(final PluginDisableEvent pluginDisableEvent) {
        if (pluginDisableEvent.getPlugin().equals(this.bukkitCommandManager.getOwningPlugin())) {
            final Collection<String> rootCommands = this.bukkitCommandManager.rootCommands();
            final BukkitCommandManager<C> bukkitCommandManager = this.bukkitCommandManager;
            "\u66d8\u646d\u57f7".length();
            "\u5609\u5dd9\u6de2\u5f4d".length();
            "\u4f82\u5c95\u63a5\u6841".length();
            Objects.requireNonNull(bukkitCommandManager);
            "\u514c\u53cc".length();
            "\u538a\u53e0".length();
            rootCommands.forEach(bukkitCommandManager::deleteRootCommand);
        }
    }
    
    public static int ColonialObfuscator_\u709d\u69b6\u4e69\u6200\u5244\u674f\u5fe4\u6ecd\u5eb6\u6074\u7039\u6a61\u5ade\u64e7\u6907\u5bc3\u60c2\u6a32\u5d8e\u662c\u657f\u5fed\u68b1\u5da0\u5d96\u63b1\u63ca\u549a\u5a9a\u4eca\u4f15\u6119\u5a30\u5b20\u69bf\u5644\u4ec4\u67ee\u6a3c\u69db\u5ef9(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
