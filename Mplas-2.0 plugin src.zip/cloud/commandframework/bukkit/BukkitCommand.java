package cloud.commandframework.bukkit;

import cloud.commandframework.arguments.*;
import cloud.commandframework.meta.*;
import org.bukkit.command.*;
import java.util.concurrent.*;
import org.bukkit.*;
import cloud.commandframework.exceptions.*;
import java.util.logging.*;
import org.bukkit.plugin.*;
import java.util.*;
import cloud.commandframework.permission.*;
import cloud.commandframework.*;
import org.apiguardian.api.*;
import cloud.commandframework.execution.*;

public final class BukkitCommand<C> extends Command implements PluginIdentifiableCommand
{
    public BukkitCommand(final String s, final List<String> list, final cloud.commandframework.Command<C> cloudCommand, final CommandArgument<C, ?> command, final BukkitCommandManager<C> manager) {
        super(s, (String)cloudCommand.getCommandMeta().getOrDefault(CommandMeta.DESCRIPTION, \u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(-566198226, -1656672371, "", -1658302994, -1458331894)), \u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(669491824, 704540023, "", 417649311, 732899664), (List)list);
        this.command = command;
        this.manager = manager;
        this.cloudCommand = cloudCommand;
        if (this.command.getOwningCommand() != null) {
            this.setPermission(this.command.getOwningCommand().getCommandPermission().toString());
        }
        this.disabled = false;
    }
    
    public List<String> tabComplete(final CommandSender commandSender, final String s, final String[] array) throws IllegalArgumentException {
        "\u6d61\u5428".length();
        "\u6d5a\u5320".length();
        final StringBuilder sb = new StringBuilder(this.command.getName());
        for (int length = array.length, i = 0; i < length; i -= 15085, i += 15086) {
            sb.append(\u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(2069503474, -529008949, "\ue544", 1928084683, 973353685)).append(array[i]);
            "\u6106".length();
            "\u6f24".length();
            "\u6ea2".length();
        }
        return this.manager.suggest(this.manager.getCommandSenderMapper().apply(commandSender), sb.toString());
    }
    
    public boolean execute(final CommandSender commandSender, final String s, final String[] array) {
        "\u5dd8".length();
        "\u6172\u52d9\u6b5d\u53d3".length();
        "\u6b91\u5f24\u5439".length();
        final StringBuilder sb = new StringBuilder(this.command.getName());
        for (int length = array.length, i = 0; i < length; i += 22095, i -= 22094) {
            sb.append(\u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(564887156, 28029350, "\u7437", -941269426, -866785848)).append(array[i]);
            "\u7011\u6c9b\u4fe3\u5451".length();
            "\u4e95\u63fb\u5237\u6ef7\u6f92".length();
            "\u59e7\u7035".length();
            "\u5dd6\u5824\u6df7\u6a47\u54ed".length();
        }
        final C c;
        final StringBuilder sb2;
        final InvalidSyntaxException ex;
        final StringBuilder sb3;
        final Throwable t;
        final StringBuilder sb4;
        final Throwable t2;
        final Throwable t3;
        this.manager.executeCommand(this.manager.getCommandSenderMapper().apply(commandSender), sb.toString()).whenComplete((p2, cause) -> {
            if (cause != null) {
                if (cause instanceof CompletionException) {
                    cause = (CommandExecutionException)cause.getCause();
                }
                if (cause instanceof InvalidSyntaxException) {
                    this.manager.handleException(c, InvalidSyntaxException.class, (InvalidSyntaxException)cause, (p2, p3) -> {
                        // new(java.lang.StringBuilder.class)
                        "\u6927".length();
                        "\u707e\u59e9".length();
                        new StringBuilder();
                        commandSender.sendMessage(sb2.append(ChatColor.RED).append(\u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(-286321878, 393626679, "\ufd33\ufd3b\ufd21\ufd32\ufd3f\ufd3e\ufd3a\ufd4c\ufd0d\ufd0f\ufd08\ufd1c\ufd17\ufd0b\ufd02\ufd5c\ufd35\ufd01\ufd3a\ua4a7\ua0ed\u92d6\ua672\ua89c\u9891\u8d0d\ua5b1\ub26c\u9564\u9a6b\u90f4\ua656\u9907\ua4cd\u99bd\u9725\u8de1\u925d\u9581\u9409\uad56\u98c0\u95ea\uafd5\ua2f5\ua6e8\u92a8\u8dbc\u9734\ub33c\ua0fc", 600917273, -422318275)).append(ChatColor.GRAY).append(\u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(-754472403, 720462095, "\ud0bf", -513748956, 1017433045)).append(ex.getCorrectSyntax()).toString());
                    });
                }
                else if (cause instanceof InvalidCommandSenderException) {
                    this.manager.handleException(c, InvalidCommandSenderException.class, (InvalidCommandSenderException)cause, (p2, p3) -> {
                        // new(java.lang.StringBuilder.class)
                        "\u6c04".length();
                        "\u5047\u5aca\u591f\u6d74\u5044".length();
                        "\u4fcf\u5b6d\u6961\u4fc1\u603d".length();
                        new StringBuilder();
                        commandSender.sendMessage(sb3.append(ChatColor.RED).append(t.getMessage()).toString());
                    });
                }
                else if (cause instanceof NoPermissionException) {
                    this.manager.handleException(c, NoPermissionException.class, (NoPermissionException)cause, (p1, p2) -> commandSender.sendMessage(BukkitCommand.MESSAGE_NO_PERMS));
                }
                else if (cause instanceof NoSuchCommandException) {
                    this.manager.handleException(c, NoSuchCommandException.class, (NoSuchCommandException)cause, (p1, p2) -> commandSender.sendMessage(\u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(1749329399, 1174732333, "\u90f8\u90ee\u90eb\u90ec\u90eb\u90f5\u90e7\u90a5\u90ca\u90ea\u90ef\u90fd\u90f0\u90ee\u90e5\u90bb\u9091\u90f9\u90fa\uc972\ucd3e\uff5b\ucba9\uc55a\uf57d\ue0c2\uc868\udfaf\uf8e4\uf7ed\ufd21\ucbd0\uf4c1\uc957\uf46f\ufafc\ue03b\uff96\uf81c", 395483024, 1290427556)));
                }
                else if (cause instanceof ArgumentParseException) {
                    this.manager.handleException(c, ArgumentParseException.class, (ArgumentParseException)cause, (p2, p3) -> {
                        // new(java.lang.StringBuilder.class)
                        "\u6e5e\u69ec".length();
                        new StringBuilder();
                        commandSender.sendMessage(sb4.append(ChatColor.RED).append(\u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(-739691972, 2107362969, "\u8d5a\u8d52\u8d48\u8d5b\u8d56\u8d57\u8d53\u8d15\u8d54\u8d56\u8d51\u8d45\u8d4e\u8d52\u8d5b\u8d35\u8d4e\u8d63\u8d5a\ud4cf\ud088\ue2a2\ud65b\ud8b1\ue891\ufd3b", 1412375121, -445623388)).append(ChatColor.GRAY).append(t2.getCause().getMessage()).toString());
                    });
                }
                else if (cause instanceof CommandExecutionException) {
                    this.manager.handleException(c, CommandExecutionException.class, cause, (p2, p3) -> {
                        commandSender.sendMessage(BukkitCommand.MESSAGE_INTERNAL_ERROR);
                        this.manager.getOwningPlugin().getLogger().log(Level.SEVERE, \u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(2050805902, 10165913, "\u2853\u2843\u2844\u2840\u2857\u2855\u2847\u284d\u286c\u280e\u2840\u284f\u2857\u2840\u2853\u2846\u2843\u2858\u2803\u71c5\u75db\u47f7\u7301\u7dff\u4d9f\u5822\u7087\u6718\u404d\u4f4f\u45ce\u733c\u4c24\u71e9\u4c92", -655885778, -2061165460), t3.getCause());
                    });
                }
                else {
                    commandSender.sendMessage(BukkitCommand.MESSAGE_INTERNAL_ERROR);
                    this.manager.getOwningPlugin().getLogger().log(Level.SEVERE, \u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(-582133365, 2061124214, "\uc9f7\uc9f5\uc9b7\uc9e0\uc9f9\uc9f9\uc9ff\uc9fc\uc9d6\uc9f2\uc9c0\uc9d3\uc992\uc9c6\uc9de\uc9d1\uc9cf\uc9c6\uc9e0\u907c\u9427\ua606\u92bc\u9c15\uac6f\ub9cf\u9123\u86ac\ua1ad\uaebc\ua42f\u92cf\uadc6\u904c\uad74\ua3fb\ub936\ua69c\ua14b\ua0f0\u99b9\uac64\ua12b\u9b0a\u963d\u9237\ua626\ub97f\ua3ab\u87ad\u9464\ua1ad\uaeb5\u86fc\uad5c\u911b\ua12e\u9948", -1917356394, -1376148322), cause);
                }
            }
            return;
        });
        "\u52a6".length();
        "\u6b6f".length();
        "\u5599\u7007\u6c81".length();
        return true;
    }
    
    public String getDescription() {
        return this.cloudCommand.getCommandMeta().getOrDefault(CommandMeta.DESCRIPTION, \u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(1328559088, -1351153226, "", -245812847, -846029253));
    }
    
    public Plugin getPlugin() {
        return this.manager.getOwningPlugin();
    }
    
    public String getUsage() {
        return this.manager.commandSyntaxFormatter().apply(Collections.singletonList((CommandArgument<Object, ?>)Objects.requireNonNull((T)this.namedNode().getValue())), this.namedNode());
    }
    
    public boolean testPermissionSilent(final CommandSender commandSender) {
        final CommandTree.Node<CommandArgument<C, ?>> namedNode = this.namedNode();
        return !this.disabled && namedNode != null && this.manager.hasPermission(this.manager.getCommandSenderMapper().apply(commandSender), namedNode.getNodeMeta().getOrDefault(\u603b\u5f14\u6fda\u5b64\u5f34\u4f4a\u660d\u63f3\u57de\u60e2\u6bb3\u6b6e\u53a5\u6169\u5185\u5603\u5380\u5bcd\u6857\u58b1\u6fff\u5715\u5c61\u5c93\u5877\u527a\u575f\u59cb\u6880\u66b6\u55c5\u513b\u626b\u52f2\u4ff0\u5387\u5af9\u65cf\u6501\u5071\u702e(-1163772358, -209215891, "\u261b\u2623\u2634\u2629\u262b\u2637\u263c\u262a\u2600\u262d", 1293117376, 1037164991), Permission.empty()));
    }
    
    @API(status = API.Status.INTERNAL, since = "1.7.0")
    public void disable() {
        this.disabled = true;
    }
    
    public boolean isRegistered() {
        return !this.disabled;
    }
    
    public CommandTree.Node<CommandArgument<C, ?>> namedNode() {
        return this.manager.commandTree().getNamedNode(this.command.getName());
    }
    
    public static int ColonialObfuscator_\u61f6\u6b8e\u5d75\u6925\u528b\u6d4a\u6ef7\u5514\u530c\u5af7\u6ee7\u5b26\u5a89\u5b20\u68b0\u5839\u6e83\u5e8d\u4e98\u5c16\u596f\u63d7\u60c1\u6d54\u5974\u6ffe\u4fac\u6216\u6101\u6d90\u6962\u5721\u610b\u4f66\u5ac3\u5cc1\u580a\u5888\u613a\u5dd9\u60a1(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
