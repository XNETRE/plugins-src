package cloud.commandframework.bukkit.internal;

import com.google.common.annotations.*;
import java.util.function.*;
import java.util.*;
import java.lang.reflect.*;
import java.util.stream.*;
import org.bukkit.*;

@Beta
public final class CraftBukkitReflection
{
    public static int ColonialObfuscator_\u6d91\u6510\u6410\u6ffe\u68b7\u6414\u63c6\u56f8\u6794\u5b85\u5a94\u6364\u5508\u5038\u6736\u5a3e\u53e3\u6b05\u4eb8\u62f2\u7027\u5226\u59dc\u5099\u5771\u6e54\u6a9e\u66db\u5709\u6ea9\u59ae\u516a\u6295\u548d\u52ec\u553e\u5e3e\u68fe\u6743\u5f02\u5abe(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
