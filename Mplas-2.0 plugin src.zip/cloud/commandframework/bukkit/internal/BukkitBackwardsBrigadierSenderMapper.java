package cloud.commandframework.bukkit.internal;

import java.util.function.*;
import com.google.common.annotations.*;
import java.lang.reflect.*;
import cloud.commandframework.bukkit.*;
import org.bukkit.command.*;

@Beta
public final class BukkitBackwardsBrigadierSenderMapper<C, S> implements Function<C, S>
{
    public BukkitBackwardsBrigadierSenderMapper(final BukkitCommandManager<C> commandManager) {
        this.commandManager = commandManager;
    }
    
    @Override
    public S apply(final C c) {
        try {
            final Method get_LISTENER_METHOD = BukkitBackwardsBrigadierSenderMapper.GET_LISTENER_METHOD;
            final Object obj = null;
            final Object[] args = { null };
            "\u5750\u5d24\u6834".length();
            args[0] = this.commandManager.getBackwardsCommandSenderMapper().apply(c);
            return (S)get_LISTENER_METHOD.invoke(obj, args);
        }
        catch (ReflectiveOperationException cause) {
            "\u5d2d\u6083".length();
            "\u5154\u51a5\u6cc2\u531e\u4e5f".length();
            "\u5bd4\u5dd5\u6a1a\u6eff".length();
            "\u7025\u6dd8\u536a".length();
            final RuntimeException ex = new RuntimeException(cause);
            "\u6617\u572f\u5f67\u5569\u6e1d".length();
            "\u676e\u6b67".length();
            "\u6274".length();
            "\u5fea\u658f".length();
            throw ex;
        }
    }
    
    public static int ColonialObfuscator_\u5364\u5cfc\u5b36\u69a8\u5cab\u4e74\u51fc\u6eb5\u6aea\u6dc9\u5eb7\u6030\u6b84\u6530\u6bf4\u6bf7\u6b52\u5113\u5516\u697e\u5dd9\u4f7c\u5ad2\u650e\u6620\u50ea\u4e27\u532b\u6de8\u5e7b\u5e28\u5297\u65da\u5ee0\u56f1\u6828\u560b\u5344\u534c\u5f9c\u70c8(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
