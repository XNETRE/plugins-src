package cloud.commandframework.bukkit.internal;

import com.google.common.annotations.*;
import org.bukkit.*;
import com.mojang.brigadier.arguments.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.function.*;

@Beta
public final class MinecraftArgumentTypes
{
    public static int ColonialObfuscator_\u7140\u6edc\u5889\u5ef1\u4f4c\u6afb\u5c89\u6f9d\u6751\u5b4c\u6482\u65f9\u6822\u687d\u5a22\u6424\u6dfe\u5c1d\u6540\u59a7\u6277\u5003\u57d1\u7019\u674b\u4f0f\u5c5f\u6aba\u621f\u5f06\u53de\u551a\u5bf6\u62e8\u4e7b\u4fb4\u5c99\u69a2\u59ea\u5144\u7088(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
