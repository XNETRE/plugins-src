package cloud.commandframework.bukkit.internal;

import com.google.common.annotations.*;
import java.lang.reflect.*;
import java.util.*;

@Beta
public final class CommandBuildContextSupplier
{
    public static int ColonialObfuscator_\u5ade\u64eb\u4e88\u5fd5\u7072\u5416\u5c11\u595c\u5316\u6ef0\u527a\u55b4\u60d3\u5936\u53bc\u658d\u5f49\u4e86\u5229\u6c87\u62a7\u6444\u5f56\u6db4\u5eb0\u5ca2\u55bf\u51d4\u528d\u5f13\u557e\u5480\u5521\u6323\u63e7\u5433\u67f0\u4f0e\u6fec\u5a35\u711f(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
