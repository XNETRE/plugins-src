package cloud.commandframework.bukkit.internal;

import com.google.common.annotations.*;
import java.util.*;
import io.leangen.geantyref.*;
import java.lang.reflect.*;

@Beta
public final class RegistryReflection
{
    public static int ColonialObfuscator_\u69c8\u599d\u6c16\u5564\u6ae9\u6b01\u5df2\u6975\u573c\u6035\u64c6\u58e0\u50e9\u711e\u4e4e\u6b6a\u637a\u5e6d\u57ef\u69f7\u5936\u532f\u5589\u6e2d\u68e9\u6cdf\u622d\u5afa\u6419\u6cd1\u6e01\u5a0c\u5b9a\u5695\u555c\u540c\u5b8d\u6e87\u534f\u6ed5\u6224(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
