package cloud.commandframework.bukkit;

import cloud.commandframework.internal.*;
import org.bukkit.*;
import org.bukkit.help.*;
import java.lang.reflect.*;
import cloud.commandframework.arguments.*;
import java.util.function.*;
import java.util.*;
import cloud.commandframework.*;
import org.bukkit.entity.*;
import org.apiguardian.api.*;
import org.bukkit.command.*;

public class BukkitPluginRegistrationHandler<C> implements CommandRegistrationHandler
{
    public BukkitPluginRegistrationHandler() {
        this.registeredCommands = new HashMap<CommandArgument<?, ?>, Command>();
        this.recognizedAliases = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
    }
    
    public final void initialize(final BukkitCommandManager<C> bukkitCommandManager) throws Exception {
        final Method declaredMethod = Bukkit.getServer().getClass().getDeclaredMethod(\u6f06\u6458\u6821\u62d0\u5596\u603d\u5985\u668f\u6941\u5cbb\u58a2\u62c9\u6675\u58bb\u6118\u4f49\u6663\u5070\u6b13\u50be\u4ff3\u587e\u67cf\u644f\u610a\u6248\u6da9\u5ebd\u652b\u5177\u6875\u5c3b\u6a12\u511e\u560e\u601d\u66ce\u6ff3\u617a\u5815\u6a0a(891655403, -1232758447, "\u65b4\u6599\u658a\u65a1\u658d\u658b\u6582\u6584\u65a9\u658d\u65a1\u6591\u6587", 465144653, -688594073), (Class<?>[])new Class[0]);
        declaredMethod.setAccessible(true);
        this.commandMap = (CommandMap)declaredMethod.invoke(Bukkit.getServer(), new Object[0]);
        final Field declaredField = SimpleCommandMap.class.getDeclaredField(\u6f06\u6458\u6821\u62d0\u5596\u603d\u5985\u668f\u6941\u5cbb\u58a2\u62c9\u6675\u58bb\u6118\u4f49\u6663\u5070\u6b13\u50be\u4ff3\u587e\u67cf\u644f\u610a\u6248\u6da9\u5ebd\u652b\u5177\u6875\u5c3b\u6a12\u511e\u560e\u601d\u66ce\u6ff3\u617a\u5815\u6a0a(-719320071, -725816723, "\u4fda\u4ff4\u4ff7\u4fef\u4ff6\u4fc3\u4fe6\u4fea\u4fc8\u4fee\u4fe4\u4ffe\u4fee", 448867915, -611876819));
        declaredField.setAccessible(true);
        this.bukkitCommands = (Map<String, Command>)declaredField.get(this.commandMap);
        this.bukkitCommandManager = bukkitCommandManager;
        Bukkit.getHelpMap().registerHelpTopicFactory((Class)BukkitCommand.class, GenericCommandHelpTopic::new);
    }
    
    @Override
    public final boolean registerCommand(final cloud.commandframework.Command<?> command) {
        final CommandArgument<C, ?> commandArgument = command.getArguments().get(0);
        if (!(this.bukkitCommandManager.commandRegistrationHandler() instanceof CloudCommodoreManager) && this.registeredCommands.containsKey(commandArgument)) {
            return false;
        }
        final String name = commandArgument.getName();
        final String namespacedLabel = this.getNamespacedLabel(name);
        "\u6e44\u580f\u4f6b".length();
        "\u669e".length();
        "\u55d7\u5958".length();
        "\u5431\u6361".length();
        final ArrayList list = new ArrayList<Object>(((StaticArgument<?>)commandArgument).getAlternativeAliases());
        "\u64aa\u6a3d".length();
        "\u6df5\u5a2a\u5d34\u5252".length();
        "\u6917\u55b0\u6a25\u6814\u6094".length();
        "\u609e".length();
        final BukkitCommand bukkitCommand = new BukkitCommand<C>(name, (List<String>)list, (cloud.commandframework.Command<Object>)command, (CommandArgument<Object, ?>)commandArgument, (BukkitCommandManager<Object>)this.bukkitCommandManager);
        if (this.bukkitCommandManager.getSetting(CommandManager.ManagerSettings.OVERRIDE_EXISTING_COMMANDS)) {
            this.bukkitCommands.remove(name);
            "\u6507".length();
            "\u69c3\u5a11\u64cc\u5556".length();
            "\u5cff\u6582\u57b5".length();
            "\u53a2\u6437".length();
            "\u5f9e\u57fb\u526e\u4f60".length();
            final ArrayList<String> list2 = (ArrayList<String>)list;
            final Map<String, Command> bukkitCommands = this.bukkitCommands;
            "\u706d\u5d0d\u6a72".length();
            "\u697e\u661c\u6f35\u6ae8\u5f78".length();
            Objects.requireNonNull(bukkitCommands);
            "\u5c03\u5651".length();
            "\u68ad\u63d7\u6cac".length();
            "\u50f9\u6e93\u5655\u6142\u55b7".length();
            "\u7096\u6587\u6182\u4fea".length();
            list2.forEach(bukkitCommands::remove);
        }
        "\u6a5f".length();
        "\u50aa\u568d\u6ff9\u5c99".length();
        "\u641f\u65f7\u601a\u59a9\u5c50".length();
        "\u5b41\u6b10\u5cbf\u6e3a".length();
        final HashSet<String> set = new HashSet<String>();
        for (final String s2 : list) {
            set.add(this.getNamespacedLabel(s2));
            "\u5c90\u5c55\u5f8a\u504b".length();
            "\u6be4\u5374\u6a36".length();
            "\u555d\u634d\u5e55\u64a6".length();
            if (!this.bukkitCommandOrAliasExists(s2)) {
                set.add(s2);
                "\u4e4c\u5e22\u61f1\u648c".length();
                "\u66ce".length();
            }
        }
        if (!this.bukkitCommandExists(name)) {
            set.add(name);
            "\u53fc".length();
            "\u663f\u516b\u6608\u6586\u591d".length();
            "\u6d59\u6cc3\u5ee5".length();
            "\u5cc8\u5149\u6199\u6656\u6bd4".length();
            "\u5955".length();
        }
        set.add(namespacedLabel);
        "\u588c\u6a20\u640e\u6991".length();
        this.commandMap.register(name, this.bukkitCommandManager.getOwningPlugin().getName().toLowerCase(), (Command)bukkitCommand);
        "\u5d53\u5071\u6cab\u4eed".length();
        this.recognizedAliases.addAll(set);
        "\u6fd0".length();
        "\u55e1\u5ce1\u564a".length();
        "\u4fd9\u67f0\u6696\u6822".length();
        if (this.bukkitCommandManager.getSplitAliases()) {
            set.forEach(s -> this.registerExternal(s, command, (BukkitCommand<C>)bukkitCommand));
        }
        this.registeredCommands.put(commandArgument, bukkitCommand);
        "\u6b6d".length();
        "\u5f84\u6977\u682a".length();
        "\u60df\u5985\u6b81".length();
        return true;
    }
    
    @Override
    public final void unregisterRootCommand(final StaticArgument<?> staticArgument) {
        final Command command = this.registeredCommands.get(staticArgument);
        if (command == null) {
            return;
        }
        ((BukkitCommand)command).disable();
        "\u53b9\u65a1\u5351\u596e\u67ac".length();
        "\u57d8\u7055\u5817".length();
        "\u6052\u5551\u5207\u4ed2\u5af8".length();
        final ArrayList<String> list = (ArrayList<String>)new ArrayList<Object>(staticArgument.getAlternativeAliases());
        "\u590b\u5c2c".length();
        "\u5c6a".length();
        final HashSet<String> set = new HashSet<String>();
        for (final String s : list) {
            set.add(this.getNamespacedLabel(s));
            "\u6daa".length();
            "\u6975\u58b5\u5ee2\u5664".length();
            if (this.bukkitCommandOrAliasExists(s)) {
                set.add(s);
                "\u53a0\u55ee\u5b2d".length();
            }
        }
        if (this.bukkitCommandExists(staticArgument.getName())) {
            set.add(staticArgument.getName());
            "\u7049\u517b".length();
            "\u62a6\u631b\u5dc3\u68dd".length();
        }
        set.add(this.getNamespacedLabel(staticArgument.getName()));
        "\u5932\u5e67\u6a77\u6bef\u6717".length();
        "\u571e".length();
        this.bukkitCommands.remove(staticArgument.getName());
        "\u5ced".length();
        "\u6873\u6167\u629f\u5221\u5d1b".length();
        this.bukkitCommands.remove(this.getNamespacedLabel(staticArgument.getName()));
        "\u4f49\u6a0b\u68a9\u5079\u586a".length();
        "\u6fbd\u5532\u5f0a\u6f46".length();
        "\u6a75\u5ebc\u5220\u507f\u5224".length();
        this.recognizedAliases.removeAll(set);
        "\u5a40\u6ba0\u5789\u70bb\u70d8".length();
        "\u5f41\u56ab\u69d4\u690a".length();
        "\u5816\u62a5".length();
        "\u63b6\u61e9\u63ee".length();
        if (this.bukkitCommandManager.getSplitAliases()) {
            set.forEach(this::unregisterExternal);
        }
        this.registeredCommands.remove(staticArgument);
        "\u57e5\u6fa5\u6e3f".length();
        "\u5f98".length();
        "\u63ef\u5b72\u4fd9\u5aab\u52e1".length();
        if (this.bukkitCommandManager.hasCapability(CloudBukkitCapabilities.BRIGADIER)) {
            Bukkit.getOnlinePlayers().forEach(Player::updateCommands);
        }
    }
    
    public String getNamespacedLabel(final String s) {
        final String \u6f06\u6458\u6821\u62d0\u5596\u603d\u5985\u668f\u6941\u5cbb\u58a2\u62c9\u6675\u58bb\u6118\u4f49\u6663\u5070\u6b13\u50be\u4ff3\u587e\u67cf\u644f\u610a\u6248\u6da9\u5ebd\u652b\u5177\u6875\u5c3b\u6a12\u511e\u560e\u601d\u66ce\u6ff3\u617a\u5815\u6a0a = \u6f06\u6458\u6821\u62d0\u5596\u603d\u5985\u668f\u6941\u5cbb\u58a2\u62c9\u6675\u58bb\u6118\u4f49\u6663\u5070\u6b13\u50be\u4ff3\u587e\u67cf\u644f\u610a\u6248\u6da9\u5ebd\u652b\u5177\u6875\u5c3b\u6a12\u511e\u560e\u601d\u66ce\u6ff3\u617a\u5815\u6a0a(744761471, 414703810, "\u3d8b\u3df2\u3db9\u3da2\u3df4", 596990097, 1461235137);
        final Object[] args = new Object[2];
        "\u6f4c\u5631\u7093".length();
        "\u66aa\u59a0\u6999\u5841\u603c".length();
        "\u53ad\u655d\u5bb9\u5b33\u6ea5".length();
        "\u6ecd\u5063".length();
        args[0] = this.bukkitCommandManager.getOwningPlugin().getName();
        "\u52de\u5a76\u6700\u5802".length();
        args[1] = s;
        return String.format(\u6f06\u6458\u6821\u62d0\u5596\u603d\u5985\u668f\u6941\u5cbb\u58a2\u62c9\u6675\u58bb\u6118\u4f49\u6663\u5070\u6b13\u50be\u4ff3\u587e\u67cf\u644f\u610a\u6248\u6da9\u5ebd\u652b\u5177\u6875\u5c3b\u6a12\u511e\u560e\u601d\u66ce\u6ff3\u617a\u5815\u6a0a, args).toLowerCase();
    }
    
    public boolean isRecognized(final String s) {
        return this.recognizedAliases.contains(s);
    }
    
    public void registerExternal(final String s, final cloud.commandframework.Command<?> command, final BukkitCommand<C> bukkitCommand) {
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public void unregisterExternal(final String s) {
    }
    
    public boolean bukkitCommandExists(final String s) {
        final Command command = this.bukkitCommands.get(s);
        if (command == null) {
            return false;
        }
        if (command instanceof PluginIdentifiableCommand) {
            return command.getLabel().equals(s) && !((PluginIdentifiableCommand)command).getPlugin().getName().equalsIgnoreCase(this.bukkitCommandManager.getOwningPlugin().getName());
        }
        return command.getLabel().equals(s);
    }
    
    public boolean bukkitCommandOrAliasExists(final String s) {
        final Command command = this.bukkitCommands.get(s);
        if (command instanceof PluginIdentifiableCommand) {
            return !((PluginIdentifiableCommand)command).getPlugin().getName().equalsIgnoreCase(this.bukkitCommandManager.getOwningPlugin().getName());
        }
        return command != null;
    }
    
    public static int ColonialObfuscator_\u5fc7\u4e58\u5fc8\u62d6\u6061\u63ab\u5883\u6e10\u6da1\u532f\u5510\u57de\u5d9a\u6308\u69de\u592a\u6a68\u55ba\u5eaa\u6e7b\u58a9\u69a7\u5183\u5af0\u6148\u6267\u5f93\u5eac\u5771\u630e\u627e\u552a\u5b69\u64c3\u674a\u6126\u53d9\u6dc6\u6373\u6352\u54f0(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
