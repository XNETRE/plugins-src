package cloud.commandframework.bukkit.annotation.specifier;

import java.lang.annotation.*;
import org.apiguardian.api.*;

@Target({ ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@API(status = API.Status.STABLE, since = "1.8.0")
public @interface AllowEmptySelection {
    boolean value() default true;
}
