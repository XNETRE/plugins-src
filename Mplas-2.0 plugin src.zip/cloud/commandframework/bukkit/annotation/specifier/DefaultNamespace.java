package cloud.commandframework.bukkit.annotation.specifier;

import java.lang.annotation.*;

@Target({ ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
public @interface DefaultNamespace {
    String value();
}
