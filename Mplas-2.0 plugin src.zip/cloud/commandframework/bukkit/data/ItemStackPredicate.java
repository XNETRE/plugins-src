package cloud.commandframework.bukkit.data;

import java.util.function.*;
import org.bukkit.inventory.*;

public interface ItemStackPredicate extends Predicate<ItemStack>
{
}
