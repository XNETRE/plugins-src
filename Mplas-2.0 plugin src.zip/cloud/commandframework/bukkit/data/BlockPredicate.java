package cloud.commandframework.bukkit.data;

import java.util.function.*;
import org.bukkit.block.*;

public interface BlockPredicate extends Predicate<Block>
{
    BlockPredicate loadChunks();
}
