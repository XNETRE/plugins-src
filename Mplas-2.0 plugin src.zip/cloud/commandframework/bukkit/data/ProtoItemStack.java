package cloud.commandframework.bukkit.data;

import org.bukkit.*;
import org.bukkit.inventory.*;

public interface ProtoItemStack
{
    Material material();
    
    boolean hasExtraData();
    
    ItemStack createItemStack(final int p0, final boolean p1) throws IllegalArgumentException;
}
