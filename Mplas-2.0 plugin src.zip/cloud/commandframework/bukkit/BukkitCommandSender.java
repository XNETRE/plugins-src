package cloud.commandframework.bukkit;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import com.google.common.base.*;

@Deprecated
public abstract class BukkitCommandSender
{
    public BukkitCommandSender(final CommandSender internalSender) {
        this.internalSender = internalSender;
    }
    
    @Override
    public final boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && Objects.equal((Object)this.internalSender, (Object)((BukkitCommandSender)o).internalSender));
    }
    
    @Override
    public final int hashCode() {
        final Object[] array = { null };
        "\u6f99\u6beb".length();
        array[0] = this.internalSender;
        return Objects.hashCode(array);
    }
    
    public CommandSender getInternalSender() {
        return this.internalSender;
    }
    
    public abstract boolean isPlayer();
    
    public abstract Player asPlayer();
    
    public void sendMessage(final String s) {
        this.internalSender.sendMessage(s);
    }
    
    public static int ColonialObfuscator_\u5eda\u6109\u5d24\u56c8\u6704\u6ce7\u6020\u692d\u557f\u55af\u5e71\u59bd\u582f\u5a8e\u544d\u5b5e\u5b3b\u6540\u6496\u54e1\u4f28\u5a2b\u705a\u636d\u5258\u6a00\u665d\u5152\u562c\u5776\u5bfd\u617a\u4e85\u6dbc\u67da\u66bb\u652d\u6bf8\u4f05\u52fb\u62ce(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
