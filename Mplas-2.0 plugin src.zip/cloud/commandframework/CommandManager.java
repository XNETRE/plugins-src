package cloud.commandframework;

import org.apiguardian.api.*;
import cloud.commandframework.annotations.injection.*;
import java.util.concurrent.atomic.*;
import cloud.commandframework.arguments.parser.*;
import io.leangen.geantyref.*;
import cloud.commandframework.services.types.*;
import cloud.commandframework.captions.*;
import cloud.commandframework.context.*;
import java.util.concurrent.*;
import cloud.commandframework.execution.*;
import cloud.commandframework.internal.*;
import cloud.commandframework.permission.*;
import cloud.commandframework.arguments.*;
import java.util.stream.*;
import cloud.commandframework.meta.*;
import cloud.commandframework.arguments.flags.*;
import java.util.function.*;
import cloud.commandframework.execution.preprocessor.*;
import cloud.commandframework.services.*;
import cloud.commandframework.execution.postprocessor.*;
import java.util.*;
import cloud.commandframework.annotations.*;

@API(status = API.Status.STABLE)
public abstract class CommandManager<C>
{
    public CommandManager(final Function<CommandTree<C>, CommandExecutionCoordinator<C>> function, final CommandRegistrationHandler commandRegistrationHandler) {
        this.exceptionHandlers = new HashMap<Class<? extends Exception>, BiConsumer<C, ? extends Exception>>();
        this.managerSettings = EnumSet.of(ManagerSettings.ENFORCE_INTERMEDIARY_PERMISSIONS);
        this.commandContextFactory = new StandardCommandContextFactory<C>();
        this.servicePipeline = ServicePipeline.builder().build();
        this.parserRegistry = new StandardParserRegistry<C>();
        this.commands = new LinkedList<Command<C>>();
        this.parameterInjectorRegistry = new ParameterInjectorRegistry<C>();
        this.capabilities = new HashSet<CloudCapability>();
        this.captionVariableReplacementHandler = new SimpleCaptionVariableReplacementHandler();
        this.commandSyntaxFormatter = new StandardCommandSyntaxFormatter<C>();
        this.commandSuggestionProcessor = new FilteringCommandSuggestionProcessor<C>((FilteringCommandSuggestionProcessor.Filter<C>)FilteringCommandSuggestionProcessor.Filter.startsWith(true));
        this.state = new AtomicReference<RegistrationState>(RegistrationState.BEFORE_REGISTRATION);
        this.commandTree = CommandTree.newTree(this);
        this.commandExecutionCoordinator = function.apply(this.commandTree);
        this.commandRegistrationHandler = commandRegistrationHandler;
        this.commandSuggestionEngine = (CommandSuggestionEngine<C>)new DelegatingCommandSuggestionEngineFactory(this).create();
        this.servicePipeline.registerServiceType((TypeToken<? extends Service<Object, Object>>)new TypeToken<CommandPreprocessor<C>>(), (Service<Object, Object>)new AcceptingCommandPreprocessor());
        this.servicePipeline.registerServiceType((TypeToken<? extends Service<Object, Object>>)new TypeToken<CommandPostprocessor<C>>(), (Service<Object, Object>)new AcceptingCommandPostprocessor());
        this.captionRegistry = (CaptionRegistry<C>)new SimpleCaptionRegistryFactory().create();
        this.parameterInjectorRegistry().registerInjector(CommandContext.class, (commandContext, p1) -> commandContext);
    }
    
    public CompletableFuture<CommandResult<C>> executeCommand(final C c, final String s) {
        final CommandContext<C> create = this.commandContextFactory.create(false, c, this);
        "\u4e5c\u69b3\u5ddd\u5e76\u7009".length();
        final LinkedList<String> tokenize = new CommandInputTokenizer(s).tokenize();
        final CommandContext<C> commandContext = create;
        final String \u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc = \u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(178467990, 23660791, "\u1c88\u1ca5\u1cb4\u1ca5\u1cb1\u1c9f\u1ca6\u1cad\u1c93\u1cba\u1cb0\u1c89\u1c8c", -2104047330, 1214114283);
        "\u4edb\u6f62\u593d\u6018\u6134".length();
        "\u4f59\u5aad".length();
        "\u4e3c".length();
        "\u4f99\u5f50\u6781\u5476\u5d59".length();
        "\u62e7\u5d86".length();
        commandContext.store(\u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc, new LinkedList(tokenize));
        try {
            if (this.preprocessContext(create, tokenize) == State.ACCEPTED) {
                return this.commandExecutionCoordinator.coordinateExecution(create, tokenize);
            }
        }
        catch (Exception ex) {
            "\u6794\u6867\u5787\u59b7".length();
            "\u679e\u65de\u5d0c".length();
            "\u6b7d\u6b7b\u5fd6\u60c2\u630a".length();
            final CompletableFuture<CommandResult<C>> completableFuture = new CompletableFuture<CommandResult<C>>();
            completableFuture.completeExceptionally(ex);
            "\u621f\u5dce\u566c".length();
            "\u64ac\u6a7b\u6b3e".length();
            "\u5953\u51ab\u5c4c\u5d76\u62d1".length();
            return completableFuture;
        }
        return CompletableFuture.completedFuture((CommandResult<C>)null);
    }
    
    public List<String> suggest(final C c, final String s) {
        return this.commandSuggestionEngine.getSuggestions(this.commandContextFactory.create(true, c, this), s);
    }
    
    public CommandManager<C> command(final Command<C> command) {
        if (!this.transitionIfPossible(RegistrationState.BEFORE_REGISTRATION, RegistrationState.REGISTERING) && !this.isCommandRegistrationAllowed()) {
            "\u5dbf".length();
            final IllegalStateException ex = new IllegalStateException(\u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(-949187426, 506499628, "\ud9d1\ud9c5\ud9c8\ud9d7\ud9d9\ud9d4\ud998\ud9c6\ud9ff\ud99e\ud9c9\ud9c2\ud9c7\ud9da\ud9c3\ud9d6\ud9dd\ud9d4\ud9aa\u87a1\ub64c\u8509\ub6ee\u89a6\u8e6f\ub16f\u861f\ub476\ub358\u8957\ub4c4\ub9c2\ubb7d\u87de\u8b6d\u8dcc\u81ea\ub03a\ub182\ub5b4\u8c40\ub4bf\u8cd7\ubd2a\u833b\u8a22\u8a5d\u859d\u8952\u8f59\u8231\ubbc5\ubeb0\ubed6\u852f\u8aaf\u8370\ub439\ubf02\uaefd\u8264\u876c\u828f\u8181\u8ea7\u85b2\ub503\ub73a\u8885\ubf62\ubddf\ub49c\uaf4a\ub289\ubb8f\ub584\u87f5\u8243\ub840\u89ea\u91f6\ub557\ub40d\u879b\u8414\u8796\u906a\ub264\uba1f\u8020\ubab9\u8eca\ub7a6\u8e00\ub8ea\ub325\ubb13\u8dd3\u8421\ub23a\ub564\ube49\u81e1\u810d\ubdd0\ub757\ub744\u87b1\ub7ac\ubcf2\u8daf\u8c09\uaf25\ubb39\u8c75\ub1f6\ub766\ube17\u8ce2\u8f3c\ude65\ude50\ude55\ude5f\ude4c\ude5d\ude49\ude45\ude66\ude55\ude03\ude4d\ude51\ude1b\ude5d\ude44\ude51\ude4c\ude6e\u87d3\ub635\u857b\ub6db\u89cb\u8e11\ub116\u8634\ub4bf\ub3c2\u89ca\ub45d\ub944\ubbf0\u8757\u8be9\u8d15\u8172\ub0af\ub15f\ub561\u8cd4\ub428\u8c40\ubda4\u83b1\u8abd\u8a87\u8546\u89d6\u8fd6\u82ed\ubb7a\ube09\ube29\u85d5", -2080695315, 1406131352));
            "\u68fa\u5e28\u683e\u559f\u548d".length();
            "\u5c9b\u5d54\u61af\u5eee".length();
            throw ex;
        }
        this.commandTree.insertCommand(command);
        this.commands.add(command);
        "\u5543\u6b6a\u5fdc\u5606".length();
        return this;
    }
    
    public CommandManager<C> command(final Command.Builder<C> builder) {
        return this.command(builder.manager(this).build());
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public CaptionVariableReplacementHandler captionVariableReplacementHandler() {
        return this.captionVariableReplacementHandler;
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public void captionVariableReplacementHandler(final CaptionVariableReplacementHandler captionVariableReplacementHandler) {
        this.captionVariableReplacementHandler = captionVariableReplacementHandler;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public CommandSyntaxFormatter<C> getCommandSyntaxFormatter() {
        return this.commandSyntaxFormatter();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public CommandSyntaxFormatter<C> commandSyntaxFormatter() {
        return this.commandSyntaxFormatter;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public void setCommandSyntaxFormatter(final CommandSyntaxFormatter<C> commandSyntaxFormatter) {
        this.commandSyntaxFormatter(commandSyntaxFormatter);
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public void commandSyntaxFormatter(final CommandSyntaxFormatter<C> commandSyntaxFormatter) {
        this.commandSyntaxFormatter = commandSyntaxFormatter;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public CommandRegistrationHandler getCommandRegistrationHandler() {
        return this.commandRegistrationHandler();
    }
    
    public CommandRegistrationHandler commandRegistrationHandler() {
        return this.commandRegistrationHandler;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public final void setCommandRegistrationHandler(final CommandRegistrationHandler commandRegistrationHandler) {
        this.commandRegistrationHandler(commandRegistrationHandler);
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public final void commandRegistrationHandler(final CommandRegistrationHandler commandRegistrationHandler) {
        this.requireState(RegistrationState.BEFORE_REGISTRATION);
        this.commandRegistrationHandler = commandRegistrationHandler;
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public final void registerCapability(final CloudCapability cloudCapability) {
        this.capabilities.add(cloudCapability);
        "\u6d7a\u5487\u54b9\u6b33".length();
        "\u6ccc".length();
        "\u54dd".length();
        "\u67af\u5e4f\u6b05\u6cb7".length();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public boolean hasCapability(final CloudCapability cloudCapability) {
        return this.capabilities.contains(cloudCapability);
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public Collection<CloudCapability> capabilities() {
        "\u5df5\u5a3d\u5cb5".length();
        return (Collection<CloudCapability>)Collections.unmodifiableSet((Set<?>)new HashSet<Object>(this.capabilities));
    }
    
    public boolean hasPermission(final C c, final CommandPermission commandPermission) {
        if (commandPermission instanceof Permission) {
            return commandPermission.toString().isEmpty() || this.hasPermission(c, commandPermission.toString());
        }
        if (commandPermission instanceof PredicatePermission) {
            return ((PredicatePermission)commandPermission).hasPermission(c);
        }
        if (commandPermission instanceof OrPermission) {
            final Iterator<CommandPermission> iterator = commandPermission.getPermissions().iterator();
            while (iterator.hasNext()) {
                if (this.hasPermission(c, iterator.next())) {
                    return true;
                }
            }
            return false;
        }
        if (commandPermission instanceof AndPermission) {
            final Iterator<CommandPermission> iterator2 = commandPermission.getPermissions().iterator();
            while (iterator2.hasNext()) {
                if (!this.hasPermission(c, iterator2.next())) {
                    return false;
                }
            }
            return true;
        }
        "\u4fdd\u5d80".length();
        "\u5523".length();
        "\u51c1\u51c7".length();
        final IllegalArgumentException ex = new IllegalArgumentException(\u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(-1099841474, -707903948, "\u72d9\u72cf\u72ce\u72c9\u72ca\u72d4\u72ca\u7288\u72f8\u72c1\u72d5\u72d8\u72d9\u72d2\u72ef\u72e1\u72ff\u72e2\u7286\u2b64\u1a8a\u29c6\u1a3a\u253d", -9307566, 930379415) + commandPermission.getClass());
        "\u675f\u6b14\u568a".length();
        "\u6abb\u6565\u5eed\u5311".length();
        "\u598c\u68a1\u4fbf".length();
        throw ex;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public final CaptionRegistry<C> getCaptionRegistry() {
        return this.captionRegistry();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public final CaptionRegistry<C> captionRegistry() {
        return this.captionRegistry;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public final void setCaptionRegistry(final CaptionRegistry<C> captionRegistry) {
        this.captionRegistry(captionRegistry);
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public final void captionRegistry(final CaptionRegistry<C> captionRegistry) {
        this.captionRegistry = captionRegistry;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED)
    public final void registerDefaultCaptions(final CaptionRegistry<C> captionRegistry) {
        this.captionRegistry = captionRegistry;
    }
    
    public abstract boolean hasPermission(final C p0, final String p1);
    
    @API(status = API.Status.EXPERIMENTAL, since = "1.7.0")
    public void deleteRootCommand(final String s) throws CloudCapability.CloudCapabilityMissingException {
        if (!this.hasCapability(CloudCapability.StandardCapabilities.ROOT_COMMAND_DELETION)) {
            "\u5e97\u6b37\u6d92\u572a\u6a81".length();
            final CloudCapability.CloudCapabilityMissingException ex = new CloudCapability.CloudCapabilityMissingException(CloudCapability.StandardCapabilities.ROOT_COMMAND_DELETION);
            "\u4f64\u6e30\u52ca\u6a45\u50cb".length();
            "\u506c".length();
            "\u68aa\u64ce\u4fed\u59b6\u61f6".length();
            "\u5e39".length();
            throw ex;
        }
        final CommandTree.Node<CommandArgument<C, ?>> namedNode = this.commandTree.getNamedNode(s);
        if (namedNode == null) {
            return;
        }
        this.commandRegistrationHandler.unregisterRootCommand((StaticArgument)namedNode.getValue());
        final CommandTree<C> commandTree = this.commandTree;
        final CommandTree.Node<CommandArgument<C, ?>> node = namedNode;
        final boolean b = true;
        final Collection<Command<C>> commands = this.commands;
        "\u52a0\u6d3e\u6730".length();
        Objects.requireNonNull(commands);
        "\u6566\u5622\u59ef\u54ae\u5bc9".length();
        "\u596b".length();
        "\u6d12\u6567\u6e59".length();
        commandTree.deleteRecursively(node, b, (Consumer<Command<C>>)commands::remove);
        this.commandTree.verifyAndRegister();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public Collection<String> rootCommands() {
        return this.commandTree.getRootNodes().stream().map((Function<? super CommandTree.Node<CommandArgument<C, ?>>, ?>)CommandTree.Node::getValue).filter(commandArgument -> commandArgument instanceof StaticArgument).map(staticArgument -> staticArgument).map((Function<? super Object, ?>)CommandArgument::getName).collect((Collector<? super Object, ?, Collection<String>>)Collectors.toList());
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.4.0")
    public Command.Builder<C> commandBuilder(final String s, final Collection<String> collection, final Description description, final CommandMeta commandMeta) {
        return this.commandBuilder(s, collection, (ArgumentDescription)description, commandMeta);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public Command.Builder<C> commandBuilder(final String s, final Collection<String> collection, final ArgumentDescription argumentDescription, final CommandMeta commandMeta) {
        return Command.newBuilder(s, commandMeta, argumentDescription, collection.toArray(new String[0])).manager(this);
    }
    
    public Command.Builder<C> commandBuilder(final String s, final Collection<String> collection, final CommandMeta commandMeta) {
        return Command.newBuilder(s, commandMeta, ArgumentDescription.empty(), collection.toArray(new String[0])).manager(this);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.4.0")
    public Command.Builder<C> commandBuilder(final String s, final CommandMeta commandMeta, final Description description, final String[] array) {
        return this.commandBuilder(s, commandMeta, (ArgumentDescription)description, array);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public Command.Builder<C> commandBuilder(final String s, final CommandMeta commandMeta, final ArgumentDescription argumentDescription, final String[] array) {
        return Command.newBuilder(s, commandMeta, argumentDescription, array).manager(this);
    }
    
    public Command.Builder<C> commandBuilder(final String s, final CommandMeta commandMeta, final String[] array) {
        return Command.newBuilder(s, commandMeta, ArgumentDescription.empty(), array).manager(this);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.4.0")
    public Command.Builder<C> commandBuilder(final String s, final Description description, final String[] array) {
        return this.commandBuilder(s, (ArgumentDescription)description, array);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public Command.Builder<C> commandBuilder(final String s, final ArgumentDescription argumentDescription, final String[] array) {
        return Command.newBuilder(s, this.createDefaultCommandMeta(), argumentDescription, array).manager(this);
    }
    
    public Command.Builder<C> commandBuilder(final String s, final String[] array) {
        return Command.newBuilder(s, this.createDefaultCommandMeta(), ArgumentDescription.empty(), array).manager(this);
    }
    
    public <T> CommandArgument.Builder<C, T> argumentBuilder(final Class<T> clazz, final String s) {
        return CommandArgument.ofType(clazz, s).manager(this);
    }
    
    public CommandFlag.Builder<Void> flagBuilder(final String s) {
        return CommandFlag.builder(s);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public CommandTree<C> getCommandTree() {
        return this.commandTree();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public CommandTree<C> commandTree() {
        return this.commandTree;
    }
    
    public abstract CommandMeta createDefaultCommandMeta();
    
    public void registerCommandPreProcessor(final CommandPreprocessor<C> commandPreprocessor) {
        final ServicePipeline servicePipeline = this.servicePipeline;
        "\u514a\u4e9e".length();
        "\u62b2\u5558\u4fe4\u51c9\u5454".length();
        "\u5227".length();
        "\u708b\u69ea\u6f8a\u5bdd\u5cbd".length();
        servicePipeline.registerServiceImplementation((TypeToken<? extends Service<Object, Object>>)new TypeToken<CommandPreprocessor<C>>(), (Service<Object, Object>)commandPreprocessor, (Collection<Predicate<Object>>)Collections.emptyList());
        "\u5df7".length();
        "\u6743\u6bcd\u5c6a".length();
    }
    
    public void registerCommandPostProcessor(final CommandPostprocessor<C> commandPostprocessor) {
        final ServicePipeline servicePipeline = this.servicePipeline;
        "\u6bb4".length();
        "\u590a".length();
        servicePipeline.registerServiceImplementation((TypeToken<? extends Service<Object, Object>>)new TypeToken<CommandPostprocessor<C>>(), (Service<Object, Object>)commandPostprocessor, (Collection<Predicate<Object>>)Collections.emptyList());
        "\u5164\u6d40\u6b80\u5e68\u696e".length();
        "\u4e74\u58cc\u708f\u5688".length();
    }
    
    public State preprocessContext(final CommandContext<C> commandContext, final LinkedList<String> list) {
        final ServicePipeline servicePipeline = this.servicePipeline;
        "\u6667\u61fc\u6b80\u67ca\u5887".length();
        "\u5dba".length();
        "\u64f3\u5de4\u69f7".length();
        final ServicePump<CommandPreprocessingContext<C>> pump = servicePipeline.pump(new CommandPreprocessingContext<C>(commandContext, list));
        "\u570b\u5dfb\u6a4f\u52ba\u59e8".length();
        pump.through((TypeToken<? extends Service<CommandPreprocessingContext<C>, Object>>)new TypeToken<CommandPreprocessor<C>>()).getResult();
        "\u541f\u61fe\u5fd4".length();
        "\u6723\u583a\u7135".length();
        "\u6ed4\u53a7\u6af3\u65ff\u5095".length();
        return commandContext.getOptional(\u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(-31316524, -1891485963, "\u06bb\u0696\u068a\u0684\u0688\u068e\u0689\u068a\u06a4\u0693\u069b\u068b\u0685\u068e\u0680\u0696\u0697\u0687\u06af\u5f0f\u6ee0\u5db3\u6e57\u510e\u56ce", -235832892, 1001942082)).orElse(\u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(1519828950, -1670950928, "", -1920410184, 1323527527)).isEmpty() ? State.REJECTED : State.ACCEPTED;
    }
    
    public State postprocessContext(final CommandContext<C> commandContext, final Command<C> command) {
        final ServicePipeline servicePipeline = this.servicePipeline;
        "\u6d3e\u69b3\u58c7".length();
        "\u6d0a\u666c\u5bd9\u6205".length();
        "\u54bb".length();
        "\u5029\u63bb\u5023".length();
        "\u4eab\u625e\u6183\u6120\u5c3f".length();
        final ServicePump<CommandPostprocessingContext<C>> pump = servicePipeline.pump(new CommandPostprocessingContext<C>(commandContext, command));
        "\u6ad1\u6df6\u50fa\u5360\u5a0a".length();
        "\u6ad9\u61a7".length();
        "\u6e17".length();
        "\u515a\u6d93".length();
        pump.through((TypeToken<? extends Service<CommandPostprocessingContext<C>, Object>>)new TypeToken<CommandPostprocessor<C>>()).getResult();
        "\u55d1\u5321\u53d0".length();
        "\u63d7\u5d8c".length();
        "\u6b3a\u6aea\u4e5f\u6093".length();
        "\u550a\u512d\u5144\u61dc".length();
        return commandContext.getOptional(\u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(-1521018920, 1403809435, "\u5968\u5945\u5959\u5957\u5953\u5955\u5952\u5951\u5977\u5940\u5948\u5945\u5958\u594e\u5944\u595f\u5959\u5958\u597a\u00ca\u313b\u027e\u318d\u0ece\u091d\u3615", 375625856, 1900722359)).orElse(\u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(-151985556, -1505831299, "", -1688477171, 1804825238)).isEmpty() ? State.REJECTED : State.ACCEPTED;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public CommandSuggestionProcessor<C> getCommandSuggestionProcessor() {
        return this.commandSuggestionProcessor();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public CommandSuggestionProcessor<C> commandSuggestionProcessor() {
        return this.commandSuggestionProcessor;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public void setCommandSuggestionProcessor(final CommandSuggestionProcessor<C> commandSuggestionProcessor) {
        this.commandSuggestionProcessor(commandSuggestionProcessor);
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public void commandSuggestionProcessor(final CommandSuggestionProcessor<C> commandSuggestionProcessor) {
        this.commandSuggestionProcessor = commandSuggestionProcessor;
    }
    
    @Deprecated
    @API(status = API.Status.STABLE, since = "1.7.0")
    public ParserRegistry<C> getParserRegistry() {
        return this.parserRegistry();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public ParserRegistry<C> parserRegistry() {
        return this.parserRegistry;
    }
    
    public final ParameterInjectorRegistry<C> parameterInjectorRegistry() {
        return this.parameterInjectorRegistry;
    }
    
    public final <E extends Exception> BiConsumer<C, E> getExceptionHandler(final Class<E> clazz) {
        final BiConsumer<C, ? extends Exception> biConsumer = this.exceptionHandlers.get(clazz);
        if (biConsumer == null) {
            return null;
        }
        return (BiConsumer<C, E>)biConsumer;
    }
    
    public final <E extends Exception> void registerExceptionHandler(final Class<E> clazz, final BiConsumer<C, E> biConsumer) {
        this.exceptionHandlers.put(clazz, biConsumer);
        "\u6e0b\u5dd9".length();
        "\u6144\u5007\u6ef5\u6b5f".length();
        "\u6675\u4fc0".length();
    }
    
    public final <E extends Exception> void handleException(final C c, final Class<E> clazz, final E e, final BiConsumer<C, E> other) {
        Optional.ofNullable(this.getExceptionHandler(clazz)).orElse(other).accept(c, e);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public final Collection<Command<C>> getCommands() {
        return this.commands();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public final Collection<Command<C>> commands() {
        return Collections.unmodifiableCollection((Collection<? extends Command<C>>)this.commands);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public final CommandHelpHandler<C> getCommandHelpHandler() {
        return this.createCommandHelpHandler();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public final CommandHelpHandler<C> createCommandHelpHandler() {
        "\u505f".length();
        "\u5c38".length();
        return new CommandHelpHandler<C>(this, p0 -> true);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public final CommandHelpHandler<C> getCommandHelpHandler(final Predicate<Command<C>> predicate) {
        return this.createCommandHelpHandler(predicate);
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public final CommandHelpHandler<C> createCommandHelpHandler(final Predicate<Command<C>> predicate) {
        "\u6496\u5d9e\u5e8e".length();
        "\u6a43\u5fb8\u50b4\u5af6\u50fb".length();
        "\u6f7f\u50a1".length();
        "\u5ec4".length();
        return new CommandHelpHandler<C>(this, predicate);
    }
    
    public boolean getSetting(final ManagerSettings o) {
        return this.managerSettings.contains(o);
    }
    
    public void setSetting(final ManagerSettings managerSettings, final boolean b) {
        if (b) {
            this.managerSettings.add(managerSettings);
            "\u507b\u6e62".length();
            "\u60a2\u6b42\u5f0c\u6373\u5e88".length();
        }
        else {
            this.managerSettings.remove(managerSettings);
            "\u5456\u6cc5".length();
        }
    }
    
    @API(status = API.Status.STABLE, since = "1.6.0")
    public CommandExecutionCoordinator<C> commandExecutionCoordinator() {
        return this.commandExecutionCoordinator;
    }
    
    @API(status = API.Status.STABLE, since = "1.2.0")
    public final void transitionOrThrow(final RegistrationState obj, final RegistrationState obj2) {
        if (!this.transitionIfPossible(obj, obj2)) {
            "\u6196".length();
            "\u5078".length();
            "\u6403".length();
            "\u631b\u5409\u667f\u5940".length();
            "\u530f\u6a75\u69bb\u51c9".length();
            final IllegalStateException ex = new IllegalStateException(\u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(2032162987, -553687971, "\ub549\ub54a\ub54a\ub54e\ub542\ub549\ub54a\ub50c\ub563\ub541\ub54b\ub550\ub551\ub540\ub554\ub6ec\ub6a1\ub6a9\ub697\uef74\udedc\ued9c\ude35\ue12a\ue6eb\ud9f4\uee86\udca5\udb8c", 582823409, -1243372466) + this.state.get() + \u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(-1659633499, -764836761, "\ubff2\ubfd3\ubf84\ubf99\ubfe6\ubfe5\ubfe7\ubfae\ubfdd\ubfe3\ubfa1\ubfe4\ubfff\ubff9\ubfef\ubfbe\ubfe7\ubfe6\ubfc0\ue663\ud79a\ue4c8\ud730\ue875\uefbc\ud0f3\ue7d7\ud5a2\ud293\ue89e\ud51c\ud80b\udab7\ue655\ueabd\uec4e\ue044", 905537212, -1688052253) + obj + \u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(-945581442, 1080598944, "\ucf32\ucf52\ucf4d\ucf13", 856475637, 2095004538) + obj2 + \u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(1642290332, 1147817774, "\u7ff0", 1849826514, 757166322));
            "\u6c76\u5ab9\u55fa\u6041\u5b45".length();
            "\u63a4\u64b5\u5e6b\u6f96\u5a47".length();
            throw ex;
        }
    }
    
    @API(status = API.Status.STABLE, since = "1.2.0")
    public final boolean transitionIfPossible(final RegistrationState expectedValue, final RegistrationState newValue) {
        return this.state.compareAndSet(expectedValue, newValue) || this.state.get() == newValue;
    }
    
    @API(status = API.Status.STABLE, since = "1.2.0")
    public final void requireState(final RegistrationState obj) {
        if (this.state.get() != obj) {
            "\u67a2\u65ee".length();
            "\u6ea4\u635d\u6a1a\u6af7".length();
            "\u6d04\u67e6\u6915".length();
            "\u4f61\u4f2e\u58b6\u6fb3".length();
            final IllegalStateException ex = new IllegalStateException(\u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(1955063257, 2018177407, "\ub65b\ub64a\ub64f\ub657\ub606\ub64f\ub657\ub64e\ub679\ub646\ub650\ub65f\ub65c\ub64c\ub61f\ub659\ub656\ub65e\ub670\uefda\ude22\ued70\ude98\ue19e\ue60e\ud91a\uee76\udc07\udb2a\ue12c\udc85\ud187\ud322\uef8a\ue323\ue5ce\ue9ed\ud86e\ud9d9\udda3\ue417\udce0\ue483\ud568\ueb2f\ue262\ue20f\uedd4\ue112\ue706\uea7e\ud3b3\ud6c2\ud6a7\ued4f\ue2cd\ueb04\udc53\ud77d\uc6de", -462102462, -1172356440) + obj + \u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(-1942980312, 911438115, "\u6ab8\u6a9f\u6adf\u6ac8\u6ac9\u6a85\u6ac5\u6ad6\u6aa0\u6add\u6ace\u6acc\u6a98\u6ace\u6aca\u6a92", -862437845, 334322935) + this.state.get() + \u60cc\u5fab\u63e6\u6636\u7118\u53d3\u6e70\u521b\u4e74\u670a\u60f5\u59fc\u62d2\u58ed\u67c6\u6256\u4e98\u6c65\u67f9\u67d2\u5b50\u6793\u6e64\u6f04\u6014\u5064\u65c7\u55fb\u52a1\u5d65\u4e4f\u5cf2\u61ee\u5200\u691b\u667a\u6d71\u5a1e\u6b3a\u56d0\u50cc(-378436752, -1727474249, "\ud020\ud046\ud043\ud062\ud065\ud070\ud07d\ud072\ud015", -715522147, 2096003353));
            "\u5649\u6bbc\u65ae\u5ad7".length();
            "\u66ea\u57e6".length();
            throw ex;
        }
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public final void lockRegistration() {
        if (this.registrationState() == RegistrationState.BEFORE_REGISTRATION) {
            this.transitionOrThrow(RegistrationState.BEFORE_REGISTRATION, RegistrationState.AFTER_REGISTRATION);
            return;
        }
        this.transitionOrThrow(RegistrationState.REGISTERING, RegistrationState.AFTER_REGISTRATION);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.7.0")
    public final RegistrationState getRegistrationState() {
        return this.registrationState();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public final RegistrationState registrationState() {
        return this.state.get();
    }
    
    @API(status = API.Status.STABLE, since = "1.2.0")
    public boolean isCommandRegistrationAllowed() {
        return this.getSetting(ManagerSettings.ALLOW_UNSAFE_REGISTRATION) || this.state.get() != RegistrationState.AFTER_REGISTRATION;
    }
    
    public static int ColonialObfuscator_\u654a\u6401\u5029\u656c\u627e\u660e\u6b6c\u6287\u653c\u649b\u6796\u6458\u6d0a\u5e7f\u5505\u6f7d\u5504\u5b4d\u53d7\u55f4\u5b79\u587c\u5864\u5f5b\u5274\u5ea8\u590c\u5c81\u4fab\u520d\u5495\u6454\u5f74\u66cc\u4f3c\u634c\u6760\u6ef2\u55a5\u5e40\u61ba(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
