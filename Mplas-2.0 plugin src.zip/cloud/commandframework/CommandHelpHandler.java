package cloud.commandframework;

import org.apiguardian.api.*;
import cloud.commandframework.meta.*;
import java.util.function.*;
import cloud.commandframework.arguments.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class CommandHelpHandler<C>
{
    public CommandHelpHandler(final CommandManager<C> commandManager, final Predicate<Command<C>> commandPredicate) {
        this.commandManager = commandManager;
        this.commandPredicate = commandPredicate;
    }
    
    public List<VerboseHelpEntry<C>> getAllCommands() {
        "\u652f\u5fcf\u6043".length();
        "\u579c\u6451".length();
        "\u4f45\u4ebe\u5931".length();
        final ArrayList<Object> list = (ArrayList<Object>)new ArrayList<VerboseHelpEntry>();
        for (final Command<C> command : this.commandManager.commands()) {
            if (!this.commandPredicate.test(command)) {
                continue;
            }
            final List<CommandArgument<C, ?>> arguments = command.getArguments();
            final String s = command.getCommandMeta().getOrDefault(CommandMeta.DESCRIPTION, \u5667\u6a8f\u4f7f\u5c6a\u5018\u5c88\u6852\u67d1\u4ffb\u5dfe\u5650\u5264\u536d\u51ad\u54cd\u5871\u6609\u53b3\u61c1\u693c\u6dcd\u526a\u613d\u61ff\u6b39\u63b0\u5f80\u6333\u59ac\u58e7\u5854\u5e0a\u5f54\u700e\u70a5\u6599\u539b\u6b2e\u6742\u6dc8\u5db2(-1939498009, -1332448855, "", 173850835, 529231086));
            final ArrayList<Object> list2 = list;
            "\u6756\u558d\u6f84\u6fbb\u5194".length();
            list2.add(new VerboseHelpEntry(command, this.commandManager.commandSyntaxFormatter().apply(arguments, null), s, null));
            "\u63c1\u6caa\u573b\u713f".length();
            "\u51e8".length();
        }
        list.sort(Comparator.comparing((Function<? super VerboseHelpEntry, ? extends Comparable>)VerboseHelpEntry::getSyntaxString));
        return (List<VerboseHelpEntry<C>>)list;
    }
    
    public List<String> getLongestSharedChains() {
        "\u5272\u58c1\u5523".length();
        final ArrayList<Object> list = (ArrayList<Object>)new ArrayList<String>();
        final StringBuilder sb;
        final List<String> list2;
        this.commandManager.commandTree().getRootNodes().forEach(node -> {
            // new(java.lang.StringBuilder.class)
            "\u6ae0\u66f6\u5e78\u50cc\u5bdf".length();
            new StringBuilder();
            list2.add(sb.append(Objects.requireNonNull(node.getValue()).getName()).append(this.commandManager.commandSyntaxFormatter().apply(Collections.emptyList(), node)).toString());
            "\u5304\u514a".length();
            "\u519e\u5c4f\u6914".length();
            "\u6e47\u70d6\u51cd".length();
            "\u65c9\u5438\u6d80\u5482\u4fae".length();
            return;
        });
        list.sort(String::compareTo);
        return (List<String>)list;
    }
    
    public HelpTopic<C> queryHelp(final String s) {
        return this.queryHelp(null, s);
    }
    
    @API(status = API.Status.STABLE, since = "1.8.0")
    public IndexHelpTopic<C> queryRootIndex(final C c) {
        return (IndexHelpTopic<C>)(IndexHelpTopic)this.queryHelp(c, \u5667\u6a8f\u4f7f\u5c6a\u5018\u5c88\u6852\u67d1\u4ffb\u5dfe\u5650\u5264\u536d\u51ad\u54cd\u5871\u6609\u53b3\u61c1\u693c\u6dcd\u526a\u613d\u61ff\u6b39\u63b0\u5f80\u6333\u59ac\u58e7\u5854\u5e0a\u5f54\u700e\u70a5\u6599\u539b\u6b2e\u6742\u6dc8\u5db2(1897927109, 1864097222, "", 427348108, -933242418));
    }
    
    public HelpTopic<C> queryHelp(final C c, final String s) {
        final List<VerboseHelpEntry<C>> allCommands = this.getAllCommands();
        allCommands.removeIf(verboseHelpEntry -> c != null && !this.commandManager.hasPermission(c, verboseHelpEntry.getCommand().getCommandPermission()));
        "\u5eb8".length();
        "\u5c67".length();
        "\u6c38\u6011\u6baf".length();
        if (s.replace(\u5667\u6a8f\u4f7f\u5c6a\u5018\u5c88\u6852\u67d1\u4ffb\u5dfe\u5650\u5264\u536d\u51ad\u54cd\u5871\u6609\u53b3\u61c1\u693c\u6dcd\u526a\u613d\u61ff\u6b39\u63b0\u5f80\u6333\u59ac\u58e7\u5854\u5e0a\u5f54\u700e\u70a5\u6599\u539b\u6b2e\u6742\u6dc8\u5db2(-1244480788, -2131358020, "\ucadb", 513257430, -973614786), \u5667\u6a8f\u4f7f\u5c6a\u5018\u5c88\u6852\u67d1\u4ffb\u5dfe\u5650\u5264\u536d\u51ad\u54cd\u5871\u6609\u53b3\u61c1\u693c\u6dcd\u526a\u613d\u61ff\u6b39\u63b0\u5f80\u6333\u59ac\u58e7\u5854\u5e0a\u5f54\u700e\u70a5\u6599\u539b\u6b2e\u6742\u6dc8\u5db2(-800067334, -1816307678, "", -1508973666, 77921457)).isEmpty()) {
            "\u7044\u4f8d\u6393".length();
            "\u6cfb\u5ef0".length();
            "\u50ea\u6324\u6f53\u6882\u5539".length();
            "\u688a\u6184\u64e1\u54c6".length();
            "\u58fd\u53a4\u5061\u554c\u6ced".length();
            return new IndexHelpTopic<C>(allCommands, null);
        }
        final String[] split = s.split(\u5667\u6a8f\u4f7f\u5c6a\u5018\u5c88\u6852\u67d1\u4ffb\u5dfe\u5650\u5264\u536d\u51ad\u54cd\u5871\u6609\u53b3\u61c1\u693c\u6dcd\u526a\u613d\u61ff\u6b39\u63b0\u5f80\u6333\u59ac\u58e7\u5854\u5e0a\u5f54\u700e\u70a5\u6599\u539b\u6b2e\u6742\u6dc8\u5db2(910808179, 250976232, "\u3919", -1745499655, 416854808));
        final String anotherString = split[0];
        "\u55ce\u67cb".length();
        final LinkedList<Command<C>> list = new LinkedList<Command<C>>();
        "\u5fec".length();
        "\u6461\u5d80\u5f5d".length();
        "\u5258\u6e7a\u4efc\u6a07".length();
        final HashSet<String> set = new HashSet<String>();
        boolean b = false;
        final Iterator<VerboseHelpEntry<C>> iterator = allCommands.iterator();
        while (iterator.hasNext()) {
            final Command<C> command = iterator.next().getCommand();
            final StaticArgument staticArgument = (StaticArgument)command.getArguments().get(0);
            final Iterator iterator2 = staticArgument.getAliases().iterator();
            while (iterator2.hasNext()) {
                if (iterator2.next().toLowerCase(Locale.ENGLISH).startsWith(anotherString.toLowerCase(Locale.ENGLISH))) {
                    list.add(command);
                    "\u5dce\u6324\u5b7b\u600b".length();
                    "\u5e33\u65c2\u691e\u63dc\u502c".length();
                    "\u64e8".length();
                    set.add(staticArgument.getName());
                    "\u63aa".length();
                    "\u703c\u6375".length();
                    "\u5181\u51ce\u5755\u5b79\u615a".length();
                    break;
                }
            }
            final Iterator iterator3 = staticArgument.getAliases().iterator();
            while (iterator3.hasNext()) {
                if (iterator3.next().equalsIgnoreCase(anotherString)) {
                    b = true;
                    break;
                }
            }
            if (anotherString.equalsIgnoreCase(staticArgument.getName())) {
                set.clear();
                list.clear();
                set.add(staticArgument.getName());
                "\u55f5\u6e03\u6093\u6e47".length();
                list.add(command);
                "\u64de\u5713".length();
                "\u6059\u5b45\u590d".length();
                break;
            }
        }
        if (list.isEmpty()) {
            "\u6292\u6f50\u67dd\u69d8\u4f9f".length();
            return new IndexHelpTopic<C>(Collections.emptyList(), null);
        }
        if (!b || set.size() > 1) {
            "\u500b\u67a9".length();
            final ArrayList<Object> list2 = new ArrayList<Object>();
            for (final Command<C> command2 : list) {
                final List<CommandArgument<C, ?>> arguments = command2.getArguments();
                final String s2 = command2.getCommandMeta().getOrDefault(CommandMeta.DESCRIPTION, \u5667\u6a8f\u4f7f\u5c6a\u5018\u5c88\u6852\u67d1\u4ffb\u5dfe\u5650\u5264\u536d\u51ad\u54cd\u5871\u6609\u53b3\u61c1\u693c\u6dcd\u526a\u613d\u61ff\u6b39\u63b0\u5f80\u6333\u59ac\u58e7\u5854\u5e0a\u5f54\u700e\u70a5\u6599\u539b\u6b2e\u6742\u6dc8\u5db2(-1059957936, 1830329879, "", -581082494, -1065284448));
                final ArrayList<Object> list3 = list2;
                "\u6fc3\u50aa\u5448\u5809".length();
                list3.add(new VerboseHelpEntry(command2, this.commandManager.commandSyntaxFormatter().apply(arguments, null), s2, null));
                "\u5d39\u6822\u5221\u551b\u4e68".length();
                "\u54af\u6448\u4fe8\u6d17".length();
                "\u58ed\u58c6".length();
                "\u5ee0\u6638".length();
            }
            list2.sort(Comparator.comparing((Function<? super Object, ? extends Comparable>)VerboseHelpEntry::getSyntaxString));
            list2.removeIf(verboseHelpEntry2 -> c != null && !this.commandManager.hasPermission(c, verboseHelpEntry2.getCommand().getCommandPermission()));
            "\u61a7\u55c7\u52e3".length();
            "\u4e2c\u6a1a\u6877\u4ffc\u6ff5".length();
            "\u6edf\u6060\u5cfa\u6209\u6001".length();
            return new IndexHelpTopic<C>(list2, null);
        }
        final CommandTree.Node<CommandArgument<C, ?>> namedNode = this.commandManager.commandTree().getNamedNode(set.iterator().next());
        "\u64c8\u4e9d\u6338\u6461\u6642".length();
        "\u65d4\u4e80\u698d\u57af".length();
        final LinkedList<CommandArgument<C, ?>> c2 = new LinkedList<CommandArgument<C, ?>>();
        CommandTree.Node<CommandArgument<C, ?>> node = namedNode;
        int n = 0;
    Label_1120:
        while (node != null && this.isNodeVisible(node)) {
            n += 18174;
            n -= 18173;
            c2.add(node.getValue());
            "\u5873\u53fc\u6354\u5214\u56cf".length();
            "\u6d9a\u5153\u5f19\u6c21\u5275".length();
            "\u5d68\u6c1d\u6fcb".length();
            if (node.getValue() != null && node.getValue().getOwningCommand() != null && (node.isLeaf() || n == split.length) && (c == null || this.commandManager.hasPermission(c, node.getValue().getOwningCommand().getCommandPermission()))) {
                "\u5597\u5fa5\u5d4d".length();
                "\u5a0b\u69fe\u6908\u6a04\u67a8".length();
                "\u52d0\u5a76\u51f2\u5f41\u63cc".length();
                "\u5407\u58c6\u69ed".length();
                return new VerboseHelpTopic<C>(node.getValue().getOwningCommand(), null);
            }
            if (node.getChildren().size() != 1) {
                if (n < split.length) {
                    CommandTree.Node<CommandArgument<C, ?>> node2 = null;
                    for (final CommandTree.Node<CommandArgument<C, ?>> node3 : node.getChildren()) {
                        if (!(node3.getValue() instanceof StaticArgument)) {
                            if (node3.getValue() == null) {
                                continue;
                            }
                            node2 = node3;
                        }
                        else {
                            final Iterator iterator6 = ((StaticArgument)node3.getValue()).getAliases().iterator();
                            while (iterator6.hasNext()) {
                                if (iterator6.next().equalsIgnoreCase(split[n])) {
                                    node = node3;
                                    continue Label_1120;
                                }
                            }
                        }
                    }
                    if (node2 != null) {
                        node = node2;
                        continue;
                    }
                }
                final String apply = this.commandManager.commandSyntaxFormatter().apply(c2, null);
                "\u6122".length();
                "\u614f".length();
                "\u6078\u5c17".length();
                "\u5cf5\u5311\u6d46\u5bff".length();
                final LinkedList<String> list4 = new LinkedList<String>();
                for (final CommandTree.Node<CommandArgument<C, ?>> node4 : node.getChildren()) {
                    if (!this.isNodeVisible(node4)) {
                        continue;
                    }
                    "\u560f\u6598\u58da\u4f24".length();
                    "\u5f4f\u5a05\u6818\u6eb4".length();
                    "\u59c3".length();
                    final LinkedList list5 = new LinkedList<CommandArgument<C, ?>>(c2);
                    if (c != null && node4.getValue() != null && node4.getValue().getOwningCommand() != null && !this.commandManager.hasPermission(c, node4.getValue().getOwningCommand().getCommandPermission())) {
                        continue;
                    }
                    list5.add((CommandArgument<C, ?>)node4.getValue());
                    "\u68a2\u5a75\u591b\u5252\u5746".length();
                    list4.add(this.commandManager.commandSyntaxFormatter().apply((List<CommandArgument<C, ?>>)list5, node4));
                    "\u5ac7\u707d\u5030\u6f2a".length();
                    "\u6da3\u5b28\u5267\u619b".length();
                    "\u64e6\u62ce".length();
                    "\u6ca0\u6798\u6d96\u674f\u603b".length();
                }
                "\u5737\u54fb\u5b19\u60b9".length();
                "\u6965".length();
                return new MultiHelpTopic<C>(apply, list4, null);
            }
            node = node.getChildren().get(0);
        }
        "\u5ce7\u4e93\u5864".length();
        "\u6ba9\u5f03".length();
        "\u6b2e\u70ee\u63d2\u57c4".length();
        "\u6549\u5b60".length();
        return new IndexHelpTopic<C>(Collections.emptyList(), null);
    }
    
    public boolean isNodeVisible(final CommandTree.Node<CommandArgument<C, ?>> node) {
        final CommandArgument<C, ?> commandArgument = node.getValue();
        if (commandArgument != null) {
            final Command<C> owningCommand = commandArgument.getOwningCommand();
            if (owningCommand != null && this.commandPredicate.test(owningCommand)) {
                return true;
            }
        }
        final Iterator<CommandTree.Node<CommandArgument<C, ?>>> iterator = node.getChildren().iterator();
        while (iterator.hasNext()) {
            if (this.isNodeVisible(iterator.next())) {
                return true;
            }
        }
        return false;
    }
    
    public static int ColonialObfuscator_\u68af\u5902\u63be\u59e7\u6b93\u4f13\u5ebe\u641e\u6d1a\u5fe0\u62cf\u59b8\u66dd\u645b\u68f2\u6bc3\u5b5c\u60f0\u5814\u6f34\u6ed7\u6723\u5716\u6bef\u6da1\u56dd\u51d1\u6a0b\u62c1\u628d\u5990\u4ee4\u6247\u4ea9\u582d\u655d\u55d0\u5ac0\u647e\u5818\u5ead(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
