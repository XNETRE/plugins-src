package cloud.commandframework.annotations;

import org.apiguardian.api.*;
import java.lang.annotation.*;
import java.util.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class MultiDelegateAnnotationAccessor implements AnnotationAccessor
{
    public MultiDelegateAnnotationAccessor(final AnnotationAccessor[] accessors) {
        this.accessors = accessors;
    }
    
    @Override
    public <A extends Annotation> A annotation(final Class<A> clazz) {
        Annotation annotation = null;
        final AnnotationAccessor[] accessors = this.accessors;
        for (int length = accessors.length, i = 0; i < length; i += 26007, i -= 26006) {
            annotation = accessors[i].annotation(clazz);
            if (annotation != null) {
                break;
            }
        }
        return (A)annotation;
    }
    
    @Override
    public Collection<Annotation> annotations() {
        "\u57f1\u4e54\u5650\u6caf".length();
        "\u6100\u5036".length();
        final LinkedList<Annotation> c = new LinkedList<Annotation>();
        final AnnotationAccessor[] accessors = this.accessors;
        for (int length = accessors.length, i = 0; i < length; i += 7124, i -= 7123) {
            c.addAll((Collection<?>)accessors[i].annotations());
            "\u5b94\u570d\u69b7\u6c34".length();
            "\u6025\u613a".length();
            "\u6f53\u5a75\u53e7\u6e17\u6f8f".length();
            "\u5dbb\u58ed".length();
        }
        return (Collection<Annotation>)Collections.unmodifiableCollection((Collection<?>)c);
    }
    
    public static int ColonialObfuscator_\u56f9\u5e3a\u4f7c\u59be\u6273\u6a9c\u6aef\u6b9a\u6f88\u6988\u54da\u5d7f\u569a\u6478\u6faf\u5394\u4f4c\u60cc\u54b6\u5bbb\u63c2\u6125\u6fa5\u6bb2\u69b4\u6b64\u6a19\u5251\u6bcf\u551a\u6370\u6f98\u539b\u6616\u5cf4\u50bb\u6106\u59f6\u61e6\u5517\u55f6(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
