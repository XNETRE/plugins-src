package cloud.commandframework.annotations;

import org.apiguardian.api.*;
import java.lang.reflect.*;
import java.lang.annotation.*;
import java.util.*;

@API(status = API.Status.STABLE, since = "1.2.0")
public interface AnnotationAccessor
{
     <A extends Annotation> A annotation(final Class<A> p0);
    
    Collection<Annotation> annotations();
}
