package cloud.commandframework.annotations.specifier;

import java.lang.annotation.*;
import org.apiguardian.api.*;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.PARAMETER })
@API(status = API.Status.STABLE, since = "1.7.0")
public @interface FlagYielding {
}
