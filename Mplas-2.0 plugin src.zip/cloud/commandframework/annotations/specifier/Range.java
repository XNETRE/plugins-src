package cloud.commandframework.annotations.specifier;

import java.lang.annotation.*;
import org.apiguardian.api.*;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.PARAMETER })
@API(status = API.Status.STABLE)
public @interface Range {
    String min() default "";
    
    String max() default "";
}
