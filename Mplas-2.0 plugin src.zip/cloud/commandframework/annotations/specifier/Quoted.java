package cloud.commandframework.annotations.specifier;

import java.lang.annotation.*;
import org.apiguardian.api.*;

@Target({ ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@API(status = API.Status.STABLE, since = "1.5.0")
public @interface Quoted {
}
