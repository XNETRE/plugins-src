package cloud.commandframework.annotations.specifier;

import java.lang.annotation.*;
import org.apiguardian.api.*;

@Target({ ElementType.PARAMETER })
@Retention(RetentionPolicy.RUNTIME)
@API(status = API.Status.STABLE)
public @interface Greedy {
}
