package cloud.commandframework.annotations.injection;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import cloud.commandframework.annotations.*;

@FunctionalInterface
@API(status = API.Status.STABLE, since = "1.2.0")
public interface ParameterInjector<C, T>
{
    T create(final CommandContext<C> p0, final AnnotationAccessor p1);
}
