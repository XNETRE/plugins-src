package cloud.commandframework.annotations.injection;

import cloud.commandframework.services.types.*;
import cloud.commandframework.types.tuples.*;
import cloud.commandframework.context.*;
import cloud.commandframework.annotations.*;
import org.apiguardian.api.*;

@FunctionalInterface
@API(status = API.Status.STABLE, since = "1.4.0")
public interface InjectionService<C> extends Service<Triplet<CommandContext<C>, Class<?>, AnnotationAccessor>, Object>
{
}
