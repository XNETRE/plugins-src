package cloud.commandframework.annotations.injection;

import org.apiguardian.api.*;
import cloud.commandframework.types.tuples.*;
import cloud.commandframework.context.*;
import cloud.commandframework.annotations.*;
import com.google.inject.*;

@API(status = API.Status.STABLE, since = "1.4.0")
public final class GuiceInjectionService<C> implements InjectionService<C>
{
    public GuiceInjectionService(final Injector injector) {
        this.injector = injector;
    }
    
    @Override
    public Object handle(final Triplet<CommandContext<C>, Class<?>, AnnotationAccessor> triplet) {
        try {
            return this.injector.getInstance((Class)triplet.getSecond());
        }
        catch (ConfigurationException ex) {
            return null;
        }
    }
    
    public static int ColonialObfuscator_\u6590\u5b10\u63c1\u50a3\u54aa\u7146\u584b\u689d\u689c\u6f0a\u5f16\u61ed\u62f3\u612d\u52f2\u6bf8\u597f\u6984\u5148\u5eaf\u5052\u6463\u64da\u6839\u58a6\u6769\u6041\u6359\u6940\u6eb3\u6365\u69a4\u69d6\u5599\u6d40\u4fea\u6ff2\u66f1\u56de\u524b\u6944(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
