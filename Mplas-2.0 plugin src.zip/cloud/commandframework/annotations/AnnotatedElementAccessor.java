package cloud.commandframework.annotations;

import org.apiguardian.api.*;
import java.lang.reflect.*;
import java.lang.annotation.*;
import java.util.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class AnnotatedElementAccessor implements AnnotationAccessor
{
    public AnnotatedElementAccessor(final AnnotatedElement obj) {
        this.element = Objects.requireNonNull(obj, \u6d76\u6541\u5bc9\u6fff\u6379\u6c08\u5acc\u4eb7\u5dc6\u612a\u5d1f\u64c3\u5b9e\u6db3\u62e8\u4fba\u5a66\u5d08\u6c88\u4fe6\u5c2a\u7095\u59b0\u63a3\u66e0\u6c97\u5d46\u6f6a\u681b\u6324\u5159\u5de1\u5a8a\u643b\u5282\u5840\u59dc\u6f39\u542b\u56da\u69ba(896630262, 809984009, "\u025f\u025a\u024b\u0255\u024c\u0241\u020e\u024f\u0267\u0253\u020d\u0251\u0259\u0253\u0206\u0250\u024b\u0212\u0272\u64d5\u58d8\u6dda", 1205267724, 166261410));
    }
    
    @Override
    public <A extends Annotation> A annotation(final Class<A> clazz) {
        return this.element.getAnnotation(clazz);
    }
    
    @Override
    public Collection<Annotation> annotations() {
        return Collections.unmodifiableCollection((Collection<? extends Annotation>)Arrays.asList(this.element.getAnnotations()));
    }
    
    public static int ColonialObfuscator_\u6e1a\u6110\u68b1\u6ba8\u5e60\u6f1e\u6cbf\u7077\u611b\u5000\u5f69\u57e0\u6cc8\u6824\u5e67\u5171\u67e0\u5081\u61f8\u68ff\u6c6a\u500b\u5fee\u58d5\u51b5\u5ff5\u69ac\u6f54\u6a25\u5e61\u5350\u6128\u5d22\u4ef3\u60ad\u689b\u5f6c\u69a8\u5d25\u666b\u5517(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
