package cloud.commandframework.keys;

import org.apiguardian.api.*;
import io.leangen.geantyref.*;
import java.util.*;

@API(status = API.Status.STABLE, since = "1.4.0")
public final class SimpleCloudKey<T> implements CloudKey<T>
{
    public SimpleCloudKey(final String name, final TypeToken<T> type) {
        this.name = name;
        this.type = type;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public TypeToken<T> getType() {
        return this.type;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && this.name.equals(((SimpleCloudKey)o).name));
    }
    
    @Override
    public int hashCode() {
        final Object[] values = { null };
        "\u5a5d\u5447\u61f1\u6f46\u6aa8".length();
        "\u6e34\u56e1\u6f03".length();
        "\u64c2\u5270\u504a\u65db\u4e26".length();
        values[0] = this.name;
        return Objects.hash(values);
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    public static int ColonialObfuscator_\u5673\u70b3\u5cf2\u6ef6\u6fec\u681c\u6768\u5604\u6001\u60be\u5247\u662e\u5312\u5a9e\u60be\u63e9\u4f95\u5545\u5170\u5c44\u6046\u6edf\u5c3b\u5e16\u524b\u518f\u6f08\u6dff\u5a73\u68fb\u63ae\u6115\u5cd5\u6255\u5c15\u6c9d\u544c\u5c9f\u5a49\u5b25\u5b6f(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
