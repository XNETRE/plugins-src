package cloud.commandframework.keys;

import org.apiguardian.api.*;

@FunctionalInterface
@API(status = API.Status.STABLE, since = "1.4.0")
public interface CloudKeyHolder<T>
{
    CloudKey<T> getKey();
}
