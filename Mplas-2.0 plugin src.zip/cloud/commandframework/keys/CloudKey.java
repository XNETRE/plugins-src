package cloud.commandframework.keys;

import org.apiguardian.api.*;
import io.leangen.geantyref.*;

@API(status = API.Status.STABLE, since = "1.4.0")
public interface CloudKey<T>
{
    String getName();
    
    TypeToken<T> getType();
}
