package cloud.commandframework;

import org.apiguardian.api.*;

@Deprecated
@API(status = API.Status.DEPRECATED, since = "1.4.0")
public final class Description implements ArgumentDescription
{
    public Description(final String description) {
        this.description = description;
    }
    
    @Override
    public String getDescription() {
        return this.description;
    }
    
    @Override
    public String toString() {
        return this.description;
    }
    
    public static int ColonialObfuscator_\u5a27\u6e85\u70cc\u5370\u633d\u4e9e\u639b\u57d1\u6581\u60a7\u5137\u6507\u5d5c\u5027\u5729\u6441\u4f69\u6de2\u7051\u6afe\u67cb\u57aa\u6d4b\u4e9b\u51f0\u590a\u508d\u5d17\u6897\u5453\u6bde\u5a54\u7127\u69c0\u51ee\u5568\u562f\u5f90\u6b99\u5f4e\u60e8(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
