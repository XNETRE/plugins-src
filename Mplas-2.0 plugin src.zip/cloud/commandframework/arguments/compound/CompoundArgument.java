package cloud.commandframework.arguments.compound;

import cloud.commandframework.types.tuples.*;
import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import io.leangen.geantyref.*;
import cloud.commandframework.context.*;
import java.util.*;
import cloud.commandframework.arguments.parser.*;

@API(status = API.Status.STABLE)
public class CompoundArgument<T extends Tuple, C, O> extends CommandArgument<C, O>
{
    public CompoundArgument(final boolean b, final String s, final Tuple names, final Tuple parserTuple, final Tuple types, final BiFunction<C, T, O> biFunction, final Function<Object[], T> function, final TypeToken<O> typeToken) {
        super(b, s, new CompoundParser<Object, Object, O>(parserTuple, biFunction, function, null), \u5749\u650a\u5e52\u51af\u70a9\u6e6f\u5080\u6f50\u6765\u5156\u53d1\u6101\u57c9\u5ae5\u618f\u5bdf\u6a83\u55dd\u67cd\u698f\u57b6\u696f\u68fb\u5831\u6b5f\u692f\u6610\u5173\u5b44\u5bde\u6c26\u4fa8\u6160\u5611\u5c84\u6485\u6bbc\u6727\u5ae6\u569b\u5211(-1992374766, -1073477595, "", -832191655, -1900633475), typeToken, null);
        this.parserTuple = parserTuple;
        this.names = names;
        this.types = types;
    }
    
    public Tuple getParserTuple() {
        return this.parserTuple;
    }
    
    public Tuple getNames() {
        return this.names;
    }
    
    public Tuple getTypes() {
        return this.types;
    }
    
    public static int ColonialObfuscator_\u5168\u70a7\u5480\u6c12\u6ec3\u57d8\u5c11\u68d1\u5729\u6174\u6c7b\u61f1\u5e0d\u6d81\u5bfd\u7042\u57c0\u6e43\u573d\u53e0\u5936\u50f7\u6657\u4fe6\u4f77\u6091\u514d\u7115\u5ed9\u5be5\u6d92\u5119\u712b\u6a9b\u6b75\u55ba\u5002\u57f4\u5f9f\u50ec\u6dca(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
