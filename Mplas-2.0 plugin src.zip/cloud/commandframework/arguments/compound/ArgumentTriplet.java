package cloud.commandframework.arguments.compound;

import org.apiguardian.api.*;
import java.util.function.*;
import io.leangen.geantyref.*;
import cloud.commandframework.types.tuples.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;

@API(status = API.Status.STABLE)
public class ArgumentTriplet<C, U, V, W, O> extends CompoundArgument<Triplet<U, V, W>, C, O>
{
    public ArgumentTriplet(final boolean b, final String s, final Triplet<String, String, String> triplet, final Triplet<Class<U>, Class<V>, Class<W>> triplet2, final Triplet<ArgumentParser<C, U>, ArgumentParser<C, V>, ArgumentParser<C, W>> triplet3, final BiFunction<C, Triplet<U, V, W>, O> biFunction, final TypeToken<O> typeToken) {
        super(b, s, (Tuple)triplet, (Tuple)triplet3, (Tuple)triplet2, biFunction, array -> Triplet.of(array[0], array[1], array[2]), typeToken);
    }
    
    public static int ColonialObfuscator_\u571f\u70dd\u6e3a\u67fb\u66b7\u5c78\u6ec1\u6055\u573a\u4f26\u6eea\u6c2b\u5aea\u608e\u667e\u6516\u5cf5\u6964\u5a08\u5423\u6a0c\u6bc0\u5898\u5e89\u5e6b\u6b5a\u6706\u62f2\u6dc3\u6643\u54e9\u6fe0\u6562\u4e8b\u6d5e\u68a8\u541c\u563c\u5694\u51d5\u5bb8(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
