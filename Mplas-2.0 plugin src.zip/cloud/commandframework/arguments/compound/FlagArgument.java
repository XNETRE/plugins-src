package cloud.commandframework.arguments.compound;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import cloud.commandframework.arguments.flags.*;
import io.leangen.geantyref.*;
import cloud.commandframework.keys.*;
import cloud.commandframework.context.*;
import cloud.commandframework.arguments.parser.*;
import java.util.regex.*;
import java.util.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.captions.*;

@API(status = API.Status.STABLE)
public final class FlagArgument<C> extends CommandArgument<C, Object>
{
    public FlagArgument(final Collection<CommandFlag<?>> flags) {
        super(false, \u57bc\u6f19\u6649\u53fc\u6fc3\u52b1\u65b0\u52be\u7099\u600f\u4fda\u7083\u630b\u6d7b\u5c55\u5f46\u6598\u5d15\u6292\u61ba\u5d55\u4e9f\u6225\u629c\u6f0e\u63bb\u6c38\u5bac\u5fa3\u5f5a\u6fcf\u701a\u6d2e\u517c\u647e\u540a\u4ee6\u6af5\u6037\u5f36\u650a(-67624925, -1460099418, "\u6647\u6662\u666d\u666f\u667b", 390307265, 1251704102), new FlagArgumentParser<Object>(flags.toArray(new CommandFlag[0]), null), Object.class);
        this.flags = flags;
    }
    
    public Collection<CommandFlag<?>> getFlags() {
        return Collections.unmodifiableCollection((Collection<? extends CommandFlag<?>>)this.flags);
    }
    
    public static int ColonialObfuscator_\u5d38\u5adb\u64ba\u5521\u6681\u69f1\u621a\u6651\u53ba\u6314\u5da0\u51d8\u68e2\u682b\u5f2f\u68b6\u4e5f\u4e2f\u5bba\u62ae\u5fee\u507d\u6926\u6303\u6449\u6ae5\u6f56\u5599\u5f53\u4eee\u67ca\u5d51\u522f\u57f4\u5697\u60d4\u5f61\u6961\u6bfd\u6bd3\u53d2(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
