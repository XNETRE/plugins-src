package cloud.commandframework.arguments.compound;

import org.apiguardian.api.*;
import java.util.function.*;
import io.leangen.geantyref.*;
import cloud.commandframework.types.tuples.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;

@API(status = API.Status.STABLE)
public class ArgumentPair<C, U, V, O> extends CompoundArgument<Pair<U, V>, C, O>
{
    public ArgumentPair(final boolean b, final String s, final Pair<String, String> pair, final Pair<Class<U>, Class<V>> pair2, final Pair<ArgumentParser<C, U>, ArgumentParser<C, V>> pair3, final BiFunction<C, Pair<U, V>, O> biFunction, final TypeToken<O> typeToken) {
        super(b, s, (Tuple)pair, (Tuple)pair3, (Tuple)pair2, biFunction, array -> Pair.of(array[0], array[1]), typeToken);
    }
    
    public static int ColonialObfuscator_\u4f09\u6bdc\u7017\u5e0e\u6beb\u6e70\u70e8\u6bfd\u67a9\u5d09\u5646\u62ef\u5746\u69f4\u7040\u500d\u64ee\u4fcc\u524b\u5199\u6a49\u512e\u6285\u510f\u54de\u69c9\u545e\u61b9\u5ebf\u583c\u619f\u6be9\u5bc9\u4fe4\u60c3\u5c69\u59b2\u5aed\u6efc\u6265\u5a0c(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
