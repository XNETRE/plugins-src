package cloud.commandframework.arguments;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import java.util.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.exceptions.parsing.*;

@API(status = API.Status.STABLE)
public final class StaticArgument<C> extends CommandArgument<C, String>
{
    public StaticArgument(final boolean b, final String s, final String[] array) {
        super(b, s, new StaticArgumentParser<Object>(s, array, null), String.class);
    }
    
    public void registerAlias(final String s) {
        ((StaticArgumentParser)this.getParser()).insertAlias(s);
    }
    
    public Set<String> getAliases() {
        return Collections.unmodifiableSet((Set<? extends String>)((StaticArgumentParser)this.getParser()).getAcceptedStrings());
    }
    
    public List<String> getAlternativeAliases() {
        "\u68a3\u692f\u6983".length();
        "\u50f3\u4f83\u6cc9".length();
        "\u5517\u6880\u525d\u5239\u6be5".length();
        "\u5066".length();
        return Collections.unmodifiableList((List<? extends String>)new ArrayList<String>(StaticArgumentParser.access$100((StaticArgumentParser)this.getParser())));
    }
    
    public static int ColonialObfuscator_\u56bc\u6693\u4e4c\u7008\u6ede\u70f9\u6a0c\u5b44\u58d6\u5a1f\u62fa\u5b1f\u6020\u5b69\u523f\u5f86\u557d\u6e49\u6457\u6535\u6da3\u65a1\u6244\u5180\u536c\u711d\u6547\u55f7\u52c5\u57a6\u6b27\u52cc\u6fb7\u5a29\u57d6\u6ed2\u59c2\u5b5e\u69cc\u51c3\u6f37(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
