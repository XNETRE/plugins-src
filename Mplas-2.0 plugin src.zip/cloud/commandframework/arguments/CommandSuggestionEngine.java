package cloud.commandframework.arguments;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import java.util.*;

@API(status = API.Status.STABLE)
public interface CommandSuggestionEngine<C>
{
    List<String> getSuggestions(final CommandContext<C> p0, final String p1);
}
