package cloud.commandframework.arguments;

import org.apiguardian.api.*;
import java.util.regex.*;
import io.leangen.geantyref.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.keys.*;
import java.util.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;

@API(status = API.Status.STABLE)
public class CommandArgument<C, T> implements Comparable<CommandArgument<?, ?>>, CloudKeyHolder<T>
{
    @API(status = API.Status.STABLE, since = "1.4.0")
    public CommandArgument(final boolean required, final String obj, final ArgumentParser<C, T> obj2, final String defaultValue, final TypeToken<T> valueType, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription obj3, final Collection<BiFunction<CommandContext<C>, Queue<String>, ArgumentParseResult<Boolean>>> c) {
        this.argumentRegistered = false;
        this.required = required;
        this.name = Objects.requireNonNull(obj, \u57b9\u6508\u6c17\u6632\u54e2\u5ef3\u6295\u6076\u5ed2\u5a15\u6d24\u5e9c\u5278\u67d6\u657b\u5ce8\u70c4\u6920\u5e57\u56d0\u6446\u6983\u5f2d\u638d\u6e5d\u54d9\u5c59\u6180\u618d\u52d9\u61c6\u54ae\u583a\u5c55\u5125\u6715\u60c1\u64ce\u570a\u6907\u55ef(-1696575074, -90201714, "\u8812\u881e\u8810\u8818\u885d\u8810\u8815\u8803\u8878\u8804\u8800\u880b\u8858\u880d\u8809\u885a\u880e\u8807\u8832\uea69", -508091097, -951493336));
        if (!CommandArgument.NAME_PATTERN.asPredicate().test(obj)) {
            throw new IllegalArgumentException(\u57b9\u6508\u6c17\u6632\u54e2\u5ef3\u6295\u6076\u5ed2\u5a15\u6d24\u5e9c\u5278\u67d6\u657b\u5ce8\u70c4\u6920\u5e57\u56d0\u6446\u6983\u5f2d\u638d\u6e5d\u54d9\u5c59\u6180\u618d\u52d9\u61c6\u54ae\u583a\u5c55\u5125\u6715\u60c1\u64ce\u570a\u6907\u55ef(-1581706544, 985246396, "\u9847\u983b\u9835\u983d\u9878\u9835\u9824\u982c\u9809\u987f\u9838\u982f\u986d\u983b\u9835\u983f\u983d\u9836\u9815\ufa55\uca33\uf35f\uc43e\uc5c6\uff44", 849990335, 1726608025));
        }
        this.parser = Objects.requireNonNull(obj2, \u57b9\u6508\u6c17\u6632\u54e2\u5ef3\u6295\u6076\u5ed2\u5a15\u6d24\u5e9c\u5278\u67d6\u657b\u5ce8\u70c4\u6920\u5e57\u56d0\u6446\u6983\u5f2d\u638d\u6e5d\u54d9\u5c59\u6180\u618d\u52d9\u61c6\u54ae\u583a\u5c55\u5125\u6715\u60c1\u64ce\u570a\u6907\u55ef(433265050, 799729450, "\u067f\u0665\u0674\u0675\u0663\u066c\u0637\u0674\u065a\u0668\u0634\u066a\u066c\u0668\u063f\u066b\u0676\u0629\u064b\u640b\u546c\u6d70", 242860203, -1014941577));
        this.defaultValue = defaultValue;
        this.valueType = valueType;
        this.suggestionsProvider = ((biFunction == null) ? buildDefaultSuggestionsProvider((CommandArgument<C, ?>)this) : biFunction);
        this.defaultDescription = Objects.requireNonNull(obj3, \u57b9\u6508\u6c17\u6632\u54e2\u5ef3\u6295\u6076\u5ed2\u5a15\u6d24\u5e9c\u5278\u67d6\u657b\u5ce8\u70c4\u6920\u5e57\u56d0\u6446\u6983\u5f2d\u638d\u6e5d\u54d9\u5c59\u6180\u618d\u52d9\u61c6\u54ae\u583a\u5c55\u5125\u6715\u60c1\u64ce\u570a\u6907\u55ef(-2108875773, -1686814687, "\ua3b1\ua3bf\ua3be\ua3bd\ua3a9\ua3b4\ua3a5\ua3c3\ua3a5\ua38a\ua399\ua39d\ua38b\ua383\ua399\ua387\ua380\ua398\ua3b5\uc1a4\uf197\uc8fb\uff95\ufe33\uc4f5\uc56b\ufd04\uc01b\uf77e\uc5cb\ufa76\ued9c\uf793\uce84\uc417", 439380889, 978359309));
        this.argumentPreprocessors = new LinkedList<BiFunction<CommandContext<C>, Queue<String>, ArgumentParseResult<Boolean>>>(c);
        this.key = SimpleCloudKey.of(this.name, this.valueType);
    }
    
    public CommandArgument(final boolean b, final String s, final ArgumentParser<C, T> argumentParser, final String s2, final TypeToken<T> typeToken, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final Collection<BiFunction<CommandContext<C>, Queue<String>, ArgumentParseResult<Boolean>>> collection) {
        this(b, s, argumentParser, s2, typeToken, biFunction, ArgumentDescription.empty(), collection);
    }
    
    public CommandArgument(final boolean b, final String s, final ArgumentParser<C, T> argumentParser, final String s2, final TypeToken<T> typeToken, final BiFunction<CommandContext<C>, String, List<String>> biFunction) {
        this(b, s, argumentParser, s2, typeToken, biFunction, (Collection)Collections.emptyList());
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public CommandArgument(final boolean b, final String s, final ArgumentParser<C, T> argumentParser, final String s2, final TypeToken<T> typeToken, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        this(b, s, argumentParser, s2, typeToken, biFunction, argumentDescription, (Collection)Collections.emptyList());
    }
    
    public CommandArgument(final boolean b, final String s, final ArgumentParser<C, T> argumentParser, final String s2, final Class<T> clazz, final BiFunction<CommandContext<C>, String, List<String>> biFunction) {
        this(b, s, argumentParser, s2, TypeToken.get(clazz), biFunction);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public CommandArgument(final boolean b, final String s, final ArgumentParser<C, T> argumentParser, final String s2, final Class<T> clazz, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        this(b, s, argumentParser, s2, TypeToken.get(clazz), biFunction, argumentDescription);
    }
    
    public CommandArgument(final boolean b, final String s, final ArgumentParser<C, T> argumentParser, final Class<T> clazz) {
        this(b, s, argumentParser, \u57b9\u6508\u6c17\u6632\u54e2\u5ef3\u6295\u6076\u5ed2\u5a15\u6d24\u5e9c\u5278\u67d6\u657b\u5ce8\u70c4\u6920\u5e57\u56d0\u6446\u6983\u5f2d\u638d\u6e5d\u54d9\u5c59\u6180\u618d\u52d9\u61c6\u54ae\u583a\u5c55\u5125\u6715\u60c1\u64ce\u570a\u6907\u55ef(739358814, 1510603259, "", 25325432, 1307200694), clazz, null);
    }
    
    @Override
    public final CloudKey<T> getKey() {
        return this.key;
    }
    
    public boolean isRequired() {
        return this.required;
    }
    
    public String getName() {
        return this.name;
    }
    
    public ArgumentParser<C, T> getParser() {
        return this.parser;
    }
    
    @Override
    public final String toString() {
        final String \u57b9\u6508\u6c17\u6632\u54e2\u5ef3\u6295\u6076\u5ed2\u5a15\u6d24\u5e9c\u5278\u67d6\u657b\u5ce8\u70c4\u6920\u5e57\u56d0\u6446\u6983\u5f2d\u638d\u6e5d\u54d9\u5c59\u6180\u618d\u52d9\u61c6\u54ae\u583a\u5c55\u5125\u6715\u60c1\u64ce\u570a\u6907\u55ef = \u57b9\u6508\u6c17\u6632\u54e2\u5ef3\u6295\u6076\u5ed2\u5a15\u6d24\u5e9c\u5278\u67d6\u657b\u5ce8\u70c4\u6920\u5e57\u56d0\u6446\u6983\u5f2d\u638d\u6e5d\u54d9\u5c59\u6180\u618d\u52d9\u61c6\u54ae\u583a\u5c55\u5125\u6715\u60c1\u64ce\u570a\u6907\u55ef(-1004947383, 1702177721, "\u81a4\u81df\u81d7\u81c0\u81c9\u81c3\u81c0\u8194\u81b0\u81ca\u81c3", -1027000568, 1721050426);
        final Object[] args = new Object[2];
        "\u7062\u6540\u6226".length();
        "\u5358".length();
        args[0] = this.getClass().getSimpleName();
        "\u6e26\u6d40".length();
        args[1] = this.name;
        return String.format(\u57b9\u6508\u6c17\u6632\u54e2\u5ef3\u6295\u6076\u5ed2\u5a15\u6d24\u5e9c\u5278\u67d6\u657b\u5ce8\u70c4\u6920\u5e57\u56d0\u6446\u6983\u5f2d\u638d\u6e5d\u54d9\u5c59\u6180\u618d\u52d9\u61c6\u54ae\u583a\u5c55\u5125\u6715\u60c1\u64ce\u570a\u6907\u55ef, args);
    }
    
    public CommandArgument<C, T> addPreprocessor(final BiFunction<CommandContext<C>, Queue<String>, ArgumentParseResult<Boolean>> biFunction) {
        this.argumentPreprocessors.add(biFunction);
        "\u5840\u61d4\u69d4\u6a4f".length();
        return this;
    }
    
    public ArgumentParseResult<Boolean> preprocess(final CommandContext<C> commandContext, final Queue<String> queue) {
        final Iterator<BiFunction<CommandContext<C>, Queue<String>, ArgumentParseResult<Boolean>>> iterator = this.argumentPreprocessors.iterator();
        while (iterator.hasNext()) {
            final ArgumentParseResult<Boolean> argumentParseResult = iterator.next().apply(commandContext, queue);
            if (argumentParseResult.getFailure().isPresent()) {
                return argumentParseResult;
            }
        }
        return ArgumentParseResult.success(true);
    }
    
    public Command<C> getOwningCommand() {
        return this.owningCommand;
    }
    
    public void setOwningCommand(final Command<C> owningCommand) {
        if (this.owningCommand != null) {
            "\u59ac\u6ba3\u51c2\u64db".length();
            "\u6730\u7142".length();
            "\u5246\u5ff5\u5645\u5e84".length();
            final IllegalStateException ex = new IllegalStateException(\u57b9\u6508\u6c17\u6632\u54e2\u5ef3\u6295\u6076\u5ed2\u5a15\u6d24\u5e9c\u5278\u67d6\u657b\u5ce8\u70c4\u6920\u5e57\u56d0\u6446\u6983\u5f2d\u638d\u6e5d\u54d9\u5c59\u6180\u618d\u52d9\u61c6\u54ae\u583a\u5c55\u5125\u6715\u60c1\u64ce\u570a\u6907\u55ef(-329901979, 2095882800, "\u37dd\u37d2\u37dd\u37df\u37d0\u37cd\u3792\u37cc\u37ff\u37c6\u37dd\u37c2\u3439\u342e\u346a\u3431\u3435\u3430\u3419\u5647\u663e\u5f1b\u682c\u69c1\u534d\u52d0\u6aaa\u57e8\u60db", 1005676020, 2093541500));
            "\u61eb\u6d00\u66ce".length();
            "\u661a\u61a0\u59f8\u510c\u6960".length();
            "\u5d23\u5244".length();
            "\u5eec\u56ae".length();
            throw ex;
        }
        this.owningCommand = owningCommand;
    }
    
    public final BiFunction<CommandContext<C>, String, List<String>> getSuggestionsProvider() {
        return this.suggestionsProvider;
    }
    
    public final ArgumentDescription getDefaultDescription() {
        return this.defaultDescription;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final CommandArgument commandArgument = (CommandArgument)o;
        return this.isRequired() == commandArgument.isRequired() && Objects.equals(this.getName(), commandArgument.getName());
    }
    
    @Override
    public final int hashCode() {
        final Object[] values = new Object[2];
        "\u6776\u50a3".length();
        "\u5964".length();
        values[0] = this.isRequired();
        "\u56e3\u655b".length();
        "\u5456\u60d8".length();
        values[1] = this.getName();
        return Objects.hash(values);
    }
    
    @Override
    public final int compareTo(final CommandArgument<?, ?> commandArgument) {
        if (this instanceof StaticArgument) {
            if (commandArgument instanceof StaticArgument) {
                return this.getName().compareTo(commandArgument.getName());
            }
            return -1;
        }
        else {
            if (commandArgument instanceof StaticArgument) {
                return 1;
            }
            return 0;
        }
    }
    
    public String getDefaultValue() {
        return this.defaultValue;
    }
    
    public boolean hasDefaultValue() {
        return !this.isRequired() && !this.getDefaultValue().isEmpty();
    }
    
    public TypeToken<T> getValueType() {
        return this.valueType;
    }
    
    public CommandArgument<C, T> copy() {
        final Builder<C, T> withParser = ofType(this.valueType, this.name).withSuggestionsProvider(this.suggestionsProvider).withParser(this.parser);
        Builder<C, T> builder;
        if (this.isRequired()) {
            builder = withParser.asRequired();
        }
        else if (this.defaultValue.isEmpty()) {
            builder = withParser.asOptional();
        }
        else {
            builder = withParser.asOptionalWithDefault(this.defaultValue);
        }
        return builder.withDefaultDescription(this.defaultDescription).build();
    }
    
    public boolean isArgumentRegistered() {
        return this.argumentRegistered;
    }
    
    public void setArgumentRegistered() {
        this.argumentRegistered = true;
    }
    
    public static int ColonialObfuscator_\u6b24\u5796\u6c04\u50ba\u50b2\u4fcd\u61b0\u518c\u55a8\u6951\u5cc0\u6e10\u6c46\u5c70\u5364\u4e75\u6e8a\u6676\u5773\u6486\u5a56\u7030\u6782\u5cd2\u4f3f\u648b\u6d8b\u62c5\u51aa\u552b\u594c\u5b2e\u5e23\u5c05\u5d4e\u560c\u4ef9\u600b\u5ebe\u4e93\u4ec0(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
