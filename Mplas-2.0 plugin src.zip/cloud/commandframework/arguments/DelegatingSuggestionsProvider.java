package cloud.commandframework.arguments;

import java.util.function.*;
import cloud.commandframework.context.*;
import java.util.*;
import org.apiguardian.api.*;
import cloud.commandframework.arguments.parser.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class DelegatingSuggestionsProvider<C> implements BiFunction<CommandContext<C>, String, List<String>>
{
    public DelegatingSuggestionsProvider(final String argumentName, final ArgumentParser<C, ?> parser) {
        this.argumentName = argumentName;
        this.parser = parser;
    }
    
    @Override
    public List<String> apply(final CommandContext<C> commandContext, final String s) {
        return this.parser.suggestions(commandContext, s);
    }
    
    @Override
    public String toString() {
        final String \u53fa\u6d22\u6616\u5685\u5565\u51e9\u619e\u6d25\u53b4\u64b1\u619a\u5db7\u67f5\u5a42\u5fc0\u60e6\u64b8\u5478\u6dbd\u7032\u558f\u5669\u58f4\u5ea4\u637d\u7106\u5130\u56d4\u6cb8\u6613\u67d2\u5bd1\u5736\u52c1\u6d73\u5f12\u5118\u6e88\u6adf\u5d6d\u5222 = \u53fa\u6d22\u6616\u5685\u5565\u51e9\u619e\u6d25\u53b4\u64b1\u619a\u5db7\u67f5\u5a42\u5fc0\u60e6\u64b8\u5478\u6dbd\u7032\u558f\u5669\u58f4\u5ea4\u637d\u7106\u5130\u56d4\u6cb8\u6613\u67d2\u5bd1\u5736\u52c1\u6d73\u5f12\u5118\u6e88\u6adf\u5d6d\u5222(1654096080, -309148227, "\u7066\u7068\u7063\u7066\u7064\u7066\u707a\u706d\u7048\u706f\u705e\u7074\u7061\u7072\u7073\u7077\u706a\u7069\u7043\u26e8\u1da3\u2580\u2a37\u2459\u2bac\u2b41\u2417\u2877\u16f3\u134d\u3f70\u1ffd\u2b36\u103c\u162d\u2571\u28ed\u1ff5\u2e56\u3eb9\u21da\u2b88\u133b\u113f\u19ff\u164e\u2c8b\u13f9\u242c\u1399\u25b4\u1703", 808140517, 1224412137);
        final Object[] args = new Object[2];
        "\u5527\u5355\u6366\u6728\u583c".length();
        "\u5223".length();
        "\u5933\u6d6a\u6a2c".length();
        args[0] = this.argumentName;
        "\u53f8".length();
        "\u6124\u69d2\u5b43".length();
        "\u5a22".length();
        args[1] = this.parser.getClass().getCanonicalName();
        return String.format(\u53fa\u6d22\u6616\u5685\u5565\u51e9\u619e\u6d25\u53b4\u64b1\u619a\u5db7\u67f5\u5a42\u5fc0\u60e6\u64b8\u5478\u6dbd\u7032\u558f\u5669\u58f4\u5ea4\u637d\u7106\u5130\u56d4\u6cb8\u6613\u67d2\u5bd1\u5736\u52c1\u6d73\u5f12\u5118\u6e88\u6adf\u5d6d\u5222, args);
    }
    
    public static int ColonialObfuscator_\u55f3\u4eab\u53bc\u66cb\u62ff\u6a06\u7070\u5973\u674c\u5baa\u6c05\u4e31\u524d\u5f99\u4fa8\u5560\u66e8\u6f18\u51c6\u6135\u5fcc\u68f2\u64ff\u6076\u6a75\u6b9c\u6e26\u5b11\u5052\u5d3f\u5d66\u5c9b\u5c08\u53ae\u55d6\u664f\u57a5\u55f4\u5e47\u578b\u6e22(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
