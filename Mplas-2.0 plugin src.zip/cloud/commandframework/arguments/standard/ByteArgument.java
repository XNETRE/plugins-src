package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.exceptions.parsing.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class ByteArgument<C> extends CommandArgument<C, Byte>
{
    public ByteArgument(final boolean b, final String s, final byte min, final byte max, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new ByteParser<C>(min, max), s2, Byte.class, biFunction, argumentDescription);
        this.min = min;
        this.max = max;
    }
    
    public byte getMin() {
        return this.min;
    }
    
    public byte getMax() {
        return this.max;
    }
    
    public static int ColonialObfuscator_\u5b55\u5a84\u6de4\u6f02\u6573\u66dd\u6912\u5bec\u51d9\u5db8\u643a\u5f9e\u581e\u5d2c\u66ad\u54bd\u527c\u6113\u5f1e\u5729\u5fc2\u67df\u66f3\u6a10\u4f51\u5502\u56ff\u6089\u6ea1\u5c05\u54ca\u4ff9\u6ffb\u6a36\u5796\u578f\u6226\u6288\u6c5a\u65c7\u4ff3(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
