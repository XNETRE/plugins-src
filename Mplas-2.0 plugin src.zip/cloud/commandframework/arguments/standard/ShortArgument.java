package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.exceptions.parsing.*;
import java.util.*;

@API(status = API.Status.STABLE, since = "1.5.0")
public final class ShortArgument<C> extends CommandArgument<C, Short>
{
    public ShortArgument(final boolean b, final String s, final short min, final short max, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new ShortParser<C>(min, max), s2, Short.class, biFunction, argumentDescription);
        this.min = min;
        this.max = max;
    }
    
    public short getMin() {
        return this.min;
    }
    
    public short getMax() {
        return this.max;
    }
    
    public static int ColonialObfuscator_\u6e6c\u6b5d\u61ed\u6029\u5e39\u5203\u6197\u6638\u54c1\u65eb\u6553\u5c60\u5b56\u711c\u56e2\u65b7\u63a7\u5fed\u5628\u4ee1\u5608\u5f54\u5ff7\u6ece\u5fd4\u6a8c\u61bd\u5178\u5878\u571b\u5a0a\u53cf\u6370\u5ae8\u5b92\u6a40\u5078\u5298\u4e62\u6c0f\u5a8f(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
