package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.exceptions.parsing.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class LongArgument<C> extends CommandArgument<C, Long>
{
    public LongArgument(final boolean b, final String s, final long min, final long max, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new LongParser<C>(min, max), s2, Long.class, biFunction, argumentDescription);
        this.min = min;
        this.max = max;
    }
    
    public long getMin() {
        return this.min;
    }
    
    public long getMax() {
        return this.max;
    }
    
    public static int ColonialObfuscator_\u6027\u5c18\u70dc\u51eb\u6a30\u6a1a\u5b29\u6fa1\u6fde\u50ff\u6175\u51da\u6ae2\u5d00\u4e21\u4ff4\u6c9d\u5cd0\u667b\u6920\u6738\u4f17\u5993\u65cb\u69f1\u580a\u6a83\u6bb9\u6e2c\u65a5\u5b69\u5e05\u6654\u51d3\u5524\u615e\u536b\u5e46\u579c\u59af\u5a06(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
