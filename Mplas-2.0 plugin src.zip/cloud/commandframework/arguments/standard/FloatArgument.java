package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.exceptions.parsing.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class FloatArgument<C> extends CommandArgument<C, Float>
{
    public FloatArgument(final boolean b, final String s, final float min, final float max, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new FloatParser<C>(min, max), s2, Float.class, biFunction, argumentDescription);
        this.min = min;
        this.max = max;
    }
    
    public float getMin() {
        return this.min;
    }
    
    public float getMax() {
        return this.max;
    }
    
    public static int ColonialObfuscator_\u67e8\u55ab\u593d\u5ee0\u6044\u68db\u5bff\u5448\u5be0\u6b7d\u6cc2\u5aae\u63b3\u67bc\u5c41\u4f2a\u5b87\u5d55\u65bf\u6147\u52ca\u5184\u588a\u6668\u4fa2\u6d48\u6d46\u689a\u6693\u5eb0\u585e\u6606\u65d8\u5a47\u4f07\u6cc3\u5242\u6432\u6ebc\u6c81\u6976(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
