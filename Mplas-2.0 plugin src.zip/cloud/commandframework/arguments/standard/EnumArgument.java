package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import java.util.stream.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.captions.*;
import java.util.*;

@API(status = API.Status.STABLE)
public class EnumArgument<C, E extends Enum<E>> extends CommandArgument<C, E>
{
    public EnumArgument(final Class<E> clazz, final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new EnumParser<Object, E>(clazz), s2, clazz, (BiFunction<CommandContext<Object>, String, List<String>>)biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u6627\u50a4\u500b\u51cd\u7061\u63e7\u5a3a\u6514\u5ae5\u57dd\u691f\u65c3\u511e\u4e23\u5eeb\u5249\u5ec0\u641d\u6db5\u70ab\u5c46\u6a02\u6417\u65a0\u6e13\u6822\u656a\u678c\u6b91\u6447\u4ffe\u6f69\u6480\u6494\u50ed\u5cbc\u56a5\u61cf\u6b8f\u6028\u6e1f(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
