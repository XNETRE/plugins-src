package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.exceptions.parsing.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class IntegerArgument<C> extends CommandArgument<C, Integer>
{
    public IntegerArgument(final boolean b, final String s, final int min, final int max, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new IntegerParser<C>(min, max), s2, Integer.class, biFunction, argumentDescription);
        this.min = min;
        this.max = max;
    }
    
    public int getMin() {
        return this.min;
    }
    
    public int getMax() {
        return this.max;
    }
    
    public static int ColonialObfuscator_\u66c0\u62d5\u6856\u6687\u4eb5\u5100\u6359\u692c\u6c1e\u584e\u6295\u5728\u6c5a\u53bc\u52d2\u65c8\u5438\u6b15\u638f\u6c2a\u5969\u6d69\u5661\u6cca\u6808\u608b\u5261\u501b\u5396\u556b\u60e1\u51aa\u5500\u5813\u5783\u6118\u69af\u6989\u635d\u70b2\u59d1(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
