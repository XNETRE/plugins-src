package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import java.time.*;
import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import java.util.regex.*;
import java.util.function.*;
import java.util.*;
import java.util.stream.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.captions.*;

@API(status = API.Status.STABLE, since = "1.7.0")
public final class DurationArgument<C> extends CommandArgument<C, Duration>
{
    public DurationArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new Parser<C>(), s2, Duration.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u65ad\u57fa\u5f83\u6c11\u6b02\u5cee\u5882\u6bff\u5828\u5db0\u6307\u65fe\u70fc\u5e63\u5482\u62be\u6bbe\u5265\u6eb2\u710c\u6be3\u6149\u4e20\u5fbf\u54ff\u5264\u64ec\u5bf0\u6338\u6cd1\u6d9a\u5deb\u568a\u6f0f\u6210\u5fa0\u5a52\u4ead\u5bb4\u653a\u5957(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
