package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.util.*;
import java.util.regex.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.captions.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class StringArgument<C> extends CommandArgument<C, String>
{
    public StringArgument(final boolean b, final String s, final StringMode stringMode, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new StringParser<C>(stringMode, biFunction), s2, String.class, biFunction, argumentDescription);
        this.stringMode = stringMode;
    }
    
    public StringMode getStringMode() {
        return this.stringMode;
    }
    
    public static int ColonialObfuscator_\u6551\u6982\u4fcb\u4eca\u589d\u65d6\u5855\u5394\u6012\u6c05\u6db4\u6599\u6843\u6c8d\u52ef\u613d\u4f45\u5230\u63d4\u641a\u6c23\u5429\u58d5\u599f\u6304\u5191\u5805\u591f\u5f76\u6d5c\u52cf\u6646\u633b\u5839\u6368\u55e1\u712f\u5ae8\u6fe5\u5228\u61d1(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
