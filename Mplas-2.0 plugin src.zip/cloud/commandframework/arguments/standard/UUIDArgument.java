package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.captions.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class UUIDArgument<C> extends CommandArgument<C, UUID>
{
    public UUIDArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new UUIDParser<C>(), s2, UUID.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u6ded\u61d3\u6e39\u60bd\u673d\u6fc0\u5aa7\u5670\u56d6\u5826\u5d7d\u5fd1\u4fbd\u51db\u6b2d\u5ba9\u5ba6\u5e4b\u568d\u4f36\u57e9\u51b3\u5e6b\u6197\u4ef2\u6c1f\u6760\u5794\u5da1\u5195\u5cc8\u6240\u65ef\u6d20\u6ef6\u562c\u5f59\u531a\u5152\u6f54\u5e7d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
