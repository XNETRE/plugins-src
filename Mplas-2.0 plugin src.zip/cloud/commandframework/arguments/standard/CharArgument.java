package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.captions.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class CharArgument<C> extends CommandArgument<C, Character>
{
    public CharArgument(final boolean b, final String s, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new CharacterParser<C>(), s2, Character.class, biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u5ce6\u6c3a\u55d4\u5da3\u5b6d\u6b93\u7133\u4f1a\u5429\u68b7\u6bf1\u4eff\u5dd5\u6d13\u4ef4\u596a\u6b61\u6c3d\u5f91\u565f\u6c43\u55ed\u5d76\u544d\u67d7\u5e85\u61da\u56db\u6fbc\u6346\u5689\u5bf7\u59c8\u53e0\u6bb1\u708f\u507e\u55e1\u5876\u6d4e\u5928(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
