package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import java.util.stream.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.captions.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class BooleanArgument<C> extends CommandArgument<C, Boolean>
{
    public BooleanArgument(final boolean b, final String s, final boolean liberal, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new BooleanParser<C>(liberal), s2, Boolean.class, biFunction, argumentDescription);
        this.liberal = liberal;
    }
    
    public boolean isLiberal() {
        return this.liberal;
    }
    
    public static int ColonialObfuscator_\u61c0\u593b\u5494\u512a\u5f1a\u5942\u6689\u5f67\u68e6\u63d7\u66cc\u6700\u6042\u4f6b\u5eef\u6d88\u52f7\u6336\u6e47\u4f2c\u528d\u643c\u62d2\u7126\u5f47\u50fb\u625e\u563f\u627f\u5be1\u5961\u63ae\u607c\u57f8\u6d8b\u6500\u6712\u4ef2\u5382\u6d65\u549a(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
