package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.exceptions.parsing.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class DoubleArgument<C> extends CommandArgument<C, Double>
{
    public DoubleArgument(final boolean b, final String s, final double min, final double max, final String s2, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription) {
        super(b, s, new DoubleParser<C>(min, max), s2, Double.class, biFunction, argumentDescription);
        this.min = min;
        this.max = max;
    }
    
    public double getMin() {
        return this.min;
    }
    
    public double getMax() {
        return this.max;
    }
    
    public static int ColonialObfuscator_\u6c97\u6ffd\u60cc\u516d\u66e3\u4f00\u596a\u700d\u6d45\u5e77\u604c\u6b37\u6e3e\u5ff0\u7005\u5c79\u6556\u525b\u5866\u4f0c\u4fe0\u618e\u4f90\u6453\u5fc7\u6647\u5d0e\u62e3\u6931\u65bb\u4f8f\u5a69\u660b\u5967\u5504\u5c43\u5c12\u66f7\u5955\u5fb3\u58a8(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
