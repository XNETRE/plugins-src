package cloud.commandframework.arguments.standard;

import cloud.commandframework.arguments.*;
import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import io.leangen.geantyref.*;
import java.util.regex.*;
import cloud.commandframework.arguments.parser.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class StringArrayArgument<C> extends CommandArgument<C, String[]>
{
    public StringArrayArgument(final boolean b, final String s, final BiFunction<CommandContext<C>, String, List<String>> biFunction, final ArgumentDescription argumentDescription, final boolean b2) {
        super(b, s, new StringArrayParser<C>(b2), \u53eb\u6c30\u6c64\u523d\u5491\u52fa\u5e2a\u6cce\u54d0\u668f\u58cf\u57f4\u711c\u5c50\u6b3c\u6f54\u686b\u665a\u6bd8\u6ce2\u6b3e\u6475\u60ed\u5e8f\u65f7\u585f\u4f07\u5290\u56b3\u6559\u65b4\u53e9\u4fa4\u687e\u6fc7\u5623\u6f24\u57ef\u6df0\u5dfa\u6514(-1167393158, 1628977541, "", -498703913, 931405684), TypeToken.get(String[].class), biFunction, argumentDescription);
    }
    
    public static int ColonialObfuscator_\u5479\u5f2a\u5dc9\u5d80\u6c12\u66c7\u6dfd\u5193\u6ee3\u52db\u51c1\u5819\u5082\u6d65\u6a93\u4f51\u53e0\u6c34\u5274\u56cd\u5c0f\u659e\u6a2c\u6b10\u6a5e\u5873\u6d95\u6681\u5713\u51e3\u64d8\u5674\u6086\u55ce\u58dc\u6e67\u70b0\u6b6a\u51d8\u68e5\u5d58(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
