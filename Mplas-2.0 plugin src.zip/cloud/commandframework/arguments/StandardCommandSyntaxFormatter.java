package cloud.commandframework.arguments;

import org.apiguardian.api.*;
import cloud.commandframework.*;
import cloud.commandframework.arguments.compound.*;
import java.util.*;
import cloud.commandframework.arguments.flags.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public class StandardCommandSyntaxFormatter<C> implements CommandSyntaxFormatter<C>
{
    @Override
    public final String apply(final List<CommandArgument<C, ?>> list, final CommandTree.Node<CommandArgument<C, ?>> node) {
        final FormattingInstance instance = this.createInstance();
        final Iterator<CommandArgument<C, ?>> iterator = list.iterator();
        while (iterator.hasNext()) {
            final CommandArgument<C, ?> commandArgument = iterator.next();
            if (commandArgument instanceof StaticArgument) {
                instance.appendLiteral((StaticArgument<?>)commandArgument);
            }
            else if (commandArgument instanceof CompoundArgument) {
                instance.appendCompound((CompoundArgument<?, ?, ?>)commandArgument);
            }
            else if (commandArgument instanceof FlagArgument) {
                instance.appendFlag((FlagArgument<?>)commandArgument);
            }
            else if (commandArgument.isRequired()) {
                instance.appendRequired(commandArgument);
            }
            else {
                instance.appendOptional(commandArgument);
            }
            if (iterator.hasNext()) {
                instance.appendBlankSpace();
            }
        }
        for (CommandTree.Node<CommandArgument<C, ?>> node2 = node; node2 != null && !node2.isLeaf(); node2 = node2.getChildren().get(0)) {
            if (node2.getChildren().size() > 1) {
                instance.appendBlankSpace();
                final Iterator<CommandTree.Node<CommandArgument<C, ?>>> iterator2 = node2.getChildren().iterator();
                while (iterator2.hasNext()) {
                    final CommandTree.Node<CommandArgument<C, ?>> node3 = iterator2.next();
                    if (node3.getValue() instanceof StaticArgument) {
                        instance.appendName(node3.getValue().getName());
                    }
                    else if (node3.getValue().isRequired()) {
                        instance.appendRequired(node3.getValue());
                    }
                    else {
                        instance.appendOptional(node3.getValue());
                    }
                    if (iterator2.hasNext()) {
                        instance.appendPipe();
                    }
                }
                break;
            }
            final CommandArgument<C, ?> commandArgument2 = node2.getChildren().get(0).getValue();
            if (commandArgument2 instanceof CompoundArgument) {
                instance.appendBlankSpace();
                instance.appendCompound((CompoundArgument<?, ?, ?>)commandArgument2);
            }
            else if (commandArgument2 instanceof FlagArgument) {
                instance.appendBlankSpace();
                instance.appendFlag((FlagArgument<?>)commandArgument2);
            }
            else if (commandArgument2 instanceof StaticArgument) {
                instance.appendBlankSpace();
                instance.appendLiteral((StaticArgument<?>)commandArgument2);
            }
            else {
                instance.appendBlankSpace();
                if (commandArgument2.isRequired()) {
                    instance.appendRequired(commandArgument2);
                }
                else {
                    instance.appendOptional(commandArgument2);
                }
            }
        }
        return instance.toString();
    }
    
    public FormattingInstance createInstance() {
        "\u60c0\u6232\u636b\u608a".length();
        "\u6464\u5b8c\u53f7".length();
        "\u6348".length();
        "\u6495\u6505\u509a\u6e40\u6a8b".length();
        return new FormattingInstance();
    }
    
    public static int ColonialObfuscator_\u56bb\u601b\u6c22\u50e9\u644a\u6946\u4e37\u66a3\u6908\u6a9c\u69c1\u70ff\u55c3\u5de4\u51a7\u657a\u65e3\u5329\u66bc\u4f09\u6476\u6e04\u6de9\u57df\u5d14\u5bba\u66e0\u638d\u6914\u6f38\u5352\u4e8d\u6c67\u541a\u68c9\u6e2a\u511f\u63ed\u6d77\u645b\u5c66(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
