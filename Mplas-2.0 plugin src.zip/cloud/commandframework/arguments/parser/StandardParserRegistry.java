package cloud.commandframework.arguments.parser;

import org.apiguardian.api.*;
import java.lang.annotation.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import io.leangen.geantyref.*;
import java.lang.reflect.*;
import cloud.commandframework.arguments.standard.*;
import java.util.*;
import cloud.commandframework.annotations.specifier.*;

@API(status = API.Status.STABLE)
public final class StandardParserRegistry<C> implements ParserRegistry<C>
{
    public StandardParserRegistry() {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: invokespecial   java/lang/Object.<init>:()V
        //     4: aload_0        
        //     5: new             Ljava/util/HashMap;
        //     8: dup            
        //     9: invokespecial   java/util/HashMap.<init>:()V
        //    12: putfield        cloud/commandframework/arguments/parser/StandardParserRegistry.namedParsers:Ljava/util/Map;
        //    15: aload_0        
        //    16: new             Ljava/util/HashMap;
        //    19: dup            
        //    20: invokespecial   java/util/HashMap.<init>:()V
        //    23: putfield        cloud/commandframework/arguments/parser/StandardParserRegistry.parserSuppliers:Ljava/util/Map;
        //    26: aload_0        
        //    27: new             Ljava/util/HashMap;
        //    30: dup            
        //    31: invokespecial   java/util/HashMap.<init>:()V
        //    34: putfield        cloud/commandframework/arguments/parser/StandardParserRegistry.annotationMappers:Ljava/util/Map;
        //    37: aload_0        
        //    38: new             Ljava/util/HashMap;
        //    41: dup            
        //    42: invokespecial   java/util/HashMap.<init>:()V
        //    45: putfield        cloud/commandframework/arguments/parser/StandardParserRegistry.namedSuggestionProviders:Ljava/util/Map;
        //    48: aload_0        
        //    49: ldc             Lcloud/commandframework/annotations/specifier/Range;.class
        //    51: new             Lcloud/commandframework/arguments/parser/StandardParserRegistry$RangeMapper;
        //    54: dup            
        //    55: aconst_null    
        //    56: invokespecial   cloud/commandframework/arguments/parser/StandardParserRegistry$RangeMapper.<init>:(Lcloud/commandframework/arguments/parser/StandardParserRegistry$1;)V
        //    59: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerAnnotationMapper:(Ljava/lang/Class;Ljava/util/function/BiFunction;)V
        //    62: aload_0        
        //    63: ldc             Lcloud/commandframework/annotations/specifier/Greedy;.class
        //    65: new             Lcloud/commandframework/arguments/parser/StandardParserRegistry$GreedyMapper;
        //    68: dup            
        //    69: aconst_null    
        //    70: invokespecial   cloud/commandframework/arguments/parser/StandardParserRegistry$GreedyMapper.<init>:(Lcloud/commandframework/arguments/parser/StandardParserRegistry$1;)V
        //    73: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerAnnotationMapper:(Ljava/lang/Class;Ljava/util/function/BiFunction;)V
        //    76: aload_0        
        //    77: ldc             Lcloud/commandframework/annotations/specifier/Quoted;.class
        //    79: invokedynamic   BootstrapMethod #0, apply:()Ljava/util/function/BiFunction;
        //    84: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerAnnotationMapper:(Ljava/lang/Class;Ljava/util/function/BiFunction;)V
        //    87: aload_0        
        //    88: ldc             Lcloud/commandframework/annotations/specifier/Liberal;.class
        //    90: invokedynamic   BootstrapMethod #1, apply:()Ljava/util/function/BiFunction;
        //    95: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerAnnotationMapper:(Ljava/lang/Class;Ljava/util/function/BiFunction;)V
        //    98: aload_0        
        //    99: ldc             Lcloud/commandframework/annotations/specifier/FlagYielding;.class
        //   101: invokedynamic   BootstrapMethod #2, apply:()Ljava/util/function/BiFunction;
        //   106: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerAnnotationMapper:(Ljava/lang/Class;Ljava/util/function/BiFunction;)V
        //   109: aload_0        
        //   110: ldc             Ljava/lang/Byte;.class
        //   112: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   115: invokedynamic   BootstrapMethod #3, apply:()Ljava/util/function/Function;
        //   120: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   123: aload_0        
        //   124: ldc             Ljava/lang/Short;.class
        //   126: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   129: invokedynamic   BootstrapMethod #4, apply:()Ljava/util/function/Function;
        //   134: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   137: aload_0        
        //   138: ldc             Ljava/lang/Integer;.class
        //   140: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   143: invokedynamic   BootstrapMethod #5, apply:()Ljava/util/function/Function;
        //   148: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   151: aload_0        
        //   152: ldc             Ljava/lang/Long;.class
        //   154: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   157: invokedynamic   BootstrapMethod #6, apply:()Ljava/util/function/Function;
        //   162: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   165: aload_0        
        //   166: ldc             Ljava/lang/Float;.class
        //   168: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   171: invokedynamic   BootstrapMethod #7, apply:()Ljava/util/function/Function;
        //   176: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   179: aload_0        
        //   180: ldc             Ljava/lang/Double;.class
        //   182: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   185: invokedynamic   BootstrapMethod #8, apply:()Ljava/util/function/Function;
        //   190: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   193: aload_0        
        //   194: ldc             Ljava/lang/Character;.class
        //   196: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   199: invokedynamic   BootstrapMethod #9, apply:()Ljava/util/function/Function;
        //   204: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   207: aload_0        
        //   208: ldc             [Ljava/lang/String;.class
        //   210: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   213: invokedynamic   BootstrapMethod #10, apply:()Ljava/util/function/Function;
        //   218: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   221: aload_0        
        //   222: ldc             Ljava/lang/String;.class
        //   224: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   227: invokedynamic   BootstrapMethod #11, apply:()Ljava/util/function/Function;
        //   232: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   235: aload_0        
        //   236: ldc_w           Ljava/lang/Boolean;.class
        //   239: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   242: invokedynamic   BootstrapMethod #12, apply:()Ljava/util/function/Function;
        //   247: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   250: aload_0        
        //   251: ldc_w           Ljava/util/UUID;.class
        //   254: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   257: invokedynamic   BootstrapMethod #13, apply:()Ljava/util/function/Function;
        //   262: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   265: aload_0        
        //   266: ldc_w           Ljava/time/Duration;.class
        //   269: invokestatic    io/leangen/geantyref/TypeToken.get:(Ljava/lang/Class;)Lio/leangen/geantyref/TypeToken;
        //   272: invokedynamic   BootstrapMethod #14, apply:()Ljava/util/function/Function;
        //   277: invokevirtual   cloud/commandframework/arguments/parser/StandardParserRegistry.registerParserSupplier:(Lio/leangen/geantyref/TypeToken;Ljava/util/function/Function;)V
        //   280: return         
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.decompiler.languages.java.ast.NameVariables.generateNameForVariable(NameVariables.java:264)
        //     at com.strobel.decompiler.languages.java.ast.NameVariables.assignNamesToVariables(NameVariables.java:198)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:276)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at us.deathmarine.luyten.FileSaver.doSaveJarDecompiled(FileSaver.java:192)
        //     at us.deathmarine.luyten.FileSaver.access$300(FileSaver.java:45)
        //     at us.deathmarine.luyten.FileSaver$4.run(FileSaver.java:112)
        //     at java.base/java.lang.Thread.run(Thread.java:829)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Override
    public <T> void registerParserSupplier(final TypeToken<T> typeToken, final Function<ParserParameters, ArgumentParser<C, ?>> function) {
        this.parserSuppliers.put(typeToken, function);
        "\u5436\u5ac1\u6202".length();
        "\u66a2\u5caa\u5011\u530e".length();
    }
    
    @Override
    public void registerNamedParserSupplier(final String s, final Function<ParserParameters, ArgumentParser<C, ?>> function) {
        this.namedParsers.put(s, function);
        "\u5d7c\u601f".length();
    }
    
    @Override
    public <A extends Annotation, T> void registerAnnotationMapper(final Class<A> clazz, final BiFunction<A, TypeToken<?>, ParserParameters> biFunction) {
        this.annotationMappers.put(clazz, biFunction);
        "\u6a05".length();
        "\u4f76\u67d1\u5595\u5b82".length();
        "\u6b74".length();
        "\u570e".length();
    }
    
    @Override
    public ParserParameters parseAnnotations(final TypeToken<?> typeToken, final Collection<? extends Annotation> collection) {
        "\u5f14\u62f9".length();
        "\u587d\u69e1\u54c1\u64df\u5e34".length();
        "\u6b81".length();
        final ParserParameters parserParameters = new ParserParameters();
        final BiFunction<? extends Annotation, TypeToken<?>, ParserParameters> biFunction;
        final ParserParameters parserParameters2;
        collection.forEach(annotation -> {
            biFunction = this.annotationMappers.get(annotation.annotationType());
            if (biFunction == null) {
                return;
            }
            else {
                parserParameters2.merge(biFunction.apply(annotation, typeToken));
                return;
            }
        });
        return parserParameters;
    }
    
    @Override
    public <T> Optional<ArgumentParser<C, T>> createParser(final TypeToken<T> typeToken, final ParserParameters parserParameters) {
        TypeToken<T> value;
        if (GenericTypeReflector.erase(typeToken.getType()).isPrimitive()) {
            value = TypeToken.get(StandardParserRegistry.PRIMITIVE_MAPPINGS.get(GenericTypeReflector.erase(typeToken.getType())));
        }
        else {
            value = typeToken;
        }
        final Function<ParserParameters, ArgumentParser<C, ?>> function = this.parserSuppliers.get(value);
        if (function != null) {
            return Optional.of(function.apply(parserParameters));
        }
        if (GenericTypeReflector.isSuperType(Enum.class, value.getType())) {
            "\u500c\u5e05\u6571\u6ed5".length();
            return Optional.of((ArgumentParser<C, T>)new EnumArgument.EnumParser<C, T>((Class<Enum>)GenericTypeReflector.erase(value.getType())));
        }
        return Optional.empty();
    }
    
    @Override
    public <T> Optional<ArgumentParser<C, T>> createParser(final String s, final ParserParameters parserParameters) {
        final Function<ParserParameters, ArgumentParser<C, ?>> function = this.namedParsers.get(s);
        if (function == null) {
            return Optional.empty();
        }
        return Optional.of(function.apply(parserParameters));
    }
    
    @Override
    public void registerSuggestionProvider(final String s, final BiFunction<CommandContext<C>, String, List<String>> biFunction) {
        this.namedSuggestionProviders.put(s.toLowerCase(Locale.ENGLISH), biFunction);
        "\u55e1\u5c59\u5378\u5881".length();
        "\u5bfa".length();
    }
    
    @Override
    public Optional<BiFunction<CommandContext<C>, String, List<String>>> getSuggestionProvider(final String s) {
        return Optional.ofNullable(this.namedSuggestionProviders.get(s.toLowerCase(Locale.ENGLISH)));
    }
    
    public static int ColonialObfuscator_\u5849\u696f\u5914\u6d77\u555c\u6172\u5314\u6f93\u5786\u6038\u68b2\u555e\u6f99\u6a8e\u608b\u65cd\u553a\u5efa\u5dc2\u6fe2\u5c3a\u57bd\u505e\u51b0\u6bc4\u5bdc\u5f45\u5a18\u6b66\u5aee\u52cd\u5926\u628b\u6fe1\u644e\u4fe5\u5ef2\u66c1\u5c7b\u6285\u4f6d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
