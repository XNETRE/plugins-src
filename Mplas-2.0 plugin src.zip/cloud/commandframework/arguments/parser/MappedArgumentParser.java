package cloud.commandframework.arguments.parser;

import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import java.util.*;

@API(status = API.Status.STABLE, since = "1.5.0")
public final class MappedArgumentParser<C, I, O> implements ArgumentParser<C, O>
{
    public MappedArgumentParser(final ArgumentParser<C, I> base, final BiFunction<CommandContext<C>, I, ArgumentParseResult<O>> mapper) {
        this.base = base;
        this.mapper = mapper;
    }
    
    public ArgumentParser<C, I> getBaseParser() {
        return this.base;
    }
    
    @Override
    public ArgumentParseResult<O> parse(final CommandContext<C> commandContext, final Queue<String> queue) {
        return this.base.parse(commandContext, queue).flatMapParsedValue(n -> this.mapper.apply(commandContext, n));
    }
    
    @Override
    public List<String> suggestions(final CommandContext<C> commandContext, final String s) {
        return this.base.suggestions(commandContext, s);
    }
    
    @Override
    public <O1> ArgumentParser<C, O1> map(final BiFunction<CommandContext<C>, O, ArgumentParseResult<O1>> biFunction) {
        "\u6daa\u5e70\u65af\u5886".length();
        return new MappedArgumentParser<C, Object, O1>((ArgumentParser<C, ?>)this.base, (commandContext, n) -> this.mapper.apply(commandContext, n).flatMapParsedValue(o -> biFunction.apply(commandContext, o)));
    }
    
    @Override
    public boolean isContextFree() {
        return this.base.isContextFree();
    }
    
    @Override
    public int getRequestedArgumentCount() {
        return this.base.getRequestedArgumentCount();
    }
    
    @Override
    public int hashCode() {
        return ColonialObfuscator_\u5041\u695b\u607f\u515f\u6783\u558f\u5d66\u5d3b\u510b\u60bf\u4ec7\u67eb\u6aec\u688b\u6fa2\u6e4a\u6b6b\u6052\u4e6e\u4e58\u5384\u5da0\u5f03\u6497\u5245\u69ef\u5305\u575e\u707d\u5c93\u63f7\u5e23\u6f41\u6299\u63da\u58c4\u5b61\u6238\u4f88\u6c2b\u5e8e(ColonialObfuscator_\u5041\u695b\u607f\u515f\u6783\u558f\u5d66\u5d3b\u510b\u60bf\u4ec7\u67eb\u6aec\u688b\u6fa2\u6e4a\u6b6b\u6052\u4e6e\u4e58\u5384\u5da0\u5f03\u6497\u5245\u69ef\u5305\u575e\u707d\u5c93\u63f7\u5e23\u6f41\u6299\u63da\u58c4\u5b61\u6238\u4f88\u6c2b\u5e8e(31, this.base.hashCode()), 7 * this.mapper.hashCode());
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof MappedArgumentParser)) {
            return false;
        }
        final MappedArgumentParser mappedArgumentParser = (MappedArgumentParser)o;
        return this.base.equals(mappedArgumentParser.base) && this.mapper.equals(mappedArgumentParser.mapper);
    }
    
    @Override
    public String toString() {
        "\u5b69\u5cf1".length();
        "\u6907\u50c5\u6dbf".length();
        "\u54a6\u5a9c".length();
        return \u5288\u6975\u544c\u5c56\u579a\u6536\u6c7c\u6242\u56b1\u5445\u5165\u6298\u5c7d\u5093\u64ca\u5271\u5357\u5b7a\u5249\u6fef\u5a49\u4eb9\u5f43\u6cc6\u5cef\u6811\u6485\u6c4c\u519d\u6c61\u50d1\u5ea8\u7102\u5730\u5ec2\u5b77\u6152\u5818\u4ff3\u6438\u5dde(-236788248, 1447852114, "\u2d09\u2d0e\u2d1d\u2d1d\u2d08\u2d01\u2d2d\u2d10\u2d27\u2d1f\u2d02\u2d1a\u2d16\u2d03\u2d24\u2d03\u2d0a\u2d11\u2d2b\u729a\u7a71\u7245\u4a71\u41fc\u43a9\u49d9", 968323875, 676905886) + this.base + ',' + \u5288\u6975\u544c\u5c56\u579a\u6536\u6c7c\u6242\u56b1\u5445\u5165\u6298\u5c7d\u5093\u64ca\u5271\u5357\u5b7a\u5249\u6fef\u5a49\u4eb9\u5f43\u6cc6\u5cef\u6811\u6485\u6c4c\u519d\u6c61\u50d1\u5ea8\u7102\u5730\u5ec2\u5b77\u6152\u5818\u4ff3\u6438\u5dde(1221328853, -982262999, "\u85b2\u8591\u8582\u859e\u858b\u8598\u85de", 498798925, 744927277) + this.mapper + '}';
    }
    
    public static int ColonialObfuscator_\u5041\u695b\u607f\u515f\u6783\u558f\u5d66\u5d3b\u510b\u60bf\u4ec7\u67eb\u6aec\u688b\u6fa2\u6e4a\u6b6b\u6052\u4e6e\u4e58\u5384\u5da0\u5f03\u6497\u5245\u69ef\u5305\u575e\u707d\u5c93\u63f7\u5e23\u6f41\u6299\u63da\u58c4\u5b61\u6238\u4f88\u6c2b\u5e8e(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
