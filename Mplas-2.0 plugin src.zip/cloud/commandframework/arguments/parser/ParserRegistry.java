package cloud.commandframework.arguments.parser;

import org.apiguardian.api.*;
import io.leangen.geantyref.*;
import java.util.function.*;
import java.lang.annotation.*;
import cloud.commandframework.context.*;
import java.util.*;

@API(status = API.Status.STABLE)
public interface ParserRegistry<C>
{
     <T> void registerParserSupplier(final TypeToken<T> p0, final Function<ParserParameters, ArgumentParser<C, ?>> p1);
    
    void registerNamedParserSupplier(final String p0, final Function<ParserParameters, ArgumentParser<C, ?>> p1);
    
     <A extends Annotation, T> void registerAnnotationMapper(final Class<A> p0, final BiFunction<A, TypeToken<?>, ParserParameters> p1);
    
    ParserParameters parseAnnotations(final TypeToken<?> p0, final Collection<? extends Annotation> p1);
    
     <T> Optional<ArgumentParser<C, T>> createParser(final TypeToken<T> p0, final ParserParameters p1);
    
     <T> Optional<ArgumentParser<C, T>> createParser(final String p0, final ParserParameters p1);
    
    @API(status = API.Status.STABLE, since = "1.1.0")
    void registerSuggestionProvider(final String p0, final BiFunction<CommandContext<C>, String, List<String>> p1);
    
    @API(status = API.Status.STABLE, since = "1.1.0")
    Optional<BiFunction<CommandContext<C>, String, List<String>>> getSuggestionProvider(final String p0);
}
