package cloud.commandframework.arguments.parser;

import org.apiguardian.api.*;
import io.leangen.geantyref.*;

@API(status = API.Status.STABLE)
public final class StandardParameters
{
    public static int ColonialObfuscator_\u5a29\u5b76\u5c73\u542e\u6c68\u4eaf\u5139\u5137\u5131\u593b\u5290\u50c7\u700d\u709b\u66c6\u5d64\u5b6b\u536b\u5d28\u5ff9\u5d80\u56ad\u52ae\u5ce8\u6546\u7139\u56f3\u6005\u670d\u61ac\u5e00\u6c3f\u548d\u64f9\u6d07\u53f4\u598c\u6152\u4f3f\u64a7\u6201(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
