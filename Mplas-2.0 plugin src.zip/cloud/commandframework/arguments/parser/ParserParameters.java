package cloud.commandframework.arguments.parser;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class ParserParameters
{
    public ParserParameters() {
        this.internalMap = new HashMap<ParserParameter<?>, Object>();
    }
    
    public <T> boolean has(final ParserParameter<T> parserParameter) {
        return this.internalMap.containsKey(parserParameter);
    }
    
    public <T> void store(final ParserParameter<T> parserParameter, final T t) {
        this.internalMap.put(parserParameter, t);
        "\u64b3".length();
        "\u6c4a\u62a8\u63df\u5a9a\u520c".length();
    }
    
    public <T> T get(final ParserParameter<T> key, final T defaultValue) {
        return (T)this.internalMap.getOrDefault(key, defaultValue);
    }
    
    public void merge(final ParserParameters parserParameters) {
        this.internalMap.putAll(parserParameters.internalMap);
    }
    
    public Map<ParserParameter<?>, Object> getAll() {
        return Collections.unmodifiableMap((Map<? extends ParserParameter<?>, ?>)this.internalMap);
    }
    
    public static int ColonialObfuscator_\u584d\u5c06\u5037\u6f4f\u5bcc\u7061\u6210\u6dbd\u6cd0\u5a7a\u5863\u707f\u6d37\u60be\u61ea\u6f05\u65e3\u4e25\u5ecc\u4ea2\u5dac\u632b\u6924\u5025\u61a5\u64cd\u5cf4\u5302\u6410\u70ef\u62ef\u6778\u4f47\u51b4\u56fd\u6b99\u5329\u6a9f\u5723\u6d09\u4e32(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
