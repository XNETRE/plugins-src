package cloud.commandframework.arguments.parser;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import java.util.function.*;
import java.util.*;

@FunctionalInterface
@API(status = API.Status.STABLE)
public interface ArgumentParser<C, T>
{
    ArgumentParseResult<T> parse(final CommandContext<C> p0, final Queue<String> p1);
    
    default List<String> suggestions(final CommandContext<C> commandContext, final String s) {
        return Collections.emptyList();
    }
    
    @API(status = API.Status.STABLE, since = "1.5.0")
    default <O> ArgumentParser<C, O> map(final BiFunction<CommandContext<C>, T, ArgumentParseResult<O>> obj) {
        "\u6575\u6b17\u51c4\u5973".length();
        "\u59f4\u5ce2\u703d\u5853".length();
        "\u50bf".length();
        "\u51ba\u5dca\u67eb".length();
        return new MappedArgumentParser<C, Object, O>(this, Objects.requireNonNull(obj, "mapper"));
    }
    
    default boolean isContextFree() {
        return false;
    }
    
    @API(status = API.Status.STABLE, since = "1.1.0")
    default int getRequestedArgumentCount() {
        return 1;
    }
}
