package cloud.commandframework.arguments.parser;

import org.apiguardian.api.*;
import io.leangen.geantyref.*;
import java.util.*;

@API(status = API.Status.STABLE)
public class ParserParameter<T>
{
    public ParserParameter(final String key, final TypeToken<T> expectedType) {
        this.key = key;
        this.expectedType = expectedType;
    }
    
    public String getKey() {
        return this.key;
    }
    
    public TypeToken<T> getExpectedType() {
        return this.expectedType;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final ParserParameter parserParameter = (ParserParameter)o;
        return Objects.equals(this.key, parserParameter.key) && Objects.equals(this.expectedType, parserParameter.expectedType);
    }
    
    @Override
    public final int hashCode() {
        final Object[] values = new Object[2];
        "\u661d\u56a4\u588e".length();
        "\u6cf4\u6e7a\u6bb1".length();
        "\u5583\u6718\u709a\u568b".length();
        "\u5830\u65df".length();
        values[0] = this.key;
        "\u6b9c\u6195\u4f53\u5f4a".length();
        "\u5814\u5365\u612a\u525b".length();
        values[1] = this.expectedType;
        return Objects.hash(values);
    }
    
    public static int ColonialObfuscator_\u6ee4\u66a5\u64d7\u6bb7\u64e4\u6780\u660b\u6fef\u675f\u6bdd\u4fb5\u5039\u6389\u6c8f\u5020\u6c9c\u5ec0\u684c\u5a0c\u6d20\u5e16\u63af\u4e91\u5dd2\u6fe0\u636c\u6422\u6e3d\u5f58\u5b5c\u5e93\u6194\u67e8\u698d\u4f63\u5a72\u62a6\u564d\u57ca\u56be\u6597(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
