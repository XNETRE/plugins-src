package cloud.commandframework.arguments.parser;

import org.apiguardian.api.*;
import java.util.*;
import java.util.function.*;

@API(status = API.Status.STABLE)
public abstract class ArgumentParseResult<T>
{
    public abstract Optional<T> getParsedValue();
    
    @API(status = API.Status.STABLE, since = "1.5.0")
    public abstract <U> ArgumentParseResult<U> mapParsedValue(final Function<T, U> p0);
    
    @API(status = API.Status.STABLE, since = "1.5.0")
    public abstract <U> ArgumentParseResult<U> flatMapParsedValue(final Function<T, ArgumentParseResult<U>> p0);
    
    public abstract Optional<Throwable> getFailure();
    
    @API(status = API.Status.STABLE, since = "1.5.0")
    public abstract ArgumentParseResult<T> mapFailure(final Function<Throwable, Throwable> p0);
    
    public static int ColonialObfuscator_\u6673\u598e\u62c4\u5291\u67f2\u6454\u5e0d\u65f0\u5c56\u6805\u6e44\u5a42\u5ffb\u57a7\u54ce\u6bbd\u6ee7\u5d34\u5442\u6edd\u522a\u6cae\u59a7\u6d7c\u4fb9\u5353\u598c\u5429\u57b8\u4fd9\u6430\u6271\u5789\u577d\u5e5c\u6651\u6bc6\u4f40\u565d\u6b20\u6d42(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
