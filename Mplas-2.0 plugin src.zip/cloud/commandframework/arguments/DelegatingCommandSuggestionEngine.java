package cloud.commandframework.arguments;

import org.apiguardian.api.*;
import cloud.commandframework.*;
import cloud.commandframework.context.*;
import cloud.commandframework.internal.*;
import cloud.commandframework.services.*;
import cloud.commandframework.execution.preprocessor.*;
import java.util.*;
import cloud.commandframework.execution.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class DelegatingCommandSuggestionEngine<C> implements CommandSuggestionEngine<C>
{
    public DelegatingCommandSuggestionEngine(final CommandManager<C> commandManager, final CommandTree<C> commandTree) {
        this.commandManager = commandManager;
        this.commandTree = commandTree;
    }
    
    @Override
    public List<String> getSuggestions(final CommandContext<C> commandContext, final String s) {
        "\u52ec\u6816".length();
        final LinkedList<String> tokenize = new CommandInputTokenizer(s).tokenize();
        final String \u658f\u64a0\u5f58\u560e\u58ca\u6c04\u5163\u62c0\u5924\u6dfe\u5603\u52ce\u6565\u63e1\u6952\u66ab\u667b\u50d9\u5250\u5825\u5395\u6427\u5fe5\u547b\u6b12\u596d\u7026\u63ee\u6367\u5fa8\u5c21\u56fb\u5567\u5eb2\u54f7\u568a\u5724\u5a95\u5e23\u5afe\u68d5 = \u658f\u64a0\u5f58\u560e\u58ca\u6c04\u5163\u62c0\u5924\u6dfe\u5603\u52ce\u6565\u63e1\u6952\u66ab\u667b\u50d9\u5250\u5825\u5395\u6427\u5fe5\u547b\u6b12\u596d\u7026\u63ee\u6367\u5fa8\u5c21\u56fb\u5567\u5eb2\u54f7\u568a\u5724\u5a95\u5e23\u5afe\u68d5(-876466942, -1532962985, "\u284d\u2866\u2849\u285a\u284c\u285c\u2863\u286a\u2856\u2879\u287d\u2846\u2841", -367152229, 458449311);
        "\u670c\u5c25\u6d44".length();
        "\u63a1\u62f1\u6e6f".length();
        commandContext.store(\u658f\u64a0\u5f58\u560e\u58ca\u6c04\u5163\u62c0\u5924\u6dfe\u5603\u52ce\u6565\u63e1\u6952\u66ab\u667b\u50d9\u5250\u5825\u5395\u6427\u5fe5\u547b\u6b12\u596d\u7026\u63ee\u6367\u5fa8\u5c21\u56fb\u5567\u5eb2\u54f7\u568a\u5724\u5a95\u5e23\u5afe\u68d5, new LinkedList(tokenize));
        List<String> emptyList;
        if (this.commandManager.preprocessContext(commandContext, tokenize) == State.ACCEPTED) {
            final CommandSuggestionProcessor<C> commandSuggestionProcessor = this.commandManager.commandSuggestionProcessor();
            "\u6eda\u5a77\u64fd\u6e1d\u5160".length();
            "\u6984\u6ae6\u6e6d\u6dbf".length();
            emptyList = commandSuggestionProcessor.apply(new CommandPreprocessingContext<Object>((CommandContext<Object>)commandContext, tokenize), this.commandTree.getSuggestions(commandContext, tokenize));
        }
        else {
            emptyList = Collections.emptyList();
        }
        if (this.commandManager.getSetting(CommandManager.ManagerSettings.FORCE_SUGGESTION) && emptyList.isEmpty()) {
            return DelegatingCommandSuggestionEngine.SINGLE_EMPTY_SUGGESTION;
        }
        return emptyList;
    }
    
    public static int ColonialObfuscator_\u703e\u5d41\u6f7a\u55a3\u53f2\u670f\u500a\u54ac\u5f5c\u60e2\u670d\u62b5\u5161\u626c\u6a48\u5a36\u597c\u6342\u682d\u6463\u636f\u5737\u6827\u691a\u5266\u578e\u565c\u6553\u527e\u6b40\u6cb9\u674b\u66e4\u5252\u6235\u4e6b\u6d7e\u5502\u686c\u5cac\u6fd9(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
