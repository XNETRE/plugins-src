package cloud.commandframework.arguments.flags;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class FlagContext
{
    public FlagContext() {
        this.flagValues = new HashMap<String, List>();
    }
    
    public void addPresenceFlag(final CommandFlag<?> commandFlag) {
        final Object o;
        this.flagValues.computeIfAbsent(commandFlag.getName(), p0 -> {
            // new(java.util.ArrayList.class)
            "\u591e\u5eb4\u4f4b\u62aa\u6f79".length();
            "\u681b\u4f54\u5aec\u6d5f".length();
            new ArrayList();
            return o;
        }).add(FlagContext.FLAG_PRESENCE_VALUE);
        "\u5a86\u59f7".length();
        "\u5d9a\u5e5f".length();
    }
    
    public <T> void addValueFlag(final CommandFlag<T> commandFlag, final T t) {
        final Object o;
        this.flagValues.computeIfAbsent(commandFlag.getName(), p0 -> {
            // new(java.util.ArrayList.class)
            "\u688c".length();
            "\u566e\u6c7d\u5628\u51f5".length();
            "\u5095\u5c41\u5670\u64c5\u6efd".length();
            "\u5ca2\u672e\u61f4\u616f".length();
            new ArrayList();
            return o;
        }).add(t);
        "\u6884\u68c6\u4fe1\u66b2".length();
        "\u58ee\u555a\u5fce\u5cdd".length();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public <T> int count(final CommandFlag<T> commandFlag) {
        return this.getAll(commandFlag).size();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public int count(final String s) {
        return this.getAll(s).size();
    }
    
    public boolean isPresent(final String s) {
        final List list = this.flagValues.get(s);
        return list != null && !list.isEmpty();
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public boolean isPresent(final CommandFlag<Void> commandFlag) {
        return this.isPresent(commandFlag.getName());
    }
    
    @API(status = API.Status.STABLE, since = "1.2.0")
    public <T> Optional<T> getValue(final String s) {
        final List<T> list = this.flagValues.get(s);
        if (list == null || list.isEmpty()) {
            return Optional.empty();
        }
        return Optional.of((T)list.get(0));
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> Optional<T> getValue(final CommandFlag<T> commandFlag) {
        return this.getValue(commandFlag.getName());
    }
    
    public <T> T getValue(final String s, final T other) {
        return this.getValue(s).orElse(other);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> T getValue(final CommandFlag<T> commandFlag, final T other) {
        return this.getValue(commandFlag).orElse(other);
    }
    
    @API(status = API.Status.STABLE, since = "1.2.0")
    public boolean hasFlag(final String s) {
        return this.getValue(s).isPresent();
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public boolean hasFlag(final CommandFlag<?> commandFlag) {
        return this.getValue(commandFlag).isPresent();
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public boolean contains(final String s) {
        return this.hasFlag(s);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public boolean contains(final CommandFlag<?> commandFlag) {
        return this.hasFlag(commandFlag);
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public <T> T get(final String s) {
        return this.getValue(s).orElse(null);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> T get(final CommandFlag<T> commandFlag) {
        return this.getValue(commandFlag).orElse(null);
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public <T> Collection<T> getAll(final CommandFlag<T> commandFlag) {
        final List<? extends T> list = this.flagValues.get(commandFlag.getName());
        if (list != null) {
            return (Collection<T>)Collections.unmodifiableList((List<?>)list);
        }
        return (Collection<T>)Collections.emptyList();
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public <T> Collection<T> getAll(final String s) {
        final List<? extends T> list = this.flagValues.get(s);
        if (list != null) {
            return (Collection<T>)Collections.unmodifiableList((List<?>)list);
        }
        return (Collection<T>)Collections.emptyList();
    }
    
    public static int ColonialObfuscator_\u62e3\u5078\u6a2f\u56f1\u5105\u583e\u6d4d\u5d7b\u6ec2\u5a9c\u6a55\u5f81\u642c\u6631\u68ee\u5768\u5cf1\u6a7e\u7074\u53dd\u58a8\u5854\u52cc\u5a65\u58af\u6f9f\u6d5b\u68c3\u6a80\u63ef\u56e2\u6769\u5b7b\u5bb8\u6f33\u5de6\u4fe8\u5142\u6e23\u5543\u6c72(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
