package cloud.commandframework.arguments.flags;

import org.apiguardian.api.*;
import cloud.commandframework.arguments.*;
import cloud.commandframework.*;
import cloud.commandframework.permission.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class CommandFlag<T>
{
    public CommandFlag(final String obj, final String[] obj2, final ArgumentDescription obj3, final CommandPermission obj4, final CommandArgument<?, T> commandArgument, final FlagMode obj5) {
        this.name = Objects.requireNonNull(obj, \u5d38\u4fe7\u6a8d\u6b10\u69d2\u5357\u65e0\u4ebd\u5301\u6967\u60d7\u7104\u54fc\u5967\u57f9\u569a\u64a3\u4f30\u6b9e\u615f\u6fb3\u4f8d\u6d32\u62c5\u6aaa\u4e47\u57ed\u537b\u5182\u5bbb\u6b8e\u5a7a\u68a6\u6abd\u6a70\u62ed\u4ea1\u5e26\u4f25\u70de\u6a79(-485543539, -1153110306, "\ue8e7\ue8c5\ue8c9\ue8c3\ue880\ue8c5\ue8cc\ue8cf\ue893\ue8be\ue8a2\ue8e4\ue8a7\ue8b1\ue8f5\ue8af\ue8a0\ue8a5\ue88b", -819962056, 1065773217));
        this.aliases = Objects.requireNonNull(obj2, \u5d38\u4fe7\u6a8d\u6b10\u69d2\u5357\u65e0\u4ebd\u5301\u6967\u60d7\u7104\u54fc\u5967\u57f9\u569a\u64a3\u4f30\u6b9e\u615f\u6fb3\u4f8d\u6d32\u62c5\u6aaa\u4e47\u57ed\u537b\u5182\u5bbb\u6b8e\u5a7a\u68a6\u6abd\u6a70\u62ed\u4ea1\u5e26\u4f25\u70de\u6a79(1912538153, 1321684775, "\uc74a\uc768\uc76f\uc77b\uc769\uc77b\uc764\uc73d\uc75c\uc770\uc77a\uc766\uc760\uc768\uc73f\uc76f\uc772\uc729\uc74b\u9d97\ua846\u9fea", 518466925, 721854731));
        this.description = Objects.requireNonNull(obj3, \u5d38\u4fe7\u6a8d\u6b10\u69d2\u5357\u65e0\u4ebd\u5301\u6967\u60d7\u7104\u54fc\u5967\u57f9\u569a\u64a3\u4f30\u6b9e\u615f\u6fb3\u4f8d\u6d32\u62c5\u6aaa\u4e47\u57ed\u537b\u5182\u5bbb\u6b8e\u5a7a\u68a6\u6abd\u6a70\u62ed\u4ea1\u5e26\u4f25\u70de\u6a79(1167186825, -947996062, "\ufef1\ufec3\ufed7\ufec7\ufed6\ufecd\ufedd\ufed7\ufee8\ufecc\ufec8\ufe96\ufed2\ufec7\ufecb\ufedd\ufec6\ufeff\ufe87\ua4fe\u9131\ua6dc\ua340\uaec4\u8ed5\u9de8", 2025703247, -658089870));
        this.permission = Objects.requireNonNull(obj4, \u5d38\u4fe7\u6a8d\u6b10\u69d2\u5357\u65e0\u4ebd\u5301\u6967\u60d7\u7104\u54fc\u5967\u57f9\u569a\u64a3\u4f30\u6b9e\u615f\u6fb3\u4f8d\u6d32\u62c5\u6aaa\u4e47\u57ed\u537b\u5182\u5bbb\u6b8e\u5a7a\u68a6\u6abd\u6a70\u62ed\u4ea1\u5e26\u4f25\u70de\u6a79(425051458, -2130110792, "\u9414\u9422\u9437\u9428\u942c\u9436\u943f\u942b\u940f\u941c\u9457\u9404\u9401\u9419\u941a\u940d\u940c\u944a\u9424\uce18\ufb95\ucc73\uc9ba\uc43c\ue434", -1168826537, -2006493046));
        this.commandArgument = commandArgument;
        this.mode = Objects.requireNonNull(obj5, \u5d38\u4fe7\u6a8d\u6b10\u69d2\u5357\u65e0\u4ebd\u5301\u6967\u60d7\u7104\u54fc\u5967\u57f9\u569a\u64a3\u4f30\u6b9e\u615f\u6fb3\u4f8d\u6d32\u62c5\u6aaa\u4e47\u57ed\u537b\u5182\u5bbb\u6b8e\u5a7a\u68a6\u6abd\u6a70\u62ed\u4ea1\u5e26\u4f25\u70de\u6a79(-732672344, 1647171679, "\u4cca\u4ce7\u4cee\u4ceb\u4cae\u4ce9\u4ce2\u4cef\u4ccd\u4ce2\u4cfc\u4cbc\u4cf9\u4ced\u4cab\u4ccf\u4cce\u4cc9\u4ce5", 1713013457, 1247500482));
    }
    
    public String getName() {
        return this.name;
    }
    
    public Collection<String> getAliases() {
        return Arrays.asList(this.aliases);
    }
    
    @API(status = API.Status.STABLE, since = "1.7.0")
    public FlagMode mode() {
        return this.mode;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.4.0")
    public Description getDescription() {
        if (this.description instanceof Description) {
            return (Description)this.description;
        }
        return Description.of(this.description.getDescription());
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public ArgumentDescription getArgumentDescription() {
        return this.description;
    }
    
    public CommandArgument<?, T> getCommandArgument() {
        return this.commandArgument;
    }
    
    @API(status = API.Status.STABLE, since = "1.6.0")
    public CommandPermission permission() {
        return this.permission;
    }
    
    @Override
    public String toString() {
        final String \u5d38\u4fe7\u6a8d\u6b10\u69d2\u5357\u65e0\u4ebd\u5301\u6967\u60d7\u7104\u54fc\u5967\u57f9\u569a\u64a3\u4f30\u6b9e\u615f\u6fb3\u4f8d\u6d32\u62c5\u6aaa\u4e47\u57ed\u537b\u5182\u5bbb\u6b8e\u5a7a\u68a6\u6abd\u6a70\u62ed\u4ea1\u5e26\u4f25\u70de\u6a79 = \u5d38\u4fe7\u6a8d\u6b10\u69d2\u5357\u65e0\u4ebd\u5301\u6967\u60d7\u7104\u54fc\u5967\u57f9\u569a\u64a3\u4f30\u6b9e\u615f\u6fb3\u4f8d\u6d32\u62c5\u6aaa\u4e47\u57ed\u537b\u5182\u5bbb\u6b8e\u5a7a\u68a6\u6abd\u6a70\u62ed\u4ea1\u5e26\u4f25\u70de\u6a79(538377351, 1528281782, "\u6cfa\u6cd7\u6cdf\u6c8b", -2091996940, -950304175);
        final Object[] args = { null };
        "\u58b4\u63f7\u50b6\u5ad3\u6257".length();
        args[0] = this.name;
        return String.format(\u5d38\u4fe7\u6a8d\u6b10\u69d2\u5357\u65e0\u4ebd\u5301\u6967\u60d7\u7104\u54fc\u5967\u57f9\u569a\u64a3\u4f30\u6b9e\u615f\u6fb3\u4f8d\u6d32\u62c5\u6aaa\u4e47\u57ed\u537b\u5182\u5bbb\u6b8e\u5a7a\u68a6\u6abd\u6a70\u62ed\u4ea1\u5e26\u4f25\u70de\u6a79, args);
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && this.getName().equals(((CommandFlag)o).getName()));
    }
    
    @Override
    public int hashCode() {
        final Object[] values = { null };
        "\u57dc\u64c2\u5620\u6ae7".length();
        "\u65a3".length();
        values[0] = this.getName();
        return Objects.hash(values);
    }
    
    public static int ColonialObfuscator_\u5eba\u5821\u56a5\u52b5\u5f95\u5a16\u6870\u54c8\u5b60\u6a42\u69f7\u706c\u6c62\u6e18\u59d3\u5026\u53ef\u5e75\u5ede\u5777\u5d47\u7068\u552a\u4f87\u536a\u6377\u5f2b\u66a8\u634c\u705e\u5123\u59b9\u6fdf\u5199\u67ff\u6d0e\u5f08\u6123\u5039\u54e6\u58cd(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
