package cloud.commandframework.arguments.preprocessor;

import cloud.commandframework.context.*;
import java.util.*;
import cloud.commandframework.arguments.parser.*;
import org.apiguardian.api.*;
import java.util.function.*;
import java.util.regex.*;
import cloud.commandframework.exceptions.parsing.*;
import cloud.commandframework.captions.*;

@API(status = API.Status.STABLE)
public final class RegexPreprocessor<C> implements BiFunction<CommandContext<C>, Queue<String>, ArgumentParseResult<Boolean>>
{
    public RegexPreprocessor(final String s, final Caption failureCaption) {
        this.rawPattern = s;
        this.predicate = Pattern.compile(s).asPredicate();
        this.failureCaption = failureCaption;
    }
    
    @Override
    public ArgumentParseResult<Boolean> apply(final CommandContext<C> commandContext, final Queue<String> queue) {
        final String s = queue.peek();
        if (s == null) {
            "\u6dcd".length();
            "\u4f12".length();
            return ArgumentParseResult.failure(new NoInputProvidedException(RegexPreprocessor.class, commandContext));
        }
        if (this.predicate.test(s)) {
            return ArgumentParseResult.success(true);
        }
        "\u5823\u6e73\u5801".length();
        "\u5ba7\u63db\u70cc".length();
        return (ArgumentParseResult<Boolean>)ArgumentParseResult.failure(new RegexValidationException(this.rawPattern, s, this.failureCaption, commandContext, null));
    }
    
    public static int ColonialObfuscator_\u59b4\u68d3\u6960\u5c94\u5e54\u656d\u5c7c\u6328\u6a65\u5797\u6102\u6ed5\u4fc7\u632d\u61c8\u615a\u67bd\u545c\u5f3b\u67ec\u600e\u5a6a\u6c12\u50fb\u60eb\u5ca0\u7129\u5a46\u5cdc\u505a\u5977\u6029\u7021\u50f2\u6bcf\u6ea6\u5e60\u6835\u523d\u56a3\u704a(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
