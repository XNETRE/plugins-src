package cloud.commandframework.arguments;

import org.apiguardian.api.*;
import java.util.*;
import cloud.commandframework.*;

@FunctionalInterface
@API(status = API.Status.STABLE)
public interface CommandSyntaxFormatter<C>
{
    String apply(final List<CommandArgument<C, ?>> p0, final CommandTree.Node<CommandArgument<C, ?>> p1);
}
