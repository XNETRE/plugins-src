package cloud.commandframework.extra.confirmation;

import org.apiguardian.api.*;
import cloud.commandframework.types.tuples.*;
import java.util.*;
import cloud.commandframework.meta.*;
import cloud.commandframework.*;
import cloud.commandframework.execution.postprocessor.*;
import cloud.commandframework.execution.*;
import java.util.concurrent.*;
import cloud.commandframework.context.*;
import java.util.function.*;
import cloud.commandframework.services.types.*;

@API(status = API.Status.STABLE)
public class CommandConfirmationManager<C>
{
    public CommandConfirmationManager(final long duration, final TimeUnit timeUnit, final Consumer<CommandPostprocessingContext<C>> notifier, final Consumer<C> errorNotifier) {
        this.notifier = notifier;
        this.errorNotifier = errorNotifier;
        this.pendingCommands = new LinkedHashMap<C, Pair<CommandPostprocessingContext<C>, Long>>();
        this.timeoutMillis = timeUnit.toMillis(duration);
    }
    
    public void notifyConsumer(final CommandPostprocessingContext<C> commandPostprocessingContext) {
        this.notifier.accept(commandPostprocessingContext);
    }
    
    public void addPending(final CommandPostprocessingContext<C> commandPostprocessingContext) {
        this.pendingCommands.put(commandPostprocessingContext.getCommandContext().getSender(), Pair.of(commandPostprocessingContext, System.currentTimeMillis()));
        "\u5152\u6d50\u5863".length();
        "\u5319\u5f3c".length();
        "\u5b71".length();
        "\u525d\u6eae\u6ab0\u695a".length();
    }
    
    public Optional<CommandPostprocessingContext<C>> getPending(final C c) {
        final Pair<CommandPostprocessingContext<C>, Long> pair = this.pendingCommands.remove(c);
        if (pair != null && System.currentTimeMillis() < pair.getSecond() + this.timeoutMillis) {
            return Optional.of(pair.getFirst());
        }
        return Optional.empty();
    }
    
    public SimpleCommandMeta.Builder decorate(final SimpleCommandMeta.Builder builder) {
        return builder.with(CommandConfirmationManager.META_CONFIRMATION_REQUIRED, true);
    }
    
    public void registerConfirmationProcessor(final CommandManager<C> commandManager) {
        "\u6202".length();
        commandManager.registerCommandPostProcessor(new CommandConfirmationPostProcessor(null));
    }
    
    public CommandExecutionHandler<C> createConfirmationExecutionHandler() {
        final Optional<CommandPostprocessingContext<C>> optional;
        CommandPostprocessingContext<C> commandPostprocessingContext;
        return commandContext -> {
            this.getPending(commandContext.getSender());
            if (optional.isPresent()) {
                commandPostprocessingContext = optional.get();
                return commandPostprocessingContext.getCommand().getCommandExecutionHandler().executeFuture(commandPostprocessingContext.getCommandContext());
            }
            else {
                this.errorNotifier.accept(commandContext.getSender());
                return CompletableFuture.completedFuture((Void)null);
            }
        };
    }
    
    public static int ColonialObfuscator_\u4f2a\u4eb5\u52ec\u52a1\u6838\u69d2\u5e96\u5d2f\u59a9\u54f7\u5aec\u5d91\u7017\u5f84\u57e3\u5434\u70f9\u5c85\u6ac3\u5681\u4f70\u6a52\u5bf4\u543e\u6e40\u5fcd\u6086\u6559\u6582\u506d\u6b97\u6704\u575d\u528f\u548a\u6a2f\u5b6e\u5264\u5c6c\u6937\u5cf1(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
