package cloud.commandframework.exceptions;

import org.apiguardian.api.*;
import cloud.commandframework.arguments.*;

@API(status = API.Status.STABLE)
public final class NoCommandInLeafException extends IllegalStateException
{
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
    public NoCommandInLeafException(final CommandArgument<?, ?> commandArgument) {
        super(String.format(\u7074\u5158\u5ee4\u6723\u6658\u5cad\u55ef\u52e6\u6065\u570a\u5b95\u6228\u56f1\u6628\u50f9\u61bf\u61f8\u60f7\u4e82\u5a4b\u5dab\u4f79\u4fe3\u5489\u5253\u6630\u6b75\u4e22\u595b\u5ad6\u6337\u55ca\u6847\u66a6\u4f40\u6664\u5db0\u670c\u5d38\u61df\u5917(1121424082, -1043251984, "\u6df6\u6df2\u6df2\u6df7\u6db3\u6dfb\u6dfd\u6dfa\u6ddb\u6db2\u6db6\u6da6\u6df5\u6db0\u6daa\u6dfa\u6de9\u6dff\u6dc3\u0374\u328e\u057e\u052d\u02da\u01e6\u32be\u3a92\u019c\u3f66\u351c\u0e98\u392a\u08be\u3561\u01d5\u02c8\u3bd0\u3131\u0dc1\u3770\u3884\u33ae\u37c1\u00fd\u0a0c\u06f7\u31c1\u3b27\u30ae\u3b82\u0987\u061a\u3bf3\u34da", 2032787362, -297591687), commandArgument.getName()));
        this.commandArgument = commandArgument;
    }
    
    public CommandArgument<?, ?> getCommandArgument() {
        return this.commandArgument;
    }
    
    public static int ColonialObfuscator_\u5936\u4f5e\u5881\u6db7\u54bc\u6149\u5a9e\u6ce1\u6a57\u5b23\u5c51\u595a\u541a\u6f78\u6d77\u6666\u631a\u67e0\u6e4a\u641c\u5833\u68fc\u55cd\u6979\u5c66\u6e4a\u514f\u6c4f\u51db\u5597\u5e36\u6465\u6263\u54e7\u6cf6\u6ec3\u6e8a\u5f6a\u5545\u54cc\u5754(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
