package cloud.commandframework.exceptions;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;

@API(status = API.Status.STABLE, since = "1.2.0")
public class CommandExecutionException extends IllegalArgumentException
{
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
    public CommandExecutionException(final Throwable t) {
        this(t, null);
    }
    
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" }, since = "1.4.0")
    public CommandExecutionException(final Throwable cause, final CommandContext<?> commandContext) {
        super(cause);
        this.commandContext = commandContext;
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public CommandContext<?> getCommandContext() {
        return this.commandContext;
    }
    
    public static int ColonialObfuscator_\u68c9\u55a2\u5ecd\u64f1\u54be\u6118\u63bd\u58ee\u69c9\u6568\u5a82\u61ad\u65e8\u54b4\u5973\u6245\u52e9\u6333\u51ce\u5fa4\u7147\u5917\u6fbe\u5673\u5a6e\u6748\u5174\u506b\u6268\u667e\u514f\u5c97\u6736\u5073\u6bfe\u6f65\u4e7f\u5eff\u523b\u621f\u546f(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
