package cloud.commandframework.exceptions.parsing;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import cloud.commandframework.captions.*;

@API(status = API.Status.STABLE, since = "1.1.0")
public class NoInputProvidedException extends ParserException
{
    public NoInputProvidedException(final Class<?> clazz, final CommandContext<?> commandContext) {
        super(clazz, commandContext, StandardCaptionKeys.ARGUMENT_PARSE_FAILURE_NO_INPUT_PROVIDED, new CaptionVariable[0]);
    }
    
    public static int ColonialObfuscator_\u6dc2\u6512\u6fa3\u4f4b\u6f50\u6bfe\u60f8\u6669\u6fe3\u6978\u6e6d\u5d8b\u56b2\u6fb5\u56e0\u703c\u650e\u4e48\u51bd\u6d7e\u6030\u6abc\u545d\u6da7\u6eeb\u6177\u55a3\u5b9a\u64ca\u56b5\u5782\u638b\u65b3\u4f69\u5c4e\u64d0\u5919\u6e2a\u547e\u702a\u6ece(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
