package cloud.commandframework.exceptions.parsing;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import cloud.commandframework.captions.*;

@API(status = API.Status.STABLE)
public abstract class NumberParseException extends ParserException
{
    public NumberParseException(final String input, final Number n, final Number n2, final Class<?> clazz, final CommandContext<?> commandContext) {
        super(clazz, commandContext, StandardCaptionKeys.ARGUMENT_PARSE_FAILURE_NUMBER, new CaptionVariable[] { CaptionVariable.of(\u57e4\u6aa6\u55b0\u4ec8\u54d8\u5dc2\u65ef\u69ac\u6bc4\u5bc1\u6d04\u6d2c\u4ff2\u5839\u6d6b\u705a\u65ad\u6b53\u6020\u6c7c\u607f\u5bd4\u6a52\u6c55\u6fda\u6139\u6cfc\u639e\u6220\u5391\u6d7f\u637e\u56db\u5d68\u5a0c\u6741\u54dd\u55d6\u6cc1\u55c1\u4f08(491885536, 155321683, "\u388a\u38a0\u3882\u3885\u3886", 2110095262, -1651781235), input), CaptionVariable.of(\u57e4\u6aa6\u55b0\u4ec8\u54d8\u5dc2\u65ef\u69ac\u6bc4\u5bc1\u6d04\u6d2c\u4ff2\u5839\u6d6b\u705a\u65ad\u6b53\u6020\u6c7c\u607f\u5bd4\u6a52\u6c55\u6fda\u6139\u6cfc\u639e\u6220\u5391\u6d7f\u637e\u56db\u5d68\u5a0c\u6741\u54dd\u55d6\u6cc1\u55c1\u4f08(876011666, 864883194, "\u3451\u347a\u347f", 762483325, 1590122346), String.valueOf(n)), CaptionVariable.of(\u57e4\u6aa6\u55b0\u4ec8\u54d8\u5dc2\u65ef\u69ac\u6bc4\u5bc1\u6d04\u6d2c\u4ff2\u5839\u6d6b\u705a\u65ad\u6b53\u6020\u6c7c\u607f\u5bd4\u6a52\u6c55\u6fda\u6139\u6cfc\u639e\u6220\u5391\u6d7f\u637e\u56db\u5d68\u5a0c\u6741\u54dd\u55d6\u6cc1\u55c1\u4f08(-1964424534, 1210496627, "\u7c25\u7c06\u7c1d", -983810871, -1245793253), String.valueOf(n2)) });
        this.input = input;
        this.min = n;
        this.max = n2;
    }
    
    public abstract String getNumberType();
    
    public abstract boolean hasMax();
    
    public abstract boolean hasMin();
    
    public String getInput() {
        return this.input;
    }
    
    public Number getMin() {
        return this.min;
    }
    
    public Number getMax() {
        return this.max;
    }
    
    public static int ColonialObfuscator_\u5e8d\u5748\u53ff\u50dd\u6df2\u5687\u59ac\u569c\u6726\u7140\u5b0b\u6143\u61bd\u5d91\u60d6\u6954\u6bac\u63be\u6375\u525e\u6fe2\u63ce\u4f83\u53bb\u6570\u5b48\u6219\u61b7\u6d2e\u5f4b\u6c47\u6a48\u5003\u5bc1\u5301\u52e3\u68db\u6474\u509b\u69f7\u4e69(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
