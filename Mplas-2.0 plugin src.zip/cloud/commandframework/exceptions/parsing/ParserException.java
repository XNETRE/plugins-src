package cloud.commandframework.exceptions.parsing;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import cloud.commandframework.captions.*;
import java.util.*;

@API(status = API.Status.STABLE)
public class ParserException extends IllegalArgumentException
{
    public ParserException(final Class<?> argumentParser, final CommandContext<?> context, final Caption errorCaption, final CaptionVariable[] captionVariables) {
        this.argumentParser = argumentParser;
        this.context = context;
        this.errorCaption = errorCaption;
        this.captionVariables = captionVariables;
    }
    
    @Override
    public final String getMessage() {
        return this.context.formatMessage(this.errorCaption, this.captionVariables);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public Caption errorCaption() {
        return this.errorCaption;
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public CaptionVariable[] captionVariables() {
        return Arrays.copyOf(this.captionVariables, this.captionVariables.length);
    }
    
    public final Class<?> getArgumentParserClass() {
        return this.argumentParser;
    }
    
    public final CommandContext<?> getContext() {
        return this.context;
    }
    
    public static int ColonialObfuscator_\u643f\u5fc0\u63b5\u52a6\u5d04\u65ff\u5c59\u51ec\u5b3f\u4f5a\u59ee\u6454\u6d58\u6358\u610b\u5397\u4fca\u51aa\u5c87\u69c1\u56e3\u5fcf\u51be\u5747\u5c2c\u6dd9\u5120\u6009\u5c5d\u525a\u587f\u52ac\u57ea\u6759\u6fa2\u5a38\u4e20\u65f6\u6986\u6e81\u548c(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
