package cloud.commandframework.exceptions;

import org.apiguardian.api.*;
import java.util.*;
import cloud.commandframework.arguments.*;

@API(status = API.Status.STABLE)
public class ArgumentParseException extends CommandParseException
{
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
    public ArgumentParseException(final Throwable cause, final Object o, final List<CommandArgument<?, ?>> list) {
        super(o, list);
        this.cause = cause;
    }
    
    @Override
    public synchronized Throwable getCause() {
        return this.cause;
    }
    
    public static int ColonialObfuscator_\u5e38\u4fc3\u6173\u69ce\u565a\u5738\u5be7\u5181\u6ee1\u68af\u61ec\u632f\u5c3b\u7136\u6c3b\u6a5b\u66c4\u668b\u5769\u5ad6\u655b\u6fcd\u4e88\u635a\u708f\u6f7c\u56da\u602e\u4ff1\u5219\u5b53\u616b\u5fc2\u65a9\u690a\u6e14\u6143\u5a31\u7059\u5f81\u6481(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
