package cloud.commandframework.exceptions;

import org.apiguardian.api.*;
import cloud.commandframework.*;
import java.util.*;
import cloud.commandframework.arguments.*;

@API(status = API.Status.STABLE)
public final class InvalidCommandSenderException extends CommandParseException
{
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
    public InvalidCommandSenderException(final Object o, final Class<?> clazz, final List<CommandArgument<?, ?>> list) {
        this(o, clazz, list, null);
    }
    
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" }, since = "1.4.0")
    public InvalidCommandSenderException(final Object o, final Class<?> requiredSender, final List<CommandArgument<?, ?>> list, final Command<?> command) {
        super(o, list);
        this.requiredSender = requiredSender;
        this.command = command;
    }
    
    public Class<?> getRequiredSender() {
        return this.requiredSender;
    }
    
    @Override
    public String getMessage() {
        final String \u4e53\u6789\u6330\u538a\u6e77\u5172\u5a65\u5d9d\u7061\u67be\u6d32\u5634\u5ea9\u551b\u627e\u6f05\u5c84\u51e2\u69f2\u6009\u6d4d\u5057\u69c0\u5abf\u69d0\u6be5\u6f6b\u592f\u54e3\u51da\u688e\u50b7\u689f\u6af0\u706d\u6281\u5360\u533d\u57f6\u5dbe\u69b0 = \u4e53\u6789\u6330\u538a\u6e77\u5172\u5a65\u5d9d\u7061\u67be\u6d32\u5634\u5ea9\u551b\u627e\u6f05\u5c84\u51e2\u69f2\u6009\u6d4d\u5057\u69c0\u5abf\u69d0\u6be5\u6f6b\u592f\u54e3\u51da\u688e\u50b7\u689f\u6af0\u706d\u6281\u5360\u533d\u57f6\u5dbe\u69b0(1240649483, -409100830, "\u3797\u37ee\u37bf\u37f2\u37e8\u37bf\u37f8\u37fb\u37c2\u37b8\u37fc\u37e5\u37e2\u37f2\u37e9\u37f1\u37ea\u37b0\u37c8\u5ed0\u526d\u6658\u5dd1\u479f\u6161\u6339\u6db1\u6037\u6acf\u69bb\u5fe5\u55d8\u78a5\u7874\u69e0\u5cb6\u6e0b\u6704\u5c08\u5ed3\u6b98\u6e31\u7853\u5a02\u6951\u790a\u5860\u6975\u6032\u7944\u5273\u6b49\u509c\u5817\u5a53\u6285\u6f06\u53ef\u515e\u5960\u6c60", 780083489, 1491420217);
        final Object[] args = new Object[2];
        "\u5a54\u5e5d".length();
        "\u6126\u6dc2".length();
        args[0] = this.getCommandSender().getClass().getSimpleName();
        "\u6294".length();
        "\u6670\u553c".length();
        "\u516c\u502f\u5818".length();
        args[1] = this.requiredSender.getSimpleName();
        return String.format(\u4e53\u6789\u6330\u538a\u6e77\u5172\u5a65\u5d9d\u7061\u67be\u6d32\u5634\u5ea9\u551b\u627e\u6f05\u5c84\u51e2\u69f2\u6009\u6d4d\u5057\u69c0\u5abf\u69d0\u6be5\u6f6b\u592f\u54e3\u51da\u688e\u50b7\u689f\u6af0\u706d\u6281\u5360\u533d\u57f6\u5dbe\u69b0, args);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public Command<?> getCommand() {
        return this.command;
    }
    
    public static int ColonialObfuscator_\u5a27\u538e\u5d95\u5059\u5ed0\u5710\u6f4a\u64d1\u6705\u6ac1\u6255\u6250\u6aa2\u6af1\u5f47\u6978\u6a20\u6996\u6f22\u5cdf\u5727\u5b28\u4e39\u57a5\u6806\u677d\u505c\u5664\u544e\u5f1a\u65c9\u6a8a\u5bb0\u55b7\u66f3\u5038\u6df2\u4fc6\u65a0\u6191\u65d1(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
