package cloud.commandframework.exceptions;

import org.apiguardian.api.*;
import java.util.*;
import cloud.commandframework.arguments.*;

@API(status = API.Status.STABLE)
public class InvalidSyntaxException extends CommandParseException
{
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
    public InvalidSyntaxException(final String correctSyntax, final Object o, final List<CommandArgument<?, ?>> list) {
        super(o, list);
        this.correctSyntax = correctSyntax;
    }
    
    public String getCorrectSyntax() {
        return this.correctSyntax;
    }
    
    @Override
    public final String getMessage() {
        final String \u5dc9\u6ef0\u607b\u5a55\u51a6\u5a90\u648e\u5d12\u5290\u5a58\u5338\u4f7d\u59c2\u5fe2\u6af6\u58dd\u5917\u4ec2\u5691\u5d5c\u5b2c\u6c7f\u55b4\u52b2\u6073\u5dd5\u6ff6\u6a26\u5de4\u59d6\u70c4\u6b06\u6349\u58bb\u4f0d\u58be\u66d3\u4ed7\u6c3a\u6d5c\u6e8c = \u5dc9\u6ef0\u607b\u5a55\u51a6\u5a90\u648e\u5d12\u5290\u5a58\u5338\u4f7d\u59c2\u5fe2\u6af6\u58dd\u5917\u4ec2\u5691\u5d5c\u5b2c\u6c7f\u55b4\u52b2\u6073\u5dd5\u6ff6\u6a26\u5de4\u59d6\u70c4\u6b06\u6349\u58bb\u4f0d\u58be\u66d3\u4ed7\u6c3a\u6d5c\u6e8c(207775145, -1448173835, "\ub5e1\ub5eb\ub5ff\ub5ea\ub5e5\ub5e6\ub5e4\ub5ac\ub5cf\ub5ef\ub596\ub584\ub58d\ub593\ub59c\ub5cc\ub587\ub591\ub5a4\ue8ae\ue9d1\ue7a7\ue380\udf29\ud875\uefd2\udecf\ue0d3\ud965\ue805\ud046\ud6da\udfc4\ueaf2\ue54f\ue8c6\ue73a\ue65e\ud057\udb1e\uec08\udd67\ue807\ue167\ue815", -999990986, 1232869249);
        final Object[] args = { null };
        "\u4f9f\u655e".length();
        "\u50b5\u5b39".length();
        args[0] = this.correctSyntax;
        return String.format(\u5dc9\u6ef0\u607b\u5a55\u51a6\u5a90\u648e\u5d12\u5290\u5a58\u5338\u4f7d\u59c2\u5fe2\u6af6\u58dd\u5917\u4ec2\u5691\u5d5c\u5b2c\u6c7f\u55b4\u52b2\u6073\u5dd5\u6ff6\u6a26\u5de4\u59d6\u70c4\u6b06\u6349\u58bb\u4f0d\u58be\u66d3\u4ed7\u6c3a\u6d5c\u6e8c, args);
    }
    
    public static int ColonialObfuscator_\u6b54\u5cf5\u54df\u5adc\u6b22\u68c8\u6544\u5952\u624a\u5568\u6dbc\u6629\u5657\u5c9d\u52f8\u5f19\u6eee\u518c\u6b50\u671c\u5748\u6a52\u5cb7\u4fc6\u5a36\u6cad\u60ae\u648b\u5e96\u6633\u57f2\u6150\u5017\u6e2e\u6957\u5ae6\u65e9\u4fec\u5302\u5b9c\u588e(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
