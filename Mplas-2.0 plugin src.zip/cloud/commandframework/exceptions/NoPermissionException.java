package cloud.commandframework.exceptions;

import org.apiguardian.api.*;
import cloud.commandframework.permission.*;
import java.util.*;
import cloud.commandframework.arguments.*;

@API(status = API.Status.STABLE)
public class NoPermissionException extends CommandParseException
{
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
    public NoPermissionException(final CommandPermission missingPermission, final Object o, final List<CommandArgument<?, ?>> list) {
        super(o, list);
        this.missingPermission = missingPermission;
    }
    
    @Override
    public final String getMessage() {
        final String \u70fd\u5df6\u6354\u5a23\u6bdf\u6076\u5edc\u699e\u6228\u63e0\u709e\u6e57\u6934\u65f9\u6b2e\u5c2d\u605f\u59a5\u6e53\u5d41\u5b6e\u6e23\u5026\u69f7\u5092\u6064\u5ea7\u56b6\u6c2d\u65af\u55d8\u6ac0\u511b\u50b8\u608f\u4e37\u5342\u59ae\u5581\u7022\u5978 = \u70fd\u5df6\u6354\u5a23\u6bdf\u6076\u5edc\u699e\u6228\u63e0\u709e\u6e57\u6934\u65f9\u6b2e\u5c2d\u605f\u59a5\u6e53\u5d41\u5b6e\u6e23\u5026\u69f7\u5092\u6064\u5ea7\u56b6\u6c2d\u65af\u55d8\u6ac0\u511b\u50b8\u608f\u4e37\u5342\u59ae\u5581\u7022\u5978(-738440433, -1330218638, "\u06e7\u06e8\u06f0\u06f0\u06ea\u0515\u0515\u055c\u052e\u0511\u0503\u050c\u050f\u050a\u0509\u0505\u0519\u0502\u0560\u57e3\u6f62\u52e8\u6039", 1453108731, 538351983);
        final Object[] args = { null };
        "\u6ca6\u5fb0\u64d7\u64c9".length();
        "\u6a6a\u584d\u6db7".length();
        "\u5a4c\u52fe".length();
        args[0] = this.missingPermission;
        return String.format(\u70fd\u5df6\u6354\u5a23\u6bdf\u6076\u5edc\u699e\u6228\u63e0\u709e\u6e57\u6934\u65f9\u6b2e\u5c2d\u605f\u59a5\u6e53\u5d41\u5b6e\u6e23\u5026\u69f7\u5092\u6064\u5ea7\u56b6\u6c2d\u65af\u55d8\u6ac0\u511b\u50b8\u608f\u4e37\u5342\u59ae\u5581\u7022\u5978, args);
    }
    
    public String getMissingPermission() {
        return this.missingPermission.toString();
    }
    
    @Override
    public final synchronized Throwable fillInStackTrace() {
        return this;
    }
    
    @Override
    public final synchronized Throwable initCause(final Throwable t) {
        return this;
    }
    
    public static int ColonialObfuscator_\u600a\u5ae4\u6f16\u57d6\u5cca\u5305\u51d4\u5909\u5975\u625d\u6966\u4f51\u6d92\u601c\u5042\u5622\u5092\u61d6\u4f99\u69b8\u4fd4\u64cd\u4e69\u63b9\u6dd3\u610c\u6776\u63bc\u5144\u6e73\u6da8\u5628\u6a42\u6489\u596f\u581e\u51fb\u6dfe\u6e47\u5956\u60de(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
