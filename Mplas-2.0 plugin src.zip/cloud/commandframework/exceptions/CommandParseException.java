package cloud.commandframework.exceptions;

import org.apiguardian.api.*;
import cloud.commandframework.arguments.*;
import java.util.*;

@API(status = API.Status.STABLE)
public class CommandParseException extends IllegalArgumentException
{
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
    public CommandParseException(final Object commandSender, final List<CommandArgument<?, ?>> currentChain) {
        this.commandSender = commandSender;
        this.currentChain = currentChain;
    }
    
    public Object getCommandSender() {
        return this.commandSender;
    }
    
    public List<CommandArgument<?, ?>> getCurrentChain() {
        return Collections.unmodifiableList((List<? extends CommandArgument<?, ?>>)this.currentChain);
    }
    
    public static int ColonialObfuscator_\u624f\u5045\u6090\u6a18\u6602\u5e3e\u687a\u4f6b\u70b3\u6292\u553f\u4e93\u61aa\u6471\u5c18\u5fb3\u52e9\u6d27\u668a\u6b8c\u6074\u523d\u59d2\u636d\u5554\u67fc\u610d\u64b4\u5066\u6d7e\u6532\u64ae\u68f0\u5006\u5a1b\u5813\u6729\u5adf\u6e81\u5796\u5ef5(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
