package cloud.commandframework.exceptions;

import org.apiguardian.api.*;
import cloud.commandframework.arguments.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class NoSuchCommandException extends CommandParseException
{
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
    public NoSuchCommandException(final Object o, final List<CommandArgument<?, ?>> list, final String suppliedCommand) {
        super(o, list);
        this.suppliedCommand = suppliedCommand;
    }
    
    @Override
    public String getMessage() {
        "\u6a3d\u6991\u6133".length();
        final StringBuilder sb = new StringBuilder();
        for (final CommandArgument<?, ?> commandArgument : this.getCurrentChain()) {
            if (commandArgument == null) {
                continue;
            }
            sb.append(\u4eeb\u50a5\u6327\u5c19\u5049\u6b36\u6599\u5980\u5242\u6d41\u6551\u7075\u61b5\u5e37\u6cbf\u6008\u57a5\u585f\u4f48\u5c95\u67cb\u6c0a\u637a\u5a47\u52c1\u52fe\u5cec\u6a44\u5e17\u4f07\u60db\u6a1e\u69fd\u6d62\u6000\u51fd\u5fd4\u6516\u623a\u4f20\u6de5(589312118, -1173897146, "\u759f", -585124380, 85405736)).append(commandArgument.getName());
            "\u59fa\u56c9".length();
            "\u509c\u6483\u6a51\u5919\u6849".length();
            "\u51c7\u5a65\u58fe".length();
        }
        final String \u4eeb\u50a5\u6327\u5c19\u5049\u6b36\u6599\u5980\u5242\u6d41\u6551\u7075\u61b5\u5e37\u6cbf\u6008\u57a5\u585f\u4f48\u5c95\u67cb\u6c0a\u637a\u5a47\u52c1\u52fe\u5cec\u6a44\u5e17\u4f07\u60db\u6a1e\u69fd\u6d62\u6000\u51fd\u5fd4\u6516\u623a\u4f20\u6de5 = \u4eeb\u50a5\u6327\u5c19\u5049\u6b36\u6599\u5980\u5242\u6d41\u6551\u7075\u61b5\u5e37\u6cbf\u6008\u57a5\u585f\u4f48\u5c95\u67cb\u6c0a\u637a\u5a47\u52c1\u52fe\u5cec\u6a44\u5e17\u4f07\u60db\u6a1e\u69fd\u6d62\u6000\u51fd\u5fd4\u6516\u623a\u4f20\u6de5(-1318522055, 810748038, "\u972f\u9739\u9725\u9730\u9748\u9742\u9741\u9744\u9767\u9758\u9740\u9753\u971e\u974c\u9741\u9757\u974b\u975b\u977a\uf131\ud859\uccb3\ufc91\uc4c0\uc3f5\ufc63\uccd8\uf6c3\ucf61\uca0a\uca45\uc2e9\uf422\ucd25\uce71\uc921\ufde6\uf97c\ufc59\uc3b3\ufd50\uc91a\uf70c\uc6f2\uf471\uce4e\uf6cc\ue733\uf1f9", 815350204, -1937494726);
        final Object[] args = new Object[2];
        "\u6a42\u5944\u5bd5\u6fae\u57fb".length();
        "\u5bb0\u5b28\u69c2\u6db7\u5985".length();
        "\u546e\u6ee0\u70a9\u6690".length();
        args[0] = this.suppliedCommand;
        "\u567d\u6ea4\u70c0".length();
        args[1] = sb.toString();
        return String.format(\u4eeb\u50a5\u6327\u5c19\u5049\u6b36\u6599\u5980\u5242\u6d41\u6551\u7075\u61b5\u5e37\u6cbf\u6008\u57a5\u585f\u4f48\u5c95\u67cb\u6c0a\u637a\u5a47\u52c1\u52fe\u5cec\u6a44\u5e17\u4f07\u60db\u6a1e\u69fd\u6d62\u6000\u51fd\u5fd4\u6516\u623a\u4f20\u6de5, args);
    }
    
    public String getSuppliedCommand() {
        return this.suppliedCommand;
    }
    
    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
    
    @Override
    public synchronized Throwable initCause(final Throwable t) {
        return this;
    }
    
    public static int ColonialObfuscator_\u5968\u6e98\u5eeb\u5e4f\u67dc\u59a6\u50db\u694e\u4f41\u64bb\u69bd\u60fa\u6f96\u642c\u598d\u57ec\u6eee\u5d34\u54d1\u690a\u5241\u5412\u63b5\u5ac3\u6b65\u5d20\u54b7\u58dd\u5570\u60bd\u5076\u6e0b\u6e97\u4e57\u5fb7\u4fcd\u555d\u6654\u50ef\u5186\u5f9d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
