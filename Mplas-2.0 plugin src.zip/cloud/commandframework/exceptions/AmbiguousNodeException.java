package cloud.commandframework.exceptions;

import org.apiguardian.api.*;
import cloud.commandframework.arguments.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class AmbiguousNodeException extends IllegalStateException
{
    @API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
    public AmbiguousNodeException(final CommandArgument<?, ?> parentNode, final CommandArgument<?, ?> ambiguousNode, final List<CommandArgument<?, ?>> children) {
        this.parentNode = parentNode;
        this.ambiguousNode = ambiguousNode;
        this.children = children;
    }
    
    public CommandArgument<?, ?> getParentNode() {
        return this.parentNode;
    }
    
    public CommandArgument<?, ?> getAmbiguousNode() {
        return this.ambiguousNode;
    }
    
    public List<CommandArgument<?, ?>> getChildren() {
        return this.children;
    }
    
    @Override
    public String getMessage() {
        "\u68d4\u4e7e".length();
        "\u6399\u63b3\u68a5\u60c7\u6463".length();
        final StringBuilder append = new StringBuilder(\u70db\u690a\u6e14\u5441\u52e3\u5af6\u69d5\u524e\u5387\u5bb3\u5bd3\u52c4\u6b85\u508a\u55b8\u5fde\u64fb\u5b08\u5ebf\u6c8b\u6aa9\u50b0\u5a07\u6b72\u69d6\u6559\u536a\u6835\u6c9c\u4e5c\u546a\u628b\u5abf\u6ac5\u4fa0\u5ab6\u5574\u568a\u6846\u5e82\u5ff6(589956512, 400679926, "\u7245\u7244\u7237\u723e\u7232\u7226\u7233\u7225\u7203\u727c\u7219\u722a\u7224\u7234\u726e\u7260", 551185214, -40566993)).append(this.ambiguousNode.getName()).append(\u70db\u690a\u6e14\u5441\u52e3\u5af6\u69d5\u524e\u5387\u5bb3\u5bd3\u52c4\u6b85\u508a\u55b8\u5fde\u64fb\u5b08\u5ebf\u6c8b\u6aa9\u50b0\u5a07\u6b72\u69d6\u6559\u536a\u6835\u6c9c\u4e5c\u546a\u628b\u5abf\u6ac5\u4fa0\u5ab6\u5574\u568a\u6846\u5e82\u5ff6(1961282370, -2061906440, "\u3ad7\u3abb\u3abb\u3a88\u3a88\u3a8d\u3a9f\u3ac1\u3aa1\u3a88\u3ac8\u3a95\u3a97\u3a84\u3a86\u3a95\u3acb\u3a94\u3aaa\u524c\u6817\u6a88\u56c2\u69cb\u5506\u63b8\u6fe6\u680a\u55db\u5dc8\u7531", 806596637, 2091158547)).append((this.parentNode == null) ? \u70db\u690a\u6e14\u5441\u52e3\u5af6\u69d5\u524e\u5387\u5bb3\u5bd3\u52c4\u6b85\u508a\u55b8\u5fde\u64fb\u5b08\u5ebf\u6c8b\u6aa9\u50b0\u5a07\u6b72\u69d6\u6559\u536a\u6835\u6c9c\u4e5c\u546a\u628b\u5abf\u6ac5\u4fa0\u5ab6\u5574\u568a\u6846\u5e82\u5ff6(1914374131, 498013757, "\ud205\ud264\ud27b\ud27f\ud264\ud22a", 765812737, -989682763) : this.parentNode.getName()).append(\u70db\u690a\u6e14\u5441\u52e3\u5af6\u69d5\u524e\u5387\u5bb3\u5bd3\u52c4\u6b85\u508a\u55b8\u5fde\u64fb\u5b08\u5ebf\u6c8b\u6aa9\u50b0\u5a07\u6b72\u69d6\u6559\u536a\u6835\u6c9c\u4e5c\u546a\u628b\u5abf\u6ac5\u4fa0\u5ab6\u5574\u568a\u6846\u5e82\u5ff6(870256929, -143782552, "\u1fd2\u1ff7\u1f9a\u1fb5\u1fb7\u1ffd\u1fb9\u1fbe\u1f9f\u1fb6\u1fbd\u1fb9\u1fab\u1fb1\u1f98\u1f96", -1622982862, 636828874));
        final Iterator<CommandArgument<?, ?>> iterator = this.children.iterator();
        while (iterator.hasNext()) {
            append.append(iterator.next().getName());
            "\u6b7d".length();
            if (iterator.hasNext()) {
                append.append(\u70db\u690a\u6e14\u5441\u52e3\u5af6\u69d5\u524e\u5387\u5bb3\u5bd3\u52c4\u6b85\u508a\u55b8\u5fde\u64fb\u5b08\u5ebf\u6c8b\u6aa9\u50b0\u5a07\u6b72\u69d6\u6559\u536a\u6835\u6c9c\u4e5c\u546a\u628b\u5abf\u6ac5\u4fa0\u5ab6\u5574\u568a\u6846\u5e82\u5ff6(-1484721200, -2048225451, "\ue0ed\ue0c2", -778416793, -847261344));
                "\u6fae\u6265\u5643\u5278".length();
                "\u5c9d\u67bb".length();
                "\u544b\u5c57\u5c39\u5138".length();
            }
        }
        return append.append(\u70db\u690a\u6e14\u5441\u52e3\u5af6\u69d5\u524e\u5387\u5bb3\u5bd3\u52c4\u6b85\u508a\u55b8\u5fde\u64fb\u5b08\u5ebf\u6c8b\u6aa9\u50b0\u5a07\u6b72\u69d6\u6559\u536a\u6835\u6c9c\u4e5c\u546a\u628b\u5abf\u6ac5\u4fa0\u5ab6\u5574\u568a\u6846\u5e82\u5ff6(717881533, 381873435, "\u63bd", -235046840, -686033351)).toString();
    }
    
    public static int ColonialObfuscator_\u5d36\u4f76\u68f9\u5388\u6e09\u63de\u6e02\u66b9\u6790\u50a2\u5360\u5bad\u5095\u4f37\u5dc4\u5db2\u5e97\u6795\u53d4\u62bc\u5f17\u6fb3\u5b02\u5363\u5d6d\u5512\u5c4c\u5b10\u5a7c\u55a6\u5858\u6e6d\u556a\u6690\u53a8\u507d\u6a7a\u711f\u65df\u6a54\u5494(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
