package cloud.commandframework;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE, since = "1.4.0")
public interface ArgumentDescription
{
    String getDescription();
    
    default boolean isEmpty() {
        return this.getDescription().isEmpty();
    }
}
