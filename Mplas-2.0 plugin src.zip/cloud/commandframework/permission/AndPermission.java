package cloud.commandframework.permission;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class AndPermission implements CommandPermission
{
    public AndPermission(final Set<CommandPermission> s) {
        this.permissions = Collections.unmodifiableSet((Set<? extends CommandPermission>)s);
    }
    
    @Override
    public Collection<CommandPermission> getPermissions() {
        return this.permissions;
    }
    
    @Override
    public String toString() {
        "\u63e2\u6b50\u61b0\u56b0".length();
        "\u66a4\u659a\u5df9\u6f3d".length();
        final StringBuilder sb = new StringBuilder();
        final Iterator<CommandPermission> iterator = this.permissions.iterator();
        while (iterator.hasNext()) {
            sb.append('(').append(iterator.next().toString()).append(')');
            "\u5b78\u6f5b".length();
            "\u62fb\u501c\u57b5\u4e40\u6e65".length();
            "\u534d\u64a8".length();
            "\u692a\u5a53\u6339".length();
            "\u65df\u5477\u6474\u586c".length();
            if (iterator.hasNext()) {
                sb.append(\u53d3\u5ed6\u6e56\u51e8\u610d\u6f53\u70b6\u6d72\u5b1d\u5137\u5408\u5900\u4ea6\u6b73\u6583\u67e3\u5343\u50fc\u66fd\u4f6f\u60fb\u6bbd\u4e43\u6849\u4eb8\u5f81\u6892\u5a93\u691e\u6507\u5d14\u5221\u7015\u5ce6\u6b20\u6957\u7096\u5fb0\u627d\u668f\u4eb4(-732402045, -398024047, "\u5aca\u5ae1\u5ae3", -1023612198, 1725463649));
                "\u6e64".length();
                "\u61c8\u5688\u5efc\u5d83".length();
                "\u5409\u61e0\u6bbf".length();
            }
        }
        return sb.toString();
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && this.permissions.equals(((AndPermission)o).permissions));
    }
    
    @Override
    public int hashCode() {
        final Object[] values = { null };
        "\u5da4\u6893\u6d72".length();
        "\u59c7\u69d7\u6bd4".length();
        "\u6e5d\u59e0\u6f96\u50e7".length();
        values[0] = this.getPermissions();
        return Objects.hash(values);
    }
    
    public static int ColonialObfuscator_\u58b8\u5ec9\u70d0\u67e1\u6d7a\u54da\u66ef\u4e5c\u6b00\u5298\u55fe\u4f61\u70fe\u4f7a\u6bca\u5d87\u6c4e\u6c4e\u5f3e\u6d8d\u6658\u6d82\u5ae2\u6336\u636a\u59fb\u6507\u4f34\u712e\u5979\u5e05\u6584\u668a\u637b\u58b6\u6d5c\u604f\u5b52\u553e\u5c8b\u53fe(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
