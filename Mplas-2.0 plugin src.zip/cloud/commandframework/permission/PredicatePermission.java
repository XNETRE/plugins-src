package cloud.commandframework.permission;

import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.keys.*;
import java.util.*;

@FunctionalInterface
@API(status = API.Status.STABLE, since = "1.4.0")
public interface PredicatePermission<C> extends CommandPermission, CloudKeyHolder<Void>
{
    default CloudKey<Void> getKey() {
        return SimpleCloudKey.of(this.getClass().getSimpleName());
    }
    
    boolean hasPermission(final C p0);
    
    default Collection<CommandPermission> getPermissions() {
        return (Collection<CommandPermission>)Collections.singleton(this);
    }
}
