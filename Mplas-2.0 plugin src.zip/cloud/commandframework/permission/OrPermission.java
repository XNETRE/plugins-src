package cloud.commandframework.permission;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class OrPermission implements CommandPermission
{
    public OrPermission(final Set<CommandPermission> s) {
        this.permissions = Collections.unmodifiableSet((Set<? extends CommandPermission>)s);
    }
    
    @Override
    public Collection<CommandPermission> getPermissions() {
        return this.permissions;
    }
    
    @Override
    public String toString() {
        "\u5b0e\u509f\u6a26".length();
        "\u5431\u5d38\u638f\u62cd".length();
        "\u6e9c\u6659\u5883\u6eae".length();
        final StringBuilder sb = new StringBuilder();
        final Iterator<CommandPermission> iterator = this.permissions.iterator();
        while (iterator.hasNext()) {
            sb.append('(').append(iterator.next().toString()).append(')');
            "\u7104".length();
            if (iterator.hasNext()) {
                sb.append('|');
                "\u62e7\u6acb\u5c3f\u701e\u68ac".length();
                "\u5170\u5d74".length();
            }
        }
        return sb.toString();
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && this.permissions.equals(((OrPermission)o).permissions));
    }
    
    @Override
    public int hashCode() {
        final Object[] values = { null };
        "\u6dd4\u6149\u580b\u5e2f".length();
        "\u5aa5".length();
        "\u6c63\u5a9b\u66b7".length();
        values[0] = this.getPermissions();
        return Objects.hash(values);
    }
    
    public static int ColonialObfuscator_\u6dd9\u68c6\u585b\u702b\u62c6\u53ec\u605a\u5586\u5c69\u6c38\u5191\u5910\u59d0\u4fd0\u4e3e\u569b\u6f51\u56f0\u67c1\u5129\u67c5\u69b1\u5bf7\u53da\u5b6d\u68ee\u5467\u644c\u68fb\u6c7f\u6b6d\u5dbb\u7113\u5135\u5642\u5bc1\u5401\u501c\u5ab4\u6f23\u70a5(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
