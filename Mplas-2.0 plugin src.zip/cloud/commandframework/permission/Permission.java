package cloud.commandframework.permission;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class Permission implements CommandPermission
{
    public Permission(final String permission) {
        this.permission = permission;
    }
    
    public String getPermission() {
        return this.permission;
    }
    
    @Override
    public Collection<CommandPermission> getPermissions() {
        return (Collection<CommandPermission>)Collections.singleton(this);
    }
    
    @Override
    public String toString() {
        return this.permission;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && Objects.equals(this.getPermission(), ((Permission)o).getPermission()));
    }
    
    @Override
    public int hashCode() {
        final Object[] values = { null };
        "\u5dfc\u66c5\u6c74\u6560".length();
        "\u5f9d\u63e2\u67b5\u5711\u6de6".length();
        values[0] = this.getPermission();
        return Objects.hash(values);
    }
    
    public static int ColonialObfuscator_\u657b\u4fc2\u6f69\u537c\u6c76\u6eeb\u6c9e\u697b\u6c52\u572e\u70ba\u5c59\u6746\u667c\u5ec1\u55d0\u6f89\u560b\u5237\u5f09\u6cc1\u5574\u607e\u69df\u5883\u50ba\u50eb\u6cc3\u63d1\u51b3\u576a\u5302\u62c5\u63d4\u576d\u5b98\u6ce1\u5a0e\u54b9\u5da5\u6f28(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
