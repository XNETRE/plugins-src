package cloud.commandframework.permission;

import org.apiguardian.api.*;
import cloud.commandframework.keys.*;
import java.util.function.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class WrappingPredicatePermission<C> implements PredicatePermission<C>
{
    public WrappingPredicatePermission(final CloudKey<Void> key, final Predicate<C> predicate) {
        this.key = key;
        this.predicate = predicate;
    }
    
    @Override
    public boolean hasPermission(final C c) {
        return this.predicate.test(c);
    }
    
    @Override
    public CloudKey<Void> getKey() {
        return this.key;
    }
    
    @Override
    public String toString() {
        return this.key.getName();
    }
    
    public static int ColonialObfuscator_\u6dea\u58f7\u5e32\u4f5b\u5fbf\u53b3\u5ae4\u67c3\u56c7\u68d9\u6e90\u531c\u5ed9\u59e1\u6144\u4e89\u524d\u4e79\u5b3a\u621f\u6b02\u5e83\u6f8d\u59d0\u6a58\u6ce7\u4e97\u5b70\u60dd\u6e4c\u6426\u52a3\u6e48\u5cfa\u55ec\u6721\u5353\u53c8\u652c\u6b61\u5c1d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
