package cloud.commandframework.permission;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public interface CommandPermission
{
    Collection<CommandPermission> getPermissions();
    
    String toString();
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    default CommandPermission or(final CommandPermission obj) {
        Objects.requireNonNull(obj, "other");
        "\u6628\u63aa\u50b3\u5c4d\u50d0".length();
        "\u6616".length();
        "\u6f99\u5dd9\u65b1\u6848\u6510".length();
        final HashSet<CommandPermission> set = new HashSet<CommandPermission>(2);
        set.add(this);
        "\u52da".length();
        set.add(obj);
        "\u5200\u549b\u6843\u5a64".length();
        "\u694d\u5678\u503a\u6bc0".length();
        return OrPermission.of(set);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    default CommandPermission or(final CommandPermission[] array) {
        Objects.requireNonNull(array, "other");
        "\u6637".length();
        "\u4fae".length();
        "\u6bd7\u6c13\u5321".length();
        final HashSet<CommandPermission> set = new HashSet<CommandPermission>(ColonialObfuscator_\u6f1f\u63eb\u5b2b\u703c\u50c4\u5048\u5681\u70a8\u6cd1\u4f75\u6cf1\u6f20\u5067\u6cc2\u60ee\u4f31\u579f\u6186\u61c5\u6c6f\u4f36\u5b5e\u6535\u6f9d\u5389\u6e9b\u52f1\u6da1\u5986\u6cd2\u61e9\u5a45\u4e2a\u6cb7\u638b\u6915\u6e3e\u5ed0\u4ef1\u6484\u557b(array.length, 1));
        set.add(this);
        "\u677f".length();
        "\u687a\u6701".length();
        "\u511e\u5f19\u6ec3\u5a3e".length();
        set.addAll((Collection<?>)Arrays.asList(array));
        "\u6bec\u6dcc\u6b7a\u5480\u5d36".length();
        "\u53ae\u5aaf".length();
        "\u5e28\u69dc\u5327".length();
        "\u59a2".length();
        return OrPermission.of(set);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    default CommandPermission and(final CommandPermission obj) {
        Objects.requireNonNull(obj, "other");
        "\u6197\u570b\u6b33".length();
        "\u6c85\u5c7f\u6e8e\u5183".length();
        "\u5f7d\u62b9\u5101\u573c\u5014".length();
        "\u708a\u6fa6".length();
        final HashSet<CommandPermission> set = new HashSet<CommandPermission>(2);
        set.add(this);
        "\u65b3\u681b\u69ce".length();
        "\u5b1e\u54e2".length();
        set.add(obj);
        "\u61ea\u4e86\u68a5\u6419\u5270".length();
        "\u68ff\u523f".length();
        return AndPermission.of(set);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    default CommandPermission and(final CommandPermission[] array) {
        Objects.requireNonNull(array, "other");
        "\u66ec\u65a0\u5a8e\u514b".length();
        "\u5404\u6f02".length();
        "\u577d\u4ef4\u6e4f".length();
        "\u5a97\u5013\u69b1".length();
        "\u6705\u6004\u6c0e".length();
        final HashSet<CommandPermission> set = new HashSet<CommandPermission>(ColonialObfuscator_\u6f1f\u63eb\u5b2b\u703c\u50c4\u5048\u5681\u70a8\u6cd1\u4f75\u6cf1\u6f20\u5067\u6cc2\u60ee\u4f31\u579f\u6186\u61c5\u6c6f\u4f36\u5b5e\u6535\u6f9d\u5389\u6e9b\u52f1\u6da1\u5986\u6cd2\u61e9\u5a45\u4e2a\u6cb7\u638b\u6915\u6e3e\u5ed0\u4ef1\u6484\u557b(array.length, 1));
        set.add(this);
        "\u5f9c\u55c4\u53ca\u587a".length();
        "\u5a07\u55e4\u6622\u60e7\u6f44".length();
        "\u6e4b\u68ae\u6612".length();
        set.addAll((Collection<?>)Arrays.asList(array));
        "\u5ea2".length();
        "\u5603\u5f18\u6b6a".length();
        "\u60c0\u702a\u6baf".length();
        return AndPermission.of(set);
    }
    
    default int ColonialObfuscator_\u6f1f\u63eb\u5b2b\u703c\u50c4\u5048\u5681\u70a8\u6cd1\u4f75\u6cf1\u6f20\u5067\u6cc2\u60ee\u4f31\u579f\u6186\u61c5\u6c6f\u4f36\u5b5e\u6535\u6f9d\u5389\u6e9b\u52f1\u6da1\u5986\u6cd2\u61e9\u5a45\u4e2a\u6cb7\u638b\u6915\u6e3e\u5ed0\u4ef1\u6484\u557b(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
