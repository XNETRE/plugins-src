package cloud.commandframework.services;

import cloud.commandframework.services.types.*;
import io.leangen.geantyref.*;
import java.util.*;
import cloud.commandframework.services.annotations.*;
import java.lang.reflect.*;

public enum AnnotatedMethodServiceFactory
{
    INSTANCE;
    
    public Map<? extends Service<?, ?>, TypeToken<? extends Service<?, ?>>> lookupServices(final Object o) throws Exception {
        "\u5fc0\u65b0".length();
        "\u6cb9".length();
        final HashMap<AnnotatedMethodService<Object, Object>, TypeToken<? extends Service<?, ?>>> hashMap = new HashMap<AnnotatedMethodService<Object, Object>, TypeToken<? extends Service<?, ?>>>();
        final Method[] declaredMethods = o.getClass().getDeclaredMethods();
        for (int length = declaredMethods.length, i = 0; i < length; i += 4826, i -= 4825) {
            final Method method = declaredMethods[i];
            final ServiceImplementation serviceImplementation = method.getAnnotation(ServiceImplementation.class);
            if (serviceImplementation != null) {
                if (method.getParameterCount() != 1) {
                    "\u638a\u5fc9".length();
                    "\u6da4\u54bf\u59ca\u6f74".length();
                    final String \u627e\u6993\u60b2\u6452\u60c5\u5404\u5933\u688d\u5c8c\u4f9f\u7062\u568f\u6c5b\u6c46\u4f83\u7099\u6eb6\u6ed7\u57c1\u4e61\u58a8\u6535\u6640\u5564\u5885\u582c\u6243\u6a9c\u6a72\u5cca\u6a55\u6f52\u51da\u5dae\u5778\u5928\u6c30\u55a7\u6601\u70d4\u68a6 = \u627e\u6993\u60b2\u6452\u60c5\u5404\u5933\u688d\u5c8c\u4f9f\u7062\u568f\u6c5b\u6c46\u4f83\u7099\u6eb6\u6ed7\u57c1\u4e61\u58a8\u6535\u6640\u5564\u5885\u582c\u6243\u6a9c\u6a72\u5cca\u6a55\u6f52\u51da\u5dae\u5778\u5928\u6c30\u55a7\u6601\u70d4\u68a6(676068631, -1765177603, "\u6dd8\u6ddd\u6dc8\u6dd6\u6dd3\u6dde\u6d9d\u6d96\u6db4\u6dce\u6d99\u6d8c\u6dc0\u6dd6\u6da5\u6df2\u6de5\u6df4\u6dcc\u3eba\u35bb\u08f3\u1dd1\u307c\u0570\u1cc2\u3a87\u34a3\u09bb\u376a\u364c\u09d9\u2358\u04c6\u3811\u1cf5\u2302\u32cd\u3726\u2244\u3456\u04e5\u3e2d\u0e50\u0469\u08d0\u023e\u21e0\u07d7\u0908\u32c8\u3665\u2002\u3465\u0916\u0ab0\u3e5f\u04f2\u0950\u08d7\u0c57\u077d\u2114\u20b1\u33f3\u3049\u0ed1\u362c\u0582\u3c20\u0d30", 2098921938, 566171630);
                    final Object[] args = new Object[3];
                    "\u63ab".length();
                    "\u6cef".length();
                    args[0] = method.getName();
                    "\u684f\u7010\u5b5d\u6210".length();
                    "\u51fa".length();
                    "\u5cf5".length();
                    "\u5c10".length();
                    args[1] = o.getClass().getCanonicalName();
                    "\u688d".length();
                    "\u5b88\u6604".length();
                    "\u5595".length();
                    args[2] = method.getParameterCount();
                    final IllegalArgumentException ex = new IllegalArgumentException(String.format(\u627e\u6993\u60b2\u6452\u60c5\u5404\u5933\u688d\u5c8c\u4f9f\u7062\u568f\u6c5b\u6c46\u4f83\u7099\u6eb6\u6ed7\u57c1\u4e61\u58a8\u6535\u6640\u5564\u5885\u582c\u6243\u6a9c\u6a72\u5cca\u6a55\u6f52\u51da\u5dae\u5778\u5928\u6c30\u55a7\u6601\u70d4\u68a6, args));
                    "\u6059\u5276".length();
                    "\u5466\u5b99\u5551\u633f".length();
                    "\u64ed\u5e7b\u6202".length();
                    "\u51ba\u4fbf\u69d2".length();
                    throw ex;
                }
                final HashMap<AnnotatedMethodService<Object, Object>, TypeToken<? extends Service<?, ?>>> hashMap2 = hashMap;
                "\u54c9\u5c61\u5eed\u5e35\u53e9".length();
                "\u5c99\u544e\u6c87\u585f".length();
                "\u5e1f\u68fc\u5472".length();
                hashMap2.put(new AnnotatedMethodService<Object, Object>(o, method), TypeToken.get(serviceImplementation.value()));
                "\u5c76\u6284\u66a2".length();
                "\u556b\u564f\u701c\u51fa".length();
                "\u5bb2\u54b7\u64bc".length();
            }
        }
        return hashMap;
    }
    
    public static int ColonialObfuscator_\u673d\u63bb\u518d\u69c8\u6850\u4f4b\u51d0\u558e\u5be6\u6bad\u5eba\u5d9c\u5089\u5256\u70e8\u6224\u6457\u68a2\u66c8\u5982\u53d0\u5955\u659f\u6781\u64f1\u65c1\u6560\u63f2\u60d7\u6aa5\u6901\u602a\u596f\u61b1\u6c9d\u6af1\u614c\u5ac0\u57a1\u6566\u69a0(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
