package cloud.commandframework.services;

import cloud.commandframework.services.types.*;
import java.util.function.*;
import io.leangen.geantyref.*;
import java.util.*;

public enum ServiceFilterHandler
{
    INSTANCE;
    
    public <Context> boolean passes(final ServiceRepository.ServiceWrapper<? extends Service<Context, ?>> serviceWrapper, final Context context) {
        if (!serviceWrapper.isDefaultImplementation()) {
            for (final Predicate<Context> predicate : serviceWrapper.getFilters()) {
                try {
                    if (!predicate.test(context)) {
                        return false;
                    }
                    continue;
                }
                catch (Exception ex2) {
                    "\u5021\u64d6\u5854\u6fbd\u4f1b".length();
                    "\u525c\u6ce6\u5347\u6d64\u6427".length();
                    final String \u5cd9\u6587\u57dd\u6417\u5b84\u5e47\u58d4\u5833\u6171\u5a42\u4f54\u7037\u58c6\u5abf\u6d58\u677a\u553a\u6a55\u5e78\u5d08\u56c8\u5113\u53c6\u5ea9\u68a7\u66df\u6b8c\u5528\u59d4\u7068\u639f\u6966\u6ca6\u6558\u513c\u6758\u4efe\u618e\u518e\u6e42\u6819 = \u5cd9\u6587\u57dd\u6417\u5b84\u5e47\u58d4\u5833\u6171\u5a42\u4f54\u7037\u58c6\u5abf\u6d58\u677a\u553a\u6a55\u5e78\u5d08\u56c8\u5113\u53c6\u5ea9\u68a7\u66df\u6b8c\u5528\u59d4\u7068\u639f\u6966\u6ca6\u6558\u513c\u6758\u4efe\u618e\u518e\u6e42\u6819(-2027385964, -1510961575, "\u1d22\u1d28\u1d20\u1d27\u1d28\u1d2f\u1d60\u1d38\u1d7f\u1d1c\u1d5e\u1d5f\u1d49\u1d55\u1d4d\u1d4d\u1d4c\u1d41\u1d2a\u7651\u7880\u73e9\u41f6\u7c8a\u4bb9\u7437\u7583\u7ed2\u4901\u7ce7\u493d\u7085\u473f\u78a0\u4c46\u7e7e\u4ee2\u6d03\u7870", 39051832, -738788654);
                    final Object[] args = new Object[2];
                    "\u6d64\u52ee\u6ba2".length();
                    args[0] = TypeToken.get(predicate.getClass()).getType().getTypeName();
                    "\u51d0".length();
                    args[1] = serviceWrapper;
                    final PipelineException ex = new PipelineException(String.format(\u5cd9\u6587\u57dd\u6417\u5b84\u5e47\u58d4\u5833\u6171\u5a42\u4f54\u7037\u58c6\u5abf\u6d58\u677a\u553a\u6a55\u5e78\u5d08\u56c8\u5113\u53c6\u5ea9\u68a7\u66df\u6b8c\u5528\u59d4\u7068\u639f\u6966\u6ca6\u6558\u513c\u6758\u4efe\u618e\u518e\u6e42\u6819, args), ex2);
                    "\u5c99\u67bd\u59b4\u5a6b".length();
                    "\u58be\u592d\u59e3\u5a5d\u56c4".length();
                    "\u6c25".length();
                    "\u5863".length();
                    throw ex;
                }
            }
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u6653\u6358\u7043\u5edb\u6126\u6b5d\u4fca\u6d44\u52a9\u5146\u6214\u5ad0\u532c\u66c9\u5354\u66de\u5599\u4fa3\u6082\u51ed\u5cdc\u50f8\u65ee\u639d\u5d6e\u5859\u5e3d\u5ffc\u5b25\u5457\u4e4b\u6b7b\u4f8c\u57f4\u6251\u6553\u5473\u6aa3\u6443\u52d0\u5c00(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
