package cloud.commandframework.services;

public final class PipelineException extends RuntimeException
{
    public PipelineException(final Exception cause) {
        super(cause);
    }
    
    public PipelineException(final String message, final Exception cause) {
        super(message, cause);
    }
    
    public static int ColonialObfuscator_\u6624\u67ec\u54f4\u6be0\u5285\u6409\u6268\u5b2e\u6fe7\u5cb5\u571b\u4f83\u5625\u60c4\u6849\u56ae\u53df\u6455\u62c9\u5543\u65c9\u596c\u65bf\u5d35\u55cc\u5fc2\u6dcb\u4f30\u4e51\u6401\u4f95\u5d2f\u603c\u5c60\u5cc1\u4ea9\u54e1\u544b\u6938\u528b\u504d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
