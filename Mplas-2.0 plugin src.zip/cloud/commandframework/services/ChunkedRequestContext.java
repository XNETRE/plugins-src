package cloud.commandframework.services;

import java.util.*;

public abstract class ChunkedRequestContext<Context, Result>
{
    public ChunkedRequestContext(final Collection<Context> c) {
        this.lock = new Object();
        this.requests = new ArrayList<Context>((Collection<? extends Context>)c);
        this.results = new HashMap<Context, Result>(c.size());
    }
    
    public final Map<Context, Result> getAvailableResults() {
        final Object lock = this.lock;
        "\u58dc\u65e3".length();
        "\u6b25\u5939\u544d".length();
        "\u624c".length();
        final Object o = lock;
        // monitorenter(lock)
        try {
            // monitorexit(o)
            return Collections.unmodifiableMap((Map<? extends Context, ? extends Result>)this.results);
        }
        finally {
            // monitorexit(o)
            "\u509d\u6e15".length();
        }
    }
    
    public final List<Context> getRemaining() {
        final Object lock = this.lock;
        "\u52a1\u633c".length();
        "\u56af\u4f49".length();
        "\u5b77\u5589\u569b".length();
        "\u629b\u5e54".length();
        final Object o = lock;
        // monitorenter(lock)
        try {
            // monitorexit(o)
            return Collections.unmodifiableList((List<? extends Context>)this.requests);
        }
        finally {
            // monitorexit(o)
            "\u6bc2\u559a\u4f87\u5923".length();
            "\u572d".length();
        }
    }
    
    public final void storeResult(final Context context, final Result result) {
        final Object lock = this.lock;
        "\u5de6\u5011\u5e51\u586f\u5876".length();
        "\u6b21\u63ff".length();
        final Object o = lock;
        // monitorenter(lock)
        try {
            this.results.put(context, result);
            "\u5419".length();
            "\u69de\u6b8d\u60a2".length();
            this.requests.remove(context);
            "\u5b7d\u6f91\u5555\u6d78".length();
            "\u51ca\u602d\u683d\u4e67".length();
        }
        // monitorexit(o)
        finally {
            // monitorexit(o)
            "\u6ebe\u6b4b\u4fda\u6acb\u6100".length();
            "\u64fa\u694b\u6d5f\u5e06\u6a7d".length();
        }
    }
    
    public final boolean isCompleted() {
        final Object lock = this.lock;
        "\u6cc3\u6830".length();
        "\u64d6\u506d".length();
        final Object o = lock;
        // monitorenter(lock)
        try {
            // monitorexit(o)
            return this.requests.isEmpty();
        }
        finally {
            // monitorexit(o)
            "\u5164\u6ac5\u4faa\u6f5b\u5f52".length();
            "\u670e".length();
            "\u508a".length();
            "\u6470\u635c\u65d1".length();
        }
    }
    
    public static int ColonialObfuscator_\u5d28\u59c6\u7005\u4e7f\u56ea\u636e\u6c65\u70b1\u60f2\u5699\u5d91\u6777\u5ab7\u7127\u61a9\u706c\u54a5\u6de3\u5be6\u65a6\u67db\u70a2\u6c0e\u5897\u55a5\u668b\u4f49\u5b25\u6487\u6bcf\u5c9a\u5af4\u6392\u6519\u50df\u64ae\u50ad\u6bef\u5dc5\u565c\u5189(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
