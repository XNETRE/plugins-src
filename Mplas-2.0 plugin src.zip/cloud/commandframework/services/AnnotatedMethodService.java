package cloud.commandframework.services;

import cloud.commandframework.services.types.*;
import java.lang.reflect.*;
import cloud.commandframework.services.annotations.*;
import java.lang.invoke.*;
import java.util.*;

public class AnnotatedMethodService<Context, Result> implements Service<Context, Result>
{
    public AnnotatedMethodService(final Object instance, final Method method) throws Exception {
        ExecutionOrder executionOrder = ExecutionOrder.SOON;
        try {
            final Order order = method.getAnnotation(Order.class);
            if (order != null) {
                executionOrder = order.value();
            }
        }
        catch (Exception ex) {}
        this.instance = instance;
        this.executionOrder = executionOrder;
        method.setAccessible(true);
        this.methodHandle = MethodHandles.lookup().unreflect(method);
        this.method = method;
    }
    
    @Override
    public Result handle(final Context context) {
        try {
            return (Result)this.methodHandle.invoke(this.instance, (Object)context);
        }
        catch (Throwable cause) {
            "\u54b8\u6681\u67b2\u63a8\u51a4".length();
            "\u7051\u7030".length();
            final String \u56ee\u5d15\u545e\u6d5f\u50f8\u66af\u524a\u51eb\u593a\u566b\u5b01\u5cc3\u708f\u561f\u68d6\u6e16\u69dd\u6893\u60fd\u52dd\u5d5d\u70ae\u501c\u5fc1\u70c2\u5d30\u6576\u5aee\u6bf6\u4e29\u536f\u5c28\u522a\u5600\u5e30\u4fdf\u6d2c\u671a\u6079\u66de\u58c7 = \u56ee\u5d15\u545e\u6d5f\u50f8\u66af\u524a\u51eb\u593a\u566b\u5b01\u5cc3\u708f\u561f\u68d6\u6e16\u69dd\u6893\u60fd\u52dd\u5d5d\u70ae\u501c\u5fc1\u70c2\u5d30\u6576\u5aee\u6bf6\u4e29\u536f\u5c28\u522a\u5600\u5e30\u4fdf\u6d2c\u671a\u6079\u66de\u58c7(1318871072, 255304824, "\uce92\uce9a\uce90\uce99\uce90\uce95\uced8\uce86\ucebf\ucede\uce98\ucef6\ucefc\uceef\ucea0\uceff\uceed\ucee2\uced2\u9540\u9b91\u9bb1\u804f\ube01\uaac4\ua656\u9ecd\uab58\ube46\uaee5\ua1b6\u9c57\uab00\uaa61\ua1db\u9a3d\u92cd\u950a\u9b6f\uab94\u952a\uabe8\u9ef8\uaf76\uac9a\u9be2\ua427\ua159\u9cb0\u9b88\u973d\uae5d\uab58\u9271\u9172\ua5d8\u9b16\u9590\u9973\u8128\ua369\u940f\ua334", 306692405, -36910086);
            final Object[] args = new Object[2];
            "\u62f4\u5f27\u4f5e".length();
            "\u60d0\u5a39\u6de1\u5603".length();
            "\u7006\u5e8b\u57ed".length();
            "\u6c55\u5330\u5955\u4f2d\u5395".length();
            args[0] = this.method.getName();
            "\u617b\u6e62\u5b44\u5657\u5b3e".length();
            "\u6cf0\u6fa0\u711a\u5602\u6839".length();
            "\u5841\u5f91".length();
            args[1] = this.instance.getClass().getCanonicalName();
            new IllegalStateException(String.format(\u56ee\u5d15\u545e\u6d5f\u50f8\u66af\u524a\u51eb\u593a\u566b\u5b01\u5cc3\u708f\u561f\u68d6\u6e16\u69dd\u6893\u60fd\u52dd\u5d5d\u70ae\u501c\u5fc1\u70c2\u5d30\u6576\u5aee\u6bf6\u4e29\u536f\u5c28\u522a\u5600\u5e30\u4fdf\u6d2c\u671a\u6079\u66de\u58c7, args), cause).printStackTrace();
            return null;
        }
    }
    
    @Override
    public ExecutionOrder order() {
        return this.executionOrder;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && Objects.equals(this.methodHandle, ((AnnotatedMethodService)o).methodHandle));
    }
    
    @Override
    public int hashCode() {
        final Object[] values = { null };
        "\u5044\u65e5\u6ca1\u6147\u6ee4".length();
        "\u67cc".length();
        "\u54ca\u5571\u6105\u5504\u52f6".length();
        "\u564f\u6d48\u6fd2\u6129".length();
        "\u5231".length();
        values[0] = this.methodHandle;
        return Objects.hash(values);
    }
    
    public static int ColonialObfuscator_\u50bc\u57e0\u5e23\u6de0\u510a\u5f37\u523c\u6890\u5f93\u70cd\u64fa\u5afa\u6ef7\u56df\u68af\u642d\u6a94\u50f6\u6289\u4e8c\u5018\u6bfe\u7093\u5cd5\u5eef\u61bb\u5d76\u6fcc\u573f\u6a1b\u63a1\u579c\u5710\u5627\u5cc3\u5269\u62a8\u620c\u6aad\u5452\u62c9(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
