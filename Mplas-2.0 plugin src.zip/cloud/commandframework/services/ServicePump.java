package cloud.commandframework.services;

import io.leangen.geantyref.*;
import cloud.commandframework.services.types.*;

public final class ServicePump<Context>
{
    public ServicePump(final ServicePipeline servicePipeline, final Context context) {
        this.servicePipeline = servicePipeline;
        this.context = context;
    }
    
    public <Result> ServiceSpigot<Context, Result> through(final TypeToken<? extends Service<Context, Result>> typeToken) {
        "\u6745\u65c0\u4fbd\u4fcb\u6741".length();
        "\u6f2b\u6530\u575e\u4ec4\u4fc4".length();
        return new ServiceSpigot<Context, Result>(this.servicePipeline, this.context, typeToken);
    }
    
    public <Result> ServiceSpigot<Context, Result> through(final Class<? extends Service<Context, Result>> clazz) {
        return this.through((TypeToken<? extends Service<Context, Result>>)TypeToken.get((Class<? extends Service<Context, Result>>)clazz));
    }
    
    public static int ColonialObfuscator_\u6cd0\u61cb\u5705\u6196\u5276\u6feb\u660f\u53e8\u684f\u62e0\u4ee8\u6032\u588b\u5fa5\u5685\u66d8\u5afd\u5482\u6ee3\u5e35\u62eb\u6562\u6abd\u5c6d\u6bd9\u54ce\u57dc\u63bd\u63e2\u63d9\u514f\u5049\u58be\u6f1a\u6aed\u5201\u6298\u658e\u6e46\u556f\u6912(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
