package cloud.commandframework.services;

public enum ExecutionOrder
{
    LAST, 
    LATER, 
    LATE, 
    SOON, 
    SOONER, 
    FIRST;
    
    public static int ColonialObfuscator_\u68da\u502e\u6222\u6355\u61b3\u4fe5\u65e3\u6b9e\u595d\u579b\u6e7b\u5862\u5d98\u63ba\u53e8\u6dad\u70ef\u4e39\u592f\u5939\u5f1f\u626f\u69b5\u69bf\u5757\u5a7f\u6273\u5838\u699e\u664a\u6549\u5de9\u5e50\u6300\u5a45\u5bb7\u5397\u66e3\u57c0\u5569\u5765(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
