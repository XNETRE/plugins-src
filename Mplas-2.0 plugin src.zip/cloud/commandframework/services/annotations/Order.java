package cloud.commandframework.services.annotations;

import java.lang.annotation.*;
import cloud.commandframework.services.*;

@Target({ ElementType.TYPE, ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface Order {
    ExecutionOrder value() default ExecutionOrder.SOON;
}
