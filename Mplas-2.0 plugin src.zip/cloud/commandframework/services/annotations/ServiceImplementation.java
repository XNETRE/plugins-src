package cloud.commandframework.services.annotations;

import java.lang.annotation.*;
import cloud.commandframework.services.types.*;

@Target({ ElementType.METHOD })
@Retention(RetentionPolicy.RUNTIME)
public @interface ServiceImplementation {
    Class<? extends Service<?, ?>> value();
}
