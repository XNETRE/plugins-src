package cloud.commandframework.services;

import java.lang.reflect.*;
import java.util.concurrent.*;
import io.leangen.geantyref.*;
import cloud.commandframework.services.types.*;
import java.util.function.*;
import java.util.*;

public final class ServicePipeline
{
    public ServicePipeline(final Executor executor) {
        this.lock = new Object();
        this.repositories = new HashMap<Type, ServiceRepository<?, ?>>();
        this.executor = executor;
    }
    
    public <Context, Result> ServicePipeline registerServiceType(final TypeToken<? extends Service<Context, Result>> typeToken, final Service<Context, Result> service) {
        final Object lock = this.lock;
        "\u5123\u61ca\u57d6\u6141\u6128".length();
        "\u4f82\u5f2f".length();
        "\u6aab\u5728\u6ab2\u665b\u567e".length();
        final Object o = lock;
        // monitorenter(lock)
        try {
            if (this.repositories.containsKey(typeToken.getType())) {
                "\u57f4\u6360\u62cf\u61fc\u4e50".length();
                "\u610e".length();
                "\u59b8\u5399\u60e4".length();
                "\u5d6e".length();
                final String \u5338\u6390\u616c\u5f12\u689d\u61b6\u6df5\u6328\u54ea\u6d0e\u5f10\u6d40\u5f74\u5dbf\u673c\u690d\u5118\u601a\u6bb6\u645b\u5929\u5e9a\u5789\u6042\u56e8\u5028\u5d11\u5cd1\u62a4\u57cb\u5164\u687e\u56fe\u67a8\u6cc4\u6b93\u5e07\u54f6\u6f51\u6a11\u5539 = \u5338\u6390\u616c\u5f12\u689d\u61b6\u6df5\u6328\u54ea\u6d0e\u5f10\u6d40\u5f74\u5dbf\u673c\u690d\u5118\u601a\u6bb6\u645b\u5929\u5e9a\u5789\u6042\u56e8\u5028\u5d11\u5cd1\u62a4\u57cb\u5164\u687e\u56fe\u67a8\u6cc4\u6b93\u5e07\u54f6\u6f51\u6a11\u5539(-154112709, -1319284044, "\uf4d7\uf4cc\uf4db\uf4dd\uf4cc\uf4c0\uf4cd\uf484\uf4ef\uf4ca\uf48b\uf4cd\uf4d9\uf4c1\uf4d5\uf484\uf49f\uf481\uf4f9\u9251\uacdd\u949c\u9664\uae03\ua3c7\u8455\ua419\ua320\ua612\u90c8\u9a8e\u84ac\u84fe\u9d09\u9f43\u9274\ua058\uae81\u9a16\u9f98\u8440\ua1b6\uad12\u9851\u93bc\uaa33\u9a8f\ua389", 1988684932, 603334604);
                final Object[] args = { null };
                "\u6137".length();
                "\u67f1\u5706\u5ac4\u648d".length();
                "\u6279\u5bad".length();
                "\u4f50\u5218\u59ba\u5894\u702b".length();
                args[0] = typeToken.getType().getTypeName();
                final IllegalArgumentException ex = new IllegalArgumentException(String.format(\u5338\u6390\u616c\u5f12\u689d\u61b6\u6df5\u6328\u54ea\u6d0e\u5f10\u6d40\u5f74\u5dbf\u673c\u690d\u5118\u601a\u6bb6\u645b\u5929\u5e9a\u5789\u6042\u56e8\u5028\u5d11\u5cd1\u62a4\u57cb\u5164\u687e\u56fe\u67a8\u6cc4\u6b93\u5e07\u54f6\u6f51\u6a11\u5539, args));
                "\u6436\u5576".length();
                throw ex;
            }
            "\u6bd0".length();
            "\u6004\u5175\u66ed\u56bd".length();
            "\u64f1".length();
            "\u55e9".length();
            final ServiceRepository<Object, Object> serviceRepository = new ServiceRepository<Object, Object>((TypeToken<? extends Service<Object, Object>>)typeToken);
            serviceRepository.registerImplementation(service, (Collection<Predicate<?>>)Collections.emptyList());
            this.repositories.put(typeToken.getType(), serviceRepository);
            "\u65db\u5e37\u5f37".length();
            "\u5cff".length();
            // monitorexit(o)
            return this;
        }
        finally {
            // monitorexit(o)
            "\u675e\u5e84\u628c".length();
            "\u6214\u5a16\u64ee".length();
        }
    }
    
    public <T> ServicePipeline registerMethods(final T t) throws Exception {
        final Object lock = this.lock;
        "\u65e7\u5b73\u70fc\u5b19\u55a3".length();
        final Object o = lock;
        // monitorenter(lock)
        try {
            for (final Map.Entry<? extends Service<?, ?>, TypeToken<? extends Service<?, ?>>> entry : AnnotatedMethodServiceFactory.INSTANCE.lookupServices(t).entrySet()) {
                final TypeToken<? extends Service<?, ?>> typeToken = entry.getValue();
                final ServiceRepository<Object, Object> serviceRepository = this.repositories.get(typeToken.getType());
                if (serviceRepository == null) {
                    "\u5e22\u55f0".length();
                    final String \u5338\u6390\u616c\u5f12\u689d\u61b6\u6df5\u6328\u54ea\u6d0e\u5f10\u6d40\u5f74\u5dbf\u673c\u690d\u5118\u601a\u6bb6\u645b\u5929\u5e9a\u5789\u6042\u56e8\u5028\u5d11\u5cd1\u62a4\u57cb\u5164\u687e\u56fe\u67a8\u6cc4\u6b93\u5e07\u54f6\u6f51\u6a11\u5539 = \u5338\u6390\u616c\u5f12\u689d\u61b6\u6df5\u6328\u54ea\u6d0e\u5f10\u6d40\u5f74\u5dbf\u673c\u690d\u5118\u601a\u6bb6\u645b\u5929\u5e9a\u5789\u6042\u56e8\u5028\u5d11\u5cd1\u62a4\u57cb\u5164\u687e\u56fe\u67a8\u6cc4\u6b93\u5e07\u54f6\u6f51\u6a11\u5539(-58842879, 1176575888, "\u6e9b\u6e97\u6ec4\u6e95\u6e81\u6e90\u6e9b\u6e88\u6ea2\u6e88\u6ec6\u6e86\u6e94\u6e87\u6e8c\u6e82\u6e9d\u6e90\u6e95\u087e\u36f8\u0eb5\u0c06\u347a\u39f4\u1e75\u3e6c\u3946\u3c56\u0a9d\u009f\u1ea7\u1eaa\u0749\u054c", 1236330382, 168146825);
                    final Object[] args = { null };
                    "\u5b4b\u6d2f\u5920".length();
                    "\u676f\u55d0\u5010\u6f3f".length();
                    args[0] = typeToken.getType().getTypeName();
                    final IllegalArgumentException ex = new IllegalArgumentException(String.format(\u5338\u6390\u616c\u5f12\u689d\u61b6\u6df5\u6328\u54ea\u6d0e\u5f10\u6d40\u5f74\u5dbf\u673c\u690d\u5118\u601a\u6bb6\u645b\u5929\u5e9a\u5789\u6042\u56e8\u5028\u5d11\u5cd1\u62a4\u57cb\u5164\u687e\u56fe\u67a8\u6cc4\u6b93\u5e07\u54f6\u6f51\u6a11\u5539, args));
                    "\u55f0\u665d\u57c8\u6643".length();
                    "\u4ed4\u58c2\u686f\u6fe5".length();
                    "\u6185".length();
                    throw ex;
                }
                serviceRepository.registerImplementation((Service)entry.getKey(), (Collection<Predicate<Object>>)Collections.emptyList());
            }
        }
        // monitorexit(o)
        finally {
            // monitorexit(o)
            "\u55d6\u6fef\u6eb1\u4f87\u5743".length();
        }
        return this;
    }
    
    public <Context, Result> ServicePipeline registerServiceImplementation(final TypeToken<? extends Service<Context, Result>> typeToken, final Service<Context, Result> service, final Collection<Predicate<Context>> collection) {
        final Object lock = this.lock;
        "\u672e\u5779".length();
        final Object o = lock;
        // monitorenter(lock)
        try {
            this.getRepository((TypeToken<? extends Service<Context, Response>>)typeToken).registerImplementation(service, collection);
        }
        // monitorexit(o)
        finally {
            // monitorexit(o)
            "\u6c6d".length();
            "\u5664\u577c\u66ab\u69f0".length();
        }
        return this;
    }
    
    public <Context, Result> ServicePipeline registerServiceImplementation(final Class<? extends Service<Context, Result>> clazz, final Service<Context, Result> service, final Collection<Predicate<Context>> collection) {
        return this.registerServiceImplementation((TypeToken<? extends Service<Context, Result>>)TypeToken.get((Class<? extends Service<Context, Result>>)clazz), service, collection);
    }
    
    public <Context> ServicePump<Context> pump(final Context context) {
        "\u5ece\u585d".length();
        "\u5bf4\u4f8f\u5726\u5a94\u564d".length();
        return new ServicePump<Context>(this, context);
    }
    
    public <Context, Result> ServiceRepository<Context, Result> getRepository(final TypeToken<? extends Service<Context, Result>> typeToken) {
        final ServiceRepository<?, ?> serviceRepository = this.repositories.get(typeToken.getType());
        if (serviceRepository == null) {
            "\u6dcb".length();
            "\u581a".length();
            "\u4f76\u4e2e\u6bd1".length();
            final String \u5338\u6390\u616c\u5f12\u689d\u61b6\u6df5\u6328\u54ea\u6d0e\u5f10\u6d40\u5f74\u5dbf\u673c\u690d\u5118\u601a\u6bb6\u645b\u5929\u5e9a\u5789\u6042\u56e8\u5028\u5d11\u5cd1\u62a4\u57cb\u5164\u687e\u56fe\u67a8\u6cc4\u6b93\u5e07\u54f6\u6f51\u6a11\u5539 = \u5338\u6390\u616c\u5f12\u689d\u61b6\u6df5\u6328\u54ea\u6d0e\u5f10\u6d40\u5f74\u5dbf\u673c\u690d\u5118\u601a\u6bb6\u645b\u5929\u5e9a\u5789\u6042\u56e8\u5028\u5d11\u5cd1\u62a4\u57cb\u5164\u687e\u56fe\u67a8\u6cc4\u6b93\u5e07\u54f6\u6f51\u6a11\u5539(-172016925, -89644899, "\u73b1\u73bd\u73f6\u73a7\u73b3\u73a2\u73a1\u73b2\u7398\u73b2\u73f4\u73b4\u73a6\u73b5\u73c6\u73c8\u73d7\u73da\u73e7\u150c\u2b8a\u13c7\u117c\u2900\u248e\u030f\u231e\u2434\u2124\u17ef\u1df5\u03cd\u03c0\u1a23\u183e", 1944235954, -1290549648);
            final Object[] args = { null };
            "\u6cc0\u5b3b\u6c0b\u6fd1\u6f85".length();
            "\u6076".length();
            "\u5e7d".length();
            args[0] = typeToken.getType().getTypeName();
            final IllegalArgumentException ex = new IllegalArgumentException(String.format(\u5338\u6390\u616c\u5f12\u689d\u61b6\u6df5\u6328\u54ea\u6d0e\u5f10\u6d40\u5f74\u5dbf\u673c\u690d\u5118\u601a\u6bb6\u645b\u5929\u5e9a\u5789\u6042\u56e8\u5028\u5d11\u5cd1\u62a4\u57cb\u5164\u687e\u56fe\u67a8\u6cc4\u6b93\u5e07\u54f6\u6f51\u6a11\u5539, args));
            "\u60aa\u5b96\u5dff\u5172\u569e".length();
            "\u5416\u4efc\u6a46\u51c7\u69ec".length();
            "\u51c3\u5156".length();
            "\u6925\u68df\u4fa9\u52f6".length();
            throw ex;
        }
        return (ServiceRepository<Context, Result>)serviceRepository;
    }
    
    public Collection<Type> getRecognizedTypes() {
        return Collections.unmodifiableCollection((Collection<? extends Type>)this.repositories.keySet());
    }
    
    public <Context, Result, S extends Service<Context, Result>> Collection<TypeToken<? extends S>> getImplementations(final TypeToken<S> typeToken) {
        final ServiceRepository<Object, Object> repository = this.getRepository((TypeToken<? extends Service<Object, Object>>)typeToken);
        "\u6d9c\u6cd2\u66d8\u5034\u6821".length();
        "\u6fd8\u585d".length();
        final LinkedList<TypeToken<?>> list = new LinkedList<TypeToken<?>>();
        final LinkedList<ServiceRepository.ServiceWrapper<? extends Service<Object, Object>>> queue = repository.getQueue();
        queue.sort(null);
        Collections.reverse(queue);
        final Iterator<ServiceRepository.ServiceWrapper<Object>> iterator = queue.iterator();
        while (iterator.hasNext()) {
            list.add(TypeToken.get(iterator.next().getImplementation().getClass()));
            "\u6526\u5803\u4fc8\u4f56".length();
            "\u6d2a\u5385\u51e5\u6dc8".length();
            "\u6b52\u6abd\u6820".length();
            "\u6491\u5c14\u60d3\u6fea\u6cdb".length();
        }
        return (Collection<TypeToken<? extends S>>)Collections.unmodifiableList((List<?>)list);
    }
    
    public Executor getExecutor() {
        return this.executor;
    }
    
    public static int ColonialObfuscator_\u6f34\u6bad\u525d\u6af2\u5b7f\u56ed\u56ea\u64e1\u4fe5\u6f37\u6c3d\u6988\u5e5b\u59ad\u50d7\u65aa\u5a22\u5f7b\u66cf\u5c64\u640d\u5e2f\u61e2\u6f13\u5d98\u67ed\u4f97\u5e58\u5865\u52cf\u5c72\u638b\u6ff2\u5f7f\u6c8f\u5881\u4eb3\u5ecf\u6ad3\u5557\u5d46(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
