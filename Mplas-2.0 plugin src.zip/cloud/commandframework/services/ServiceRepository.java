package cloud.commandframework.services;

import io.leangen.geantyref.*;
import cloud.commandframework.services.types.*;
import java.util.function.*;
import cloud.commandframework.services.annotations.*;
import java.util.*;

public final class ServiceRepository<Context, Response>
{
    public ServiceRepository(final TypeToken<? extends Service<Context, Response>> serviceType) {
        this.lock = new Object();
        this.registrationOrder = 0;
        this.serviceType = serviceType;
        this.implementations = new LinkedList<ServiceWrapper<? extends Service<Context, Response>>>();
    }
    
    public <T extends Service<Context, Response>> void registerImplementation(final T t, final Collection<Predicate<Context>> collection) {
        final Object lock = this.lock;
        "\u6de0\u528e\u53d2".length();
        "\u5354".length();
        "\u68c8\u5b4e\u6944".length();
        final Object o = lock;
        // monitorenter(lock)
        try {
            final List<ServiceWrapper<? extends Service<Context, Response>>> implementations = this.implementations;
            "\u6a91\u4f7a\u592a".length();
            "\u508d".length();
            "\u5f4a".length();
            implementations.add(new ServiceWrapper<Service<Context, Response>>(t, collection, null));
            "\u5c74".length();
        }
        // monitorexit(o)
        finally {
            // monitorexit(o)
            "\u5a25\u5113\u7136\u4fa6".length();
            "\u5a8a".length();
            "\u7122".length();
            "\u6760\u6131\u6499".length();
        }
    }
    
    public LinkedList<ServiceWrapper<? extends Service<Context, Response>>> getQueue() {
        final Object lock = this.lock;
        "\u6c54\u5a92\u5c1d\u654f\u5777".length();
        final Object o = lock;
        // monitorenter(lock)
        try {
            "\u5049\u5394".length();
            "\u6ea5\u6dd9\u5d51\u5479".length();
            "\u5238\u58ad\u638f\u4f2b".length();
            // monitorexit(o)
            return new LinkedList<ServiceWrapper<? extends Service<Context, Response>>>(this.implementations);
        }
        finally {
            // monitorexit(o)
            "\u5cd6\u4ece\u5c95\u6574\u712b".length();
            "\u5985\u5c70\u66cd".length();
            "\u6306\u65a3".length();
            "\u6b81\u691a\u56f6".length();
        }
    }
    
    public static int ColonialObfuscator_\u5824\u5489\u4e89\u6516\u6ead\u5c05\u6d72\u56e6\u6762\u50d2\u523a\u609c\u4f54\u54f0\u6eda\u6c6d\u6b86\u5f52\u5a11\u65b5\u708d\u6c72\u58a0\u6a70\u65c0\u64c5\u5a5f\u5fbd\u6ea5\u5e69\u5f73\u5889\u6a6a\u51ac\u6bd2\u6c6f\u6fbc\u5cda\u7034\u7081\u5e4e(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
