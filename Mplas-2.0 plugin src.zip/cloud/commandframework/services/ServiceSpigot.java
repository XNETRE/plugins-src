package cloud.commandframework.services;

import io.leangen.geantyref.*;
import cloud.commandframework.services.types.*;
import java.util.concurrent.*;
import java.util.*;
import java.util.function.*;

public final class ServiceSpigot<Context, Result>
{
    public ServiceSpigot(final ServicePipeline pipeline, final Context context, final TypeToken<? extends Service<Context, Result>> typeToken) {
        this.context = context;
        this.pipeline = pipeline;
        this.repository = pipeline.getRepository(typeToken);
    }
    
    public Result getResult() throws IllegalStateException, PipelineException {
        final LinkedList<ServiceRepository.ServiceWrapper<? extends Service<Context, Result>>> queue = this.repository.getQueue();
        queue.sort(null);
        boolean b = false;
        while (true) {
            final ServiceRepository.ServiceWrapper<? extends Service<Context, Result>> serviceWrapper = queue.pollLast();
            "\u4fd6\u661a\u5573".length();
            "\u6b63\u5550\u564c".length();
            "\u4e61".length();
            "\u4e3d\u67bb\u65c7".length();
            final ServiceRepository.ServiceWrapper<? extends Service<Context, Result>> serviceWrapper2 = serviceWrapper;
            if (serviceWrapper != null) {
                b = (serviceWrapper2.getImplementation() instanceof ConsumerService);
                if (!ServiceFilterHandler.INSTANCE.passes(serviceWrapper2, this.context)) {
                    continue;
                }
                Object handle;
                try {
                    handle = ((Service<Context, Object>)serviceWrapper2.getImplementation()).handle(this.context);
                }
                catch (Exception ex2) {
                    "\u62bb\u6b97\u5825\u5cbc".length();
                    "\u63b3".length();
                    "\u63ab\u596d\u671b".length();
                    "\u5b32\u4e30".length();
                    final String \u6753\u568d\u6dc6\u67d2\u5a10\u5bef\u6e1e\u6a34\u6e7c\u521d\u544a\u5154\u5443\u6652\u5d96\u62ef\u5560\u6c6b\u50e6\u60b7\u6fa3\u707b\u6c6a\u6bc9\u51be\u4fc7\u5f79\u5178\u5574\u5c20\u5443\u4e82\u5730\u568f\u5eff\u63ad\u637d\u5325\u5b53\u4e44\u5ac2 = \u6753\u568d\u6dc6\u67d2\u5a10\u5bef\u6e1e\u6a34\u6e7c\u521d\u544a\u5154\u5443\u6652\u5d96\u62ef\u5560\u6c6b\u50e6\u60b7\u6fa3\u707b\u6c6a\u6bc9\u51be\u4fc7\u5f79\u5178\u5574\u5c20\u5443\u4e82\u5730\u568f\u5eff\u63ad\u637d\u5325\u5b53\u4e44\u5ac2(262509431, -690329945, "\u2259\u225d\u2257\u2252\u225b\u225a\u2217\u224d\u2274\u2229\u227e\u2279\u226f\u227e\u2266\u227c\u2275\u2274\u221d\u70cb\u7d29\u7adc\u7ed5\u7ce3\u445a\u7fbe\u4946\u4078\u4f9d\u4b87\u6ca7\u76cc\u4d52", -691479465, -952562725);
                    final Object[] args = { null };
                    "\u5862\u68d9\u589f\u5955".length();
                    args[0] = serviceWrapper2;
                    final PipelineException ex = new PipelineException(String.format(\u6753\u568d\u6dc6\u67d2\u5a10\u5bef\u6e1e\u6a34\u6e7c\u521d\u544a\u5154\u5443\u6652\u5d96\u62ef\u5560\u6c6b\u50e6\u60b7\u6fa3\u707b\u6c6a\u6bc9\u51be\u4fc7\u5f79\u5178\u5574\u5c20\u5443\u4e82\u5730\u568f\u5eff\u63ad\u637d\u5325\u5b53\u4e44\u5ac2, args), ex2);
                    "\u70a3\u4fd7\u6e27\u5504".length();
                    "\u6227".length();
                    throw ex;
                }
                if (serviceWrapper2.getImplementation() instanceof SideEffectService) {
                    if (handle == null) {
                        "\u61ec\u576d".length();
                        final String \u6753\u568d\u6dc6\u67d2\u5a10\u5bef\u6e1e\u6a34\u6e7c\u521d\u544a\u5154\u5443\u6652\u5d96\u62ef\u5560\u6c6b\u50e6\u60b7\u6fa3\u707b\u6c6a\u6bc9\u51be\u4fc7\u5f79\u5178\u5574\u5c20\u5443\u4e82\u5730\u568f\u5eff\u63ad\u637d\u5325\u5b53\u4e44\u5ac22 = \u6753\u568d\u6dc6\u67d2\u5a10\u5bef\u6e1e\u6a34\u6e7c\u521d\u544a\u5154\u5443\u6652\u5d96\u62ef\u5560\u6c6b\u50e6\u60b7\u6fa3\u707b\u6c6a\u6bc9\u51be\u4fc7\u5f79\u5178\u5574\u5c20\u5443\u4e82\u5730\u568f\u5eff\u63ad\u637d\u5325\u5b53\u4e44\u5ac2(1658907035, 560035538, "\uab33\uab24\uab29\uab2a\uab0c\uab29\uab22\uab2d\uab07\uab3c\uab1c\uab38\uab2e\uab3b\uab25\uab3b\uab19\uab40\uab69\uf9ed\uf448\uf3f9\uf7f3\uf58c\ucd34\uf68b\uc036\uc919\uc6fb\uc2ee\ue580\uffa8\uc430\uca44\uc1a4\ue43f", 2016880528, 1547965434);
                        final Object[] args2 = { null };
                        "\u54fb\u5e22\u6bb3\u5ce1".length();
                        "\u6b14\u5a5e\u4e63".length();
                        "\u5e98\u56d9\u5074\u6dc6\u5017".length();
                        args2[0] = serviceWrapper2;
                        final IllegalStateException ex3 = new IllegalStateException(String.format(\u6753\u568d\u6dc6\u67d2\u5a10\u5bef\u6e1e\u6a34\u6e7c\u521d\u544a\u5154\u5443\u6652\u5d96\u62ef\u5560\u6c6b\u50e6\u60b7\u6fa3\u707b\u6c6a\u6bc9\u51be\u4fc7\u5f79\u5178\u5574\u5c20\u5443\u4e82\u5730\u568f\u5eff\u63ad\u637d\u5325\u5b53\u4e44\u5ac22, args2));
                        "\u5c31\u643e".length();
                        "\u52f7\u6704\u6448".length();
                        "\u5a86\u4e8d".length();
                        "\u6dfc\u5440\u68ec\u5d04".length();
                        throw ex3;
                    }
                    if (handle == State.ACCEPTED) {
                        return (Result)handle;
                    }
                    continue;
                }
                else {
                    if (handle != null) {
                        return (Result)handle;
                    }
                    continue;
                }
            }
            else {
                if (b) {
                    return (Result)State.ACCEPTED;
                }
                "\u52c2\u4e60\u6f53\u4e9d".length();
                final IllegalStateException ex4 = new IllegalStateException(\u6753\u568d\u6dc6\u67d2\u5a10\u5bef\u6e1e\u6a34\u6e7c\u521d\u544a\u5154\u5443\u6652\u5d96\u62ef\u5560\u6c6b\u50e6\u60b7\u6fa3\u707b\u6c6a\u6bc9\u51be\u4fc7\u5f79\u5178\u5574\u5c20\u5443\u4e82\u5730\u568f\u5eff\u63ad\u637d\u5325\u5b53\u4e44\u5ac2(91177483, -2051153177, "\ud412\ud41e\ud451\ud400\ud410\ud401\ud40e\ud41d\ud44b\ud461\ud423\ud472\ud47f\ud46f\ud473\ud461\ud46d\ud479\ud456\u8694\u8b33\u8cca\u88ca\u8aa2\ub25e\u89fc\ubf41\ub673\ub99c\ubd9f\u9afc\u80ca\ubb02\ub519\ubedc\u9b46\ub550\u82f8\u8741\ubd99\ub7d6\ub340\u9b03\ubd10\ubd79\u8261\u9bc6\ubaf8\u8355\ubb2e\u89c6\u851a\ub007\u853c\u8374\u865c\u8acd\u836c\ub3e0\ub2e9\u89c8\ubf71\ua4f6\ubf95\ubbd6\ubd20\ub9b6\ub968\u8e29\ub7a9\u8ddb\u9b96\ub3a2\ub334\u802f\ua4cd\ub654\u8a65\u80cc\ubad4\u84f7\u8184\u8d7f\u833e\ubf5c\u840d\ubc40\u8758\u8d90\ub072\u823d", 354552632, -224297013));
                "\u6102\u6933".length();
                "\u6981\u6c6b\u56b8\u6583".length();
                throw ex4;
            }
        }
    }
    
    public void getResult(final BiConsumer<Result, Throwable> biConsumer) {
        try {
            biConsumer.accept(this.getResult(), null);
        }
        catch (PipelineException ex) {
            biConsumer.accept(null, ex.getCause());
        }
        catch (Exception ex2) {
            biConsumer.accept(null, ex2);
        }
    }
    
    public CompletableFuture<Result> getResultAsynchronously() {
        return CompletableFuture.supplyAsync(this::getResult, this.pipeline.getExecutor());
    }
    
    public ServicePump<Result> forward() {
        return this.pipeline.pump(this.getResult());
    }
    
    public CompletableFuture<ServicePump<Result>> forwardAsynchronously() {
        final CompletableFuture<Result> resultAsynchronously = this.getResultAsynchronously();
        final ServicePipeline pipeline = this.pipeline;
        "\u6f39\u55aa\u63c3\u597f".length();
        "\u6d3d\u70eb\u6488\u5d99".length();
        Objects.requireNonNull(pipeline);
        "\u5532\u52b1\u63b6".length();
        "\u5f61".length();
        "\u52cb\u6fc0".length();
        return (CompletableFuture<ServicePump<Result>>)resultAsynchronously.thenApply((Function<? super Result, ?>)pipeline::pump);
    }
    
    public static int ColonialObfuscator_\u6609\u70e2\u56e4\u5cbe\u6f2a\u64c2\u6f45\u6744\u60da\u6001\u562f\u679e\u56ea\u61b8\u53b4\u5890\u5777\u63de\u6358\u6042\u660b\u52da\u5341\u6331\u556a\u53a7\u63a6\u6cbc\u577a\u678b\u5216\u6128\u6862\u530e\u60fe\u6142\u543b\u4fb8\u5096\u6d57\u57eb(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
