package cloud.commandframework.services;

public enum State
{
    ACCEPTED, 
    REJECTED;
    
    public static int ColonialObfuscator_\u5cf2\u5c28\u5b02\u6ece\u659d\u6512\u6175\u5971\u5da9\u6ac0\u53dd\u61ae\u5d8b\u539a\u5162\u70c8\u573b\u6fcf\u6465\u6cd7\u5dba\u6384\u5bf2\u50b1\u5fac\u70ea\u70d8\u5afd\u66c1\u708f\u6ff3\u5532\u58d8\u6cb1\u70c6\u55b6\u5d28\u61c0\u57cc\u5720\u521c(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
