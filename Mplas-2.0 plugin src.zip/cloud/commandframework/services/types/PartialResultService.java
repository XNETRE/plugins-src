package cloud.commandframework.services.types;

import cloud.commandframework.services.*;
import java.util.function.*;
import java.util.*;

public interface PartialResultService<Context, Result, Chunked extends ChunkedRequestContext<Context, Result>> extends Service<Chunked, Map<Context, Result>>
{
    default Map<Context, Result> handle(final Chunked obj) {
        if (!obj.isCompleted()) {
            final Map<Context, Result> handleRequests = this.handleRequests(((ChunkedRequestContext<Context, Result>)obj).getRemaining());
            "\u5905\u5575\u59e4\u6230\u6fdb".length();
            "\u6b0d\u63a2\u4f8c\u6428\u5258".length();
            "\u69e6\u5705".length();
            Objects.requireNonNull(obj);
            "\u5f7d\u6ffa\u4f29".length();
            "\u682d\u518a\u5eb5\u4efe".length();
            "\u5228\u645b\u534c\u530c\u6417".length();
            "\u6914".length();
            handleRequests.forEach(obj::storeResult);
        }
        if (obj.isCompleted()) {
            return obj.getAvailableResults();
        }
        return null;
    }
    
    Map<Context, Result> handleRequests(final List<Context> p0);
}
