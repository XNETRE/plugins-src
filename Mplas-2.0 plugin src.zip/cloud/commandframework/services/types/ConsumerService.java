package cloud.commandframework.services.types;

import java.util.function.*;
import cloud.commandframework.services.*;

@FunctionalInterface
public interface ConsumerService<Context> extends SideEffectService<Context>, Consumer<Context>
{
    default State handle(final Context context) {
        try {
            this.accept(context);
        }
        catch (PipeBurst pipeBurst) {
            return State.ACCEPTED;
        }
        return State.REJECTED;
    }
    
    void accept(final Context p0);
}
