package cloud.commandframework.services.types;

import java.util.function.*;
import cloud.commandframework.services.*;

@FunctionalInterface
public interface Service<Context, Result> extends Function<Context, Result>
{
    Result handle(final Context p0) throws Exception;
    
    default Result apply(final Context context) {
        try {
            return this.handle(context);
        }
        catch (Exception ex2) {
            "\u65e9\u5395\u5e31\u69d6".length();
            "\u5ce2\u5cfa\u70d3\u5152".length();
            "\u6ca0\u69fd\u6a49\u64a4".length();
            "\u5453\u5f9a\u69ba".length();
            final PipelineException ex = new PipelineException(ex2);
            "\u6762\u6d72".length();
            throw ex;
        }
    }
    
    default ExecutionOrder order() {
        return null;
    }
}
