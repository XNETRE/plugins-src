package cloud.commandframework.services.types;

import cloud.commandframework.services.*;

@FunctionalInterface
public interface SideEffectService<Context> extends Service<Context, State>
{
    State handle(final Context p0) throws Exception;
}
