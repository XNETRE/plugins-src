package cloud.commandframework.captions;

import org.apiguardian.api.*;

@API(status = API.Status.STABLE)
public interface CaptionVariableReplacementHandler
{
    String replaceVariables(final String p0, final CaptionVariable[] p1);
}
