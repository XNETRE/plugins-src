package cloud.commandframework.captions;

import org.apiguardian.api.*;

@API(status = API.Status.STABLE)
public final class SimpleCaptionVariableReplacementHandler implements CaptionVariableReplacementHandler
{
    @Override
    public String replaceVariables(final String s, final CaptionVariable[] array) {
        String replace = s;
        for (int length = array.length, i = 0; i < length; i += 24801, i -= 24800) {
            final CaptionVariable captionVariable = array[i];
            final String s2 = replace;
            final String \u5ed6\u595e\u6cab\u6c88\u6e30\u4f65\u4fc2\u57b4\u64b4\u6337\u56e1\u53fd\u57c9\u674b\u6796\u6337\u52ee\u6897\u4efc\u688c\u6039\u647e\u578f\u6887\u5635\u5fce\u5400\u6b15\u66f7\u51f5\u6cdb\u5e6d\u65b8\u5355\u5748\u699c\u6d42\u64f2\u65ca\u539e\u65d5 = \u5ed6\u595e\u6cab\u6c88\u6e30\u4f65\u4fc2\u57b4\u64b4\u6337\u56e1\u53fd\u57c9\u674b\u6796\u6337\u52ee\u6897\u4efc\u688c\u6039\u647e\u578f\u6887\u5635\u5fce\u5400\u6b15\u66f7\u51f5\u6cdb\u5e6d\u65b8\u5355\u5748\u699c\u6d42\u64f2\u65ca\u539e\u65d5(1353584875, 565998211, "\u9aee\u9a93\u9ac7\u9ac9", -1658219321, -2060555143);
            final Object[] args = { null };
            "\u713b\u5480".length();
            args[0] = captionVariable.getKey();
            replace = s2.replace(String.format(\u5ed6\u595e\u6cab\u6c88\u6e30\u4f65\u4fc2\u57b4\u64b4\u6337\u56e1\u53fd\u57c9\u674b\u6796\u6337\u52ee\u6897\u4efc\u688c\u6039\u647e\u578f\u6887\u5635\u5fce\u5400\u6b15\u66f7\u51f5\u6cdb\u5e6d\u65b8\u5355\u5748\u699c\u6d42\u64f2\u65ca\u539e\u65d5, args), captionVariable.getValue());
        }
        return replace;
    }
    
    public static int ColonialObfuscator_\u5a01\u5889\u5be3\u5328\u6b80\u6453\u69f1\u701d\u5d7a\u58de\u70f2\u5956\u5d31\u5d01\u6086\u6abf\u50d3\u4fd8\u6ec2\u5ad1\u59f7\u5c99\u579c\u66ab\u5e21\u534b\u68d8\u6afc\u6421\u6978\u60ec\u6b5f\u6ffe\u5ed1\u64c9\u67cf\u592b\u6185\u50f9\u6a68\u62e5(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
