package cloud.commandframework.captions;

import org.apiguardian.api.*;

@API(status = API.Status.STABLE)
public final class CaptionVariable
{
    public CaptionVariable(final String key, final String value) {
        this.key = key;
        this.value = value;
    }
    
    public String getKey() {
        return this.key;
    }
    
    public String getValue() {
        return this.value;
    }
    
    public static int ColonialObfuscator_\u5b40\u57bb\u5f45\u6d72\u6b20\u63d6\u52d6\u61d8\u61a7\u5d06\u63e0\u5d28\u5468\u6269\u5d40\u6a2b\u6b38\u4fcb\u6731\u528c\u6562\u5659\u52ce\u5017\u6ae1\u589e\u7019\u6e5c\u61a0\u6e31\u5d37\u6a7a\u5424\u53cd\u5e30\u6774\u64f9\u4e5f\u5015\u58b9\u4ea5(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
