package cloud.commandframework.captions;

import org.apiguardian.api.*;

@API(status = API.Status.STABLE)
public interface CaptionRegistry<C>
{
    String getCaption(final Caption p0, final C p1);
}
