package cloud.commandframework.captions;

import org.apiguardian.api.*;

@API(status = API.Status.STABLE)
public final class SimpleCaptionRegistryFactory<C>
{
    public SimpleCaptionRegistry<C> create() {
        "\u4ec4\u50c6".length();
        "\u65eb\u526d\u4f53".length();
        return new SimpleCaptionRegistry<C>();
    }
    
    public static int ColonialObfuscator_\u512f\u51bb\u6dc7\u67d4\u5b88\u50ec\u527b\u5ce3\u5030\u544c\u6aa1\u5cf6\u53b0\u51f8\u5dca\u4fa1\u6d3e\u5062\u4e8c\u6f8c\u5cf4\u5b1e\u5946\u6d7a\u6bd3\u4f10\u6076\u5af9\u605e\u62c3\u6b8d\u6552\u53f9\u6651\u596d\u5f41\u54da\u61bd\u5e86\u4ea2\u639b(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
