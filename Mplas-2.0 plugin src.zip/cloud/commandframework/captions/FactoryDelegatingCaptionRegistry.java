package cloud.commandframework.captions;

import org.apiguardian.api.*;
import java.util.function.*;

@API(status = API.Status.STABLE)
public interface FactoryDelegatingCaptionRegistry<C> extends CaptionRegistry<C>
{
    void registerMessageFactory(final Caption p0, final BiFunction<Caption, C, String> p1);
}
