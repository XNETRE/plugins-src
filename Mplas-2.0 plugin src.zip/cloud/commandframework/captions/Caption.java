package cloud.commandframework.captions;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class Caption
{
    public Caption(final String key) {
        this.key = key;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && Objects.equals(this.key, ((Caption)o).key));
    }
    
    public String getKey() {
        return this.key;
    }
    
    @Override
    public int hashCode() {
        final Object[] values = { null };
        "\u508e\u6da0".length();
        "\u6acc\u66b6\u6217\u5db4".length();
        "\u5369\u6ab4\u51c7\u5b6d".length();
        values[0] = this.key;
        return Objects.hash(values);
    }
    
    @Override
    public String toString() {
        final String \u6602\u6fa5\u538d\u5fd1\u704a\u654e\u5c82\u637f\u5578\u4fe9\u4f0d\u52c3\u5600\u5446\u6949\u60b7\u6a52\u6a54\u6aca\u4eab\u56f3\u65f8\u5831\u6f80\u68d0\u56d5\u7061\u7117\u4f8c\u6deb\u588d\u5e45\u5fb5\u68d1\u699a\u58c1\u5bb3\u61f1\u5764\u5a85\u6341 = \u6602\u6fa5\u538d\u5fd1\u704a\u654e\u5c82\u637f\u5578\u4fe9\u4f0d\u52c3\u5600\u5446\u6949\u60b7\u6a52\u6a54\u6aca\u4eab\u56f3\u65f8\u5831\u6f80\u68d0\u56d5\u7061\u7117\u4f8c\u6deb\u588d\u5e45\u5fb5\u68d1\u699a\u58c1\u5bb3\u61f1\u5764\u5a85\u6341(-122835341, -869585660, "\u8937\u893a\u8929\u8929\u8934\u8936\u893e\u8939\u890b\u892b\u8932\u8962\u897f\u896e\u893b\u8975\u8935", -975046007, 353890505);
        final Object[] args = { null };
        "\u58d4\u5cde\u6b70\u5a89".length();
        args[0] = this.key;
        return String.format(\u6602\u6fa5\u538d\u5fd1\u704a\u654e\u5c82\u637f\u5578\u4fe9\u4f0d\u52c3\u5600\u5446\u6949\u60b7\u6a52\u6a54\u6aca\u4eab\u56f3\u65f8\u5831\u6f80\u68d0\u56d5\u7061\u7117\u4f8c\u6deb\u588d\u5e45\u5fb5\u68d1\u699a\u58c1\u5bb3\u61f1\u5764\u5a85\u6341, args);
    }
    
    public static int ColonialObfuscator_\u6b31\u4e4d\u55b5\u6c11\u5dd6\u645e\u6c94\u5e7b\u7080\u5901\u66df\u547d\u5c7c\u53c0\u5e46\u658d\u6f3e\u68c4\u673f\u542d\u7105\u52cf\u50f8\u4ec2\u6b4d\u68f6\u4ff7\u4f8e\u502c\u663f\u5872\u5021\u6f80\u6ac1\u63e7\u5248\u628c\u5505\u6fb7\u541d\u52a5(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
