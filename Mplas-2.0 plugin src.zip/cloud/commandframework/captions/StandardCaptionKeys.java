package cloud.commandframework.captions;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class StandardCaptionKeys
{
    public static int ColonialObfuscator_\u6372\u4eb5\u606b\u62dc\u7132\u6acf\u5eb8\u6c57\u51a6\u576d\u60a9\u6e29\u6799\u6454\u55ac\u60f5\u54ce\u5cfe\u65e6\u54c8\u58b7\u6f53\u55f4\u51ff\u64f5\u5d22\u5b34\u5e29\u5d0e\u5f69\u5092\u6b03\u67fb\u6a0a\u687b\u7066\u5895\u5411\u6f88\u5705\u4eb1(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
