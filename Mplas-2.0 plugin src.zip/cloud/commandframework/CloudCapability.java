package cloud.commandframework;

import org.apiguardian.api.*;

@API(status = API.Status.STABLE, since = "1.7.0")
public interface CloudCapability
{
    String toString();
}
