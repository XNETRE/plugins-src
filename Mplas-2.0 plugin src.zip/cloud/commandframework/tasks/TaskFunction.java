package cloud.commandframework.tasks;

import java.util.function.*;

public interface TaskFunction<I, O> extends Function<I, O>, TaskRecipeStep
{
    O apply(final I p0);
}
