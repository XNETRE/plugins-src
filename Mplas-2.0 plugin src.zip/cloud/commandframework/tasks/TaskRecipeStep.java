package cloud.commandframework.tasks;

public interface TaskRecipeStep
{
}
