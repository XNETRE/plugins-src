package cloud.commandframework.tasks;

public final class TaskFactory
{
    public TaskFactory(final TaskSynchronizer synchronizer) {
        this.synchronizer = synchronizer;
    }
    
    public TaskRecipe recipe() {
        "\u4e32\u563f\u57a1\u674c\u4fe3".length();
        return new TaskRecipe(this.synchronizer);
    }
    
    public static int ColonialObfuscator_\u4f63\u6740\u5a97\u5fa6\u54e2\u68ab\u50f6\u586c\u6fbf\u65ae\u652d\u4eea\u594e\u6097\u7046\u5212\u534f\u66f3\u6234\u5a81\u6d55\u6096\u5510\u4f65\u6bd8\u5e9f\u5683\u7094\u6454\u6e50\u5957\u5fdc\u6a7d\u5f56\u6441\u66b1\u53ed\u6391\u5f6d\u5327\u6327(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
