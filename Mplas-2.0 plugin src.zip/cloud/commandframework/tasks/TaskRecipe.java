package cloud.commandframework.tasks;

import java.util.concurrent.*;
import java.util.function.*;
import java.util.*;

public final class TaskRecipe
{
    public TaskRecipe(final TaskSynchronizer synchronizer) {
        this.recipeSteps = new LinkedHashMap<TaskRecipeStep, Boolean>();
        this.synchronizer = synchronizer;
    }
    
    public <I> TaskRecipeComponentOutputting<I, I> begin(final I n) {
        this.addAsynchronous(TaskFunction.identity());
        "\u4ff1".length();
        "\u6588\u68e6\u5f89".length();
        "\u652c".length();
        return new TaskRecipeComponentOutputting<I, I>(n, null);
    }
    
    public void addAsynchronous(final TaskRecipeStep key) {
        this.recipeSteps.put(key, false);
        "\u5e93\u5814\u5c09".length();
        "\u52ca\u6fd6\u6914\u53e8\u507f".length();
    }
    
    public void addSynchronous(final TaskRecipeStep key) {
        this.recipeSteps.put(key, true);
        "\u6655\u56a9".length();
        "\u5852\u650d\u69ab".length();
    }
    
    public void execute(final Object value, final Runnable runnable) {
        "\u5f8a\u602e".length();
        "\u6a92\u56ae\u600d".length();
        "\u659a\u59d0\u6ece\u5bdc\u677f".length();
        "\u5f6a".length();
        CompletableFuture.completedFuture(value).whenComplete((BiConsumer<? super Object, ? super Throwable>)this.execute(new LinkedHashMap<TaskRecipeStep, Boolean>(this.recipeSteps).entrySet().iterator(), runnable));
        "\u50c7\u6dd4\u6a77\u6a92\u5c47".length();
        "\u57e7".length();
        "\u6533".length();
    }
    
    public BiConsumer execute(final Iterator<Map.Entry<TaskRecipeStep, Boolean>> p0, final Runnable p1) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: aload_1        
        //     2: aload_2        
        //     3: invokedynamic   BootstrapMethod #0, accept:(Lcloud/commandframework/tasks/TaskRecipe;Ljava/util/Iterator;Ljava/lang/Runnable;)Ljava/util/function/BiConsumer;
        //     8: areturn        
        //    Signature:
        //  (Ljava/util/Iterator<Ljava/util/Map$Entry<Lcloud/commandframework/tasks/TaskRecipeStep;Ljava/lang/Boolean;>;>;Ljava/lang/Runnable;)Ljava/util/function/BiConsumer;
        //    RuntimeVisibleTypeAnnotations: 00 02 16 00 00 00 20 00 00 16 01 00 00 20 00 00
        // 
        // The error that occurred was:
        // 
        // java.lang.NullPointerException
        //     at com.strobel.decompiler.languages.java.ast.NameVariables.generateNameForVariable(NameVariables.java:264)
        //     at com.strobel.decompiler.languages.java.ast.NameVariables.assignNamesToVariables(NameVariables.java:198)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:276)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at us.deathmarine.luyten.FileSaver.doSaveJarDecompiled(FileSaver.java:192)
        //     at us.deathmarine.luyten.FileSaver.access$300(FileSaver.java:45)
        //     at us.deathmarine.luyten.FileSaver$4.run(FileSaver.java:112)
        //     at java.base/java.lang.Thread.run(Thread.java:829)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    public static int ColonialObfuscator_\u653d\u697c\u5cc5\u5772\u6909\u561f\u4e72\u5f9b\u5ce0\u638c\u50b9\u69f9\u4f4d\u7042\u62be\u6041\u5d25\u69b9\u6ceb\u54f5\u5e7b\u5116\u6c86\u5d3d\u5a06\u53b7\u66f6\u5b38\u5fd9\u65d5\u6aa5\u68f3\u6620\u581d\u532c\u5378\u5663\u5ee2\u50aa\u70dc\u690a(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
