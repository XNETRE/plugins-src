package cloud.commandframework.tasks;

import java.util.function.*;

@FunctionalInterface
public interface TaskConsumer<I> extends Consumer<I>, TaskRecipeStep
{
    void accept(final I p0);
}
