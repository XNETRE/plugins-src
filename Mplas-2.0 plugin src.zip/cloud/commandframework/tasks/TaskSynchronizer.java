package cloud.commandframework.tasks;

import java.util.concurrent.*;

public interface TaskSynchronizer
{
     <I> CompletableFuture<Void> runSynchronous(final I p0, final TaskConsumer<I> p1);
    
     <I, O> CompletableFuture<O> runSynchronous(final I p0, final TaskFunction<I, O> p1);
    
     <I> CompletableFuture<Void> runAsynchronous(final I p0, final TaskConsumer<I> p1);
    
     <I, O> CompletableFuture<O> runAsynchronous(final I p0, final TaskFunction<I, O> p1);
}
