package cloud.commandframework;

import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.execution.*;
import cloud.commandframework.internal.*;

@Deprecated
@API(status = API.Status.DEPRECATED, since = "1.2.0")
public abstract class LockableCommandManager<C> extends CommandManager<C>
{
    public LockableCommandManager(final Function<CommandTree<C>, CommandExecutionCoordinator<C>> function, final CommandRegistrationHandler commandRegistrationHandler) {
        super(function, commandRegistrationHandler);
    }
    
    public final void lockWrites() {
        this.lockRegistration();
    }
    
    public static int ColonialObfuscator_\u64ba\u5669\u6a36\u6f8d\u5ccf\u503f\u5ff2\u4fb2\u6cf1\u6832\u6d3f\u6aa0\u65a8\u6184\u680e\u6b3a\u4e5a\u704e\u656d\u6d1f\u50ed\u54c8\u5279\u5702\u6b83\u675a\u52af\u653c\u4fd7\u6f09\u52bd\u711a\u7031\u5c09\u520d\u4e23\u60e5\u65e0\u51fb\u70a5\u5063(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
