package cloud.commandframework;

import org.apiguardian.api.*;
import cloud.commandframework.execution.*;
import java.util.stream.*;
import cloud.commandframework.arguments.*;
import java.util.*;
import cloud.commandframework.arguments.flags.*;
import cloud.commandframework.meta.*;
import io.leangen.geantyref.*;
import java.util.function.*;
import cloud.commandframework.types.tuples.*;
import cloud.commandframework.arguments.compound.*;
import cloud.commandframework.permission.*;

@API(status = API.Status.STABLE)
public class Command<C>
{
    @API(status = API.Status.STABLE, since = "1.3.0")
    public Command(final List<CommandComponent<C>> obj, final CommandExecutionHandler<C> commandExecutionHandler, final Class<? extends C> senderType, final CommandPermission commandPermission, final CommandMeta commandMeta) {
        this.components = Objects.requireNonNull(obj, \u6160\u56b5\u54c5\u6dac\u68a3\u4fb7\u6831\u610e\u5b76\u7046\u629a\u6a57\u6301\u66b7\u4ef6\u4f4e\u5a98\u691e\u51bf\u6766\u5173\u60c7\u7007\u5463\u6abf\u70a4\u52c2\u6da3\u5cf8\u6446\u571d\u646b\u6c37\u675e\u5667\u63a2\u5290\u5be7\u5129\u6656\u5d0c(2016382873, 131584697, "\u8aff\u8afc\u8afc\u8af8\u8af4\u8aff\u8afc\u8a8a\u8aeb\u8ac9\u8ace\u8ac7\u8adf\u8acd\u8ac5\u8ad4\u8ad4\u8acd\u8ab2\udf8e\uec58\uea08\ue1f7\ud0f0\ue3cd\ud6ee\ue12b\ue5b4\ue001\ue6c0\ud29e\ud2bf\ud961\ue750", -1798523431, -998284794));
        this.arguments = this.components.stream().map((Function<? super Object, ?>)CommandComponent::getArgument).collect((Collector<? super Object, ?, List<CommandArgument<C, ?>>>)Collectors.toList());
        if (this.components.isEmpty()) {
            throw new IllegalArgumentException(\u6160\u56b5\u54c5\u6dac\u68a3\u4fb7\u6831\u610e\u5b76\u7046\u629a\u6a57\u6301\u66b7\u4ef6\u4f4e\u5a98\u691e\u51bf\u6766\u5173\u60c7\u7007\u5463\u6abf\u70a4\u52c2\u6da3\u5cf8\u6446\u571d\u646b\u6c37\u675e\u5667\u63a2\u5290\u5be7\u5129\u6656\u5d0c(-1426559363, 1929177749, "\uf432\uf42c\uf47a\uf436\uf43f\uf433\uf428\uf421\uf457\uf432\uf436\uf42d\uf46f\uf443\uf44c\uf458\uf442\uf454\uf477\ua108\u9296\u9491\u9f3b\uae6c\u9d4d\ua86e\u9ffe\u9b2c\u9e95\u9817\uac53\uac2c\ua7f1\u9997\ua706\uba78\ua8ae\u9bc4\u95ab\ua534\ua94b\ua113", 1344540851, 1249796203));
        }
        this.flagArgument = this.arguments.stream().filter(commandArgument -> commandArgument instanceof FlagArgument).map(flagArgument -> flagArgument).findFirst().orElse(null);
        int n = 0;
        for (final CommandArgument<C, ?> commandArgument2 : this.arguments) {
            if (commandArgument2.getName().isEmpty()) {
                throw new IllegalArgumentException(\u6160\u56b5\u54c5\u6dac\u68a3\u4fb7\u6831\u610e\u5b76\u7046\u629a\u6a57\u6301\u66b7\u4ef6\u4f4e\u5a98\u691e\u51bf\u6766\u5173\u60c7\u7007\u5463\u6abf\u70a4\u52c2\u6da3\u5cf8\u6446\u571d\u646b\u6c37\u675e\u5667\u63a2\u5290\u5be7\u5129\u6656\u5d0c(-1419269443, -803191387, "\u8a96\u8a88\u8ae1\u8af1\u8aeb\u8ae5\u8ae1\u8af7\u8a83\u8ae1\u8ae5\u8afb\u8af6\u8af1\u8aa7\u8afe\u8aea\u8aee\u8a85\udfbc\uec65\uea34\ue1c0\ud0d5\ue3ec\ud693\ue149\ue59a\ue037\ue6b5\ud2ae", -146950850, 1543950514));
            }
            if (n != 0 && commandArgument2.isRequired()) {
                throw new IllegalArgumentException(String.format(\u6160\u56b5\u54c5\u6dac\u68a3\u4fb7\u6831\u610e\u5b76\u7046\u629a\u6a57\u6301\u66b7\u4ef6\u4f4e\u5a98\u691e\u51bf\u6766\u5173\u60c7\u7007\u5463\u6abf\u70a4\u52c2\u6da3\u5cf8\u6446\u571d\u646b\u6c37\u675e\u5667\u63a2\u5290\u5be7\u5129\u6656\u5d0c(-282197563, 1037165121, "\u6c1e\u6c11\u6c11\u6c11\u6c1d\u6c12\u6c11\u6c5b\u6c38\u6c19\u6c09\u6c0b\u6c14\u6c0b\u6c03\u6c0f\u6c41\u6c54\u6c7a\u3959\u0ad7\u0c9c\u0779\u362e\u051d\u3019\u0789\u034b\u06ado\u3478\u340b\u3f9c\u01bd\u3f73\u2218\u30dc\u03bb\u0d8c\u3d49\u3126\u3975\u33fd\u3905\u388b\u08cc\u0a5c\u0d2b?\u03e8\u0d4f\u0ea9\u32ab\u36ba\u3b5a\u3773\u0b07\u009b\u04ab\u3d04\u35de\u086a\u08d8\u0916\u34bd", 224112711, -1430896675), commandArgument2.getName()));
            }
            if (commandArgument2.isRequired()) {
                continue;
            }
            n = 1;
        }
        this.commandExecutionHandler = commandExecutionHandler;
        this.senderType = senderType;
        this.commandPermission = commandPermission;
        this.commandMeta = commandMeta;
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public Command(final List<CommandComponent<C>> list, final CommandExecutionHandler<C> commandExecutionHandler, final Class<? extends C> clazz, final CommandMeta commandMeta) {
        this(list, commandExecutionHandler, clazz, Permission.empty(), commandMeta);
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public Command(final List<CommandComponent<C>> list, final CommandExecutionHandler<C> commandExecutionHandler, final CommandPermission commandPermission, final CommandMeta commandMeta) {
        this(list, commandExecutionHandler, null, commandPermission, commandMeta);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED)
    public Command(final Map<CommandArgument<C, ?>, Description> map, final CommandExecutionHandler<C> commandExecutionHandler, final Class<? extends C> clazz, final CommandPermission commandPermission, final CommandMeta commandMeta) {
        this(mapToComponents(map), commandExecutionHandler, clazz, commandPermission, commandMeta);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED)
    public Command(final Map<CommandArgument<C, ?>, Description> map, final CommandExecutionHandler<C> commandExecutionHandler, final Class<? extends C> clazz, final CommandMeta commandMeta) {
        this(mapToComponents(map), commandExecutionHandler, clazz, commandMeta);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED)
    public Command(final Map<CommandArgument<C, ?>, Description> map, final CommandExecutionHandler<C> commandExecutionHandler, final CommandPermission commandPermission, final CommandMeta commandMeta) {
        this(mapToComponents(map), commandExecutionHandler, commandPermission, commandMeta);
    }
    
    public List<CommandArgument<C, ?>> getArguments() {
        "\u4fe7\u68d0\u4ee5\u7138\u5c0f".length();
        "\u6e6e\u63cf\u505d\u4e93\u50c0".length();
        "\u5d52\u5077".length();
        "\u5af6\u5545\u64b9".length();
        "\u5cb7\u5e34\u62b5\u5021".length();
        return new ArrayList<CommandArgument<C, ?>>(this.arguments);
    }
    
    @API(status = API.Status.EXPERIMENTAL, since = "1.8.0")
    public List<CommandArgument<C, ?>> nonFlagArguments() {
        "\u55d9\u6d8f\u6d33\u679a\u54db".length();
        "\u51eb\u6211".length();
        final ArrayList<CommandArgument<C, ?>> list = new ArrayList<CommandArgument<C, ?>>(this.arguments);
        if (this.flagArgument != null) {
            list.remove(this.flagArgument);
            "\u659a\u6fe6\u6250\u52ec".length();
            "\u5306\u6381\u6516".length();
        }
        return list;
    }
    
    @API(status = API.Status.EXPERIMENTAL, since = "1.8.0")
    public FlagArgument<C> flagArgument() {
        return this.flagArgument;
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public List<CommandComponent<C>> getComponents() {
        "\u64bf".length();
        "\u6ce8".length();
        "\u4edf\u6c95\u667a\u5333\u70f6".length();
        "\u6d52\u56b3\u50b0\u5a80\u69dd".length();
        return new ArrayList<CommandComponent<C>>(this.components);
    }
    
    public CommandExecutionHandler<C> getCommandExecutionHandler() {
        return this.commandExecutionHandler;
    }
    
    public Optional<Class<? extends C>> getSenderType() {
        return Optional.ofNullable(this.senderType);
    }
    
    public CommandPermission getCommandPermission() {
        return this.commandPermission;
    }
    
    public CommandMeta getCommandMeta() {
        return this.commandMeta;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED)
    public String getArgumentDescription(final CommandArgument<C, ?> obj) {
        for (final CommandComponent<C> commandComponent : this.components) {
            if (commandComponent.getArgument().equals(obj)) {
                return commandComponent.getArgumentDescription().getDescription();
            }
        }
        "\u6444\u6e3b\u542f".length();
        "\u679a\u6e92\u529d".length();
        "\u5b13\u4e41\u60d3\u6549\u64c5".length();
        "\u6fc4\u4f4b\u54b6\u66c4\u6389".length();
        final IllegalArgumentException ex = new IllegalArgumentException(\u6160\u56b5\u54c5\u6dac\u68a3\u4fb7\u6831\u610e\u5b76\u7046\u629a\u6a57\u6301\u66b7\u4ef6\u4f4e\u5a98\u691e\u51bf\u6766\u5173\u60c7\u7007\u5463\u6abf\u70a4\u52c2\u6da3\u5cf8\u6446\u571d\u646b\u6c37\u675e\u5667\u63a2\u5290\u5be7\u5129\u6656\u5d0c(1739678409, -1845261067, "\ub60b\ub604\ub604\ub604\ub608\ub607\ub604\ub64e\ub62d\ub60c\ub61c\ub61e\ub601\ub61e\ub616\ub61a\ub654\ub608\ub625\ue34b\ud0c5\ud6cf\udd60\uec2f\udf08\uea06\uddc9\ud90a", 217605639, 1579433520) + obj);
        "\u5aff\u6630".length();
        "\u5b5c\u5211".length();
        "\u5874\u593e".length();
        "\u6178\u6293".length();
        throw ex;
    }
    
    @Override
    public final String toString() {
        "\u6fa7\u5602\u701d".length();
        final StringBuilder sb = new StringBuilder();
        final Iterator<CommandArgument<C, ?>> iterator = this.getArguments().iterator();
        while (iterator.hasNext()) {
            sb.append(iterator.next().getName()).append(' ');
            "\u5415\u67e3\u660e\u56ac".length();
            "\u7104\u5d39\u6d03".length();
        }
        final String string = sb.toString();
        final int beginIndex = 0;
        final int length = string.length();
        final int n = 1;
        "\u653c\u68f5".length();
        return string.substring(beginIndex, length - n);
    }
    
    public boolean isHidden() {
        return this.getCommandMeta().getOrDefault(CommandMeta.HIDDEN, false);
    }
    
    public static int ColonialObfuscator_\u5c85\u57bf\u4f9f\u663b\u55a5\u6220\u6510\u6232\u6927\u64e2\u4f92\u6c74\u568a\u59bd\u5956\u6a7b\u52e2\u4f61\u5a98\u6de4\u69af\u6c18\u5f1a\u6743\u6887\u5979\u55cc\u585f\u6179\u6ca7\u5770\u4fae\u51ba\u5309\u6aac\u69b8\u4fbf\u4ea3\u5b8a\u65fe\u680d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
