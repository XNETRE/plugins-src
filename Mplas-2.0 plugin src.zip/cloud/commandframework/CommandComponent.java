package cloud.commandframework;

import org.apiguardian.api.*;
import cloud.commandframework.arguments.*;
import java.util.*;

@API(status = API.Status.STABLE, since = "1.3.0")
public final class CommandComponent<C>
{
    public CommandComponent(final CommandArgument<C, ?> argument, final ArgumentDescription description) {
        this.argument = argument;
        this.description = description;
    }
    
    public CommandArgument<C, ?> getArgument() {
        return this.argument;
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.4.0")
    public Description getDescription() {
        if (this.description instanceof Description) {
            return (Description)this.description;
        }
        "\u5a1b\u5202\u64a6".length();
        "\u651d\u5edb\u670f\u533b".length();
        "\u70ac\u6d27\u60f5\u6af1\u6094".length();
        "\u56d2\u50f9".length();
        return new Description(this.description.getDescription());
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public ArgumentDescription getArgumentDescription() {
        return this.description;
    }
    
    @Override
    public int hashCode() {
        final Object[] values = new Object[2];
        "\u61cf".length();
        "\u642b\u67e5\u59b7\u62fb\u6e6b".length();
        values[0] = this.getArgument();
        "\u5b4d\u6133\u6956\u540d\u5479".length();
        "\u5681\u5fe1".length();
        values[1] = this.getArgumentDescription();
        return Objects.hash(values);
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o instanceof CommandComponent) {
            final CommandComponent commandComponent = (CommandComponent)o;
            return this.getArgument().equals(commandComponent.getArgument()) && this.getArgumentDescription().equals(commandComponent.getArgumentDescription());
        }
        return false;
    }
    
    @Override
    public String toString() {
        final String \u60e5\u58ed\u51cd\u5c0e\u7022\u624a\u574e\u6eed\u69db\u679f\u5dd9\u68a0\u6927\u50aa\u63d0\u6b08\u689f\u5e39\u6da9\u5c8d\u6e7f\u5872\u5547\u5f95\u64ac\u53a3\u7095\u706b\u6307\u68e7\u5451\u7006\u61fc\u659f\u4ee7\u5d5d\u7025\u5608\u6c93\u65f4\u53b7 = \u60e5\u58ed\u51cd\u5c0e\u7022\u624a\u574e\u6eed\u69db\u679f\u5dd9\u68a0\u6927\u50aa\u63d0\u6b08\u689f\u5e39\u6da9\u5c8d\u6e7f\u5872\u5547\u5f95\u64ac\u53a3\u7095\u706b\u6307\u68e7\u5451\u7006\u61fc\u659f\u4ee7\u5d5d\u7025\u5608\u6c93\u65f4\u53b7(219280818, 1415653226, "\uc68a\uc6f7\uc6fd\uc6e7\uc6f4\uc6e9\uc6f2\uc6e4\uc6ce\uc6ef\uc6f0\uc6a9\uc6b6\uc6cf\uc693\uc6cd\uc6d6\uc6da\uc6e6\uadff\u93d5\uae6e\uabc5\ua872\u8985\ua696\uabe0\ua400\uaf84\u90fd", 661515475, -925042457);
        final Object[] args = new Object[3];
        "\u6b16".length();
        "\u69f0".length();
        "\u67ee\u5384\u655a\u5588\u6fed".length();
        args[0] = this.getClass().getSimpleName();
        "\u58af\u7056\u6f38\u550f\u562e".length();
        "\u643c\u5717\u5d42\u5af8".length();
        "\u5bac\u6a7a\u67d8\u6081".length();
        args[1] = this.argument;
        "\u51b2\u6343\u4e39\u6433".length();
        args[2] = this.description;
        return String.format(\u60e5\u58ed\u51cd\u5c0e\u7022\u624a\u574e\u6eed\u69db\u679f\u5dd9\u68a0\u6927\u50aa\u63d0\u6b08\u689f\u5e39\u6da9\u5c8d\u6e7f\u5872\u5547\u5f95\u64ac\u53a3\u7095\u706b\u6307\u68e7\u5451\u7006\u61fc\u659f\u4ee7\u5d5d\u7025\u5608\u6c93\u65f4\u53b7, args);
    }
    
    public static int ColonialObfuscator_\u6e60\u6733\u5e69\u6e40\u5712\u56fa\u6f2f\u6315\u6ee1\u6866\u6f40\u51df\u680c\u5e8b\u6dd8\u5789\u5497\u555f\u5154\u4e99\u5cc0\u5fe3\u7027\u5193\u712a\u514c\u5163\u5879\u583b\u5cf7\u6774\u5f0e\u6c8d\u64b6\u6adc\u519e\u556f\u575b\u67e1\u6d1e\u67d7(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
