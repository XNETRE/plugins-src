package cloud.commandframework.brigadier;

public interface BrigadierManagerHolder<C>
{
    CloudBrigadierManager<C, ?> brigadierManager();
}
