package cloud.commandframework.brigadier;

import cloud.commandframework.arguments.parser.*;
import java.util.function.*;
import com.mojang.brigadier.arguments.*;
import com.mojang.brigadier.suggestion.*;
import java.util.*;

public final class BrigadierMapping<C, K extends ArgumentParser<C, ?>, S>
{
    public BrigadierMapping(final boolean cloudSuggestions, final BrigadierMappingBuilder.SuggestionProviderSupplier<K, S> suggestionsOverride, final Function<K, ? extends ArgumentType<?>> mapper) {
        this.cloudSuggestions = cloudSuggestions;
        this.suggestionsOverride = suggestionsOverride;
        this.mapper = mapper;
    }
    
    public Function<K, ? extends ArgumentType<?>> getMapper() {
        return this.mapper;
    }
    
    public BrigadierMapping<C, K, S> withNativeSuggestions(final boolean b) {
        if (b && this.cloudSuggestions) {
            "\u5624".length();
            return new BrigadierMapping<C, K, S>(false, this.suggestionsOverride, this.mapper);
        }
        if (!b && !this.cloudSuggestions) {
            "\u5632\u5f90".length();
            return new BrigadierMapping<C, K, S>(true, this.suggestionsOverride, this.mapper);
        }
        return this;
    }
    
    public SuggestionProvider<S> makeSuggestionProvider(final K k) {
        if (this.cloudSuggestions) {
            return CloudBrigadierManager.delegateSuggestions();
        }
        return (SuggestionProvider<S>)((this.suggestionsOverride == null) ? null : this.suggestionsOverride.provide(k, CloudBrigadierManager.delegateSuggestions()));
    }
    
    public static int ColonialObfuscator_\u6829\u6dd0\u4f9b\u5cd0\u641c\u6588\u4eb6\u600d\u5ee5\u68f9\u5f5f\u529c\u596a\u703b\u4edd\u546c\u525f\u6fe3\u7020\u6b84\u5ef6\u6d3f\u5b31\u5a96\u60ab\u5f23\u60bc\u5c46\u648b\u6967\u6752\u6d87\u52e3\u6cbe\u4e56\u6a36\u6de3\u63db\u52eb\u6ff4\u56f1(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
