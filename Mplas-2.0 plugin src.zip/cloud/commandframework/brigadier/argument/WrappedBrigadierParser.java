package cloud.commandframework.brigadier.argument;

import java.util.function.*;
import com.mojang.brigadier.arguments.*;
import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import cloud.commandframework.arguments.parser.*;
import com.mojang.brigadier.exceptions.*;
import com.mojang.brigadier.context.*;
import com.mojang.brigadier.tree.*;
import com.mojang.brigadier.*;
import com.mojang.brigadier.suggestion.*;
import java.util.*;

public final class WrappedBrigadierParser<C, T> implements ArgumentParser<C, T>
{
    public WrappedBrigadierParser(final ArgumentType<T> argumentType) {
        this(() -> argumentType, 1);
    }
    
    public WrappedBrigadierParser(final Supplier<ArgumentType<T>> supplier) {
        this(supplier, 1);
    }
    
    public WrappedBrigadierParser(final ArgumentType<T> argumentType, final int n) {
        this(() -> argumentType, n);
    }
    
    public WrappedBrigadierParser(final Supplier<ArgumentType<T>> supplier, final int n) {
        this(supplier, n, null);
    }
    
    @API(status = API.Status.STABLE, since = "1.8.0")
    public WrappedBrigadierParser(final Supplier<ArgumentType<T>> supplier, final int expectedArgumentCount, final ParseFunction<T> parse) {
        Objects.requireNonNull(supplier, \u6bae\u5f18\u6360\u4eea\u570a\u5877\u5eae\u6d76\u5e9a\u675b\u5dd0\u5dd0\u5e0c\u69d1\u5d86\u53de\u57fc\u6c86\u5482\u538f\u6f64\u68db\u537f\u5182\u6778\u5478\u6633\u54d8\u5625\u6be4\u6b4e\u5835\u624a\u5c4a\u502a\u5691\u6d78\u6a9b\u54ad\u6eb2\u56f6(-1140986040, -1592818320, "\u31ab\u3194\u318d\u319f\u3199\u3198\u319c\u319a\u31af\u31a7\u318f\u319a\u3188", 425220589, 781058655));
        this.nativeType = supplier;
        this.expectedArgumentCount = expectedArgumentCount;
        this.parse = parse;
    }
    
    public ArgumentType<T> getNativeArgument() {
        return this.nativeType.get();
    }
    
    @Override
    public ArgumentParseResult<T> parse(final CommandContext<C> commandContext, final Queue<String> queue) {
        StringReader original;
        if (queue instanceof StringReader) {
            original = (StringReader)queue;
        }
        else if (queue instanceof StringReaderAsQueue) {
            original = ((StringReaderAsQueue)queue).getOriginal();
        }
        else {
            "\u5c78".length();
            "\u57a7\u588f\u5ac7".length();
            original = new QueueAsStringReader(queue);
        }
        try {
            final ArgumentParseResult<T> success = ArgumentParseResult.success((this.parse != null) ? this.parse.apply(this.nativeType.get(), original) : this.nativeType.get().parse(original));
            if (original instanceof QueueAsStringReader) {
                ((QueueAsStringReader)original).updateQueue();
            }
            return success;
        }
        catch (CommandSyntaxException ex) {
            final ArgumentParseResult<T> failure = ArgumentParseResult.failure((Throwable)ex);
            if (original instanceof QueueAsStringReader) {
                ((QueueAsStringReader)original).updateQueue();
            }
            return failure;
        }
        finally {
            if (original instanceof QueueAsStringReader) {
                ((QueueAsStringReader)original).updateQueue();
            }
            "\u5582\u5945".length();
            "\u7138\u5d78\u6105\u6e2e\u63dd".length();
            "\u52db".length();
            "\u5d4e\u6917".length();
        }
    }
    
    @Override
    public List<String> suggestions(final CommandContext<C> commandContext, final String s) {
        "\u5e1f\u5651\u5936\u5b37\u56ea".length();
        final com.mojang.brigadier.context.CommandContext commandContext2 = new com.mojang.brigadier.context.CommandContext((Object)commandContext.getOrDefault(\u6bae\u5f18\u6360\u4eea\u570a\u5877\u5eae\u6d76\u5e9a\u675b\u5dd0\u5dd0\u5e0c\u69d1\u5d86\u53de\u57fc\u6c86\u5482\u538f\u6f64\u68db\u537f\u5182\u6778\u5478\u6633\u54d8\u5625\u6be4\u6b4e\u5835\u624a\u5c4a\u502a\u5691\u6d78\u6a9b\u54ad\u6eb2\u56f6(675096020, 1095029073, "\ud3aa\ud3bd\ud3b0\ud3b3\ud3a9\ud3a0\ud392\ud3a1\ud393\ud3a2\ud3a9\ud3bf\ud3bd\ud3af\ud3a0\ud3a1\ud396\ud3bd\ud39e\u826c\ub776\ubd51\u8b9f\ub5a5\ubf86\ub23f\u81a7\ub8ae\ub57e\ubaf6", -202111125, -1316413352), commandContext.getSender()), commandContext.getRawInputJoined(), (Map)Collections.emptyMap(), (Command)null, (CommandNode)null, (List)Collections.emptyList(), StringRange.at(0), (com.mojang.brigadier.context.CommandContext)null, (RedirectModifier)null, false);
        final ArgumentType<T> argumentType = this.nativeType.get();
        final com.mojang.brigadier.context.CommandContext commandContext3 = commandContext2;
        "\u6762\u657e\u6483".length();
        "\u6469\u6343".length();
        "\u667d".length();
        final List list = argumentType.listSuggestions(commandContext3, new SuggestionsBuilder(s, 0)).join().getList();
        "\u4fac\u515f".length();
        "\u66ce\u6c70".length();
        final ArrayList list2 = new ArrayList<String>(list.size());
        final Iterator<Suggestion> iterator = list.iterator();
        while (iterator.hasNext()) {
            list2.add(iterator.next().getText());
            "\u60ac\u6c6f".length();
        }
        return (List<String>)list2;
    }
    
    @Override
    public boolean isContextFree() {
        return true;
    }
    
    @Override
    public int getRequestedArgumentCount() {
        return this.expectedArgumentCount;
    }
    
    public static int ColonialObfuscator_\u6835\u4f22\u5313\u530e\u6a8b\u6e12\u4e2c\u66b6\u6f61\u4f67\u59b2\u6138\u4fb6\u503c\u6e4b\u55a5\u6f18\u62c8\u68eb\u61b7\u6970\u606b\u54f5\u6a06\u7063\u5547\u5f8e\u5cc0\u700f\u6bca\u6cc6\u5993\u69f4\u6e88\u67c4\u6906\u5ebb\u5c2e\u5482\u5737\u5a41(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
