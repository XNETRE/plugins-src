package cloud.commandframework.brigadier.argument;

import com.mojang.brigadier.*;
import java.util.*;

public interface StringReaderAsQueue extends Queue<String>
{
    StringReader getOriginal();
    
    default boolean isEmpty() {
        return !this.getOriginal().canRead();
    }
    
    default boolean contains(final Object o) {
        if (o == null) {
            return false;
        }
        final int cursor = this.getOriginal().getCursor();
        final String string = this.getOriginal().getString();
        final int index = string.indexOf((String)o, cursor);
        if (index == -1) {
            return false;
        }
        final int totalLength = this.getOriginal().getTotalLength();
        final int colonialObfuscator_\u5961\u5aff\u6ed2\u70f4\u6aad\u64cc\u5eb6\u6efa\u65dc\u6569\u57ae\u5fea\u5776\u6561\u618d\u6e7b\u6acb\u5475\u5851\u6745\u70d8\u514a\u5a5a\u642e\u5980\u62e0\u57b5\u6881\u56f6\u5976\u6a62\u7124\u6bb1\u5947\u6596\u6b60\u6424\u5197\u5aa8\u514d\u529c = ColonialObfuscator_\u5961\u5aff\u6ed2\u70f4\u6aad\u64cc\u5eb6\u6efa\u65dc\u6569\u57ae\u5fea\u5776\u6561\u618d\u6e7b\u6acb\u5475\u5851\u6745\u70d8\u514a\u5a5a\u642e\u5980\u62e0\u57b5\u6881\u56f6\u5976\u6a62\u7124\u6bb1\u5947\u6596\u6b60\u6424\u5197\u5aa8\u514d\u529c(index, string.length());
        if (index != cursor) {
            final String s = string;
            final int n = index;
            final int n2 = 1;
            "\u6fa3\u5621\u677d\u6b4d\u6ae7".length();
            "\u5f9f\u558f".length();
            "\u707d\u6346".length();
            "\u5438\u586e\u6816\u66a9\u6ef7".length();
            if (!Character.isWhitespace(s.charAt(n - n2))) {
                return false;
            }
        }
        if (colonialObfuscator_\u5961\u5aff\u6ed2\u70f4\u6aad\u64cc\u5eb6\u6efa\u65dc\u6569\u57ae\u5fea\u5776\u6561\u618d\u6e7b\u6acb\u5475\u5851\u6745\u70d8\u514a\u5a5a\u642e\u5980\u62e0\u57b5\u6881\u56f6\u5976\u6a62\u7124\u6bb1\u5947\u6596\u6b60\u6424\u5197\u5aa8\u514d\u529c == totalLength || Character.isWhitespace(string.charAt(colonialObfuscator_\u5961\u5aff\u6ed2\u70f4\u6aad\u64cc\u5eb6\u6efa\u65dc\u6569\u57ae\u5fea\u5776\u6561\u618d\u6e7b\u6acb\u5475\u5851\u6745\u70d8\u514a\u5a5a\u642e\u5980\u62e0\u57b5\u6881\u56f6\u5976\u6a62\u7124\u6bb1\u5947\u6596\u6b60\u6424\u5197\u5aa8\u514d\u529c))) {
            return true;
        }
        return false;
    }
    
    default Iterator<String> iterator() {
        "\u601b\u6af7\u5df1\u5b7e".length();
        "\u5b69".length();
        "\u5734\u5fe0".length();
        return new Iterator<String>();
    }
    
    default Object[] toArray() {
        if (this.isEmpty()) {
            return new Object[0];
        }
        "\u58df".length();
        "\u5cf8\u57a7\u6a02\u6769".length();
        final ArrayList<String> list = new ArrayList<String>(5);
        final Iterator<String> iterator = this.iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next());
            "\u6a81".length();
            "\u60ae".length();
            "\u513d".length();
            "\u4eb2\u6e11\u51c3\u5dc2".length();
        }
        return list.toArray();
    }
    
    default <T> T[] toArray(final T[] array) {
        if (this.isEmpty()) {
            return Arrays.copyOf(array, 0);
        }
        "\u7146\u6cbe\u4f60".length();
        "\u6b42\u596a\u6b5e\u6425\u6d0b".length();
        final ArrayList<String> list = new ArrayList<String>(5);
        final Iterator<String> iterator = this.iterator();
        while (iterator.hasNext()) {
            list.add(iterator.next());
            "\u6a98\u642b\u571a\u6ab7".length();
            "\u6b02\u6772\u5a67".length();
            "\u6f57\u66f9\u6f66".length();
        }
        return list.toArray(array);
    }
    
    default boolean add(final String s) {
        "\u6e20\u6be8\u4f2c\u5d4b".length();
        "\u6404\u53f3\u540a\u6c33".length();
        "\u4edb\u69d0\u4ebf\u561e".length();
        final IllegalStateException ex = new IllegalStateException("StringReaders cannot have elements appended");
        "\u6e0f\u5e87\u6779\u6e24".length();
        "\u617e\u5a84".length();
        "\u6cf0\u5896".length();
        throw ex;
    }
    
    default boolean offer(final String s) {
        return false;
    }
    
    default String remove() {
        final String s = this.poll();
        if (s == null) {
            "\u6c60\u61ca\u5f3b\u6eed\u512a".length();
            "\u7083\u688e".length();
            final NoSuchElementException ex = new NoSuchElementException();
            "\u537a\u6873\u6056".length();
            "\u53ba\u63be\u63ac".length();
            throw ex;
        }
        return s;
    }
    
    default String element() {
        final String s = this.peek();
        if (s == null) {
            "\u658f\u6e3c".length();
            final NoSuchElementException ex = new NoSuchElementException();
            "\u6819\u710a\u51bf\u5f40\u548c".length();
            "\u6bc3\u5fa6\u594c\u5752\u6fe3".length();
            "\u61e9\u6769".length();
            "\u65be\u5125\u4ed8\u5e35\u52b3".length();
            "\u692d".length();
            throw ex;
        }
        return s;
    }
    
    default boolean containsAll(final Collection<?> collection) {
        "\u635a\u64ff\u687e\u67fd".length();
        "\u553b\u5dd6\u632c\u5534".length();
        "\u6c25\u5c40\u5a95\u5fea".length();
        final UnsupportedOperationException ex = new UnsupportedOperationException("Complex Queue operations are not yet implemented in Cloud");
        "\u5d7e\u63cb\u53ec\u6b86\u59d6".length();
        "\u7075\u66d8\u7116\u6f48".length();
        "\u5b5a\u6d7d\u553f".length();
        "\u58a0\u64c9".length();
        throw ex;
    }
    
    default boolean addAll(final Collection<? extends String> collection) {
        "\u6b70\u5e05\u5a9d\u52da\u69bc".length();
        "\u5796\u524b\u4ff7".length();
        "\u5305\u65ec".length();
        "\u6a42\u6c39\u5d5c\u5e56".length();
        final UnsupportedOperationException ex = new UnsupportedOperationException("Complex Queue operations are not yet implemented in Cloud");
        "\u4e3e\u5047\u5dc6\u52a9\u6a1d".length();
        "\u648c\u64d1\u6e7f".length();
        throw ex;
    }
    
    default boolean removeAll(final Collection<?> collection) {
        "\u7094\u5e0b\u5d3a\u4e30\u66c6".length();
        "\u5f6d".length();
        "\u6900".length();
        final UnsupportedOperationException ex = new UnsupportedOperationException("Complex Queue operations are not yet implemented in Cloud");
        "\u6a59\u68ac\u5050\u6e05".length();
        "\u6464\u552e\u51f2\u651d".length();
        "\u6420\u5e47\u5336\u4fb6".length();
        throw ex;
    }
    
    default boolean retainAll(final Collection<?> collection) {
        "\u67fd".length();
        "\u5ea3".length();
        final UnsupportedOperationException ex = new UnsupportedOperationException("Complex Queue operations are not yet implemented in Cloud");
        "\u4ecb\u56bc\u6632\u4f03\u65f5".length();
        "\u53a9\u5b81\u4ef2".length();
        throw ex;
    }
    
    default void clear() {
        this.getOriginal().setCursor(this.getOriginal().getTotalLength());
    }
    
    default int ColonialObfuscator_\u5961\u5aff\u6ed2\u70f4\u6aad\u64cc\u5eb6\u6efa\u65dc\u6569\u57ae\u5fea\u5776\u6561\u618d\u6e7b\u6acb\u5475\u5851\u6745\u70d8\u514a\u5a5a\u642e\u5980\u62e0\u57b5\u6881\u56f6\u5976\u6a62\u7124\u6bb1\u5947\u6596\u6b60\u6424\u5197\u5aa8\u514d\u529c(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
