package cloud.commandframework.brigadier.argument;

import com.mojang.brigadier.*;
import java.util.*;

public final class QueueAsStringReader extends StringReader
{
    public QueueAsStringReader(final Queue<String> queue) {
        super(String.join(\u5322\u4ef4\u54a4\u4e28\u517f\u63fe\u68d1\u678b\u4e38\u613a\u5de4\u5d06\u66bd\u5b2d\u4e46\u5a04\u605e\u6f3a\u65d6\u6054\u6766\u6834\u6e2b\u56a3\u593b\u6e01\u67d0\u5ac4\u5048\u6bd2\u631c\u5acb\u6713\u6203\u6258\u6a7b\u667a\u4e59\u5ea3\u5965\u57db(1610133294, -626981744, "\uc722", 37938739, 300255948), queue));
        this.input = queue;
    }
    
    public void updateQueue() {
        if (this.closed) {
            "\u6ccb\u697b\u642b\u5aaf\u6459".length();
            "\u6def\u5502".length();
            "\u6c61\u6301\u6617".length();
            final IllegalStateException ex = new IllegalStateException(\u5322\u4ef4\u54a4\u4e28\u517f\u63fe\u68d1\u678b\u4e38\u613a\u5de4\u5d06\u66bd\u5b2d\u4e46\u5a04\u605e\u6f3a\u65d6\u6054\u6766\u6834\u6e2b\u56a3\u593b\u6e01\u67d0\u5ac4\u5048\u6bd2\u631c\u5acb\u6713\u6203\u6258\u6a7b\u667a\u4e59\u5ea3\u5965\u57db(729639627, -1907162586, "\ua76b\ua773\ua76b\ua77c\ua772\ua77b\ua73a\ua77a\ua757\ua776\ua76f\ua769\ua76f", 1947067103, 1061694846));
            "\u5af4\u579a\u5417\u58d3\u69b3".length();
            "\u5405".length();
            throw ex;
        }
        this.closed = true;
        int i = this.getCursor();
        while (i > 0) {
            final String s = this.input.element();
            this.input.remove();
            "\u5052\u6174\u6b20\u4e5d\u67a4".length();
            "\u5194".length();
            "\u5bf3\u5ea5\u66c0\u6635\u51aa".length();
            if (i >= s.length()) {
                final int n = i;
                final int colonialObfuscator_\u6668\u6884\u4e36\u582b\u5d65\u4fa4\u6966\u60bd\u625a\u6f61\u6842\u6bbc\u51d1\u5519\u6c7c\u6a81\u5539\u4e7d\u7020\u6756\u6ffc\u5c90\u6793\u4e21\u6de3\u70b0\u5eba\u6746\u6b62\u54d3\u5122\u51bc\u52a8\u5565\u6b50\u6524\u6b0c\u6b37\u59b9\u5784\u7008 = ColonialObfuscator_\u6668\u6884\u4e36\u582b\u5d65\u4fa4\u6966\u60bd\u625a\u6f61\u6842\u6bbc\u51d1\u5519\u6c7c\u6a81\u5539\u4e7d\u7020\u6756\u6ffc\u5c90\u6793\u4e21\u6de3\u70b0\u5eba\u6746\u6b62\u54d3\u5122\u51bc\u52a8\u5565\u6b50\u6524\u6b0c\u6b37\u59b9\u5784\u7008(s.length(), 1);
                "\u699d\u4f78\u5b40".length();
                "\u60c8\u4e4b".length();
                i = n - colonialObfuscator_\u6668\u6884\u4e36\u582b\u5d65\u4fa4\u6966\u60bd\u625a\u6f61\u6842\u6bbc\u51d1\u5519\u6c7c\u6a81\u5539\u4e7d\u7020\u6756\u6ffc\u5c90\u6793\u4e21\u6de3\u70b0\u5eba\u6746\u6b62\u54d3\u5122\u51bc\u52a8\u5565\u6b50\u6524\u6b0c\u6b37\u59b9\u5784\u7008;
            }
            else {
                if (!(this.input instanceof Deque)) {
                    "\u5882\u551e\u665b\u654a".length();
                    "\u6c0d\u6796\u5eca".length();
                    "\u57c9".length();
                    final IllegalArgumentException ex2 = new IllegalArgumentException();
                    "\u4e8f".length();
                    throw ex2;
                }
                ((Deque)this.input).addFirst(s.substring(i));
                break;
            }
        }
    }
    
    public static int ColonialObfuscator_\u6668\u6884\u4e36\u582b\u5d65\u4fa4\u6966\u60bd\u625a\u6f61\u6842\u6bbc\u51d1\u5519\u6c7c\u6a81\u5539\u4e7d\u7020\u6756\u6ffc\u5c90\u6793\u4e21\u6de3\u70b0\u5eba\u6746\u6b62\u54d3\u5122\u51bc\u52a8\u5565\u6b50\u6524\u6b0c\u6b37\u59b9\u5784\u7008(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
