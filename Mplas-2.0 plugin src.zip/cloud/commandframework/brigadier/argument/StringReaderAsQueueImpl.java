package cloud.commandframework.brigadier.argument;

import com.mojang.brigadier.*;
import java.util.*;

public final class StringReaderAsQueueImpl
{
    public static int ColonialObfuscator_\u67ec\u50f0\u6915\u57df\u7060\u584f\u6bd3\u6f7d\u581d\u537a\u54ae\u6e85\u6bdd\u5b26\u6317\u4f1a\u5dbe\u67de\u50f5\u6d89\u6748\u555c\u7008\u5afa\u5f82\u5e2e\u59da\u69ff\u6ba8\u5af7\u53c7\u6fa1\u5936\u676b\u5025\u6fd7\u5935\u6b12\u50ea\u5fa2\u4e22(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
