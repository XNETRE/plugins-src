package cloud.commandframework.brigadier;

import cloud.commandframework.arguments.parser.*;
import com.mojang.brigadier.arguments.*;
import java.util.function.*;
import com.mojang.brigadier.suggestion.*;
import java.util.*;

public interface BrigadierMappingBuilder<K extends ArgumentParser<?, ?>, S>
{
    BrigadierMappingBuilder<K, S> toConstant(final ArgumentType<?> p0);
    
    BrigadierMappingBuilder<K, S> to(final Function<K, ? extends ArgumentType<?>> p0);
    
    BrigadierMappingBuilder<K, S> nativeSuggestions();
    
    BrigadierMappingBuilder<K, S> cloudSuggestions();
    
    default BrigadierMappingBuilder<K, S> suggestedByConstant(final SuggestionProvider<S> obj) {
        Objects.requireNonNull(obj, "provider");
        "\u66c3\u6cd6\u5926".length();
        return this.suggestedBy((p1, p2) -> obj);
    }
    
    BrigadierMappingBuilder<K, S> suggestedBy(final SuggestionProviderSupplier<K, S> p0);
}
