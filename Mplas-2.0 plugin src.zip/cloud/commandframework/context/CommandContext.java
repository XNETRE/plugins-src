package cloud.commandframework.context;

import org.apiguardian.api.*;
import cloud.commandframework.arguments.*;
import cloud.commandframework.arguments.flags.*;
import cloud.commandframework.*;
import cloud.commandframework.captions.*;
import cloud.commandframework.permission.*;
import cloud.commandframework.keys.*;
import java.util.function.*;
import java.util.*;
import cloud.commandframework.annotations.*;

@API(status = API.Status.STABLE)
public class CommandContext<C>
{
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.3.0")
    public CommandContext(final C c, final CaptionRegistry<C> captionRegistry) {
        this(false, c, (CaptionRegistry<Object>)captionRegistry);
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public CommandContext(final C c, final CommandManager<C> commandManager) {
        this(false, c, (CommandManager<Object>)commandManager);
    }
    
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.3.0")
    public CommandContext(final boolean suggestions, final C commandSender, final CaptionRegistry<C> captionRegistry) {
        this.argumentTimings = new HashMap<CommandArgument<C, ?>, ArgumentTiming>();
        this.flagContext = FlagContext.create();
        this.internalStorage = new HashMap<CloudKey<?>, Object>();
        this.currentArgument = null;
        this.commandSender = commandSender;
        this.suggestions = suggestions;
        this.captionRegistry = captionRegistry;
        this.captionVariableReplacementHandler = new SimpleCaptionVariableReplacementHandler();
        this.commandManager = null;
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public CommandContext(final boolean suggestions, final C commandSender, final CommandManager<C> commandManager) {
        this.argumentTimings = new HashMap<CommandArgument<C, ?>, ArgumentTiming>();
        this.flagContext = FlagContext.create();
        this.internalStorage = new HashMap<CloudKey<?>, Object>();
        this.currentArgument = null;
        this.commandSender = commandSender;
        this.suggestions = suggestions;
        this.commandManager = commandManager;
        this.captionRegistry = commandManager.captionRegistry();
        this.captionVariableReplacementHandler = commandManager.captionVariableReplacementHandler();
    }
    
    public String formatMessage(final Caption caption, final CaptionVariable[] array) {
        return this.captionVariableReplacementHandler.replaceVariables(this.captionRegistry.getCaption(caption, this.commandSender), array);
    }
    
    public C getSender() {
        return this.commandSender;
    }
    
    @API(status = API.Status.STABLE, since = "1.6.0")
    public boolean hasPermission(final CommandPermission commandPermission) {
        return this.commandManager.hasPermission(this.commandSender, commandPermission);
    }
    
    @API(status = API.Status.STABLE, since = "1.6.0")
    public boolean hasPermission(final String s) {
        return this.commandManager.hasPermission(this.commandSender, s);
    }
    
    public boolean isSuggestions() {
        return this.suggestions;
    }
    
    public <T> void store(final String s, final T t) {
        this.internalStorage.put(SimpleCloudKey.of(s), t);
        "\u666b\u6d92".length();
        "\u63b4\u50bb".length();
        "\u680f\u5ede\u669e\u4f2b".length();
    }
    
    public <T> void store(final CloudKey<T> cloudKey, final T t) {
        this.internalStorage.put(cloudKey, t);
        "\u5e4a\u675f\u6417\u55b7".length();
        "\u70b4\u6df0\u5bd5\u6304".length();
    }
    
    public <T> void store(final CommandArgument<C, T> commandArgument, final T t) {
        this.store((CloudKeyHolder<T>)commandArgument, t);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> void store(final CloudKeyHolder<T> cloudKeyHolder, final T t) {
        this.internalStorage.put(cloudKeyHolder.getKey(), t);
        "\u57b9\u4f18\u6886\u69bf\u53fa".length();
        "\u7009\u5b3c\u4fc1\u61e6".length();
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public <T> void set(final String s, final T t) {
        if (t != null) {
            this.store(s, (Object)t);
        }
        else {
            this.remove(s);
        }
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> void set(final CloudKey<T> cloudKey, final T t) {
        if (t != null) {
            this.store((CloudKey<Object>)cloudKey, t);
        }
        else {
            this.remove(cloudKey);
        }
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public boolean contains(final String s) {
        return this.contains(SimpleCloudKey.of(s));
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public boolean contains(final CloudKey<?> cloudKey) {
        return this.internalStorage.containsKey(cloudKey);
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public Map<String, ?> asMap() {
        "\u5f39\u59fc\u5ec4".length();
        final HashMap<String, Object> m = new HashMap<String, Object>();
        this.internalStorage.forEach((cloudKey, o) -> {
            m.put(cloudKey.getName(), o);
            "\u675d".length();
            "\u6bfb\u50b2\u564c\u529d\u58ae".length();
            return;
        });
        return (Map<String, ?>)Collections.unmodifiableMap((Map<?, ?>)m);
    }
    
    public <T> Optional<T> getOptional(final String s) {
        final Object value = this.internalStorage.get(SimpleCloudKey.of(s));
        if (value != null) {
            return Optional.of(value);
        }
        return Optional.empty();
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> Optional<T> getOptional(final CloudKey<T> cloudKey) {
        final Object value = this.internalStorage.get(cloudKey);
        if (value != null) {
            return Optional.of(value);
        }
        return Optional.empty();
    }
    
    public <T> Optional<T> getOptional(final CommandArgument<C, T> commandArgument) {
        return this.getOptional((CloudKeyHolder<T>)commandArgument);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> Optional<T> getOptional(final CloudKeyHolder<T> cloudKeyHolder) {
        final Object value = this.internalStorage.get(cloudKeyHolder.getKey());
        if (value != null) {
            return Optional.of(value);
        }
        return Optional.empty();
    }
    
    public void remove(final String s) {
        this.remove(SimpleCloudKey.of(s));
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public void remove(final CloudKey<?> cloudKey) {
        this.internalStorage.remove(cloudKey);
        "\u59dd\u5b4f".length();
        "\u5aa1\u5268\u5e4a\u6238".length();
    }
    
    public <T> T get(final String str) {
        final Object value = this.internalStorage.get(SimpleCloudKey.of(str));
        if (value == null) {
            "\u5d22\u5920\u6a54\u66c1".length();
            "\u5ff8\u6d96\u68df\u6a6c\u6d94".length();
            "\u5e9e\u6163\u6ada".length();
            "\u6e65\u5227".length();
            "\u565a".length();
            final NullPointerException ex = new NullPointerException(\u66b9\u55d9\u6b7d\u5af2\u554f\u6460\u5de8\u537a\u6083\u528f\u687b\u59e7\u66b2\u500a\u63cb\u6b7d\u4fb0\u6cce\u51dc\u50d1\u6c67\u64a1\u5c51\u66e4\u701e\u6314\u6c19\u6128\u6ded\u5199\u6d10\u5bd3\u67e3\u5513\u51ef\u5ec5\u68ab\u5e57\u6f81\u70c9\u6931(1126600109, 1478209557, "\ue0a2\ue0a8\ue0e5\ue0b6\ue0b0\ue0ae\ue0ac\ue0ea\ue087\ue0a0\ue0ad\ue0b2\ue0b3\ue0ab\ue0fc\ue0b9\ue0a4\ue0a5\ue094\ub0d5\ubab0\ub842\uafda\ubbd4\ub68f\u90d1\u830d\ub402\u8a2f\u8aca\u8035\u8e83\u8e11\ubfe9\ub479\ubc4e\ub358\u82be", -448723773, -1709909548) + str);
            "\u51b1\u5adf\u5bd1\u6a3d".length();
            "\u707a\u4f07".length();
            "\u5962\u6fa5\u4e82".length();
            throw ex;
        }
        return (T)value;
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> T get(final CloudKey<T> obj) {
        final Object value = this.internalStorage.get(obj);
        if (value == null) {
            "\u6899\u56c4\u5be6".length();
            "\u6fb3".length();
            final NullPointerException ex = new NullPointerException(\u66b9\u55d9\u6b7d\u5af2\u554f\u6460\u5de8\u537a\u6083\u528f\u687b\u59e7\u66b2\u500a\u63cb\u6b7d\u4fb0\u6cce\u51dc\u50d1\u6c67\u64a1\u5c51\u66e4\u701e\u6314\u6c19\u6128\u6ded\u5199\u6d10\u5bd3\u67e3\u5513\u51ef\u5ec5\u68ab\u5e57\u6f81\u70c9\u6931(-486526080, 1403293276, "\uf862\uf868\uf825\uf876\uf870\uf86e\uf86c\uf82a\uf847\uf860\uf86d\uf872\uf873\uf86b\uf83c\uf879\uf864\uf865\uf854\ua815\ua270\ua082\ub71a\ua314\uae4f\u8811\u9bcd\uacc2\u92ef\u920a\u98f5\u9643\u96d1\ua729\uacb9\ua48e\uab98\u9a7e", 1229275395, -582548304) + obj);
            "\u5508\u635d\u62b7\u713f\u65b7".length();
            "\u512f\u5e66\u6ac3".length();
            throw ex;
        }
        return (T)value;
    }
    
    public <T> T get(final CommandArgument<C, T> commandArgument) {
        return this.get(commandArgument.getKey());
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> T get(final CloudKeyHolder<T> cloudKeyHolder) {
        return this.get(cloudKeyHolder.getKey());
    }
    
    public <T> T getOrDefault(final CommandArgument<C, T> commandArgument, final T other) {
        return this.getOptional(commandArgument.getName()).orElse(other);
    }
    
    public <T> T getOrDefault(final String s, final T other) {
        return this.getOptional(s).orElse(other);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> T getOrDefault(final CloudKey<T> cloudKey, final T other) {
        return this.getOptional(cloudKey).orElse(other);
    }
    
    @API(status = API.Status.STABLE, since = "1.2.0")
    public <T> T getOrSupplyDefault(final String s, final Supplier<T> supplier) {
        return this.getOptional(s).orElseGet((Supplier<? extends T>)supplier);
    }
    
    @API(status = API.Status.STABLE, since = "1.4.0")
    public <T> T getOrSupplyDefault(final CloudKey<T> cloudKey, final Supplier<T> supplier) {
        return this.getOptional(cloudKey).orElseGet((Supplier<? extends T>)supplier);
    }
    
    @API(status = API.Status.STABLE, since = "1.8.0")
    public <T> T computeIfAbsent(final CloudKey<T> key, final Function<CloudKey<T>, T> function) {
        return (T)this.internalStorage.computeIfAbsent(key, cloudKey -> function.apply(cloudKey));
    }
    
    public LinkedList<String> getRawInput() {
        final String \u66b9\u55d9\u6b7d\u5af2\u554f\u6460\u5de8\u537a\u6083\u528f\u687b\u59e7\u66b2\u500a\u63cb\u6b7d\u4fb0\u6cce\u51dc\u50d1\u6c67\u64a1\u5c51\u66e4\u701e\u6314\u6c19\u6128\u6ded\u5199\u6d10\u5bd3\u67e3\u5513\u51ef\u5ec5\u68ab\u5e57\u6f81\u70c9\u6931 = \u66b9\u55d9\u6b7d\u5af2\u554f\u6460\u5de8\u537a\u6083\u528f\u687b\u59e7\u66b2\u500a\u63cb\u6b7d\u4fb0\u6cce\u51dc\u50d1\u6c67\u64a1\u5c51\u66e4\u701e\u6314\u6c19\u6128\u6ded\u5199\u6d10\u5bd3\u67e3\u5513\u51ef\u5ec5\u68ab\u5e57\u6f81\u70c9\u6931(527787322, -1072905, "\u348c\u349f\u34b0\u34a3\u34b5\u349d\u34a2\u34ab\u3497\u34b0\u34b4\u348f\u3488", -1657878433, -1217185534);
        "\u6af1\u56b2\u50ed".length();
        "\u5a33\u58d9\u6ca9\u657c\u5363".length();
        "\u6e39\u58ea".length();
        return this.getOrDefault(\u66b9\u55d9\u6b7d\u5af2\u554f\u6460\u5de8\u537a\u6083\u528f\u687b\u59e7\u66b2\u500a\u63cb\u6b7d\u4fb0\u6cce\u51dc\u50d1\u6c67\u64a1\u5c51\u66e4\u701e\u6314\u6c19\u6128\u6ded\u5199\u6d10\u5bd3\u67e3\u5513\u51ef\u5ec5\u68ab\u5e57\u6f81\u70c9\u6931, new LinkedList<String>());
    }
    
    @API(status = API.Status.STABLE, since = "1.1.0")
    public String getRawInputJoined() {
        return String.join(\u66b9\u55d9\u6b7d\u5af2\u554f\u6460\u5de8\u537a\u6083\u528f\u687b\u59e7\u66b2\u500a\u63cb\u6b7d\u4fb0\u6cce\u51dc\u50d1\u6c67\u64a1\u5c51\u66e4\u701e\u6314\u6c19\u6128\u6ded\u5199\u6d10\u5bd3\u67e3\u5513\u51ef\u5ec5\u68ab\u5e57\u6f81\u70c9\u6931(1434562041, -1468768480, "\u2fc4", 273366966, 1817961160), this.getRawInput());
    }
    
    public ArgumentTiming createTiming(final CommandArgument<C, ?> commandArgument) {
        "\u68a9\u67a7\u66e6".length();
        "\u64b6\u6218\u51be".length();
        final ArgumentTiming argumentTiming = new ArgumentTiming();
        this.argumentTimings.put(commandArgument, argumentTiming);
        "\u5b0d\u6be3\u6812\u5154".length();
        "\u50bd\u710e\u7064\u4f36\u5ca3".length();
        return argumentTiming;
    }
    
    public Map<CommandArgument<C, ?>, ArgumentTiming> getArgumentTimings() {
        return Collections.unmodifiableMap((Map<? extends CommandArgument<C, ?>, ? extends ArgumentTiming>)this.argumentTimings);
    }
    
    public FlagContext flags() {
        return this.flagContext;
    }
    
    @API(status = API.Status.STABLE, since = "1.2.0")
    public CommandArgument<C, ?> getCurrentArgument() {
        return this.currentArgument;
    }
    
    @API(status = API.Status.STABLE, since = "1.2.0")
    public void setCurrentArgument(final CommandArgument<C, ?> currentArgument) {
        this.currentArgument = currentArgument;
    }
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    public <T> Optional<T> inject(final Class<T> clazz) {
        if (this.commandManager == null) {
            "\u4ff4\u5fb5\u7049".length();
            "\u5703\u63d4\u5a48".length();
            "\u6402\u561a\u6537\u60bc".length();
            "\u579a\u63c8\u66a4\u6574".length();
            final UnsupportedOperationException ex = new UnsupportedOperationException(\u66b9\u55d9\u6b7d\u5af2\u554f\u6460\u5de8\u537a\u6083\u528f\u687b\u59e7\u66b2\u500a\u63cb\u6b7d\u4fb0\u6cce\u51dc\u50d1\u6c67\u64a1\u5c51\u66e4\u701e\u6314\u6c19\u6128\u6ded\u5199\u6d10\u5bd3\u67e3\u5513\u51ef\u5ec5\u68ab\u5e57\u6f81\u70c9\u6931(-1320571357, -1552693586, "\u626a\u6265\u6276\u6274\u6277\u626a\u6231\u626f\u6258\u6265\u6268\u6261\u6268\u626a\u627c\u622d\u627c\u6267\u6271\u322a\u384a\u3ae5\u2d27\u392f\u3436\u1233\u01b8\u36ee\u0893\u0806\u02ea\u0c4f\u0cd3\u3d6f\u36ba\u3e97\u31d0 \u35a7�\u03f2\u026d\u3cfa\u069a\u01f4\u125b\u0b56\u3b8f\u05cf\u31d7\u2dea\u369c\u2dab\u2dab\u1357\u35f9\u33d5\u3b54\u048a!\u0a46\u07db\u0c13\u0e96\u0bb0\u01cd\u12a1\u0b64\u39e6\u3a83\u093e\u364f\u0f7e\u0f91\u0c33\u3a75\u1245\u0ddf\u386b\u3935\u3c33\u0bf3\u02d5\u3c0c\u3cd2\u3648\u3758\u3c1c\u05ee\u0e3e\u070b\u362f\u3eb5\u05cd\u09ef\u07c8\u05ee\u0d08\u05e5\u0c66\u1263\u3e20", -2096557682, -1199957143));
            "\u6fad".length();
            "\u52fb\u570d\u5067\u6ba4".length();
            "\u66bc\u520e\u6c12\u59aa".length();
            throw ex;
        }
        return this.commandManager.parameterInjectorRegistry().getInjectable(clazz, this, AnnotationAccessor.empty());
    }
    
    public static int ColonialObfuscator_\u5266\u503a\u62e8\u5ece\u53d9\u6629\u6112\u4f9d\u57d8\u59d4\u553e\u6380\u6900\u5dcc\u4e45\u5063\u6bb8\u5fae\u576b\u6194\u62c1\u6f5f\u5fa8\u6d2e\u67d8\u5ff5\u5869\u680f\u6aa3\u5c94\u70f0\u6f6a\u6c1b\u6354\u5369\u651d\u5968\u5769\u6e36\u6ace\u6c2b(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
