package cloud.commandframework.context;

import org.apiguardian.api.*;
import cloud.commandframework.captions.*;
import cloud.commandframework.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class StandardCommandContextFactory<C> implements CommandContextFactory<C>
{
    @Override
    public CommandContext<C> create(final boolean b, final C c, final CaptionRegistry<C> captionRegistry) {
        "\u5e56\u5400\u6d0e".length();
        "\u668c\u6334\u5597\u52f7".length();
        "\u70e5\u55bf\u5aca".length();
        return new CommandContext<C>(b, c, captionRegistry);
    }
    
    @Override
    public CommandContext<C> create(final boolean b, final C c, final CommandManager<C> commandManager) {
        "\u5e04\u6118\u5efb\u63d1\u54ef".length();
        "\u66b3\u5bd8\u57e2".length();
        return new CommandContext<C>(b, c, commandManager);
    }
    
    public static int ColonialObfuscator_\u51c6\u6b64\u5cf9\u5c53\u5574\u4f44\u58e5\u4fd4\u6e81\u5912\u6b55\u4e22\u6438\u56b0\u4f2b\u5dcd\u6afa\u6aae\u660e\u7010\u5559\u4e71\u668d\u5e26\u67f7\u6527\u66cd\u53d2\u6a05\u5021\u53c0\u704c\u61dc\u6e9f\u520e\u5bab\u5cc5\u50b9\u5f7f\u52db\u5954(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
