package cloud.commandframework.context;

import org.apiguardian.api.*;
import cloud.commandframework.captions.*;
import cloud.commandframework.*;

@API(status = API.Status.STABLE)
public interface CommandContextFactory<C>
{
    @Deprecated
    @API(status = API.Status.DEPRECATED, since = "1.3.0")
    CommandContext<C> create(final boolean p0, final C p1, final CaptionRegistry<C> p2);
    
    @API(status = API.Status.STABLE, since = "1.3.0")
    CommandContext<C> create(final boolean p0, final C p1, final CommandManager<C> p2);
}
