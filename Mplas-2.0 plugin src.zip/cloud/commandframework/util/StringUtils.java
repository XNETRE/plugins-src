package cloud.commandframework.util;

import org.apiguardian.api.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class StringUtils
{
    public static int ColonialObfuscator_\u618f\u66b0\u5824\u6750\u5a11\u67c9\u5321\u6f53\u5a77\u511d\u676b\u65e2\u5003\u585c\u6840\u5f68\u5975\u6678\u638e\u5b63\u679b\u5a92\u6e3e\u5bc1\u7091\u5a44\u5222\u5a23\u5331\u64b2\u63bc\u6072\u4e6f\u54a8\u5bc0\u53ca\u5329\u6eff\u5eec\u5b3c\u4e6e(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
