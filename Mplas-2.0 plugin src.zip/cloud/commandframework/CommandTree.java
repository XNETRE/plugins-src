package cloud.commandframework;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import cloud.commandframework.types.tuples.*;
import cloud.commandframework.arguments.parser.*;
import cloud.commandframework.arguments.*;
import java.util.stream.*;
import cloud.commandframework.arguments.compound.*;
import cloud.commandframework.permission.*;
import cloud.commandframework.exceptions.*;
import java.util.function.*;
import io.leangen.geantyref.*;
import cloud.commandframework.keys.*;
import java.util.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class CommandTree<C>
{
    public CommandTree(final CommandManager<C> commandManager) {
        this.commandLock = new Object();
        this.internalTree = new Node<CommandArgument<C, ?>>(null, null);
        this.commandManager = commandManager;
    }
    
    public Pair<Command<C>, Exception> parse(final CommandContext<C> commandContext, final Queue<String> queue) {
        if (this.internalTree.isLeaf() && Node.access$100((Node<Object>)this.internalTree) == null) {
            final Command<C> command = null;
            "\u65c7\u4ebd\u6c1c\u6faa".length();
            final C sender = commandContext.getSender();
            "\u6d5a\u69aa".length();
            "\u7110\u6ff5\u58cb\u6a20\u5314".length();
            return (Pair<Command<C>, Exception>)Pair.of(command, new NoSuchCommandException(sender, new ArrayList<CommandArgument<?, ?>>(), this.stringOrEmpty(queue.peek())));
        }
        "\u6e61\u5753\u53a7\u5635".length();
        "\u6aac\u5dbc\u619c\u6de3".length();
        final Pair<Command<C>, Exception> command2 = this.parseCommand(new ArrayList<CommandArgument<C, ?>>(), commandContext, queue, this.internalTree);
        if (command2.getFirst() != null) {
            final Command<C> command3 = command2.getFirst();
            if (command3.getSenderType().isPresent() && !command3.getSenderType().get().isAssignableFrom(commandContext.getSender().getClass())) {
                final Command<C> command4 = null;
                "\u635c\u6381\u52dc\u4f02".length();
                "\u5934".length();
                final C sender2 = commandContext.getSender();
                final Class<? extends C> clazz = command3.getSenderType().get();
                "\u6a3e\u56be\u5d95\u569f".length();
                "\u5b72".length();
                return (Pair<Command<C>, Exception>)Pair.of(command4, new InvalidCommandSenderException(sender2, clazz, new ArrayList<CommandArgument<?, ?>>(command3.getArguments()), command3));
            }
        }
        return command2;
    }
    
    public Pair<Command<C>, Exception> parseCommand(final List<CommandArgument<C, ?>> list, final CommandContext<C> commandContext, final Queue<String> queue, final Node<CommandArgument<C, ?>> node6) {
        final CommandPermission permitted = this.isPermitted(commandContext.getSender(), node6);
        if (permitted != null) {
            final Command<C> command = null;
            "\u55fe".length();
            "\u6bc6".length();
            return (Pair<Command<C>, Exception>)Pair.of(command, new NoPermissionException(permitted, commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node6).stream().filter(node -> node.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
        }
        final Pair<Command<C>, Exception> attemptParseUnambiguousChild = this.attemptParseUnambiguousChild(list, commandContext, node6, queue);
        if (attemptParseUnambiguousChild.getFirst() != null || attemptParseUnambiguousChild.getSecond() != null) {
            return attemptParseUnambiguousChild;
        }
        if (Node.access$200((Node<Object>)node6).isEmpty()) {
            if (node6.getValue() == null || node6.getValue().getOwningCommand() == null) {
                final Command<C> command2 = null;
                "\u63af\u7017\u6017\u7106".length();
                "\u5163".length();
                "\u62c0\u6edb\u6840\u4ec6\u6246".length();
                return (Pair<Command<C>, Exception>)Pair.of(command2, new InvalidSyntaxException(this.commandManager.commandSyntaxFormatter().apply(list, node6), commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node6).stream().filter(node2 -> node2.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
            }
            if (queue.isEmpty()) {
                return Pair.of(this.cast(node6.getValue().getOwningCommand()), (Exception)null);
            }
            final Command<C> command3 = null;
            "\u63c7".length();
            return (Pair<Command<C>, Exception>)Pair.of(command3, new InvalidSyntaxException(this.commandManager.commandSyntaxFormatter().apply(list, node6), commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node6).stream().filter(node3 -> node3.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
        }
        else {
            final Iterator<Node<CommandArgument<C, ?>>> iterator = node6.getChildren().iterator();
            if (iterator.hasNext()) {
                while (iterator.hasNext()) {
                    final Node<CommandArgument<C, ?>> node7 = iterator.next();
                    if (node7.getValue() != null) {
                        final CommandArgument<C, ?> currentArgument = node7.getValue();
                        final CommandContext.ArgumentTiming timing = commandContext.createTiming(currentArgument);
                        timing.setStart(System.nanoTime());
                        commandContext.setCurrentArgument(currentArgument);
                        final ArgumentParseResult<?> parse = currentArgument.getParser().parse(commandContext, queue);
                        timing.setEnd(System.nanoTime(), parse.getFailure().isPresent());
                        if (parse.getParsedValue().isPresent()) {
                            list.add(node7.getValue());
                            "\u6f09".length();
                            "\u5182".length();
                            "\u58e2\u6da4".length();
                            return this.parseCommand(list, commandContext, queue, node7);
                        }
                        continue;
                    }
                }
            }
            if (node6.equals(this.internalTree)) {
                final Command<C> command4 = null;
                "\u538d\u6586\u66f9\u5576\u5105".length();
                "\u5dd9\u6113\u6c85\u5c0e".length();
                return (Pair<Command<C>, Exception>)Pair.of(command4, new NoSuchCommandException(commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node6).stream().map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()), this.stringOrEmpty(queue.peek())));
            }
            if (node6.getValue() == null || node6.getValue().getOwningCommand() == null || !queue.isEmpty()) {
                final Command<C> command5 = null;
                "\u5029\u6d3d\u6919\u6c61".length();
                "\u6293\u6e5a\u5a65\u4fc7\u512e".length();
                "\u553e".length();
                return (Pair<Command<C>, Exception>)Pair.of(command5, new InvalidSyntaxException(this.commandManager.commandSyntaxFormatter().apply(list, node6), commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node6).stream().filter(node4 -> node4.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
            }
            final Command<C> owningCommand = node6.getValue().getOwningCommand();
            if (!this.getCommandManager().hasPermission(commandContext.getSender(), owningCommand.getCommandPermission())) {
                final Command<C> command6 = null;
                "\u5c52\u5e29\u6a40".length();
                return (Pair<Command<C>, Exception>)Pair.of(command6, new NoPermissionException(owningCommand.getCommandPermission(), commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node6).stream().filter(node5 -> node5.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
            }
            return Pair.of(node6.getValue().getOwningCommand(), (Exception)null);
        }
    }
    
    public Pair<Command<C>, Exception> attemptParseUnambiguousChild(final List<CommandArgument<C, ?>> list, final CommandContext<C> commandContext, final Node<CommandArgument<C, ?>> node11, final Queue<String> queue) {
        final List<Node<CommandArgument<C, ?>>> children = node11.getChildren();
        if (!queue.isEmpty() && children.stream().filter(node -> node.getValue() instanceof StaticArgument).map(node2 -> node2.getValue()).flatMap(staticArgument -> Stream.concat((Stream<?>)Stream.of((T)staticArgument.getName()), (Stream<?>)staticArgument.getAliases().stream())).anyMatch(s -> s.equals(queue.peek()))) {
            return Pair.of((Command<C>)null, (Exception)null);
        }
        final List<Object> list2 = children.stream().filter(node3 -> node3.getValue() != null && !(node3.getValue() instanceof StaticArgument)).collect((Collector<? super Object, ?, List<Object>>)Collectors.toList());
        if (list2.size() > 1) {
            "\u5a0c\u7121".length();
            final IllegalStateException ex = new IllegalStateException(\u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(-959039002, 2068439744, "\u8a4d\u8a5d\u8a54\u8a49\u8a41\u8a4c\u8a43\u8a5a\u8a69\u8a42\u8a03\u8a52\u8a59\u8a49\u8a41\u8a59\u8a51\u8a57\u8a66\ue863\ud0cb\ud832\ud4af\ud6c2\uefe1\ud82d\udd97\uec5f\ud640\uee68\ue6d5\ud20f\ude55\udb71\ue5d5\udb43\ufa96\udc3f\uda84\ud0cd\ue649\ud9e7\ue1e3\ue676\uec98\uc475\ue22a\udc19\ufb89\ue53c\uc456\ud787\uc518\ude85\ud460\ue695\ued12\ue4d6\ud17b\uecbc\uddea\ud741\ud720\uc483\ue3de\ud20e\ufaa7\uddeb\ud674\ue4a7\ud428\ue10e\ud530\uece5\uedfc\ud0a9\ud22c\ufbe0\uc526\ud770", -1026123925, -969161194));
            "\u6809\u6024".length();
            "\u594e".length();
            throw ex;
        }
        if (!list2.isEmpty()) {
            final Node<CommandArgument<C, ?>> node12 = list2.get(0);
            final CommandPermission permitted = this.isPermitted(commandContext.getSender(), node12);
            if (!queue.isEmpty() && permitted != null) {
                final Command<C> command = null;
                "\u677d\u528b\u57de\u6aa3".length();
                return (Pair<Command<C>, Exception>)Pair.of(command, new NoPermissionException(permitted, commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node12).stream().filter(node4 -> node4.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
            }
            if (node12.getValue() != null) {
                if (queue.isEmpty() && !(node12.getValue() instanceof FlagArgument)) {
                    if (node12.getValue().hasDefaultValue()) {
                        queue.add(node12.getValue().getDefaultValue());
                        "\u60ad\u6ef5".length();
                        "\u4ea6\u61d9\u6c7d\u500d".length();
                    }
                    else {
                        if (!node12.getValue().isRequired()) {
                            if (node12.getValue().getOwningCommand() == null) {
                                Node<CommandArgument<C, T>> node13 = (Node<CommandArgument<C, T>>)node12;
                                while (!node13.isLeaf()) {
                                    node13 = node13.getChildren().get(0);
                                    if (node13.getValue() != null && node13.getValue().getOwningCommand() != null) {
                                        node12.getValue().setOwningCommand(node13.getValue().getOwningCommand());
                                    }
                                }
                            }
                            return Pair.of(node12.getValue().getOwningCommand(), (Exception)null);
                        }
                        if (node12.isLeaf()) {
                            if (node11.getValue() == null || node11.getValue().getOwningCommand() == null) {
                                final Command<C> command2 = null;
                                "\u7142\u697c\u6f49".length();
                                "\u4fef\u58ee\u67c9\u5aa6".length();
                                "\u5260\u6fb8\u6906\u4e38".length();
                                return (Pair<Command<C>, Exception>)Pair.of(command2, new InvalidSyntaxException(this.commandManager.commandSyntaxFormatter().apply(Objects.requireNonNull(node12.getValue().getOwningCommand()).getArguments(), node12), commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node11).stream().filter(node5 -> node5.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
                            }
                            final Command<C> owningCommand = node11.getValue().getOwningCommand();
                            if (!this.getCommandManager().hasPermission(commandContext.getSender(), owningCommand.getCommandPermission())) {
                                final Command<C> command3 = null;
                                "\u6b1a".length();
                                "\u6970\u5524\u6dbb".length();
                                "\u6e1d\u6661".length();
                                "\u5568\u53d0\u6747".length();
                                "\u6102".length();
                                return (Pair<Command<C>, Exception>)Pair.of(command3, new NoPermissionException(owningCommand.getCommandPermission(), commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node11).stream().filter(node6 -> node6.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
                            }
                            return Pair.of(owningCommand, (Exception)null);
                        }
                        else {
                            if (node11.getValue() == null || node11.getValue().getOwningCommand() == null) {
                                final Command<C> command4 = null;
                                "\u57e1\u5263\u6912".length();
                                "\u50d5\u65bc\u6ff0\u624b".length();
                                "\u5ef8\u572d\u5e26".length();
                                return (Pair<Command<C>, Exception>)Pair.of(command4, new InvalidSyntaxException(this.commandManager.commandSyntaxFormatter().apply(list, node11), commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node11).stream().filter(node7 -> node7.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
                            }
                            final Command<C> owningCommand2 = node11.getValue().getOwningCommand();
                            if (!this.getCommandManager().hasPermission(commandContext.getSender(), owningCommand2.getCommandPermission())) {
                                final Command<C> command5 = null;
                                "\u5319".length();
                                "\u62d8\u67e0\u5ef5".length();
                                "\u6578\u66ed\u69dc\u671d\u5897".length();
                                return (Pair<Command<C>, Exception>)Pair.of(command5, new NoPermissionException(owningCommand2.getCommandPermission(), commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node11).stream().filter(node8 -> node8.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
                            }
                            return Pair.of(owningCommand2, (Exception)null);
                        }
                    }
                }
                final CommandArgument<C, T> currentArgument = node12.getValue();
                final CommandContext.ArgumentTiming timing = commandContext.createTiming(currentArgument);
                timing.setStart(System.nanoTime());
                final ArgumentParseResult<Boolean> preprocess = node12.getValue().preprocess(commandContext, queue);
                Object parse;
                if (!preprocess.getFailure().isPresent() && preprocess.getParsedValue().orElse(false)) {
                    commandContext.setCurrentArgument(currentArgument);
                    parse = currentArgument.getParser().parse(commandContext, queue);
                }
                else {
                    parse = preprocess;
                }
                timing.setEnd(System.nanoTime(), ((ArgumentParseResult)parse).getFailure().isPresent());
                if (((ArgumentParseResult<T>)parse).getParsedValue().isPresent()) {
                    commandContext.store(node12.getValue().getName(), (Object)((ArgumentParseResult<T>)parse).getParsedValue().get());
                    if (!node12.isLeaf()) {
                        list.add(node12.getValue());
                        "\u6f08".length();
                        "\u6c44".length();
                        return this.parseCommand(list, commandContext, queue, node12);
                    }
                    if (queue.isEmpty()) {
                        return Pair.of((Command<C>)this.cast((Command<C>)node12.getValue().getOwningCommand()), (Exception)null);
                    }
                    final Command<C> command6 = null;
                    "\u52e7".length();
                    "\u4e54\u5af7\u56b1".length();
                    return (Pair<Command<C>, Exception>)Pair.of(command6, new InvalidSyntaxException(this.commandManager.commandSyntaxFormatter().apply(list, node12), commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node11).stream().filter(node9 -> node9.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
                }
                else if (((ArgumentParseResult)parse).getFailure().isPresent()) {
                    final Command<C> command7 = null;
                    "\u659b\u61c7".length();
                    return (Pair<Command<C>, Exception>)Pair.of(command7, new ArgumentParseException(((ArgumentParseResult)parse).getFailure().get(), commandContext.getSender(), (List<CommandArgument<?, ?>>)this.getChain(node12).stream().filter(node10 -> node10.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())));
                }
            }
        }
        return Pair.of((Command<C>)null, (Exception)null);
    }
    
    public List<String> getSuggestions(final CommandContext<C> commandContext, final Queue<String> queue) {
        return this.getSuggestions(commandContext, queue, this.internalTree);
    }
    
    public List<String> getSuggestions(final CommandContext<C> commandContext, final Queue<String> c, final Node<CommandArgument<C, ?>> node2) {
        if (this.isPermitted(commandContext.getSender(), node2) != null) {
            return Collections.emptyList();
        }
        final List<Object> list = node2.getChildren().stream().filter(node -> node.getValue() instanceof StaticArgument).collect((Collector<? super Object, ?, List<Object>>)Collectors.toList());
        if (!list.isEmpty() && !c.isEmpty()) {
            "\u6046\u5329\u4ecb\u611c\u6479".length();
            "\u55e5\u69ae\u4edb\u5df9\u5f70".length();
            final LinkedList<Object> list2 = new LinkedList<Object>(c);
            final Iterator<Node<CommandArgument<C, ?>>> iterator = list.iterator();
            if (iterator.hasNext()) {
                while (iterator.hasNext()) {
                    final Node<CommandArgument<C, ?>> node3 = iterator.next();
                    if (node3.getValue() != null) {
                        commandContext.setCurrentArgument(node3.getValue());
                        if (!node3.getValue().getParser().parse(commandContext, c).getParsedValue().isPresent()) {
                            continue;
                        }
                        if (!c.isEmpty()) {
                            return this.getSuggestions(commandContext, c, node3);
                        }
                        break;
                    }
                }
            }
            c.clear();
            c.addAll((Collection<? extends E>)list2);
            "\u5a2a\u6556\u5d32".length();
            "\u5308\u5294\u6384\u590c\u50f3".length();
            "\u5252\u6986\u5c66\u5db2\u5c1c".length();
            "\u6b54\u51d3\u67ad\u528e".length();
            "\u6655\u5fae\u63c8\u6454".length();
        }
        "\u5b34\u6fdb".length();
        "\u6bad\u6a5c\u690f\u6b11".length();
        "\u6a3b\u56ff".length();
        final LinkedList<String> list3 = new LinkedList<String>();
        if (c.size() <= 1) {
            final String stringOrEmpty = this.stringOrEmpty(c.peek());
            for (final Node<CommandArgument<C, ?>> node4 : list) {
                if (this.isPermitted(commandContext.getSender(), node4) != null) {
                    continue;
                }
                commandContext.setCurrentArgument(node4.getValue());
                for (final String s : node4.getValue().getSuggestionsProvider().apply(commandContext, stringOrEmpty)) {
                    if (!s.equals(stringOrEmpty)) {
                        if (!s.startsWith(stringOrEmpty)) {
                            continue;
                        }
                        list3.add(s);
                        "\u6b9f\u53be\u680f".length();
                        "\u6364\u6245".length();
                    }
                }
            }
        }
        for (final Node<CommandArgument<C, ?>> node5 : node2.getChildren()) {
            if (node5.getValue() != null && !(node5.getValue() instanceof StaticArgument)) {
                list3.addAll((Collection<?>)this.suggestionsForDynamicArgument(commandContext, c, node5));
                "\u6f93\u56d1".length();
                "\u5bd7\u6afd\u5195\u4fd9".length();
                "\u5146\u5178".length();
                "\u6e92\u513d\u665e\u6d44".length();
            }
        }
        return list3;
    }
    
    public List<String> suggestionsForDynamicArgument(final CommandContext<C> commandContext, final Queue<String> queue, final Node<CommandArgument<C, ?>> node) {
        if (node.getValue() == null) {
            return Collections.emptyList();
        }
        if (node.getValue() instanceof CompoundArgument) {
            final int size = ((CompoundArgument)node.getValue()).getParserTuple().getSize();
            if (queue.size() <= size) {
                int n = 0;
                while (true) {
                    final int n2 = n;
                    final int n3 = size;
                    final int n4 = 1;
                    "\u5d99\u5e18".length();
                    "\u545f\u6297\u4fed\u695c\u5392".length();
                    "\u6608\u58c9\u5cc5\u6650\u57e1".length();
                    "\u5de9\u562b\u6962\u6c79\u5212".length();
                    "\u6e7b\u6887\u556e\u5a9e\u67c4".length();
                    if (n2 >= n3 - n4 || queue.size() <= 1) {
                        break;
                    }
                    queue.remove();
                    "\u6701\u52d4\u6dfe\u6bc2\u6d88".length();
                    "\u5f44".length();
                    "\u70d5\u707c\u6ef9\u5c15\u5f17".length();
                    "\u6caa".length();
                    commandContext.store(CommandTree.PARSING_ARGUMENT_KEY, ColonialObfuscator_\u5f7c\u70b0\u6d1b\u705e\u55e0\u59bb\u561a\u647c\u6b42\u6fde\u5176\u532a\u682d\u4fde\u6067\u70d8\u58da\u5993\u6348\u6127\u5528\u6fd2\u51f0\u6b52\u516a\u5b0d\u5e8c\u5067\u66b6\u4f83\u5ef1\u4ec4\u7142\u5389\u5c5d\u5665\u51a9\u5f74\u59ed\u669d\u532b(n, 2));
                    n -= 8957;
                    n += 8958;
                }
            }
        }
        else if (node.getValue().getParser() instanceof FlagArgument.FlagArgumentParser) {
            final Optional<String> currentFlag = ((FlagArgument.FlagArgumentParser)node.getValue().getParser()).parseCurrentFlag(commandContext, queue);
            currentFlag.ifPresent(s -> commandContext.store(FlagArgument.FLAG_META_KEY, s));
            if (!currentFlag.isPresent()) {
                commandContext.remove(FlagArgument.FLAG_META_KEY);
            }
        }
        else if (GenericTypeReflector.erase(node.getValue().getValueType().getType()).isArray()) {
            while (queue.size() > 1) {
                queue.remove();
                "\u5b75\u5ad9\u6e44\u62cc".length();
                "\u5fce\u502f\u6f92\u513f".length();
                "\u6beb\u6caf\u5781".length();
                "\u5dbf".length();
                "\u540d\u5d63\u5274\u7014".length();
            }
        }
        else if (queue.size() <= node.getValue().getParser().getRequestedArgumentCount()) {
            int i = 0;
            while (true) {
                final int n5 = i;
                final int requestedArgumentCount = node.getValue().getParser().getRequestedArgumentCount();
                final int n6 = 1;
                "\u67e4\u5707\u7097\u67b0\u65de".length();
                "\u6bb5".length();
                "\u610e".length();
                "\u54e9\u6343\u5b59\u6e7e\u58f9".length();
                if (n5 >= requestedArgumentCount - n6 || queue.size() <= 1) {
                    break;
                }
                final String \u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38 = \u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(-1316183361, -786131378, "\u12fb\u1286\u12a8\u12d2\u1293", 603079339, 1261593799);
                final Object[] args = new Object[2];
                "\u6c69\u5614".length();
                "\u6647\u5904\u5bea\u6249".length();
                "\u69d9\u5fc2\u53d3\u6e8b".length();
                args[0] = node.getValue().getName();
                "\u6752\u66ff\u5b1a\u65bc".length();
                "\u6faa\u6ed2\u5610".length();
                "\u636f\u6621\u5fa4\u4ec9".length();
                "\u5764\u5f3d\u5769".length();
                args[1] = i;
                commandContext.store(String.format(\u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38, args), queue.remove());
                i -= 15811;
                i += 15812;
            }
        }
        if (queue.isEmpty()) {
            return Collections.emptyList();
        }
        if (node.isLeaf()) {
            if (queue.size() == 1) {
                return this.directSuggestions(commandContext, node, queue.peek());
            }
            if (node.getValue() instanceof CompoundArgument) {
                return this.directSuggestions(commandContext, node, ((LinkedList<String>)queue).getLast());
            }
        }
        else if (queue.size() == 1 && queue.peek().isEmpty()) {
            return this.directSuggestions(commandContext, node, queue.peek());
        }
        "\u68bc".length();
        "\u5c66\u5fd9\u5464".length();
        "\u5941\u5040\u631a\u5675\u5620".length();
        final LinkedList<String> list = new LinkedList<String>(queue);
        final ArgumentParseResult<Boolean> preprocess = node.getValue().preprocess(commandContext, queue);
        final boolean b = !preprocess.getFailure().isPresent() && preprocess.getParsedValue().orElse(false);
        if (b) {
            commandContext.setCurrentArgument(node.getValue());
            final Optional<?> parsedValue = node.getValue().getParser().parse(commandContext, queue).getParsedValue();
            final boolean present = parsedValue.isPresent();
            if (node.isLeaf()) {
                if (queue.isEmpty()) {
                    queue.addAll((Collection<?>)list);
                    "\u6c55\u693d\u59fd\u5b48".length();
                    return this.directSuggestions(commandContext, node, String.join(\u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(1453132046, 348522658, "\ubf66", 1636672780, -1983571035), queue));
                }
                return Collections.emptyList();
            }
            else {
                if (present && !queue.isEmpty()) {
                    commandContext.store(node.getValue().getName(), (Object)parsedValue.get());
                    return this.getSuggestions(commandContext, queue, node);
                }
                if (!present && list.size() > 1) {
                    queue.clear();
                    queue.addAll((Collection<?>)list);
                    "\u7046\u60ce".length();
                    "\u62d2".length();
                    return Collections.emptyList();
                }
            }
        }
        queue.clear();
        queue.addAll((Collection<?>)list);
        "\u60a9\u5992".length();
        "\u694f\u5136".length();
        if (!b && queue.size() > 1) {
            return Collections.emptyList();
        }
        return this.directSuggestions(commandContext, node, queue.peek());
    }
    
    public String stringOrEmpty(final String s) {
        if (s == null) {
            return \u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(-33008639, 1679623793, "", -1761030484, 581905475);
        }
        return s;
    }
    
    public List<String> directSuggestions(final CommandContext<C> commandContext, final Node<CommandArgument<C, ?>> node, final String s) {
        final CommandArgument<C, ?> currentArgument = Objects.requireNonNull(node.getValue());
        commandContext.setCurrentArgument(currentArgument);
        List<String> c = currentArgument.getSuggestionsProvider().apply(commandContext, s);
        if (currentArgument instanceof FlagArgument && !node.getChildren().isEmpty() && !s.startsWith(\u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(-1645978115, -2024404948, "\u31c8", 431784662, 1180690081)) && !commandContext.getOptional(FlagArgument.FLAG_META_KEY).isPresent()) {
            "\u70c5\u5bcd\u5608\u6c1a".length();
            "\u4ecc\u6dbb\u5bae\u5af5\u50f2".length();
            "\u557b".length();
            c = new ArrayList<String>(c);
            final Iterator<Node<CommandArgument<C, ?>>> iterator = node.getChildren().iterator();
            while (iterator.hasNext()) {
                final CommandArgument<C, ?> currentArgument2 = Objects.requireNonNull(iterator.next().getValue());
                commandContext.setCurrentArgument(currentArgument2);
                c.addAll(currentArgument2.getSuggestionsProvider().apply(commandContext, s));
                "\u5be6\u50ee\u509c".length();
                "\u5727\u578f\u4e5b\u70ed".length();
                "\u6c2a\u522e\u6d42".length();
            }
        }
        return c;
    }
    
    public void insertCommand(final Command<C> owningCommand) {
        final Object commandLock = this.commandLock;
        "\u68f0\u5856\u6531".length();
        final Object o = commandLock;
        // monitorenter(commandLock)
        try {
            Object internalTree = this.internalTree;
            final FlagArgument<C> flagArgument = owningCommand.flagArgument();
            final List<CommandArgument<C, ?>> nonFlagArguments = owningCommand.nonFlagArguments();
            final int flagStartIndex = this.flagStartIndex(nonFlagArguments, flagArgument);
            for (int i = 0; i < nonFlagArguments.size(); i -= 9732, i += 9733) {
                final CommandArgument<C, ?> commandArgument = nonFlagArguments.get(i);
                Node<Object> node = ((Node<Object>)internalTree).getChild(commandArgument);
                if (node == null) {
                    node = ((Node<Object>)internalTree).addChild(commandArgument);
                }
                else if (commandArgument instanceof StaticArgument && node.getValue() != null) {
                    final Iterator iterator = ((StaticArgument)commandArgument).getAliases().iterator();
                    while (iterator.hasNext()) {
                        node.getValue().registerAlias(iterator.next());
                    }
                }
                if (Node.access$200((Node<Object>)internalTree).size() > 0) {
                    Node.access$200((Node<Object>)internalTree).sort(Comparator.comparing((Function<? super E, ? extends Comparable>)Node::getValue));
                }
                node.setParent((Node<Object>)internalTree);
                internalTree = node;
                if (i >= flagStartIndex) {
                    final Node<Object> access$400 = ((Node<Object>)internalTree).addChild(flagArgument);
                    access$400.setParent((Node<Object>)internalTree);
                    internalTree = access$400;
                }
            }
            if (((Node<Object>)internalTree).getValue() != null) {
                if (((Node<CommandArgument>)internalTree).getValue().getOwningCommand() != null) {
                    "\u59b8\u58fa\u6108".length();
                    final String \u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38 = \u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(1629700684, 1094235859, "\u7ad0\u7acc\u7ac5\u7adb\u7adc\u7ad0\u7add\u7ac4\u7af5\u7a9c\u7ac4\u7ada\u7add\u7acc\u7ac5\u7ade\u7acc\u7a94\u7af5\u18f4\u200e\u2845\u24d8\u26bb\u1fd8\u2850\u2d82\u1c48\u2645\u1e2d\u168d\u220a\u2e48\u2b38\u1593\u2b6e\u0a8f\u2c61\u2a92\u2095\u1652\u29bc\u11ed\u1639\u1cdd\u3473\u1223\u2c06\u0bc0\u1534\u345e\u2791\u3550\u2eb3\u241d\u16b6\u1d61\u14e9\u2174\u1ce9\u2da1\u274f\u272a\u348b\u13c9\u220f\u0ae7\u2dae\u2671\u14bf\u242d\u1151\u2527\u1ce3\u1dbb\u20e2\u2268\u0bfd\u3523", 1817992742, -441921426);
                    final Object[] args = new Object[2];
                    "\u6af0\u63cd\u5a2b\u7065".length();
                    "\u602d\u642e".length();
                    "\u5d1e\u6383".length();
                    "\u5092\u513e\u66ba\u59c8\u59a7".length();
                    args[0] = ((Node)internalTree).toString();
                    "\u534f\u682e\u4f2c".length();
                    "\u6bbf\u4e50\u5631\u5ce2".length();
                    args[1] = ((Node<CommandArgument<C, T>>)internalTree).getValue().getOwningCommand().toString();
                    final IllegalStateException ex = new IllegalStateException(String.format(\u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38, args));
                    "\u6316\u51b5\u511e\u6aac\u6a52".length();
                    "\u6527\u4eac".length();
                    throw ex;
                }
                ((Node<CommandArgument<C, T>>)internalTree).getValue().setOwningCommand(owningCommand);
            }
            this.verifyAndRegister();
        }
        // monitorexit(o)
        finally {
            // monitorexit(o)
            "\u5fd9\u5edf".length();
            "\u6b4c\u6cbd\u5280\u5765".length();
            "\u65d2\u688a".length();
            "\u4f90\u69d2\u6f42\u6199\u60cb".length();
        }
    }
    
    public int flagStartIndex(final List<CommandArgument<C, ?>> list, final FlagArgument<C> flagArgument) {
        if (flagArgument == null) {
            return Integer.MAX_VALUE;
        }
        if (this.commandManager.getSetting(CommandManager.ManagerSettings.LIBERAL_FLAG_PARSING)) {
            final int size = list.size();
            final int n = 1;
            "\u5d1c\u63db\u7029".length();
            "\u6c08".length();
            "\u5912\u51ad\u6d73".length();
            "\u5af0\u5b35".length();
            for (int i = size - n; i >= 0; i += 7102, i -= 7103) {
                if (list.get(i) instanceof StaticArgument) {
                    return i;
                }
            }
        }
        final int size2 = list.size();
        final int n2 = 1;
        "\u6be3\u5c6f\u5c6e".length();
        "\u6525\u521f\u6f4d\u5cd3\u6837".length();
        "\u545f\u5f39".length();
        return size2 - n2;
    }
    
    public CommandPermission isPermitted(final C c, final Node<CommandArgument<C, ?>> node) {
        final CommandPermission commandPermission = Node.access$500((Node<Object>)node).get(\u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(118108369, -538065045, "\u1a46\u1a7c\u1a69\u1a72\u1a76\u1a68\u1a61\u1a69\u1a4d\u1a62", -220713783, -2106605306));
        if (commandPermission != null) {
            return this.commandManager.hasPermission(c, commandPermission) ? null : commandPermission;
        }
        if (node.isLeaf()) {
            return this.commandManager.hasPermission(c, Objects.requireNonNull(Objects.requireNonNull(Node.access$100((Node<Object>)node), \u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(1255052206, 814804595, "\ud21d\ud237\ud23e\ud23f\ud274\ud224\ud23a\ud239\ud202\ud238", 1170257459, -2000938530)).getOwningCommand(), \u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(-655132207, -293872900, "\u8367\u8352\u834b\u834e\u8347\u8348\u8304\u834b\u8363\u834d\u834a\u8354\u8362\u8379", -563455212, -225346702)).getCommandPermission()) ? null : Objects.requireNonNull(((CommandArgument)Node.access$100((Node<Object>)node)).getOwningCommand(), \u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(790774214, -1352880724, "\u1afe\u1acb\u1ad6\u1ad3\u1ad6\u1ad9\u1a89\u1ac6\u1aea\u1ac4\u1ac7\u1ad9\u1ad3\u1ac8", -422783062, -1307565806)).getCommandPermission();
        }
        "\u5ec4\u568b\u5f2f".length();
        "\u5e29\u5e09\u5ebd\u621f".length();
        final LinkedList<CommandPermission> list = new LinkedList<CommandPermission>();
        final Iterator<Node<Object>> iterator = node.getChildren().iterator();
        while (iterator.hasNext()) {
            final CommandPermission permitted = this.isPermitted(c, (Node<CommandArgument<C, ?>>)iterator.next());
            if (permitted == null) {
                return null;
            }
            list.add(permitted);
            "\u6835\u6f9e\u6e51\u5636\u705e".length();
            "\u51d8\u6465\u5f9d".length();
        }
        return OrPermission.of(list);
    }
    
    public void verifyAndRegister() {
        final Object o;
        Node.access$200((Node<Object>)this.internalTree).stream().map(Node::getValue).forEach(commandArgument -> {
            if (!(commandArgument instanceof StaticArgument)) {
                // new(java.lang.IllegalStateException.class)
                "\u5ead\u6b5f\u6f0a".length();
                "\u5b3d\u6913\u5d4c\u6989\u630b".length();
                new IllegalStateException(\u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(2102160383, 2007297796, "\u8149\u8159\u8144\u8114\u8158\u8159\u8143\u815e\u8175\u8113\u8155\u8149\u814c\u8143\u814c\u8155\u8145\u811b\u8176\ue36d\udb89\ud3d6\udf52\udd26\ue41f\ud3cf\ud636\ue7ac\uddb0\ue42f\uec9e\ud80b\ud451\ud139\uefd0\ud146\uf0c1\ud66b\ud0de\udac8\uec1d\ud3e4\uebe6\uec6c\ue68e\uce71\ue823", 193633507, 338925894));
                "\u7037".length();
                "\u7087\u633f".length();
                throw o;
            }
            else {
                return;
            }
        });
        this.checkAmbiguity(this.internalTree);
        final Object o2;
        this.getLeaves(this.internalTree).forEach(commandArgument2 -> {
            if (commandArgument2.getOwningCommand() == null) {
                // new(cloud.commandframework.exceptions.NoCommandInLeafException.class)
                "\u6959".length();
                "\u52d4\u65be\u52da\u55f4\u6911".length();
                new NoCommandInLeafException(commandArgument2);
                "\u6595\u58dd\u645b\u57b6\u605d".length();
                "\u581d\u6b61\u69fb".length();
                throw o2;
            }
            else {
                this.commandManager.commandRegistrationHandler().registerCommand(commandArgument2.getOwningCommand());
                "\u520c\u6e43\u5833\u67ac".length();
                "\u642f".length();
                "\u5cde".length();
                return;
            }
        });
        final CommandPermission commandPermission;
        final List<?> list;
        final Iterator<Node<CommandArgument<C, ?>>> iterator;
        Node<CommandArgument<C, ?>> node2;
        CommandPermission commandPermission2;
        CommandPermission[] a;
        CommandPermission commandPermission3;
        final Command command;
        CommandPermission[] a2;
        this.getLeavesRaw(this.internalTree).forEach(node -> {
            node.getValue().getOwningCommand().getCommandPermission();
            Node.access$500((Node<Object>)node).put(\u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(1406190718, 1574316394, "\u9c4a\u9c72\u9c65\u9c78\u9c7a\u9c66\u9c6d\u9c7b\u9c41\u9c6c", -1516992824, 594278309), commandPermission);
            "\u638e".length();
            "\u67f0\u6292\u608a\u6615\u63b4".length();
            this.getChain(node);
            Collections.reverse(list);
            list.subList(1, list.size()).iterator();
            while (iterator.hasNext()) {
                node2 = iterator.next();
                commandPermission2 = Node.access$500((Node<Object>)node2).get(\u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(866450366, -1951404434, "\ueb04\ueb22\ueb37\ueb28\ueb2c\ueb36\ueb3f\ueb2b\ueb0f\ueb2c", 789256143, -1793791704));
                if (commandPermission2 != null) {
                    a = new CommandPermission[2];
                    "\u522b\u507e".length();
                    "\u68c7\u6b3e\u512a\u6d76".length();
                    a[0] = commandPermission;
                    "\u618f\u58d7\u58e3\u6de5".length();
                    "\u6ac6\u52c2\u69e7".length();
                    "\u6506\u6a3b\u5252\u5818".length();
                    a[1] = commandPermission2;
                    commandPermission3 = OrPermission.of(Arrays.asList(a));
                }
                else {
                    commandPermission3 = commandPermission;
                }
                if (node2.getValue() != null && node2.getValue().getOwningCommand() != null) {
                    node2.getValue().getOwningCommand();
                    if (this.getCommandManager().getSetting(CommandManager.ManagerSettings.ENFORCE_INTERMEDIARY_PERMISSIONS)) {
                        commandPermission3 = command.getCommandPermission();
                    }
                    else {
                        a2 = new CommandPermission[2];
                        "\u62dd\u61a2\u4ebd".length();
                        "\u623a\u6374\u62f2".length();
                        a2[0] = commandPermission3;
                        "\u5d9b\u5f83\u6994".length();
                        "\u58e1".length();
                        a2[1] = command.getCommandPermission();
                        commandPermission3 = OrPermission.of(Arrays.asList(a2));
                    }
                }
                Node.access$500((Node<Object>)node2).put(\u6966\u647e\u5161\u6440\u4ffa\u5533\u5097\u4fb5\u6156\u4f5c\u5c66\u6177\u6dab\u5a1d\u5bbd\u5876\u5ec2\u6c9d\u4f2e\u54dd\u5081\u710b\u6d46\u5c12\u5f1e\u552a\u5fa3\u6d5c\u6422\u610a\u68db\u5353\u5b13\u5cfa\u5550\u6fad\u6b86\u4e73\u671f\u5081\u6f38(1722610895, -2034290246, "\uc68d\uc6b5\uc6a2\uc6bf\uc6b5\uc6a9\uc6a2\uc6b4\uc696\uc6bb", 1459970884, -868589425), commandPermission3);
                "\u5c23\u6dd0\u6e95\u5afd\u66ca".length();
            }
        });
    }
    
    public void checkAmbiguity(final Node<CommandArgument<C, ?>> node6) throws AmbiguousNodeException {
        if (node6.isLeaf()) {
            return;
        }
        final List list = (List)Node.access$200((Node<Object>)node6).stream().filter(node -> node.getValue() != null && !(node.getValue() instanceof StaticArgument)).collect(Collectors.toList());
        if (list.size() > 1) {
            final Node<CommandArgument> node7 = list.get(0);
            "\u5929\u6feb\u5954\u4f96".length();
            "\u5b83\u5925\u6a6d\u6e18\u5527".length();
            "\u5171\u6570\u599a\u6de6".length();
            final AmbiguousNodeException ex = new AmbiguousNodeException(node6.getValue(), node7.getValue(), (List<CommandArgument<?, ?>>)node6.getChildren().stream().filter(node2 -> node2.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
            "\u5504\u5e7d\u689a".length();
            "\u6843\u5e61".length();
            throw ex;
        }
        final List list2 = (List)Node.access$200((Node<Object>)node6).stream().filter(node3 -> node3.getValue() instanceof StaticArgument).map(node4 -> node4).collect(Collectors.toList());
        "\u6b1b\u64f5\u6e5a\u50ab".length();
        "\u6ea0\u69b8\u5304\u5937\u69e5".length();
        "\u6e40".length();
        final HashSet<String> set = new HashSet<String>();
        for (final Node<CommandArgument> node8 : list2) {
            final Iterator iterator2 = node8.getValue().getAliases().iterator();
            while (iterator2.hasNext()) {
                if (!set.add(iterator2.next())) {
                    "\u6a06\u5675\u5cc5\u5c5f\u614c".length();
                    final AmbiguousNodeException ex2 = new AmbiguousNodeException(node6.getValue(), node8.getValue(), (List<CommandArgument<?, ?>>)node6.getChildren().stream().filter(node5 -> node5.getValue() != null).map((Function<? super Object, ?>)Node::getValue).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()));
                    "\u5d3d".length();
                    "\u5486\u5599\u5ce8\u6bc4\u50e9".length();
                    "\u6d81".length();
                    "\u677f\u575e\u682e\u5204\u53fc".length();
                    throw ex2;
                }
            }
        }
        Node.access$200((Node<Object>)node6).forEach(this::checkAmbiguity);
    }
    
    public List<Node<CommandArgument<C, ?>>> getLeavesRaw(final Node<CommandArgument<C, ?>> node) {
        "\u6c15".length();
        "\u556e".length();
        "\u557f\u6e13\u6f2a".length();
        final LinkedList<Object> list = new LinkedList<Object>();
        if (node.isLeaf()) {
            if (node.getValue() != null) {
                list.add(node);
                "\u57b1".length();
                "\u61bd\u6d9e\u6cb4\u6b23\u67dd".length();
                "\u6d69\u6138\u5a4c".length();
                "\u55a3".length();
            }
        }
        else {
            Node.access$200((Node<Object>)node).forEach(node2 -> {
                list.addAll(this.getLeavesRaw(node2));
                "\u5e4b\u66a9\u67ba\u5615".length();
                "\u5b7e\u50a9\u67b6\u5c71\u5520".length();
                "\u62d7\u6a4c\u6924".length();
                "\u6c5e".length();
                return;
            });
        }
        return (List<Node<CommandArgument<C, ?>>>)list;
    }
    
    public List<CommandArgument<C, ?>> getLeaves(final Node<CommandArgument<C, ?>> node) {
        "\u6026".length();
        final LinkedList<Object> list = new LinkedList<Object>();
        if (node.isLeaf()) {
            if (node.getValue() != null) {
                list.add(node.getValue());
                "\u4e93\u706f".length();
                "\u584d".length();
                "\u5739\u6784".length();
            }
        }
        else {
            Node.access$200((Node<Object>)node).forEach(node2 -> {
                list.addAll(this.getLeaves(node2));
                "\u68c9\u5ba0\u57f2".length();
                "\u59ad\u526b\u59f8".length();
                return;
            });
        }
        return (List<CommandArgument<C, ?>>)list;
    }
    
    public List<Node<CommandArgument<C, ?>>> getChain(final Node<CommandArgument<C, ?>> node) {
        "\u638f".length();
        "\u58e5\u6487\u65e5".length();
        "\u50c6\u70fc".length();
        final LinkedList<Node<CommandArgument<C, ?>>> list = new LinkedList<Node<CommandArgument<C, ?>>>();
        for (Node<CommandArgument<C, ?>> parent = node; parent != null; parent = parent.getParent()) {
            list.add(parent);
            "\u6ba9".length();
            "\u637f\u59d3\u6dbf".length();
            "\u6bda\u64fa\u6de3\u53c5\u5c9e".length();
        }
        Collections.reverse(list);
        return list;
    }
    
    public Command<C> cast(final Command<C> command) {
        return command;
    }
    
    public Collection<Node<CommandArgument<C, ?>>> getRootNodes() {
        return this.internalTree.getChildren();
    }
    
    public Node<CommandArgument<C, ?>> getNamedNode(final String anotherString) {
        for (final Node<CommandArgument<C, ?>> node : this.getRootNodes()) {
            if (node.getValue() != null && node.getValue() instanceof StaticArgument) {
                final Iterator iterator2 = ((StaticArgument)node.getValue()).getAliases().iterator();
                while (iterator2.hasNext()) {
                    if (iterator2.next().equalsIgnoreCase(anotherString)) {
                        return node;
                    }
                }
            }
        }
        return null;
    }
    
    public void deleteRecursively(final Node<CommandArgument<C, ?>> node, final boolean b, final Consumer<Command<C>> consumer) {
        "\u5b4f\u643f\u5343\u66a4\u5cba".length();
        "\u4ed5".length();
        final Iterator<Node<CommandArgument<C, ?>>> iterator = new ArrayList<Node<CommandArgument<C, ?>>>(Node.access$200((Node<Object>)node)).iterator();
        while (iterator.hasNext()) {
            this.deleteRecursively(iterator.next(), false, consumer);
        }
        final CommandArgument<C, T> commandArgument = node.getValue();
        final Command<C> command = (commandArgument == null) ? null : commandArgument.getOwningCommand();
        if (command != null) {
            consumer.accept(command);
        }
        this.removeNode(node, b);
        "\u58b1".length();
        "\u657f\u64f5\u5f3c\u5c8a".length();
        "\u63ed".length();
        "\u69db\u609c\u5901\u6ddd".length();
    }
    
    public boolean removeNode(final Node<CommandArgument<C, ?>> node, final boolean b) {
        if (b) {
            return ((Node<Object>)this.internalTree).removeChild((Node<Object>)node);
        }
        return node.getParent().removeChild((Node<Object>)node);
    }
    
    public CommandManager<C> getCommandManager() {
        return this.commandManager;
    }
    
    public static int ColonialObfuscator_\u5f7c\u70b0\u6d1b\u705e\u55e0\u59bb\u561a\u647c\u6b42\u6fde\u5176\u532a\u682d\u4fde\u6067\u70d8\u58da\u5993\u6348\u6127\u5528\u6fd2\u51f0\u6b52\u516a\u5b0d\u5e8c\u5067\u66b6\u4f83\u5ef1\u4ec4\u7142\u5389\u5c5d\u5665\u51a9\u5f74\u59ed\u669d\u532b(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
