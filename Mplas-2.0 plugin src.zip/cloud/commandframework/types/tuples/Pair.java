package cloud.commandframework.types.tuples;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public class Pair<U, V> implements Tuple
{
    public Pair(final U first, final V second) {
        this.first = first;
        this.second = second;
    }
    
    public final U getFirst() {
        return this.first;
    }
    
    public final V getSecond() {
        return this.second;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final Pair pair = (Pair)o;
        return Objects.equals(this.getFirst(), pair.getFirst()) && Objects.equals(this.getSecond(), pair.getSecond());
    }
    
    @Override
    public final int hashCode() {
        final Object[] values = new Object[2];
        "\u5366\u66b9".length();
        "\u50ae".length();
        values[0] = this.getFirst();
        "\u6897\u6c98\u63db\u5aa0\u6046".length();
        "\u6302\u5a84\u54e9\u4f43".length();
        "\u5ba8\u6c7b".length();
        "\u62f4\u4fc8\u62b9\u6f4d\u5a1d".length();
        values[1] = this.getSecond();
        return Objects.hash(values);
    }
    
    @Override
    public final String toString() {
        final String \u6af5\u538a\u65dc\u5ca1\u70b8\u5f01\u5e4b\u67a6\u681a\u5f42\u4fe7\u65e7\u6b3c\u59be\u664e\u6c22\u553b\u5a16\u578f\u6216\u680d\u52a9\u5875\u5d34\u6508\u620d\u4f48\u50d8\u692c\u4e36\u5f3a\u5330\u5e66\u6257\u6a79\u5e83\u5a65\u54db\u5eda\u58a2\u5a0a = \u6af5\u538a\u65dc\u5ca1\u70b8\u5f01\u5e4b\u67a6\u681a\u5f42\u4fe7\u65e7\u6b3c\u59be\u664e\u6c22\u553b\u5a16\u578f\u6216\u680d\u52a9\u5875\u5d34\u6508\u620d\u4f48\u50d8\u692c\u4e36\u5f3a\u5330\u5e66\u6257\u6a79\u5e83\u5a65\u54db\u5eda\u58a2\u5a0a(-1628529918, 1380439373, "\uaa9c\uaabc\uaae6\uaabb\uaab5\uaab6\uaaef\uaab9", -252644570, 1758861214);
        final Object[] args = new Object[2];
        "\u63fc\u693f".length();
        "\u5994\u5536\u5e00\u550e\u5c40".length();
        "\u63dd".length();
        args[0] = this.first;
        "\u57af".length();
        "\u6b8c".length();
        args[1] = this.second;
        return String.format(\u6af5\u538a\u65dc\u5ca1\u70b8\u5f01\u5e4b\u67a6\u681a\u5f42\u4fe7\u65e7\u6b3c\u59be\u664e\u6c22\u553b\u5a16\u578f\u6216\u680d\u52a9\u5875\u5d34\u6508\u620d\u4f48\u50d8\u692c\u4e36\u5f3a\u5330\u5e66\u6257\u6a79\u5e83\u5a65\u54db\u5eda\u58a2\u5a0a, args);
    }
    
    @Override
    public final int getSize() {
        return 2;
    }
    
    @Override
    public final Object[] toArray() {
        return new Object[] { this.first, this.second };
    }
    
    public static int ColonialObfuscator_\u6873\u635c\u6e6a\u6ed3\u51c5\u53e0\u6b4d\u4e5d\u50cc\u5d94\u6b21\u6623\u68f7\u5abe\u69f9\u5ff8\u62c0\u6253\u6b8b\u6e73\u5de8\u60c6\u5023\u5150\u69de\u70a4\u5b14\u6b7e\u5185\u5ec5\u5f22\u6a1b\u5c0f\u681b\u5500\u542b\u61d6\u507c\u5445\u67c2\u6aee(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
