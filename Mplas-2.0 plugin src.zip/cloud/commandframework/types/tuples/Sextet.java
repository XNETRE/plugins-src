package cloud.commandframework.types.tuples;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public class Sextet<U, V, W, X, Y, Z> implements Tuple
{
    public Sextet(final U first, final V second, final W third, final X fourth, final Y fifth, final Z sixth) {
        this.first = first;
        this.second = second;
        this.third = third;
        this.fourth = fourth;
        this.fifth = fifth;
        this.sixth = sixth;
    }
    
    public final U getFirst() {
        return this.first;
    }
    
    public final V getSecond() {
        return this.second;
    }
    
    public final W getThird() {
        return this.third;
    }
    
    public final X getFourth() {
        return this.fourth;
    }
    
    public final Y getFifth() {
        return this.fifth;
    }
    
    public final Z getSixth() {
        return this.sixth;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final Sextet sextet = (Sextet)o;
        return Objects.equals(this.getFirst(), sextet.getFirst()) && Objects.equals(this.getSecond(), sextet.getSecond()) && Objects.equals(this.getThird(), sextet.getThird()) && Objects.equals(this.getFourth(), sextet.getFourth()) && Objects.equals(this.getFifth(), sextet.getFifth()) && Objects.equals(this.getSixth(), sextet.getSixth());
    }
    
    @Override
    public final int hashCode() {
        final Object[] values = new Object[6];
        "\u702d\u708a\u6055\u671d\u6620".length();
        values[0] = this.getFirst();
        "\u6401\u6de8\u4f66\u54d4".length();
        "\u677d\u5175\u6b5b\u682a\u504b".length();
        "\u6961\u52ce\u56cf\u4f5b\u58c4".length();
        values[1] = this.getSecond();
        "\u649c\u594c\u5457\u56f5\u5a28".length();
        values[2] = this.getThird();
        "\u57b0\u5ad1".length();
        "\u6990\u4e69\u4ff5\u6ea0".length();
        "\u61b1\u6aa6\u609a".length();
        values[3] = this.getFourth();
        "\u5579\u6627\u549b\u6721\u5d57".length();
        "\u6443\u5dc1".length();
        values[4] = this.getFifth();
        "\u6519\u6566".length();
        "\u684c\u6527\u6d70\u669d\u584d".length();
        values[5] = this.getSixth();
        return Objects.hash(values);
    }
    
    @Override
    public final String toString() {
        final String \u690c\u6749\u69e8\u55e6\u62ae\u6f1b\u5b56\u62ff\u5213\u5770\u514f\u56bd\u5e15\u6ce3\u53cc\u50aa\u50a0\u60ce\u6a49\u5f88\u6fac\u5b0c\u5885\u661b\u53e9\u692c\u636c\u57a7\u7000\u63dd\u6e1a\u6891\u6e53\u588c\u57b2\u5881\u59e2\u6599\u64a6\u59c4\u4f40 = \u690c\u6749\u69e8\u55e6\u62ae\u6f1b\u5b56\u62ff\u5213\u5770\u514f\u56bd\u5e15\u6ce3\u53cc\u50aa\u50a0\u60ce\u6a49\u5f88\u6fac\u5b0c\u5885\u661b\u53e9\u692c\u636c\u57a7\u7000\u63dd\u6e1a\u6891\u6e53\u588c\u57b2\u5881\u59e2\u6599\u64a6\u59c4\u4f40(2007681789, -2018364197, "\u3467\u3447\u3411\u344c\u344e\u344d\u3410\u3443\u346b\u3442\u3413\u345e\u344b\u345f\u3408\u3443\u3453\u344a\u3432\u5f5a\u6f0b\u591f\u7b3e\u6ba1", 1990450052, -473689682);
        final Object[] args = new Object[6];
        "\u6535\u5ccc\u5cbc\u5507\u6486".length();
        "\u6abd".length();
        args[0] = this.first;
        "\u60d6\u5a46\u5841".length();
        "\u70cc\u53f3\u6f7d\u5b5c".length();
        "\u6306\u6a46\u4efa\u4eae".length();
        "\u4f49\u709a\u6bed\u58e6".length();
        args[1] = this.second;
        "\u5b86\u59f4\u5139\u655a\u5bbc".length();
        "\u6e6e".length();
        "\u6729\u60fb\u6c70\u6d77".length();
        args[2] = this.third;
        "\u5492\u69f3\u6536".length();
        "\u695f".length();
        args[3] = this.fourth;
        "\u6c2e\u5dcb".length();
        "\u5c60\u6713".length();
        "\u5ba6\u6ec4".length();
        args[4] = this.fifth;
        "\u6848\u6368\u5375\u69ba".length();
        "\u5071\u538d\u5eb1\u5133\u5d30".length();
        "\u6aa2\u6c8e\u7082".length();
        "\u6b99\u4ef8\u61d9".length();
        args[5] = this.sixth;
        return String.format(\u690c\u6749\u69e8\u55e6\u62ae\u6f1b\u5b56\u62ff\u5213\u5770\u514f\u56bd\u5e15\u6ce3\u53cc\u50aa\u50a0\u60ce\u6a49\u5f88\u6fac\u5b0c\u5885\u661b\u53e9\u692c\u636c\u57a7\u7000\u63dd\u6e1a\u6891\u6e53\u588c\u57b2\u5881\u59e2\u6599\u64a6\u59c4\u4f40, args);
    }
    
    @Override
    public final int getSize() {
        return 6;
    }
    
    @Override
    public final Object[] toArray() {
        return new Object[] { this.first, this.second, this.third, this.fourth, this.fifth, this.sixth };
    }
    
    public static int ColonialObfuscator_\u5689\u5bbc\u6c20\u7018\u56b8\u68c5\u67f2\u4eee\u64f6\u6e40\u6ee5\u5c76\u6ff1\u5c6c\u52f8\u654c\u551b\u4e9c\u6b69\u6fdc\u5b78\u5a70\u5f86\u5e6f\u5c69\u6379\u5079\u6798\u574c\u7013\u617c\u6027\u60d8\u6593\u6c16\u594d\u64b0\u5c5d\u537d\u6563\u6a26(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
