package cloud.commandframework.types.tuples;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public class Quartet<U, V, W, X> implements Tuple
{
    public Quartet(final U first, final V second, final W third, final X fourth) {
        this.first = first;
        this.second = second;
        this.third = third;
        this.fourth = fourth;
    }
    
    public final U getFirst() {
        return this.first;
    }
    
    public final V getSecond() {
        return this.second;
    }
    
    public final W getThird() {
        return this.third;
    }
    
    public final X getFourth() {
        return this.fourth;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final Quartet quartet = (Quartet)o;
        return Objects.equals(this.getFirst(), quartet.getFirst()) && Objects.equals(this.getSecond(), quartet.getSecond()) && Objects.equals(this.getThird(), quartet.getThird()) && Objects.equals(this.getFourth(), quartet.getFourth());
    }
    
    @Override
    public final int hashCode() {
        final Object[] values = new Object[4];
        "\u5f55\u6f98".length();
        values[0] = this.getFirst();
        "\u6a33\u54ad\u4f04".length();
        "\u5755\u5696\u536b".length();
        "\u7054\u60c0".length();
        "\u5ccd\u6081\u51e7\u56b2".length();
        values[1] = this.getSecond();
        "\u5d50\u5713\u6311\u6bc6\u6f67".length();
        "\u522a\u5b9c\u6f2a".length();
        "\u6abe\u59ae\u64c3\u695a\u7081".length();
        "\u65bc".length();
        "\u4f13".length();
        values[2] = this.getThird();
        "\u6c0a".length();
        "\u662c\u4ed2\u6377".length();
        "\u5f6c\u5e49".length();
        "\u5869\u6f5e\u5622".length();
        "\u515d\u541a\u6674".length();
        values[3] = this.getFourth();
        return Objects.hash(values);
    }
    
    @Override
    public final String toString() {
        final String \u669a\u5d92\u6990\u57e8\u5fe8\u710c\u5c5e\u6d35\u5b5f\u51e8\u51c8\u57c1\u51cb\u599d\u6546\u51e0\u62fb\u5d12\u58b6\u52e4\u6ca3\u5db5\u4e79\u5c33\u5b94\u6ad4\u6d0c\u70b0\u6967\u6d13\u66d1\u556c\u5242\u6640\u5525\u60e8\u6b88\u603e\u678e\u6950\u6df7 = \u669a\u5d92\u6990\u57e8\u5fe8\u710c\u5c5e\u6d35\u5b5f\u51e8\u51c8\u57c1\u51cb\u599d\u6546\u51e0\u62fb\u5d12\u58b6\u52e4\u6ca3\u5db5\u4e79\u5c33\u5b94\u6ad4\u6d0c\u70b0\u6967\u6d13\u66d1\u556c\u5242\u6640\u5525\u60e8\u6b88\u603e\u678e\u6950\u6df7(2138157467, -89990161, "\ua246\ua264\ua230\ua263\ua26f\ua26e\ua231\ua264\ua24a\ua261\ua232\ua261\ua26a\ua27c\ua229\ua261", -1838552347, 1230119612);
        final Object[] args = new Object[4];
        "\u533d\u5bdc\u55c0\u4eb1\u5980".length();
        "\u57df".length();
        args[0] = this.first;
        "\u612d".length();
        "\u5255\u6ac6\u4e2a".length();
        args[1] = this.second;
        "\u6aa2\u6ab9\u67cf".length();
        "\u58df\u5c84\u66e5".length();
        "\u69b4\u6d08".length();
        "\u683d\u6a66".length();
        args[2] = this.third;
        "\u6a68\u5e94".length();
        args[3] = this.fourth;
        return String.format(\u669a\u5d92\u6990\u57e8\u5fe8\u710c\u5c5e\u6d35\u5b5f\u51e8\u51c8\u57c1\u51cb\u599d\u6546\u51e0\u62fb\u5d12\u58b6\u52e4\u6ca3\u5db5\u4e79\u5c33\u5b94\u6ad4\u6d0c\u70b0\u6967\u6d13\u66d1\u556c\u5242\u6640\u5525\u60e8\u6b88\u603e\u678e\u6950\u6df7, args);
    }
    
    @Override
    public final int getSize() {
        return 4;
    }
    
    @Override
    public final Object[] toArray() {
        return new Object[] { this.first, this.second, this.third, this.fourth };
    }
    
    public static int ColonialObfuscator_\u52c1\u5dc0\u680d\u65d9\u5635\u66f9\u60ae\u626f\u6077\u510a\u6f43\u660c\u5ed2\u6983\u5398\u6230\u6424\u63cd\u6c9b\u6015\u52d0\u57c9\u5b93\u6cce\u67fb\u56a6\u505c\u580f\u5bb1\u58c9\u65a7\u631b\u6bb6\u5547\u6869\u5c12\u5602\u616c\u69ad\u6a37\u6fea(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
