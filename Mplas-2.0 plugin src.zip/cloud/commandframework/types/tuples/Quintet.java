package cloud.commandframework.types.tuples;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public class Quintet<U, V, W, X, Y> implements Tuple
{
    public Quintet(final U first, final V second, final W third, final X fourth, final Y fifth) {
        this.first = first;
        this.second = second;
        this.third = third;
        this.fourth = fourth;
        this.fifth = fifth;
    }
    
    public final U getFirst() {
        return this.first;
    }
    
    public final V getSecond() {
        return this.second;
    }
    
    public final W getThird() {
        return this.third;
    }
    
    public final X getFourth() {
        return this.fourth;
    }
    
    public final Y getFifth() {
        return this.fifth;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final Quintet quintet = (Quintet)o;
        return Objects.equals(this.getFirst(), quintet.getFirst()) && Objects.equals(this.getSecond(), quintet.getSecond()) && Objects.equals(this.getThird(), quintet.getThird()) && Objects.equals(this.getFourth(), quintet.getFourth()) && Objects.equals(this.getFifth(), quintet.getFifth());
    }
    
    @Override
    public final int hashCode() {
        final Object[] values = new Object[5];
        "\u5e65\u6288\u6800".length();
        "\u5f03\u696c\u503c\u5fb2\u6e60".length();
        "\u5be0\u529c".length();
        "\u5165".length();
        values[0] = this.getFirst();
        "\u5cdc\u6513\u6bc1\u52f1\u6e46".length();
        values[1] = this.getSecond();
        "\u5d17\u4fca\u4e79\u6bb8".length();
        "\u67ca\u610a\u6f5f".length();
        values[2] = this.getThird();
        "\u702d\u5ded\u528a\u5e81\u5639".length();
        "\u63e0".length();
        "\u660f\u5d5f\u621e\u53cc".length();
        "\u6f6c".length();
        "\u519b\u6dc4\u62a0\u7058\u6529".length();
        values[3] = this.getFourth();
        "\u5aac\u51e4\u6fe3".length();
        "\u6888\u5476".length();
        values[4] = this.getFifth();
        return Objects.hash(values);
    }
    
    @Override
    public final String toString() {
        final String \u6629\u5660\u5a52\u66b9\u5a9e\u5a8b\u5006\u6bb4\u6c35\u646c\u64db\u6859\u56cf\u6493\u5717\u55b2\u6612\u6b16\u6c3a\u50fc\u58e5\u6893\u6179\u6f5f\u6c84\u6820\u6c67\u65fa\u6923\u6157\u58f4\u5ada\u5795\u5eba\u5ee6\u519d\u4e87\u6a0f\u6db9\u6d8e\u54a1 = \u6629\u5660\u5a52\u66b9\u5a9e\u5a8b\u5006\u6bb4\u6c35\u646c\u64db\u6859\u56cf\u6493\u5717\u55b2\u6612\u6b16\u6c3a\u50fc\u58e5\u6893\u6179\u6f5f\u6c84\u6820\u6c67\u65fa\u6923\u6157\u58f4\u5ada\u5795\u5eba\u5ee6\u519d\u4e87\u6a0f\u6db9\u6d8e\u54a1(51557210, 2076233610, "\udf85\udfa7\udff3\udfa8\udfa4\udfa5\udffa\udfd7\udff9\udfd2\udf81\udfca\udfc1\udfd7\udf82\udfc7\udfd1\udfca\udfb0\ubffa", -476321351, -141538681);
        final Object[] args = new Object[5];
        "\u5642\u5154\u5937\u52aa".length();
        "\u67bc\u5f1f\u51af\u55f1".length();
        "\u5509\u5a5b".length();
        "\u563b\u6edb\u60ff".length();
        "\u6e99\u66b3\u5b52\u63a7".length();
        args[0] = this.first;
        "\u6d67\u5144\u52bb".length();
        "\u69e4\u6ea2\u635d\u6e7a".length();
        "\u5b1f\u6716\u5264\u5638".length();
        "\u5fc0\u7030\u5678\u6ced\u7021".length();
        args[1] = this.second;
        "\u4e87\u6ae1\u681e\u5d6b".length();
        "\u68c0\u5ce2".length();
        args[2] = this.third;
        "\u5cc1".length();
        "\u625d\u5089\u510e\u6976".length();
        args[3] = this.fourth;
        "\u6974\u51af\u4faa\u596b".length();
        "\u6a12\u6878\u6a10\u5b40".length();
        "\u5ab5\u6612\u6a61".length();
        args[4] = this.fifth;
        return String.format(\u6629\u5660\u5a52\u66b9\u5a9e\u5a8b\u5006\u6bb4\u6c35\u646c\u64db\u6859\u56cf\u6493\u5717\u55b2\u6612\u6b16\u6c3a\u50fc\u58e5\u6893\u6179\u6f5f\u6c84\u6820\u6c67\u65fa\u6923\u6157\u58f4\u5ada\u5795\u5eba\u5ee6\u519d\u4e87\u6a0f\u6db9\u6d8e\u54a1, args);
    }
    
    @Override
    public final int getSize() {
        return 5;
    }
    
    @Override
    public final Object[] toArray() {
        return new Object[] { this.first, this.second, this.third, this.fourth, this.fifth };
    }
    
    public static int ColonialObfuscator_\u636d\u6d3c\u6446\u5d06\u540c\u5bdc\u61cb\u506f\u6258\u601f\u651e\u67c4\u6290\u6b34\u525f\u6fae\u5ebb\u70f2\u713a\u5531\u5087\u687d\u546a\u5291\u66b5\u6408\u5380\u51b7\u682c\u55d5\u6fc0\u6556\u69c9\u54eb\u4ee7\u5770\u6a18\u64dd\u623d\u516d\u6337(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
