package cloud.commandframework.types.tuples;

import org.apiguardian.api.*;
import java.util.*;

@API(status = API.Status.STABLE)
public class Triplet<U, V, W> implements Tuple
{
    public Triplet(final U first, final V second, final W third) {
        this.first = first;
        this.second = second;
        this.third = third;
    }
    
    public final U getFirst() {
        return this.first;
    }
    
    public final V getSecond() {
        return this.second;
    }
    
    public final W getThird() {
        return this.third;
    }
    
    @Override
    public final boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final Triplet triplet = (Triplet)o;
        return Objects.equals(this.getFirst(), triplet.getFirst()) && Objects.equals(this.getSecond(), triplet.getSecond()) && Objects.equals(this.getThird(), triplet.getThird());
    }
    
    @Override
    public final int hashCode() {
        final Object[] values = new Object[3];
        "\u5222\u5cca\u603e".length();
        values[0] = this.getFirst();
        "\u6dd2\u6303\u54e5\u523b\u68a7".length();
        "\u6beb\u5231".length();
        values[1] = this.getSecond();
        "\u537a\u6735\u5768\u5973\u6544".length();
        "\u637d\u6019\u6fbb\u5e7c\u546f".length();
        "\u5fce\u5c5e\u6c08".length();
        values[2] = this.getThird();
        return Objects.hash(values);
    }
    
    @Override
    public final String toString() {
        final String \u6e2a\u631f\u532b\u6b8a\u6b73\u5e87\u6b40\u5673\u6f59\u561d\u6b80\u5436\u648e\u4fc7\u6350\u6777\u629c\u62d8\u5fd6\u6d3e\u538f\u622a\u6978\u5c73\u5b76\u7057\u58bb\u5c04\u5331\u5d29\u6c2d\u6abb\u4f61\u65db\u5bad\u5d3b\u6970\u6abc\u6dd6\u6ca7\u50ed = \u6e2a\u631f\u532b\u6b8a\u6b73\u5e87\u6b40\u5673\u6f59\u561d\u6b80\u5436\u648e\u4fc7\u6350\u6777\u629c\u62d8\u5fd6\u6d3e\u538f\u622a\u6978\u5c73\u5b76\u7057\u58bb\u5c04\u5331\u5d29\u6c2d\u6abb\u4f61\u65db\u5bad\u5d3b\u6970\u6abc\u6dd6\u6ca7\u50ed(287895945, 1315452722, "\ua96a\ua94c\ua918\ua947\ua94b\ua946\ua919\ua948\ua966\ua949\ua91a\ua950", 1149607331, -852889063);
        final Object[] args = new Object[3];
        "\u5367\u56b6".length();
        "\u6ffb\u6b4f\u52ac\u6e6a\u5d62".length();
        "\u54a3\u53c5".length();
        args[0] = this.first;
        "\u67db\u5f94".length();
        "\u6e3c\u64e1\u6019".length();
        args[1] = this.second;
        "\u53da\u5f1a\u58b6".length();
        "\u6a22\u5abf\u4e81\u51fc".length();
        "\u6f54\u692b".length();
        "\u6e00".length();
        "\u5b79\u6821\u6abe".length();
        args[2] = this.third;
        return String.format(\u6e2a\u631f\u532b\u6b8a\u6b73\u5e87\u6b40\u5673\u6f59\u561d\u6b80\u5436\u648e\u4fc7\u6350\u6777\u629c\u62d8\u5fd6\u6d3e\u538f\u622a\u6978\u5c73\u5b76\u7057\u58bb\u5c04\u5331\u5d29\u6c2d\u6abb\u4f61\u65db\u5bad\u5d3b\u6970\u6abc\u6dd6\u6ca7\u50ed, args);
    }
    
    @Override
    public final int getSize() {
        return 3;
    }
    
    @Override
    public final Object[] toArray() {
        return new Object[] { this.first, this.second, this.third };
    }
    
    public static int ColonialObfuscator_\u4e8b\u5a3c\u6003\u5b97\u690e\u5c37\u668f\u6a47\u531b\u4ef7\u67f5\u5582\u6ee1\u6fb3\u6664\u688f\u5e93\u5f5a\u69b8\u6a98\u6bd8\u703a\u6f95\u5068\u6771\u6229\u5bfc\u5c8b\u5faf\u6c68\u66ea\u6ffc\u6805\u67b1\u5033\u5b9c\u5ada\u613c\u68b4\u6a22\u70ef(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
