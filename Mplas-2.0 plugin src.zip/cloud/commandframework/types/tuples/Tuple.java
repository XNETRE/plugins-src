package cloud.commandframework.types.tuples;

import org.apiguardian.api.*;

@API(status = API.Status.STABLE)
public interface Tuple
{
    int getSize();
    
    Object[] toArray();
}
