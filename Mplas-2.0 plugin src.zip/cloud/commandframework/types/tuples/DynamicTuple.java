package cloud.commandframework.types.tuples;

import org.apiguardian.api.*;

@API(status = API.Status.STABLE)
public final class DynamicTuple implements Tuple
{
    public DynamicTuple(final Object[] internalArray) {
        this.internalArray = internalArray;
    }
    
    @Override
    public int getSize() {
        return this.internalArray.length;
    }
    
    @Override
    public Object[] toArray() {
        final Object[] array = new Object[this.internalArray.length];
        System.arraycopy(this.internalArray, 0, array, 0, this.internalArray.length);
        return array;
    }
    
    public static int ColonialObfuscator_\u55b6\u6b54\u650d\u5920\u5a5c\u506a\u5ac5\u6933\u68dc\u544c\u61a9\u6577\u6d66\u6717\u5827\u69e9\u5b11\u509a\u5ec4\u5007\u6911\u4f4f\u68dc\u6a71\u6718\u707e\u6800\u546e\u6b98\u4fb6\u69a7\u5680\u69f0\u60fa\u5d82\u52b4\u5465\u653e\u60bb\u6462\u59bc(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
