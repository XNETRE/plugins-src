package cloud.commandframework.execution;

import org.apiguardian.api.*;
import cloud.commandframework.execution.preprocessor.*;
import java.util.*;
import java.util.function.*;

@API(status = API.Status.STABLE)
public final class FilteringCommandSuggestionProcessor<C> implements CommandSuggestionProcessor<C>
{
    @API(status = API.Status.STABLE)
    public FilteringCommandSuggestionProcessor() {
        this(Filter.startsWith(false));
    }
    
    @API(status = API.Status.STABLE, since = "1.8.0")
    public FilteringCommandSuggestionProcessor(final Filter<C> filter) {
        this.filter = filter;
    }
    
    @Override
    public List<String> apply(final CommandPreprocessingContext<C> commandPreprocessingContext, final List<String> list) {
        String s;
        if (commandPreprocessingContext.getInputQueue().isEmpty()) {
            s = \u689d\u52a5\u6a46\u4e9d\u6382\u6624\u5b0e\u606e\u5c4a\u6dde\u646c\u67f8\u5d81\u6de9\u6992\u5d6c\u6341\u59e8\u7056\u4e84\u6107\u56ab\u5433\u5f76\u55e9\u591e\u506b\u5384\u6b0f\u59da\u6f77\u6c5f\u5c23\u578e\u59f6\u59ca\u6a29\u68b7\u6825\u59f0\u603e(-1000524511, 980723366, "", -614817270, 15612326);
        }
        else {
            s = String.join(\u689d\u52a5\u6a46\u4e9d\u6382\u6624\u5b0e\u606e\u5c4a\u6dde\u646c\u67f8\u5d81\u6de9\u6992\u5d6c\u6341\u59e8\u7056\u4e84\u6107\u56ab\u5433\u5f76\u55e9\u591e\u506b\u5384\u6b0f\u59da\u6f77\u6c5f\u5c23\u578e\u59f6\u59ca\u6a29\u68b7\u6825\u59f0\u603e(836101287, 355667596, "\u8574", 1908208344, -1491165724), commandPreprocessingContext.getInputQueue());
        }
        "\u55a9\u6fd4\u5138".length();
        "\u5652\u7147\u6d0f\u542c".length();
        final ArrayList<String> list2 = new ArrayList<String>(list.size());
        final Iterator<String> iterator = list.iterator();
        while (iterator.hasNext()) {
            final String filter = this.filter.filter(commandPreprocessingContext, iterator.next(), s);
            if (filter != null) {
                list2.add(filter);
                "\u69d3\u66d2\u6861\u6f59".length();
                "\u5dff".length();
            }
        }
        return list2;
    }
    
    public static int ColonialObfuscator_\u6279\u61ad\u527e\u5bad\u7009\u5957\u5363\u52a8\u52e7\u4fdf\u5919\u4e4c\u57f6\u6f43\u631c\u52b2\u67ae\u518f\u6e83\u61a9\u60ca\u603c\u5a1d\u60c7\u62e4\u61e2\u5f92\u512a\u65fc\u6aeb\u6b76\u4fda\u646c\u63ab\u5046\u6bbe\u5af8\u67d1\u6e04\u6c03\u5c60(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
