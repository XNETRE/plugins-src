package cloud.commandframework.execution.postprocessor;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class CommandPostprocessingContext<C>
{
    public CommandPostprocessingContext(final CommandContext<C> commandContext, final Command<C> command) {
        this.commandContext = commandContext;
        this.command = command;
    }
    
    public CommandContext<C> getCommandContext() {
        return this.commandContext;
    }
    
    public Command<C> getCommand() {
        return this.command;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final CommandPostprocessingContext commandPostprocessingContext = (CommandPostprocessingContext)o;
        return Objects.equals(this.getCommandContext(), commandPostprocessingContext.getCommandContext()) && Objects.equals(this.getCommand(), commandPostprocessingContext.getCommand());
    }
    
    @Override
    public int hashCode() {
        final Object[] values = new Object[2];
        "\u5f3b\u5a53\u5d50\u60d7\u4e94".length();
        "\u5965\u5e59\u547b".length();
        "\u60e4\u5a0f\u51c0\u5b87".length();
        values[0] = this.getCommandContext();
        "\u60bd\u52aa\u5159\u6443\u5cc4".length();
        "\u5211\u6123\u50ea".length();
        "\u6e5f\u675e\u602a".length();
        "\u5834\u63a9\u5783\u6254\u6cbe".length();
        values[1] = this.getCommand();
        return Objects.hash(values);
    }
    
    public static int ColonialObfuscator_\u713a\u6ae2\u569e\u510f\u55b6\u5ee2\u5fb4\u66e4\u6d1b\u4f79\u4ee0\u5c63\u5b71\u666a\u57f0\u6593\u6655\u4e2c\u5fb2\u6482\u58ba\u6342\u5943\u52d8\u649d\u623c\u61f7\u4f59\u6f1e\u5dd8\u672c\u6ddb\u6473\u52b5\u545a\u53ed\u68da\u54e1\u6a2d\u5765\u69b7(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
