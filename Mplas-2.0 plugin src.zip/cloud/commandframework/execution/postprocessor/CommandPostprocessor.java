package cloud.commandframework.execution.postprocessor;

import cloud.commandframework.services.types.*;
import org.apiguardian.api.*;

@API(status = API.Status.STABLE)
public interface CommandPostprocessor<C> extends ConsumerService<CommandPostprocessingContext<C>>
{
}
