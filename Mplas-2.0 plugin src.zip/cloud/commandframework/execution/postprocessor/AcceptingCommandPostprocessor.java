package cloud.commandframework.execution.postprocessor;

import org.apiguardian.api.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class AcceptingCommandPostprocessor<C> implements CommandPostprocessor<C>
{
    @Override
    public void accept(final CommandPostprocessingContext<C> commandPostprocessingContext) {
        commandPostprocessingContext.getCommandContext().store(\u61ca\u6223\u531b\u584d\u5ece\u60c2\u5860\u5627\u688f\u52b5\u603e\u5ba5\u69bb\u5d81\u622d\u55d8\u51a8\u5246\u62fb\u60ae\u5d6f\u5d51\u6840\u612e\u5f83\u64b9\u6c35\u6f40\u5212\u5cbf\u604b\u635c\u56f8\u5133\u6201\u5fb1\u5b63\u5154\u60a5\u630e\u67a8(-561140253, -1011031315, "\u404d\u4062\u407c\u407c\u407e\u407a\u407f\u407a\u4052\u4067\u406d\u407e\u4065\u4071\u4079\u4064\u407c\u407f\u405f\u1668\u277b\u13ac\u1cd0\u151d\u167c\u1c37", -513443643, -1552386150), \u61ca\u6223\u531b\u584d\u5ece\u60c2\u5860\u5627\u688f\u52b5\u603e\u5ba5\u69bb\u5d81\u622d\u55d8\u51a8\u5246\u62fb\u60ae\u5d6f\u5d51\u6840\u612e\u5f83\u64b9\u6c35\u6f40\u5212\u5cbf\u604b\u635c\u56f8\u5133\u6201\u5fb1\u5b63\u5154\u60a5\u630e\u67a8(32706623, 1142009384, "\ubb6e\ubb47\ubb42\ubb4e", 1342058573, -91605757));
    }
    
    public static int ColonialObfuscator_\u6fe2\u55be\u5072\u57fd\u5e61\u6002\u6d0b\u5133\u4fec\u4f15\u6cb9\u522b\u593d\u62a5\u6436\u4f86\u5e38\u6361\u4e9f\u69f0\u51b0\u53a2\u6b02\u6eaa\u5d55\u60fa\u5656\u5387\u698b\u585f\u5bc2\u4fb9\u6981\u650d\u504a\u69d1\u5592\u533f\u561f\u4fe9\u62f9(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
