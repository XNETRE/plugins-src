package cloud.commandframework.execution;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;

@API(status = API.Status.STABLE)
public class CommandResult<C>
{
    public CommandResult(final CommandContext<C> commandContext) {
        this.commandContext = commandContext;
    }
    
    public CommandContext<C> getCommandContext() {
        return this.commandContext;
    }
    
    public static int ColonialObfuscator_\u6580\u5597\u7098\u548f\u58cd\u6765\u5234\u5721\u6fde\u5ccb\u6b8a\u6bdd\u5d8b\u4ec7\u6fd7\u566f\u6803\u590b\u68b6\u538b\u4e65\u68fd\u56fe\u5844\u5759\u6ae8\u579e\u50ef\u509d\u5b6f\u6189\u5057\u4f83\u6a49\u5489\u5998\u6921\u6768\u5c04\u651b\u62b7(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
