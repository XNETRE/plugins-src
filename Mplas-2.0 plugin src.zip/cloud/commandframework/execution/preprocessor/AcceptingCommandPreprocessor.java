package cloud.commandframework.execution.preprocessor;

import org.apiguardian.api.*;

@API(status = API.Status.INTERNAL, consumers = { "cloud.commandframework.*" })
public final class AcceptingCommandPreprocessor<C> implements CommandPreprocessor<C>
{
    @Override
    public void accept(final CommandPreprocessingContext<C> commandPreprocessingContext) {
        commandPreprocessingContext.getCommandContext().store(\u5ea7\u550e\u4f7b\u5f78\u5ff4\u4fbb\u6a28\u6d00\u6801\u6718\u56ae\u590a\u6234\u59e1\u5049\u5b64\u51f6\u5b46\u6e26\u5e0b\u6fac\u702e\u5cba\u5c65\u5bc3\u5553\u6641\u70f4\u64f7\u5919\u59f2\u713d\u5371\u63ea\u5b7d\u53c5\u5e56\u6133\u5e4b\u6488\u6854(-1454799699, 1643167347, "\uc3b5\uc398\uc3b8\uc3b6\uc3b6\uc3b0\uc3b3\uc3b0\uc39a\uc3ad\uc3a9\uc3b9\uc3ab\uc3a0\uc3aa\uc3bc\uc3b9\uc3a9\uc39d\u91a8\ua3df\u9493\u9267\ua56e\uac01", 1084609374, 1801988649), \u5ea7\u550e\u4f7b\u5f78\u5ff4\u4fbb\u6a28\u6d00\u6801\u6718\u56ae\u590a\u6234\u59e1\u5049\u5b64\u51f6\u5b46\u6e26\u5e0b\u6fac\u702e\u5cba\u5c65\u5bc3\u5553\u6641\u70f4\u64f7\u5919\u59f2\u713d\u5371\u63ea\u5b7d\u53c5\u5e56\u6133\u5e4b\u6488\u6854(628135138, 567215534, "\udd35\udd1e\udd19\udd0b", -1879518236, -33775702));
    }
    
    public static int ColonialObfuscator_\u5813\u615a\u5b85\u5e23\u64e4\u6465\u6e92\u56aa\u5817\u527d\u5317\u51c3\u6ac7\u60cc\u692d\u557f\u6010\u5eaf\u5768\u5b8c\u6dc0\u6418\u4ecd\u6ff6\u5264\u5505\u50b3\u5a9a\u5eb6\u51c9\u52d9\u55e7\u5dc6\u6eaf\u5440\u5d87\u679c\u5aac\u6dab\u63f5\u5d54(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
