package cloud.commandframework.execution.preprocessor;

import cloud.commandframework.services.types.*;
import org.apiguardian.api.*;

@API(status = API.Status.STABLE)
public interface CommandPreprocessor<C> extends ConsumerService<CommandPreprocessingContext<C>>
{
}
