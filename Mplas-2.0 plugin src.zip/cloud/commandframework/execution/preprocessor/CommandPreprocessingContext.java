package cloud.commandframework.execution.preprocessor;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import java.util.*;

@API(status = API.Status.STABLE)
public final class CommandPreprocessingContext<C>
{
    public CommandPreprocessingContext(final CommandContext<C> commandContext, final LinkedList<String> inputQueue) {
        this.commandContext = commandContext;
        this.inputQueue = inputQueue;
    }
    
    public CommandContext<C> getCommandContext() {
        return this.commandContext;
    }
    
    public LinkedList<String> getInputQueue() {
        return this.inputQueue;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || this.getClass() != o.getClass()) {
            return false;
        }
        final CommandPreprocessingContext commandPreprocessingContext = (CommandPreprocessingContext)o;
        return Objects.equals(this.getCommandContext(), commandPreprocessingContext.getCommandContext()) && Objects.equals(this.getInputQueue(), commandPreprocessingContext.getInputQueue());
    }
    
    @Override
    public int hashCode() {
        final Object[] values = new Object[2];
        "\u5b88".length();
        values[0] = this.getCommandContext();
        "\u6b16\u6199\u52e4\u5630".length();
        "\u63d6\u67cc".length();
        values[1] = this.getInputQueue();
        return Objects.hash(values);
    }
    
    public static int ColonialObfuscator_\u6e83\u4edb\u6ba7\u6044\u69be\u5503\u6057\u53af\u6516\u669c\u6d20\u5a38\u7060\u5db7\u5d8f\u5fde\u66b2\u6e2f\u61cb\u58b4\u6a11\u535b\u525a\u6d8b\u6de6\u707c\u6bc7\u6b7d\u58b6\u5ea0\u6834\u6942\u63ab\u6b06\u6960\u5e72\u597e\u6d92\u6043\u5a19\u659c(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
