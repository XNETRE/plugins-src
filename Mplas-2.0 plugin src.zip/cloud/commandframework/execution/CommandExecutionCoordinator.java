package cloud.commandframework.execution;

import org.apiguardian.api.*;
import java.util.function.*;
import cloud.commandframework.context.*;
import cloud.commandframework.*;
import java.util.*;
import cloud.commandframework.services.*;
import cloud.commandframework.exceptions.*;
import java.util.concurrent.*;
import cloud.commandframework.types.tuples.*;

@API(status = API.Status.STABLE)
public abstract class CommandExecutionCoordinator<C>
{
    public CommandExecutionCoordinator(final CommandTree<C> commandTree) {
        this.commandTree = commandTree;
    }
    
    public abstract CompletableFuture<CommandResult<C>> coordinateExecution(final CommandContext<C> p0, final Queue<String> p1);
    
    public CommandTree<C> getCommandTree() {
        return this.commandTree;
    }
    
    public static int ColonialObfuscator_\u590a\u4fef\u7072\u6c57\u619d\u7048\u630d\u5c45\u5e4c\u67ed\u6916\u5d4e\u5ad4\u6419\u6f56\u5278\u60d6\u565b\u67fe\u63ec\u53bb\u6731\u66ef\u6138\u5160\u7082\u6ae1\u55bd\u64b4\u580d\u5fa5\u528e\u56c1\u5151\u51a1\u5744\u6b4f\u713f\u5a64\u66bc\u6cd9(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
