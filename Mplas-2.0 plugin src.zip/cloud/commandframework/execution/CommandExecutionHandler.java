package cloud.commandframework.execution;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import java.util.*;
import java.util.concurrent.*;

@FunctionalInterface
@API(status = API.Status.STABLE)
public interface CommandExecutionHandler<C>
{
    void execute(final CommandContext<C> p0);
    
    @API(status = API.Status.STABLE, since = "1.6.0")
    default CompletableFuture<Void> executeFuture(final CommandContext<C> commandContext) {
        "\u52ec\u6af4\u57be\u7094".length();
        "\u5252".length();
        final CompletableFuture<Object> completableFuture = (CompletableFuture<Object>)new CompletableFuture<Void>();
        try {
            this.execute(commandContext);
            completableFuture.complete(null);
            "\u63eb\u6f8a".length();
            "\u5230\u65cc\u4ef9".length();
            "\u688d\u629e\u6708".length();
            "\u6a45\u5703\u5210\u6e28\u530f".length();
        }
        catch (Throwable ex) {
            completableFuture.completeExceptionally(ex);
            "\u544d\u6435\u515c\u57cf\u64a6".length();
            "\u6c6a\u673a\u5db1".length();
            "\u573c\u5ee3\u649b\u6482\u4e87".length();
        }
        return (CompletableFuture<Void>)completableFuture;
    }
}
