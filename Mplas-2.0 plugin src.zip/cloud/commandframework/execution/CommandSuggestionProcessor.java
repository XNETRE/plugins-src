package cloud.commandframework.execution;

import java.util.function.*;
import cloud.commandframework.execution.preprocessor.*;
import java.util.*;
import org.apiguardian.api.*;

@API(status = API.Status.STABLE)
public interface CommandSuggestionProcessor<C> extends BiFunction<CommandPreprocessingContext<C>, List<String>, List<String>>
{
}
