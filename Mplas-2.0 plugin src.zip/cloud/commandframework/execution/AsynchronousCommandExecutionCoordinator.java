package cloud.commandframework.execution;

import org.apiguardian.api.*;
import cloud.commandframework.context.*;
import java.util.*;
import java.util.concurrent.*;
import cloud.commandframework.services.*;
import cloud.commandframework.exceptions.*;
import cloud.commandframework.*;
import cloud.commandframework.types.tuples.*;
import java.util.function.*;

@API(status = API.Status.STABLE)
public final class AsynchronousCommandExecutionCoordinator<C> extends CommandExecutionCoordinator<C>
{
    public AsynchronousCommandExecutionCoordinator(final Executor executor, final boolean synchronizeParsing, final CommandTree<C> commandTree) {
        super(commandTree);
        this.executor = ((executor == null) ? ForkJoinPool.commonPool() : executor);
        this.synchronizeParsing = synchronizeParsing;
        this.commandManager = commandTree.getCommandManager();
    }
    
    @Override
    public CompletableFuture<CommandResult<C>> coordinateExecution(final CommandContext<C> commandContext, final Queue<String> queue) {
        "\u6580".length();
        "\u6573\u63b7\u68f9".length();
        "\u5dcb\u6170".length();
        final CompletableFuture<CommandResult<C>> completableFuture = new CompletableFuture<CommandResult<C>>();
        final CompletableFuture<CommandResult<C>> completableFuture2;
        final Throwable ex2;
        final CommandResult<C> value;
        final Consumer<Command<C>> consumer = command -> {
            if (this.commandManager.postprocessContext(commandContext, command) == State.ACCEPTED) {
                command.getCommandExecutionHandler().executeFuture(commandContext).whenComplete((p2, ex) -> {
                    if (ex != null) {
                        if (ex instanceof CommandExecutionException) {
                            completableFuture2.completeExceptionally(ex);
                            "\u5fbc\u64d5\u67fb".length();
                            "\u5b00".length();
                            "\u667a".length();
                            "\u63e0\u6c1a".length();
                        }
                        else {
                            // new(cloud.commandframework.exceptions.CommandExecutionException.class)
                            "\u6999\u5207\u5d79\u5376".length();
                            "\u6e55\u5be3".length();
                            "\u6f86\u6b6c\u52e9".length();
                            "\u4f64\u6bc6\u67c6".length();
                            new CommandExecutionException(ex, commandContext);
                            completableFuture2.completeExceptionally(ex2);
                            "\u6571\u6c8c".length();
                            "\u519f\u7131\u50bc\u5cc5\u4e8b".length();
                        }
                    }
                    // new(cloud.commandframework.execution.CommandResult.class)
                    "\u6572\u64ae\u5d90\u7134".length();
                    "\u576f\u5860\u65e7".length();
                    new CommandResult(commandContext);
                    completableFuture2.complete(value);
                    "\u56a0\u710b\u5098\u53e7\u5d6a".length();
                    "\u6e88\u6d3b\u5a56\u62ee\u5559".length();
                    return;
                });
                "\u6e77".length();
            }
            return;
        };
        if (this.synchronizeParsing) {
            final Pair<Command<C>, Exception> parse = this.getCommandTree().parse(commandContext, queue);
            if (parse.getSecond() != null) {
                completableFuture.completeExceptionally(parse.getSecond());
                "\u6c73\u6d82\u5245\u4e8c\u4ea3".length();
                "\u58a9".length();
            }
            else {
                this.executor.execute(() -> consumer.accept(parse.getFirst()));
            }
        }
        else {
            final Pair<Command<C>, Throwable> pair;
            final CompletableFuture completableFuture3;
            final Consumer<Command<C>> consumer2;
            this.executor.execute(() -> {
                try {
                    this.getCommandTree().parse(commandContext, queue);
                    if (pair.getSecond() != null) {
                        completableFuture3.completeExceptionally(pair.getSecond());
                        "\u5c37\u5e78".length();
                        "\u5fdd\u6dbd\u630f\u6d17".length();
                        "\u699b\u4ea2".length();
                    }
                    else {
                        consumer2.accept(pair.getFirst());
                    }
                }
                catch (Exception ex3) {
                    completableFuture3.completeExceptionally(ex3);
                    "\u4f09\u5a94\u65ba".length();
                    "\u5c85\u530b\u66c3\u4ede\u6d4c".length();
                    "\u62b9\u5a15\u6d4e".length();
                    "\u54f3\u4e25\u6d3a\u6e01\u6392".length();
                }
                return;
            });
        }
        return completableFuture;
    }
    
    public static int ColonialObfuscator_\u698e\u546e\u65fd\u6dd1\u6f74\u5ce7\u70bf\u568a\u6f97\u6cd3\u703b\u5ae4\u63a1\u6973\u6fa1\u5f28\u5558\u5c8d\u65f9\u5690\u706e\u6dcb\u529d\u6ea4\u5c1f\u6a4d\u5fd2\u50ab\u61b8\u5eb8\u6ec8\u6831\u568b\u5812\u5129\u6f05\u5160\u675b\u5f9e\u4f5a\u5d25(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
