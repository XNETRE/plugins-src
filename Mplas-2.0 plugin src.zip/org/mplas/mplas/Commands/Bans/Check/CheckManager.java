package org.mplas.mplas.Commands.Bans.Check;

public class CheckManager
{
    public static int ColonialObfuscator_\u6841\u6c1d\u58ec\u5a6f\u5da7\u5f0a\u6d86\u7015\u5205\u63f6\u6e06\u517c\u6320\u5430\u5ce5\u6aa8\u5c7f\u65e0\u6449\u6476\u6ec6\u6258\u56ee\u5c6e\u6755\u6244\u68c4\u6130\u6d65\u6f77\u6088\u5fad\u5e25\u5af0\u6532\u6be5\u50a9\u6a00\u6e16\u59ac\u603d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
