package org.mplas.mplas.Commands.Bans.Check;

import org.bukkit.plugin.java.*;
import org.bukkit.entity.*;
import org.bukkit.scheduler.*;
import java.util.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;
import org.bukkit.scoreboard.*;
import org.bukkit.potion.*;
import org.bukkit.event.player.*;
import org.bukkit.event.*;
import org.bukkit.event.block.*;

public class check implements CommandExecutor, Listener
{
    public check(final JavaPlugin plugin) {
        this.brokenBlocks = new HashMap<Location, Material>();
        this.playerChecks = new HashMap<Player, Boolean>();
        this.playerTasks = new HashMap<Player, BukkitTask>();
        this.whiletrue = true;
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender.hasPermission(\u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(-1366456960, -1263695307, "\u3b1c\u3b22\u3b3c\u3b31\u3b23\u3b7e\u3b38\u3b33\u3b18\u3b2e\u3b2c", 529629575, 1309586688)) && !commandSender.hasPermission(\u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(1679512644, 1452818187, "\ud3cf\ud3fd\ud3e3\ud3ea\ud3f8\ud3a1\ud3e5\ud3dc\ud3f3\ud3db\ud3d6\ud3da", 185448089, -843510217))) {
            final Object[] array2 = new Object[2];
            "\u5bff".length();
            "\u592f\u5f22\u54f5\u5e58\u709d".length();
            array2[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(-627970372, -1093186989, "\u8335\u8719\u8309\u830f\u837e\u871b\u830f\u82f5\u82a0\u86ec\u82f6\u829d\u82ea\u82fb", -1399789319, 1652804419);
            "\u57d0\u6e6d".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u5e7b".length();
            "\u6a64\u500c".length();
            "\u6636\u6634\u640a\u562d\u600d".length();
            array3[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(2059052217, -403863356, "\u1899", 471656666, -1109795748);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (array.length == 0) {
            final Object[] array4 = new Object[2];
            "\u5c52\u60a2\u4ea5\u6332\u5f77".length();
            "\u6cba\u5d79\u6a8d\u6284\u58a2".length();
            "\u6564".length();
            array4[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(-838267493, -908268083, "\u261e\u266a\u2614\u2617\u261c\u266d\u261d\u2618\u2630\u261e\u2614\u2603\u2617\u2209\u2212\u2209\u2259\u224e\u226d\u499f\u78f5\u4d47\u5291\u7f4e\u4c56\u7b5b\u485a\u4abb\u42c1\u7038", -2000797244, -1664384041);
            "\u619e\u5673\u5de5\u5b06\u5e99".length();
            "\u67f6\u5bfa\u5a8f\u6e14\u6e4a".length();
            "\u5b9c".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u6d12\u5e1f".length();
            "\u53ef\u6878\u712c".length();
            "\u6470\u6609\u5a9e\u51b2".length();
            array5[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(1414093566, 1350700659, "\u80ff", -183898040, 1484923991);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
            return false;
        }
        if (!(commandSender instanceof Player)) {
            final Object[] array6 = new Object[2];
            "\u53a0\u51c8\u53ba".length();
            "\u5e9a\u6d63\u5e42\u68e0".length();
            array6[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(2038156929, -71230962, "\u60e2\u60ed\u60ed\u60e1\u60ec\u60ed\u60e0\u64fe\u60be\u60e8\u60e8\u608f\u60fe\u60f5\u64e8\u60ea\u60ff\u6091\u64d2\u0b3c\u3a5b\u0fdf\u1069\u3dfc\u0efa\u39f0\u0ef7", -965266173, 213353783);
            "\u53af\u6cc6\u6f04\u691f\u5556".length();
            "\u5a3c\u630a\u53ed\u5aa8".length();
            "\u5703\u5916".length();
            final int n3 = 1;
            final Object[] array7 = { null };
            "\u4f94\u4f63\u4ebf\u6e5d\u67af".length();
            "\u6fc4\u51cc\u60a8\u637e\u5eb0".length();
            "\u61e3".length();
            "\u6fd3\u65be\u5d69".length();
            "\u57f5\u6678\u63d3".length();
            array7[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(1725555621, -1546094398, "\ue81f", -1541503348, -857344615);
            array6[n3] = StyleUtils.gray(array7);
            commandSender.sendMessage(StyleUtils.red(array6));
            return true;
        }
        if (array.length != 1) {
            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED));
            return false;
        }
        final Player player = commandSender.getServer().getPlayer(array[0]);
        if (player == null) {
            final Object[] array8 = new Object[2];
            "\u64ea".length();
            "\u632b\u6ef4\u6e84\u5700".length();
            "\u5637\u6f53\u6747\u51b5".length();
            array8[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(1268177622, -1122196377, "\u9df7\u9df1\u9d9e\u9de2\u9de4\u99f8\u9dea\u9dee\u99db\u9dea\u9dec\u9df7\u9dff\u9def\u9de2\u99e5", 1156290286, -965119501);
            "\u5ecf".length();
            "\u638f\u59c2\u4ee7\u6d18".length();
            "\u51c3\u5cb7\u713c\u66b8\u674b".length();
            final int n4 = 1;
            final Object[] array9 = { null };
            "\u5f71".length();
            "\u59cb\u51da\u529d".length();
            "\u5c1d\u6364".length();
            "\u4fae\u5b2a".length();
            array9[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(-1181088814, -2067914286, "\u7c4f", -382033081, -1491337883);
            array8[n4] = StyleUtils.gray(array9);
            commandSender.sendMessage(StyleUtils.red(array8));
            return true;
        }
        if (array[0].equalsIgnoreCase(\u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(2053712785, 1059983985, "\u9c38\u9c12\u9c03\u9c12\u9c16", 769919402, -1295209406))) {
            this.applyEffects(player);
            final Object[] array10 = new Object[3];
            "\u6dc6\u70a6".length();
            "\u7060".length();
            "\u642d\u699e\u4f6b\u63e0\u5b07".length();
            array10[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(682982374, -404720200, "\u7b0b\u7b7d\u7f14\u7b73\u7b71\u7b0b\u7b08\u7b77\u7b20\u7b0d\u7f16\u7b15\u7b15\u7b09\u7b76\u7b7e\u7b67\u7b03\u7b2c\u10dd\u25a9\u144d\u0bfa\u2619\u1517\u2212\u117c\u13fd\u1bd7\u2d03\u1468\u164c\u23ce\u15ca\u0a6b\u1ed8\u26f8", 1946404801, -1776306491);
            "\u5d2f\u6659\u694e\u5725".length();
            final int n5 = 1;
            final Object[] array11 = { null };
            "\u5cb9\u55dd\u68ed\u6c98".length();
            array11[0] = player.getName();
            array10[n5] = StyleUtils.gold(array11);
            "\u5df1\u6b3e\u65d6\u569f\u5f5a".length();
            "\u513a".length();
            "\u5349".length();
            "\u70f1".length();
            final int n6 = 2;
            final Object[] array12 = { null };
            "\u5822".length();
            "\u66c6\u58a4\u67ce".length();
            "\u578a\u630b\u654a".length();
            array12[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(584123713, 97296624, "\ua9dd", 107255620, -236283062);
            array10[n6] = StyleUtils.gray(array12);
            commandSender.sendMessage(StyleUtils.gray(array10));
        }
        else if (array[0].equalsIgnoreCase(\u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(-253558438, 1953787819, "\u040a\u0422\u043b\u0438", 481385741, 1166096326))) {
            CheckManager.setWhileTrue(false);
            final Object[] array13 = new Object[3];
            "\u5fea\u6aa7\u5ddd\u5f06".length();
            "\u6129\u5f2f\u51d1\u512c\u5a8a".length();
            array13[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(718894445, -1320177706, "\u27b9\u27cf\u23a6\u27d9\u27db\u27a1\u27a2\u27d5\u2782\u27af\u23b4\u27bf\u27bf\u27ae\u27aa\u27cd\u27df\u27b1\u279e\u4c57\u7923\u48c7\u5770\u7a9b\u4995\u7e90\u4dfe\u4f77\u475d\u7189\u48e2\u4afe\u7f7c\u4978\u56d9\u4272\u7a52", -1867492659, 355249054);
            "\u6626".length();
            "\u5c7a\u5689".length();
            final int n7 = 1;
            final Object[] array14 = { null };
            "\u6d03".length();
            "\u6e23\u6d07\u7008".length();
            "\u663e\u4ed6\u68b3".length();
            "\u6ed7".length();
            "\u67df\u640e".length();
            array14[0] = player.getName();
            array13[n7] = StyleUtils.gold(array14);
            "\u6a88\u6176\u5143\u606e".length();
            "\u5b66".length();
            final int n8 = 2;
            final Object[] array15 = { null };
            "\u525c".length();
            array15[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(946365679, -500128140, "\ud33f", 57254444, 2032972778);
            array13[n8] = StyleUtils.gray(array15);
            commandSender.sendMessage(StyleUtils.gray(array13));
        }
        this.applyEffects(player);
        final Scoreboard newScoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        final String \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52 = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(1776322685, 1617743318, "\uf884\uf8bb\uf893\uf8a3\uf8af\uf8ba\uf8a4\uf8ad\uf882\uf8a6\uf8b0\uf8b6", -627941181, 333241794);
        final String \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e522 = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(-679636166, -1481106850, "\ub748\ub774\ub76c\ub76e\ub77c", -646496704, 27852875);
        final Object[] array16 = { null };
        "\u582f\u5651".length();
        final int n9 = 0;
        final Object[] array17 = { null };
        "\u5e0d\u6595\u51f2\u6d45".length();
        "\u5211\u5d08\u6489".length();
        array17[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(-614721702, -236858740, "\u0995\u0979\u093b\u09be\u097d\u093d\u098d\u0940\u0926\u098d\u094f\u091b\u0999\u0949\u0902\u0991\u0948\u0912\u09bf\u628a\u53a2\u66dc\u79cb\u541e\u6799\u5058\u6303\u6179\u69e9\u5b1a\u66e0\u6430\u5185\u677a\u7818\u6ce1\u5054\u61c0\u5a89\u63ff\u63b9\u6afa\u6e11\u79f8\u5c25\u6f96\u4786\u6337\u6952\u463c\u6836\u57e8\u55d7\u66ca\u4624\u6e77\u6f8a\u473a\u6ccc\u626f\u52c7\u63b1\u6cfe\u59dc\u6f9a\u5754\u631a\u51fe\u647c\u554f\u792c\u565c\u5d73\u7861\u6596\u5894\u621c\u6359\u5256\u56f0\u5c5a\u59d9\u6d14\u6650\u5521\u5971\u520a\u5fb8\u66e2\u61ac\u554a\u67c3\u6bb1\u52eb\u5361\u6db5\u56a9\u5d8e\u633c\u6e8e\u6356\u62a3\u5729\u5a01\u5ccc\u6c54\u6ea5\u629a\u59de\u50bf\u5fdb\u5704\u6764\u597d\u5b1f\u53f0\u69a1\u6924\u5d65\u5d1e\u099b\u09b7\u0d8c\u0db1\u0d8d\u0d87\u0d87\u0dbe\u0da4\u0d82\u09b1\u0d9e\u0d96\u09b7\u0d8d\u0da6\u0d84\u0d91\u09b0\u6245", -1920663270, -443101763);
        array16[n9] = StyleUtils.darkRed(array17);
        final Objective registerNewObjective = newScoreboard.registerNewObjective(\u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52, \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e522, StyleUtils.bold(array16));
        registerNewObjective.setDisplaySlot(DisplaySlot.SIDEBAR);
        registerNewObjective.getScore(\u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(-186944652, 337012610, "\uee82\uee6e\uee24\ueea1\uee62\uee22\ueeaa\uee67\uee01\ueeaa\uee70\uee24\ueea6\uee76\uee35\ueea6\uee7f\uee25\uee80\u85b5\ub49d\u81e3\u9eec\ub339\u80be\ub77f\u85dc\u87a6\u8f36\ubdc5\u8037\u82e7\ub752\u81ad\u9ec7\u8a3e\ub68b\u871f\ubc2e\u8558\u851e\u8c5d\u88ae\u9f47\uba9a\u8929\ua131\u8580\u8fe5\ua08b\u8e89\ub157\ub368\u8075\ua083\u88d0\u892d\ua19d\u8a53\u84f0\ub458\u852e\u8a69\ubfcc\u89cc\ub185\u8502\ub7a0\u82a5\ub357\u9f4a\ub0bd\ubb53\u9e07\u836f\ubeac\u8462\u85a0\ub466\ub086\ubaab\ubfe9\u8b6a\u80a9\ub319\ubf0f\ub4eb\ub998\u8084\u874d\ub312\u81dd\u8d28\ub4b3\ub577\u8b24\ub0f9\ubb98\u85a5\u88d6\u8548\u843a\ub189\ubce7\ubaad\u8af4\u885b\u84e3\ubf66\ub641\ub9aa\ub1b4\u8192\ubf0c\ubda7\ub50e\u8fd8\u8f9c\ubbd1\ubb7f\uefbd\uef17\uefea\uefae\uef2b\uefec\uefa5\uef2e\uefcf\uefa5\uef29\ueffa\uefb9\uef2f\uefeb\uefb9\uef26\ueffb\uef8f\u84fc\ub553\u80ec\u9fa5\ub2f7\u81b1\ub636\u85e2\u8759\u8f8f\ubdfb\u80c8\u825e\ub76c\u8152\u9e8e\u8af0\ub684\u8756\ubce0\u8557\u8557\u8c93\u88b1\u9f1e\uba44\u8936\ua168\u855e\u8ffa\ua0d2\u8e47\ub158\ub321\u80bb\ua08c\u8899\u89e3\ua192\u8a2a\u840e\ub467\u8557\u8a97\ubf74\u8974\ub13d\u858a\ub728\u822d\ub3df\u9fc2\ub035\ubbdb\u9e8f\u83f7\ube34\u84fa\u8538\ub4fe\ub01e\uba33\ubf71\u8be2\u8021\ub391\ubf87\ub463\ub910\u800c\u87c5\ub3ea\u8125\u8dd0\ub44b\ub58f\u8bdc\ub001\ubb60\u852d\u885e\u85c0\u84b2\ub101\ubc6f\uba25\u8a7c\u88c3\u847b\ubffe\ub6d9\ub932\ub12c\u810a\ubf94\ubd2f\ub586\u8f50\u8f14\ubb59\ubbf7\uef35\uef9f\uef52\uef16\uef93\uef54\uef1d\uef96\uef77\uef1d\uefa1\uef72\uef31\uefa7\uef63\uef31\uefae\uef73\uef17\u8464\ub5cb\u8074\u9f3d\ub26f\u8129\ub6ae\u856a\u87d1\u8f07\ubd73\u8040\u82d6\ub7e4\u81da\u9ef6\u8a88\ub6fc\u872e\ubc98\u852f\u852f\u8ceb\ub739\ua096\u85cc\ub6be\u9ee0\ubad6\ub072\u9f5a\ub1df\u8ec0\u8cb9\ubf23\u9f14\ub701\ub67b\u9e0a\ub5a2\ubb86\u8bef\ubadf\ub51f\u80fc\ub6fc\u8eb5\uba32\u8890\ubd95\u8c67\ua07a\u8f8d\u8463\ua137\ubc7f\u81bc\ubb72\ubab0\u8b76\u8f96\u85bb\u80f9\ub47a\ubfb9\u8c09\u801f\u8bfb\u8688\ubf94\ub85d\u8c62\ubead\ub258\u8bc3\u8a07\ub454\u8f89\u84e8\ubad5\ub7a6\uba38\ubb4a\u8ef9\u8397\u85dd\ub584\ub74b\ubbf3\u8076\u8951\u86ba\u8ea4\ube82\u801c\u82b7\u8a1e\ub0c8\ub08c\u84c1\u846f\ud0ad\ud007\ud0da\ud09e\ud01b\ud0dc\ud095\ud01e\ud0ff\ud095\ud019\ud0ca\ud089\ud01f\ud0db\ud089\ud016\ud0cb\ud09f\ubbec\u8a43\ubffc\ua0b5\u8de7\ubea1\u8926\ubaf2\ub849\ub09f\u82eb\ubfd8\ubd4e\u887c\ube42\ua17e\ub500\u8974\ub8a6\u8310\ubaa7\ubaa7\ub363\ub741\ua0ee\u85b4\ub6c6\u9e98\ubaae\ub00a\u9f22\ub157\u8e48\u8c31\ubfab\u9f9c\ub789\ub6f3\u9e82\ub53a\ubb1e\u8b77\uba47\ub587\u8064\ub664\u8e2d\ubaba\u8818\ubd1d\u8cef\ua0f2\u8f05\u84eb\ua1bf\ubcc7\u8104\ubbca\uba08\u8bce\u8f2e\u8503\u8041\ub4f2\ubf31\u8c81\u8097\u8b73\u8600\ubf1c\ub8d5\u8cfa\ube35\ub2c0\u8b5b\u8a9f\ub4cc\u8f11\u8470\uba5d\ub72e\ubab0\ubbc2\u8e71\u831f\u8555\ub50c\ub7b3\ubb0b\u808e\u89a9\u8642\u8e5c\ube7a\u80e4\u823f\u8a96\ub040\ub004\u8449\u84e7\ud025\ud08f\ud042\ud006\ud083\ud044\ud00d\ud086\ud067\ud00d\ud091\ud042\ud001\ud097\ud053\ud001\ud09e\ud043\ud027\ubb54\u8afb\ubf44\ua00d\u8d5f\ube19\u899e\uba7a\ub8c1\ub017\u8263\ubf50\ubdc6\u88f4\ubeca\ua1e6\ub598\u89ec\ub83e\u8388\uba3f\uba3f\ub3fb\ub7c9\ua066\u853c\ub64e\u9e10\uba26\ub082\u9faa\ub12f\u8e30\u8c49\ubfd3\u9fe4\ub7f1\ub68b\u9efa\ub4b2\uba96\u8aff\ubbcf\ub40f\u81ec\ub7ec\u8fa5\ubb22\u8980\ubc85\u8d77\ua16a\u8e9d\u8573\ua027\ubd4f\u808c\uba42\ubb80\u8a46\u8ea6\u848b\u81c9\ub54a\ube89\u8d39\u812f\u8acb\u87b8\ubea4\ub96d\u8d72\ubfbd\ub348\u8ad3\u8b17\ub544\u8e99\u85f8\ubbc5\ub6b6\ubb28\uba5a\u8fe9\u8287\u84cd\ub494\ub63b\uba83\u8106\u8821\u87ca\u8fd4\ubff2\u816c\u83c7\u8b6e\ub1b8\ub1fc\u85b1\u851f\ud1dd\ud177\ud1ca\ud18e\ud10b\ud1cc\ud185\ud10e\ud1ef\ud185\ud109\ud1da\ud199\ud10f\ud1cb\ud199\ud106\ud1db\ud1af\ubadc\u8b73\ubecc\ua185\u8cd7\ubf91\u8816\ubbc2\ub979\ub1af\u83db\ubee8\ubc7e\u894c\ubf72\ua06e\ub410\u8864\ub9b6\u8200\ubbb7\ubbb7\ub273\ub651\ua1fe\u84a4\ub7d6\u9f88\ubbbe\ub11a\u9e32\ub0a7\u8fb8\u8dc1\ube5b\u9e6c\ub679\ub703\u9f72\ub4ca\ubaee\u8a87\ubbb7\ub477\u8194\ub794\u8fdd\ubbaa\u8908\ubc0d\u8dff\ua1e2\u8e15\u85fb\ua0af\ubdd7\u8014\ubada\ubb18\u8ade\u8e3e\u8413\u8151\ub5c2\ube01\u8db1\u81a7\u8a43\u8730\ube2c\ub9e5\u8dca\ubf05\ub3f0\u8a6b\u8baf\ub5fc\u8e21\u8540\ubb4d\ub63e\ubba0\ubad2\u8f61\u820f\u8445\ub41c\ub6a3\uba1b\u819e\u88b9\u8752\u8f4c\ubf6a\u81f4\u834f\u8be6\ub130\ub174\u8539\u8597\ud155\ud1ff\ud132\ud176\ud1f3\ud134\ud17d\ud1f6\ud117\ud17d\ud181\ud152\ud111\ud187\ud143\ud111\ud18e\ud153\ud137\uba44\u8beb\ube54\ua11d\u8c4f\ubf09\u888e\ubb4a\ub9f1\ub127\u8353\ube60\ubcf6\u89c4\ubffa\ua0d6\ub4a8\u88dc\ub90e\u82b8\ubb0f\ubb0f\ub2cb\ub6d9\ua176\u842c\ub75e\u9f00\ubb36\ub192\u9eba\ub03f\u8f20\u8d59\ubec3\u9ef4\ub6e1\ub79b\u9fea\ub442\uba66\u8a0f\ubb3f\ub4ff\u811c\ub71c\u8f55\ubbd2\u8970\ubc75\u8d87\ua19a\u8e6d\u8583\ua0d7\ube5f\u839c\ub952\ub890\u8956\u8db6\u879b\u82d9\ub65a\ubd99\u8e29\u823f\u89db\u84a8\ubdb4\uba7d\u8e42\ubc8d\ub078\u89e3\u8827\ub674\u8da9\u86c8\ub8f5\ub586", -127951130, 2039899254)).setScore(4);
        registerNewObjective.getScore(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD, commandSender.getName(), ChatColor.RED)).setScore(3);
        registerNewObjective.getScore(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED)).setScore(2);
        player.setScoreboard(newScoreboard);
        final Object[] array18 = new Object[3];
        "\u580e\u5fa8".length();
        "\u5035\u5197".length();
        array18[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(-119747344, -802806002, "\u21b6\u21c0\u25a9\u21f6\u21f4\u218e\u218d\u21fa\u21ad\u2180\u259b\u2190\u2190\u218c\u21f3\u21e3\u21fa\u219e\u21b1\u4a58\u7f2c\u4ec8\u517f\u7c94\u4f9a\u789f\u4bf1\u4978\u4152\u7786\u4eed\u4cf1\u7973\u4f77\u50d6\u459d\u7dbd", -136914211, 2107512004);
        "\u6f70\u5222\u602b\u52a4".length();
        "\u68f8".length();
        "\u53e7\u6e3a\u6feb\u54b3\u5768".length();
        final int n10 = 1;
        final Object[] array19 = { null };
        "\u5aad\u5a97\u6b98\u6bd8\u69ae".length();
        "\u4f86\u6322\u5c31".length();
        "\u5cec\u64ed\u6855\u6c63\u4f94".length();
        array19[0] = player.getName();
        array18[n10] = StyleUtils.gold(array19);
        "\u6d9c\u6186\u4ee5\u6cbf\u61eb".length();
        final int n11 = 2;
        final Object[] array20 = { null };
        "\u68f2\u69d5\u52ab".length();
        array20[0] = \u6087\u6aa9\u5aca\u6f18\u7113\u4fb3\u58cb\u6cee\u585d\u6986\u58c8\u5e2c\u6e44\u6492\u69e5\u66b8\u57cb\u4f5b\u60c1\u6ed8\u61a0\u61c8\u6565\u5ef8\u6b98\u54ea\u6b40\u5ab8\u550d\u662f\u6be4\u53be\u6dd7\u6ed3\u6031\u6007\u58c2\u624a\u55e0\u5658\u4e52(-526015235, -1742464424, "\u42f4", -183544114, -791827715);
        array18[n11] = StyleUtils.gray(array20);
        commandSender.sendMessage(StyleUtils.gray(array18));
        return true;
    }
    
    public void applyEffects(final Player player) {
        this.playerChecks.put(player, true);
        "\u609c\u64da\u6ca6".length();
        player.setWalkSpeed(0.0f);
        player.setFlySpeed(0.0f);
        player.setCanPickupItems(false);
        player.setInvulnerable(true);
        "\u65f1".length();
        "\u657d".length();
        "\u5a46\u6d38".length();
        "\u6012\u4ef8\u6326\u5dda\u6385".length();
        "\u5c94\u4e5e\u660a\u508d\u5ec6".length();
        player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, Integer.MAX_VALUE, 200, false, false));
        "\u66f1\u6328\u52d5\u6d2b\u57c4".length();
        final Location location = player.getLocation();
        "\u5738\u5c23\u6315\u5374".length();
        "\u659c\u521a\u4fb4\u4e75".length();
        "\u5794\u6225\u6ea6\u5abe".length();
        final Location location2 = new Location(player.getWorld(), location.getX(), location.getY() + 0.5, location.getZ());
    }
    
    @EventHandler
    public void onPlayerToggleFlight(final PlayerToggleFlightEvent playerToggleFlightEvent) {
        final Player player = playerToggleFlightEvent.getPlayer();
        if (this.playerChecks.containsKey(player) && player.isFlying()) {
            playerToggleFlightEvent.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onBlockBreak(final BlockBreakEvent blockBreakEvent) {
        final Player player = blockBreakEvent.getPlayer();
        if (this.playerChecks.containsKey(player)) {
            blockBreakEvent.setCancelled(true);
            this.brokenBlocks.put(blockBreakEvent.getBlock().getLocation(), blockBreakEvent.getBlock().getType());
            "\u585b\u5d46\u5ca9\u5ab7".length();
            "\u531d\u672b\u6235".length();
            "\u701f\u70ce".length();
            player.teleport(player.getLocation());
            "\u5d19\u53cd".length();
            "\u599b".length();
        }
    }
    
    @EventHandler
    public void onBlockDrop(final BlockDropItemEvent blockDropItemEvent) {
        if (this.brokenBlocks.containsKey(blockDropItemEvent.getBlock().getLocation())) {
            blockDropItemEvent.getItems().clear();
        }
    }
    
    @EventHandler
    public void onBlockPlace(final BlockPlaceEvent blockPlaceEvent) {
        final Player player = blockPlaceEvent.getPlayer();
        final Location location = blockPlaceEvent.getBlockPlaced().getLocation();
        if (this.playerChecks.containsKey(player) && this.brokenBlocks.get(location) != null) {
            blockPlaceEvent.setCancelled(true);
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED));
            return;
        }
        if (this.brokenBlocks.containsKey(location)) {
            blockPlaceEvent.getBlockPlaced().setType((Material)this.brokenBlocks.get(location));
            this.brokenBlocks.remove(location);
            "\u5977\u70eb".length();
        }
    }
    
    public static int ColonialObfuscator_\u59a4\u5bca\u6428\u6abb\u5566\u5473\u6f7a\u552b\u5e5d\u51fa\u6eaf\u6467\u6ab5\u5c90\u527b\u509d\u52d2\u669a\u6eb5\u5ada\u5fe4\u5c45\u4ef5\u6f3a\u6b01\u57af\u5866\u6192\u7039\u6ab8\u58ac\u6f58\u6554\u65c8\u60ca\u69de\u6e58\u51a9\u5c6f\u5b34\u577c(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
