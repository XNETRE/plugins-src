package org.mplas.mplas.Commands.Bans.Check;

import org.bukkit.event.*;
import org.bukkit.plugin.java.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.scheduler.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.potion.*;
import org.bukkit.scoreboard.*;
import java.util.*;

public class uncheck implements CommandExecutor, Listener
{
    public uncheck(final JavaPlugin plugin) {
        this.brokenBlocks = new HashMap<Location, Material>();
        this.playerChecks = new HashMap<Player, Boolean>();
        this.playerTasks = new HashMap<Player, BukkitTask>();
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender.hasPermission(\u5f17\u6689\u4eed\u6633\u5b6e\u5ae5\u5cd2\u6b8c\u693f\u644f\u58ff\u4fbd\u5f61\u5fa3\u4eda\u5882\u691f\u5717\u6b1e\u6b9f\u5fd2\u5e3d\u555b\u574e\u5f1d\u5671\u7085\u7061\u6fe3\u63fb\u5030\u6392\u631d\u67ea\u6d5c\u6098\u6ccb\u711e\u5472\u59aa\u687c(-20754182, 1575933154, "\uca3e\uca0c\uca12\uca13\uca01\uca58\uca1e\uca11\uca3a\uca10\uca12", 279978149, 113602221)) && !commandSender.hasPermission(\u5f17\u6689\u4eed\u6633\u5b6e\u5ae5\u5cd2\u6b8c\u693f\u644f\u58ff\u4fbd\u5f61\u5fa3\u4eda\u5882\u691f\u5717\u6b1e\u6b9f\u5fd2\u5e3d\u555b\u574e\u5f1d\u5671\u7085\u7061\u6fe3\u63fb\u5030\u6392\u631d\u67ea\u6d5c\u6098\u6ccb\u711e\u5472\u59aa\u687c(-1456466517, 1347561742, "\u2d89\u2dbb\u2da5\u2db4\u2da6\u2dff\u2dbb\u2dba\u2d95\u2dbd\u2db0\u2db4", -685395315, 1214096271))) {
            final Object[] array2 = new Object[2];
            "\u6782\u66f9\u6341".length();
            array2[0] = \u5f17\u6689\u4eed\u6633\u5b6e\u5ae5\u5cd2\u6b8c\u693f\u644f\u58ff\u4fbd\u5f61\u5fa3\u4eda\u5882\u691f\u5717\u6b1e\u6b9f\u5fd2\u5e3d\u555b\u574e\u5f1d\u5671\u7085\u7061\u6fe3\u63fb\u5030\u6392\u631d\u67ea\u6d5c\u6098\u6ccb\u711e\u5472\u59aa\u687c(-852465781, 260797792, "\u7135\u7519\u7109\u7107\u7176\u7513\u7107\u7105\u7150\u751c\u7106\u7155\u7122\u7133", 2003557781, 1849801259);
            "\u66fb\u5c37\u63d9\u5c5c\u4e67".length();
            "\u5e9e\u6f31".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u7054\u6bef\u6f90".length();
            "\u5154\u671b\u6f5a".length();
            "\u6d62\u5ffa".length();
            array3[0] = \u5f17\u6689\u4eed\u6633\u5b6e\u5ae5\u5cd2\u6b8c\u693f\u644f\u58ff\u4fbd\u5f61\u5fa3\u4eda\u5882\u691f\u5717\u6b1e\u6b9f\u5fd2\u5e3d\u555b\u574e\u5f1d\u5671\u7085\u7061\u6fe3\u63fb\u5030\u6392\u631d\u67ea\u6d5c\u6098\u6ccb\u711e\u5472\u59aa\u687c(-1216718923, -2038109056, "\u5221", -1885426325, -511556579);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (array.length == 0) {
            final Object[] array4 = new Object[2];
            "\u575b\u6ed6\u6e57\u6ccf".length();
            array4[0] = \u5f17\u6689\u4eed\u6633\u5b6e\u5ae5\u5cd2\u6b8c\u693f\u644f\u58ff\u4fbd\u5f61\u5fa3\u4eda\u5882\u691f\u5717\u6b1e\u6b9f\u5fd2\u5e3d\u555b\u574e\u5f1d\u5671\u7085\u7061\u6fe3\u63fb\u5030\u6392\u631d\u67ea\u6d5c\u6098\u6ccb\u711e\u5472\u59aa\u687c(1832324373, -1040807740, "\u15f6\u1582\u15fc\u15ff\u15e4\u1595\u15e5\u15e0\u15c8\u15e6\u15ec\u15fb\u15ff\u11e1\u11fa\u11e1\u11a7\u11a0\u1183\u7bc7\u75d7\u42ce\u437d\u40e4\u7854\u4247\u78b6\u7a88\u47e8\u4639\u48e8", -130990548, 699574864);
            "\u62e0\u56bd\u561d".length();
            "\u5918\u6916".length();
            "\u5168\u6a5b\u5730\u691b".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u5ef2\u543f".length();
            "\u6ed9\u543c\u4edd\u581c\u62ef".length();
            "\u5eb4\u5a5f\u655f".length();
            "\u6512\u5a81\u5221\u6f6e".length();
            array5[0] = \u5f17\u6689\u4eed\u6633\u5b6e\u5ae5\u5cd2\u6b8c\u693f\u644f\u58ff\u4fbd\u5f61\u5fa3\u4eda\u5882\u691f\u5717\u6b1e\u6b9f\u5fd2\u5e3d\u555b\u574e\u5f1d\u5671\u7085\u7061\u6fe3\u63fb\u5030\u6392\u631d\u67ea\u6d5c\u6098\u6ccb\u711e\u5472\u59aa\u687c(616765308, -1879418442, "\u7e5b", -501841010, -1118588035);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
            return false;
        }
        final Player player = commandSender.getServer().getPlayer(array[0]);
        if (player == null) {
            final Object[] array6 = new Object[2];
            "\u6fb4\u54dd\u6de9\u4fd7\u5975".length();
            "\u5580".length();
            array6[0] = \u5f17\u6689\u4eed\u6633\u5b6e\u5ae5\u5cd2\u6b8c\u693f\u644f\u58ff\u4fbd\u5f61\u5fa3\u4eda\u5882\u691f\u5717\u6b1e\u6b9f\u5fd2\u5e3d\u555b\u574e\u5f1d\u5671\u7085\u7061\u6fe3\u63fb\u5030\u6392\u631d\u67ea\u6d5c\u6098\u6ccb\u711e\u5472\u59aa\u687c(-1648085454, -1757800070, "\ua0e3\ua0e5\ua09a\ua0e6\ua0e0\ua4fc\ua0ee\ua0ea\ua4df\ua0ee\ua0f8\ua0e3\ua0eb\ua0fb\ua0f6", -1264095482, -210311946);
            "\u6f49\u68b1\u6e52\u6ef7".length();
            "\u6d42\u681d\u6af1\u6aba".length();
            "\u55b5\u571d".length();
            final int n3 = 1;
            final Object[] array7 = { null };
            "\u6ccb\u5a03\u56c0\u5376".length();
            "\u532c\u6380\u653d\u6f19\u680f".length();
            array7[0] = \u5f17\u6689\u4eed\u6633\u5b6e\u5ae5\u5cd2\u6b8c\u693f\u644f\u58ff\u4fbd\u5f61\u5fa3\u4eda\u5882\u691f\u5717\u6b1e\u6b9f\u5fd2\u5e3d\u555b\u574e\u5f1d\u5671\u7085\u7061\u6fe3\u63fb\u5030\u6392\u631d\u67ea\u6d5c\u6098\u6ccb\u711e\u5472\u59aa\u687c(-1439340074, -1763645713, "\u8b4a", 1541782353, -13779136);
            array6[n3] = StyleUtils.gray(array7);
            commandSender.sendMessage(StyleUtils.red(array6));
            return true;
        }
        CheckManager.setWhileTrue(false);
        final Object[] array8 = new Object[3];
        "\u5458".length();
        "\u66a9".length();
        array8[0] = \u5f17\u6689\u4eed\u6633\u5b6e\u5ae5\u5cd2\u6b8c\u693f\u644f\u58ff\u4fbd\u5f61\u5fa3\u4eda\u5882\u691f\u5717\u6b1e\u6b9f\u5fd2\u5e3d\u555b\u574e\u5f1d\u5671\u7085\u7061\u6fe3\u63fb\u5030\u6392\u631d\u67ea\u6d5c\u6098\u6ccb\u711e\u5472\u59aa\u687c(-1613774193, -1889044303, "\uc105\uc171\uc51a\uc17b\uc17f\uc107\uc106\uc177\uc12e\uc101\uc518\uc11d\uc11b\uc108\uc10e\uc16f\uc183\uc1ef\uc1c2\uab8e\ua1f3\u92f3\u9337\u909b\ua854\u9603\uacac\uae9b\u93f4\u9642\u98ec\u9964\u9d5f\ua409\ua367\u8e13\u9c0f", 1812134000, -1242855654);
        "\u5cf1\u56e3".length();
        final int n4 = 1;
        final Object[] array9 = { null };
        "\u505f\u6f4d\u5cc0".length();
        "\u6991".length();
        "\u6b24\u535b".length();
        "\u5285\u53fe\u577c".length();
        array9[0] = player.getName();
        array8[n4] = StyleUtils.gold(array9);
        "\u61a5".length();
        final int n5 = 2;
        final Object[] array10 = { null };
        "\u7060\u6141\u58f4".length();
        "\u5e02\u63a9\u6cce\u6b30\u6d29".length();
        "\u67c9".length();
        "\u6ee3\u64b8\u6f01".length();
        array10[0] = \u5f17\u6689\u4eed\u6633\u5b6e\u5ae5\u5cd2\u6b8c\u693f\u644f\u58ff\u4fbd\u5f61\u5fa3\u4eda\u5882\u691f\u5717\u6b1e\u6b9f\u5fd2\u5e3d\u555b\u574e\u5f1d\u5671\u7085\u7061\u6fe3\u63fb\u5030\u6392\u631d\u67ea\u6d5c\u6098\u6ccb\u711e\u5472\u59aa\u687c(1427839253, -367913624, "\u50be", -309746789, -999882950);
        array8[n5] = StyleUtils.gray(array10);
        commandSender.sendMessage(StyleUtils.gray(array8));
        this.resetEffects(player);
        return true;
    }
    
    public void resetEffects(final Player player) {
        this.playerChecks.remove(player);
        "\u5b85\u5069\u6cb3\u58cd".length();
        "\u6992\u5061".length();
        "\u713e\u5614\u54d8".length();
        player.setWalkSpeed(0.2f);
        player.setFlySpeed(0.2f);
        player.setCanPickupItems(true);
        player.setInvulnerable(false);
        player.setAllowFlight(false);
        player.setFlying(false);
        player.removePotionEffect(PotionEffectType.CONFUSION);
        player.removePotionEffect(PotionEffectType.JUMP);
        final Scoreboard scoreboard = player.getScoreboard();
        if (scoreboard != null) {
            final Iterator iterator = scoreboard.getObjectives().iterator();
            while (iterator.hasNext()) {
                iterator.next().unregister();
            }
        }
    }
    
    public static int ColonialObfuscator_\u5415\u5330\u6bce\u5b1a\u5154\u659f\u67d6\u6ba7\u5a16\u502c\u5c40\u6edf\u5e53\u5bfa\u5cbf\u629d\u56c1\u66e4\u572f\u605d\u7146\u5a94\u6a1b\u5b88\u5ab4\u6b46\u5524\u56b7\u571a\u6d04\u5434\u5ab8\u6e81\u5520\u5a86\u6bfb\u52f0\u6b6c\u6418\u6746\u500e(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
