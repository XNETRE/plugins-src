package org.mplas.mplas.Commands.Bans;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import java.util.*;
import net.kyori.adventure.text.*;

public class KillAll implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender.hasPermission(\u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(1363675299, 1881689781, "\u2de7\u2dd7\u2dcb\u2dc4\u2dd8\u2d83\u2dc7\u2dce\u2de3\u2dcb\u2dcb", 1072984468, 262937163)) && !commandSender.hasPermission(\u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(1152819867, -1304532541, "\ud6e4\ud6d4\ud6c8\ud6c7\ud6db\ud680\ud6ce\ud6c0\ud6e1\ud6cd\ud6c7\ud6d8\ud6c1", 1888569860, 35674006))) {
            return false;
        }
        if (!command.getName().equalsIgnoreCase(\u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(973072581, 542240173, "\ufe5a\ufe75\ufe74\ufe76\ufe79\ufe72\ufe05", 58967354, 136592928))) {
            final Object[] array2 = new Object[2];
            "\u51c1".length();
            "\u52a4\u60dc\u6c9b".length();
            "\u6404\u6a5b\u5fa5\u5b8a\u5719".length();
            "\u51f8\u5e74\u5413\u4e3b".length();
            array2[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(989170955, -44198590, "\u7b9f\u7faf\u7bbf\u7bbd\u7bcc\u7fad\u7bb9\u7bbf\u7bea\u7faa\u7bb0\u7bdf\u7ba8\u7bbd", 713273263, -859453415);
            "\u50ec".length();
            "\u5da6\u4f62\u6a3c".length();
            "\u6f3d\u5e79".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u63cb\u5ff8".length();
            "\u5247".length();
            "\u583f".length();
            array3[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(-1123810794, 1870908990, "\ud8a2", -1857012110, -1016780134);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (commandSender instanceof Player) {
            final Player obj = (Player)commandSender;
            double double1 = -1.0;
            if (array.length > 0) {
                try {
                    double1 = Double.parseDouble(array[0]);
                }
                catch (NumberFormatException ex) {
                    final Object[] array4 = new Object[2];
                    "\u64e6\u5fe7".length();
                    "\u6046\u5943\u5f0f\u6e99".length();
                    array4[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(740354999, -1812838109, "\ubef8\ubeff\ubef2\ubefa\ube84\ube80\ubefc\ubef9\ubea3\ubef2\ube81\ubedf\ubac1\ubeb2\ubec1\ubed7\ubec1\ubea4\ube8a", -675302059, 1467329895);
                    "\u6ad9\u6aa2".length();
                    "\u5470".length();
                    final int n2 = 1;
                    final Object[] array5 = { null };
                    "\u6fe8\u622f\u6f96\u5772\u5287".length();
                    array5[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(1675126534, 1313407809, "\ue973", -1202268888, -1059825538);
                    array4[n2] = StyleUtils.gray(array5);
                    commandSender.sendMessage(StyleUtils.red(array4));
                    return true;
                }
            }
            int i = 0;
            final Iterator iterator = Bukkit.getWorlds().iterator();
            while (iterator.hasNext()) {
                for (final Entity entity : iterator.next().getEntities()) {
                    if (double1 == -1.0 || obj.getLocation().distance(entity.getLocation()) <= double1) {
                        if (entity instanceof Player) {
                            if (entity.equals(obj)) {
                                continue;
                            }
                            ((Player)entity).setHealth(0.0);
                            i += 4957;
                            i -= 4956;
                        }
                        else {
                            entity.remove();
                            i += 5159;
                            i -= 5158;
                        }
                    }
                }
            }
            if (i > 0) {
                final Object[] array6 = { null };
                "\u59e7\u5ec8".length();
                final int n3 = 0;
                String s2;
                if (double1 == -1.0) {
                    final Object[] array7 = { null };
                    "\u523e\u6fa7".length();
                    "\u6062\u5282\u5046\u70c0\u5589".length();
                    "\u6dfa".length();
                    array7[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(1378625239, -1919857302, "\u9c46\u9c16\u9c60\u9c10\u9875\u9c69\u9c64\u9c12\u9c40\u9ce7", 1792082807, -1935216387);
                    final Component gold = StyleUtils.gold(array7);
                    final Object[] array8 = { null };
                    "\u593c".length();
                    array8[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(-91175226, 506310755, "\u6a7d", 321962614, -1341858100);
                    s2 = invokedynamic(makeConcatWithConstants:(Lnet/kyori/adventure/text/Component;Lnet/kyori/adventure/text/Component;)Ljava/lang/String;, gold, StyleUtils.gray(array8));
                }
                else {
                    final Object[] array9 = { null };
                    "\u5819\u5586".length();
                    array9[0] = double1;
                    final Component gold2 = StyleUtils.gold(array9);
                    final Object[] array10 = { null };
                    "\u4e6d\u6273\u541c".length();
                    "\u6b63\u6b58\u5c05\u6972\u6215".length();
                    "\u56ec\u6a00\u5638\u6fd8\u67c1".length();
                    array10[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(1479254906, -1459092049, "\u04e7", 764041703, 1062730679);
                    s2 = invokedynamic(makeConcatWithConstants:(Lnet/kyori/adventure/text/Component;Lnet/kyori/adventure/text/Component;)Ljava/lang/String;, gold2, StyleUtils.gray(array10));
                }
                array6[n3] = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s2);
                commandSender.sendMessage(StyleUtils.gray(array6));
                final Object[] array11 = { null };
                "\u5c34\u5ca8\u5ef3".length();
                "\u4ff0".length();
                "\u4f86\u69a2\u6ba2\u6ed6".length();
                "\u6e86\u6b7e\u64b8".length();
                "\u5095\u6954\u5d56".length();
                final int n4 = 0;
                final Object[] array12 = { null };
                "\u5d5c\u5002\u6722".length();
                "\u6c02\u5208\u52f4\u70b8\u5597".length();
                "\u6ae9\u647c\u6b0e".length();
                array12[0] = i;
                array11[n4] = invokedynamic(makeConcatWithConstants:(Lnet/kyori/adventure/text/Component;)Ljava/lang/String;, StyleUtils.gold(array12));
                commandSender.sendMessage(StyleUtils.gray(array11));
            }
            else {
                final Object[] array13 = new Object[2];
                "\u6def\u594b\u5325\u624d".length();
                "\u645b\u675c\u6285\u67b7".length();
                "\u5ffc".length();
                array13[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(862186415, -50546785, "\ub94a\ubd55\ub935\ub947\ub945\ub94f\ub93f\ub931\ub969\ubd50", -390737840, 884289915);
                "\u518c\u6725\u5053".length();
                "\u5e9e\u6726".length();
                "\u5cdb\u6e0e\u52dc\u6f79".length();
                final int n5 = 1;
                final Object[] array14 = new Object[2];
                "\u69fe\u5f09\u5b4c\u6aa9\u5e67".length();
                "\u6f04\u589a\u6ea7\u558e".length();
                array14[0] = double1;
                "\u70a3".length();
                "\u6492\u6a52\u6b31".length();
                "\u6b02\u61e2".length();
                "\u678e\u67cc\u565b".length();
                final int n6 = 1;
                final Object[] array15 = { null };
                "\u4f59\u66d3\u5582\u5d97".length();
                "\u597a\u6d8e\u5880\u5a54\u6609".length();
                "\u6b4d".length();
                array15[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(-1771657381, -541317376, "\u953e\u910e\u9106\u9511\u910a\u9101\u9103\u9102\u912f\u910b\u910f\u9503\u9163\u9170\u917b\u911b\u913c\u915f\u9172\uf874\uf37b\uf193", -1943678000, 1345504982);
                array14[n6] = StyleUtils.gray(array15);
                array13[n5] = StyleUtils.gold(array14);
                commandSender.sendMessage(StyleUtils.gray(array13));
            }
            return true;
        }
        final Object[] array16 = new Object[2];
        "\u6f3b\u669d".length();
        "\u7097\u6fee\u6738\u507e\u6d31".length();
        array16[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(1066093343, -1717674983, "\u2f3d\u2f7f\u2f7e\u2b1f\u2f03\u2f01\u2f08\u2f08\u2f29\u2f0c\u2f7c\u2b0d\u2f10\u2f03\u2f0a\u2f15\u2f32\u2b30\u2f06\u460e\u4d73\u4b82\u4da5\u4aaa\u7f52\u4cb4\u487c\u75c9\u4d03\u7a58\u40e9\u7b22\u45a4\u4cd3\u48ad\u4bc1\u7cd5\u4031\u7d38\u4d80\u7915\u41ba\u4f5e\u7477\u779c", -21875632, 1052444677);
        "\u6bee\u5e70\u6d7c\u5d93".length();
        "\u5e38".length();
        "\u68be\u6c44\u691b\u6fa9".length();
        "\u69f1\u629c\u4ebe".length();
        final int n7 = 1;
        final Object[] array17 = { null };
        "\u7078\u61fb\u639f\u6255".length();
        "\u65e1\u6951".length();
        "\u5a61\u6a2b\u4fee\u6c47\u6f94".length();
        array17[0] = \u7001\u6678\u6234\u5869\u5e7c\u590c\u572f\u5d10\u6d93\u52b1\u6830\u6e78\u5d39\u51e5\u4e40\u5fdc\u6abb\u6fb6\u6293\u6947\u5af4\u529f\u6169\u5bea\u66a5\u61c3\u670c\u5509\u5e46\u50f8\u5923\u6a99\u5d23\u5d87\u64ae\u5f19\u600f\u68cb\u5fd2\u525c\u5c81(-2018743704, -647581370, "\ueffb", -1813853400, -1186398305);
        array16[n7] = StyleUtils.gray(array17);
        commandSender.sendMessage(StyleUtils.red(array16));
        return true;
    }
    
    public static int ColonialObfuscator_\u4ee5\u64e9\u70e2\u4ed5\u56ed\u5f1a\u5cec\u6542\u6a86\u4e8f\u5c75\u6ba0\u5498\u5d68\u6d4d\u510e\u5821\u6646\u633e\u6759\u7026\u6ccd\u64a7\u6a14\u6a31\u57c0\u6729\u6d12\u58d9\u57b1\u501c\u70aa\u6ede\u5ef8\u5476\u507f\u6b6c\u5373\u6477\u6a7d\u4e37(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
