package org.mplas.mplas.Commands.Bans;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;
import net.kyori.adventure.text.*;
import org.bukkit.event.player.*;
import org.bukkit.entity.*;

public class kick implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!commandSender.hasPermission(\u5877\u6eeb\u5ebc\u64c1\u6af3\u5199\u63d4\u6220\u5c4a\u6067\u6129\u5db7\u6ee5\u6c1c\u5eb1\u6695\u5f17\u605b\u70b2\u502b\u52b3\u4e6f\u60db\u67ef\u6a19\u5ef3\u64df\u6c7e\u6040\u6229\u6e60\u5c32\u6d19\u5629\u6119\u54ae\u548c\u545b\u5dea\u5742\u63ab(205334527, -921307374, "\u8542\u8574\u856a\u8567\u8575\u8520\u8566\u856d\u8546\u8568\u856a", 118013427, -1671632782)) || commandSender.hasPermission(\u5877\u6eeb\u5ebc\u64c1\u6af3\u5199\u63d4\u6220\u5c4a\u6067\u6129\u5db7\u6ee5\u6c1c\u5eb1\u6695\u5f17\u605b\u70b2\u502b\u52b3\u4e6f\u60db\u67ef\u6a19\u5ef3\u64df\u6c7e\u6040\u6229\u6e60\u5c32\u6d19\u5629\u6119\u54ae\u548c\u545b\u5dea\u5742\u63ab(-1060524979, -68760337, "\u65aa\u6564\u657a\u6577\u6565\u6538\u657d\u6570\u655d\u6578\u6564", -1036213377, 360293977))) {
            if (array.length == 0) {
                final Object[] array2 = new Object[2];
                "\u5f50\u5aec".length();
                "\u5f28\u689f\u53a9".length();
                "\u6a6a".length();
                array2[0] = \u5877\u6eeb\u5ebc\u64c1\u6af3\u5199\u63d4\u6220\u5c4a\u6067\u6129\u5db7\u6ee5\u6c1c\u5eb1\u6695\u5f17\u605b\u70b2\u502b\u52b3\u4e6f\u60db\u67ef\u6a19\u5ef3\u64df\u6c7e\u6040\u6229\u6e60\u5c32\u6d19\u5629\u6119\u54ae\u548c\u545b\u5dea\u5742\u63ab(456005330, 2069874706, "\u360a\u367e\u361c\u361f\u3618\u3669\u361d\u3618\u3634\u361a\u361c\u360b\u3603\u321d\u3202\u3219\u3245\u325b\u3243\u56c5\u6fbc\u549a\u7dad\u5b93\u57fe\u5af5\u6c7d\u5b57\u69e6\u67ea\u5027\u517a\u5277\u655b\u6331\u7db6\u59c9\u6cf3", 1748403726, 1185376927);
                "\u6518\u7144\u6d54\u4fad\u5485".length();
                "\u6966".length();
                "\u6c1e\u5598".length();
                "\u65c8\u6614\u6738\u620e".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u5d36\u6122\u5c1b\u5657".length();
                "\u707e\u57f1".length();
                "\u5283".length();
                "\u6cfc\u6600\u52cb\u602d\u642c".length();
                "\u6502\u6e6b\u64bc\u4f19".length();
                array3[0] = \u5877\u6eeb\u5ebc\u64c1\u6af3\u5199\u63d4\u6220\u5c4a\u6067\u6129\u5db7\u6ee5\u6c1c\u5eb1\u6695\u5f17\u605b\u70b2\u502b\u52b3\u4e6f\u60db\u67ef\u6a19\u5ef3\u64df\u6c7e\u6040\u6229\u6e60\u5c32\u6d19\u5629\u6119\u54ae\u548c\u545b\u5dea\u5742\u63ab(143905790, -894753754, "\u8747", -1968693800, 452816170);
                array2[n] = StyleUtils.gray(array3);
                commandSender.sendMessage(StyleUtils.red(array2));
                return false;
            }
            if (array.length < 2) {
                final Object[] array4 = new Object[2];
                "\u6472\u5abd\u6c65\u5587".length();
                array4[0] = \u5877\u6eeb\u5ebc\u64c1\u6af3\u5199\u63d4\u6220\u5c4a\u6067\u6129\u5db7\u6ee5\u6c1c\u5eb1\u6695\u5f17\u605b\u70b2\u502b\u52b3\u4e6f\u60db\u67ef\u6a19\u5ef3\u64df\u6c7e\u6040\u6229\u6e60\u5c32\u6d19\u5629\u6119\u54ae\u548c\u545b\u5dea\u5742\u63ab(-762572967, -924207420, "\uca25\uca51\uca2f\uca2c\uca2f\uca5e\uca2e\uca2b\uca0b\uca25\uca2f\uca38\uca34\uce2a\uce31\uce2a\uce6a\uce74\uce50\uaad6\u93ab\ua88d\u81be\ua780\uabe1\ua6ea\u906e\ua744\u95f1\u9bfd\uac34\uad69\uae98\u99b4\u9fc2\u8145\ua53e\u9004", 200790880, -104225661);
                "\u59ff\u6a66\u705c\u6410\u5564".length();
                "\u68a0\u5a93\u5eb6\u6120".length();
                final int n2 = 1;
                final Object[] array5 = { null };
                "\u6758\u5b8b\u61a2".length();
                "\u6123\u6023".length();
                array5[0] = \u5877\u6eeb\u5ebc\u64c1\u6af3\u5199\u63d4\u6220\u5c4a\u6067\u6129\u5db7\u6ee5\u6c1c\u5eb1\u6695\u5f17\u605b\u70b2\u502b\u52b3\u4e6f\u60db\u67ef\u6a19\u5ef3\u64df\u6c7e\u6040\u6229\u6e60\u5c32\u6d19\u5629\u6119\u54ae\u548c\u545b\u5dea\u5742\u63ab(-1224471110, 547884841, "\u38f4", -312793793, 292167477);
                array4[n2] = StyleUtils.gray(array5);
                commandSender.sendMessage(StyleUtils.red(array4));
                return false;
            }
            final Player player = Bukkit.getPlayer(array[0]);
            "\u7092\u5913\u61c5\u5b9e\u6d66".length();
            "\u6a38".length();
            "\u66f7\u5966\u5969\u513e\u6418".length();
            "\u6b45\u5db8\u57f0\u51b1\u5f77".length();
            "\u5261\u62de\u5055\u5546\u5567".length();
            final StringBuilder sb = new StringBuilder();
            for (int i = 1; i < array.length; i -= 19153, i += 19154) {
                sb.append(array[i]);
                "\u6025\u559d\u7126".length();
                "\u6544\u6118".length();
                final int n3 = i;
                final int length = array.length;
                final int n4 = 1;
                "\u6b69\u4fac\u5dc9".length();
                if (n3 < length - n4) {
                    sb.append(\u5877\u6eeb\u5ebc\u64c1\u6af3\u5199\u63d4\u6220\u5c4a\u6067\u6129\u5db7\u6ee5\u6c1c\u5eb1\u6695\u5f17\u605b\u70b2\u502b\u52b3\u4e6f\u60db\u67ef\u6a19\u5ef3\u64df\u6c7e\u6040\u6229\u6e60\u5c32\u6d19\u5629\u6119\u54ae\u548c\u545b\u5dea\u5742\u63ab(991799758, -1569213704, "\u10a1", -840339472, 1107649540));
                    "\u55f3".length();
                    "\u6f7c\u5193".length();
                    "\u5541\u5392\u6139\u6690\u6b6c".length();
                    "\u6a51\u67b5".length();
                }
            }
            final String string = sb.toString();
            player.kick((Component)Component.text(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, string)), PlayerKickEvent.Cause.PLUGIN);
            final Object[] array6 = new Object[2];
            "\u531f\u62ea\u7083\u5eab\u4efc".length();
            "\u6fe4\u6753\u5aa3\u650b\u53fd".length();
            "\u5a8d\u55b9\u5864\u681c".length();
            "\u6d8d\u5760\u6e7f\u650b\u6de0".length();
            array6[0] = player.getName();
            "\u5956\u6446\u6b7b\u55c8\u4f62".length();
            "\u5cdf\u5a65\u6bc1".length();
            "\u5bdd\u592f\u50ad\u66e5".length();
            final int n5 = 1;
            final Object[] array7 = new Object[2];
            "\u6524\u5ea1\u6dd6".length();
            "\u5604".length();
            array7[0] = \u5877\u6eeb\u5ebc\u64c1\u6af3\u5199\u63d4\u6220\u5c4a\u6067\u6129\u5db7\u6ee5\u6c1c\u5eb1\u6695\u5f17\u605b\u70b2\u502b\u52b3\u4e6f\u60db\u67ef\u6a19\u5ef3\u64df\u6c7e\u6040\u6229\u6e60\u5c32\u6d19\u5629\u6119\u54ae\u548c\u545b\u5dea\u5742\u63ab(-1855260185, 742544239, "\ub3b0\ub78c\ub7fa\ub788\ub391\ub78d\ub780\ub78e\ub7a9\ub7fb\ub701\ub371\ub76b\ub77b\ub360\ub76b\ub70c\ub768\ub735\ud3c4\ueaf3\ud1a6\ufcb5\uda8d", 757863030, -1236792531);
            "\u54e1".length();
            "\u5157\u5559".length();
            "\u6b75\u6b04".length();
            "\u58bb\u70ea\u5cbf".length();
            "\u5d26\u6606\u67dc\u5139".length();
            final int n6 = 1;
            final Object[] array8 = { null };
            "\u5d32\u6455".length();
            "\u6332".length();
            "\u5bda\u52d6\u6e1a\u4f1f".length();
            array8[0] = string;
            array7[n6] = StyleUtils.gold(array8);
            array6[n5] = StyleUtils.gray(array7);
            Bukkit.broadcast(StyleUtils.gold(array6));
            "\u5059\u6609".length();
            "\u6598\u5ecf\u4fd7\u633f\u53be".length();
        }
        else {
            final Object[] array9 = new Object[2];
            "\u68c0\u5515\u5234\u6037".length();
            "\u54b3\u5660".length();
            "\u68ae\u4e4f\u5f65\u58d8\u6375".length();
            "\u6164".length();
            array9[0] = \u5877\u6eeb\u5ebc\u64c1\u6af3\u5199\u63d4\u6220\u5c4a\u6067\u6129\u5db7\u6ee5\u6c1c\u5eb1\u6695\u5f17\u605b\u70b2\u502b\u52b3\u4e6f\u60db\u67ef\u6a19\u5ef3\u64df\u6c7e\u6040\u6229\u6e60\u5c32\u6d19\u5629\u6119\u54ae\u548c\u545b\u5dea\u5742\u63ab(210003840, 1080519679, "\u56da\u52f4\u56ea\u56ea\u5699\u52fe\u56ec\u56e8\u56bf\u52f1\u5715\u5778\u570d\u571e", 49775350, -230958029);
            "\u5cdb".length();
            "\u6f3a\u59cc".length();
            "\u67bf\u6fa3\u6426".length();
            final int n7 = 1;
            final Object[] array10 = { null };
            "\u4f1e\u4f16\u5339".length();
            "\u51c5\u5efc\u5acb\u6757\u5e61".length();
            "\u698e\u6c48\u5c9c\u64e5".length();
            "\u60cd".length();
            array10[0] = \u5877\u6eeb\u5ebc\u64c1\u6af3\u5199\u63d4\u6220\u5c4a\u6067\u6129\u5db7\u6ee5\u6c1c\u5eb1\u6695\u5f17\u605b\u70b2\u502b\u52b3\u4e6f\u60db\u67ef\u6a19\u5ef3\u64df\u6c7e\u6040\u6229\u6e60\u5c32\u6d19\u5629\u6119\u54ae\u548c\u545b\u5dea\u5742\u63ab(1305775028, 771586937, "\u1be0", -882641508, 379526867);
            array9[n7] = StyleUtils.gray(array10);
            commandSender.sendMessage(StyleUtils.red(array9));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u713f\u5717\u62e4\u5fd8\u4f82\u6903\u67bf\u6433\u500e\u6534\u5b6c\u6f84\u62cd\u6ea3\u5185\u55f5\u6c63\u6038\u5509\u6335\u60a0\u5dfc\u6cee\u5622\u5e98\u54e7\u5948\u67de\u708a\u6369\u694f\u5295\u6be7\u68e3\u6916\u583c\u67db\u4e40\u53ec\u5c89\u589d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
