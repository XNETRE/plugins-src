package org.mplas.mplas.Commands.Bans;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;
import org.bukkit.entity.*;
import java.util.*;
import net.kyori.adventure.text.*;

public class Kickall implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (command.getName().equalsIgnoreCase(\u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(-1914049734, 1310554209, "\u571a\u5733\u573b\u5733\u5739\u570c\u5705", 792834843, -1506969742))) {
            if (!commandSender.hasPermission(\u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(1831744893, 176682840, "\u9683\u96b1\u96af\u96a6\u96b4\u96ed\u96ab\u969c\u96b7\u969d\u969f", -1468282151, 86482513)) || commandSender.hasPermission(\u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(-721818665, 1078524284, "\ued72\ued7c\ued62\ued6f\ued7d\ued20\ued6c\ued60\ued48\ued62\ued6d\ued70\ued77", -1164324385, 864628264))) {
                if (commandSender instanceof Player) {
                    final Player obj = (Player)commandSender;
                    double double1 = -1.0;
                    if (array.length > 0) {
                        try {
                            double1 = Double.parseDouble(array[0]);
                        }
                        catch (NumberFormatException ex) {
                            final Object[] array2 = new Object[2];
                            "\u6fa1\u5399\u5f90\u6ba7".length();
                            "\u5b0e\u589a\u55dd\u5198".length();
                            array2[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(-573229492, 1631020857, "\uf3c4\uf3c3\uf3ce\uf3d6\uf3a8\uf3ac\uf3d0\uf3d5\uf38f\uf3de\uf3ad\uf3c3\uf7dd\uf3ae\uf3dd\uf3cb\uf3dd\uf3b8\uf396", 1149983917, 1142291010);
                            "\u6292\u6a6b\u7065".length();
                            final int n = 1;
                            final Object[] array3 = { null };
                            "\u69a2".length();
                            "\u542a\u5a9d\u52a6\u50ee\u528c".length();
                            "\u6e9e\u6a1f\u6133\u57c6\u62db".length();
                            "\u5574\u60f4\u5145\u6bbd".length();
                            array3[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(-2099575646, -1452344670, "\u0422", -220980537, 1230626951);
                            array2[n] = StyleUtils.gray(array3);
                            commandSender.sendMessage(StyleUtils.red(array2));
                            return true;
                        }
                    }
                    int i = 0;
                    final Iterator iterator = Bukkit.getWorlds().iterator();
                    while (iterator.hasNext()) {
                        for (final Entity entity : iterator.next().getEntities()) {
                            if ((double1 == -1.0 || obj.getLocation().distance(entity.getLocation()) <= double1) && entity instanceof Player && !entity.equals(obj)) {
                                ((Player)entity).kickPlayer(\u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(1277852944, -38942007, "\u19e6\u1992\u1de5\u19f6\u198e\u19f8\u19f4\u1de0\u19da\u19f4\u19fd\u19e8\u1993\u1983\u198f\u1df0\u19f8\u19e0\u19fa\u7b7f\u7b74\u788e\u794e\u7393\u7ecb\u719a\u4e9d\u7eae\u42e8\u42ba\u4850\u7f24", -1171267186, -139768864));
                                i += 17383;
                                i -= 17382;
                            }
                        }
                    }
                    if (i > 0) {
                        final Object[] array4 = { null };
                        "\u52d1".length();
                        "\u660a\u6db2\u6773".length();
                        "\u6936".length();
                        "\u54c2\u6975\u5176\u6028\u5393".length();
                        final int n2 = 0;
                        String s2;
                        if (double1 == -1.0) {
                            final Object[] array5 = { null };
                            "\u57c9".length();
                            "\u6752".length();
                            "\u60a0\u530e".length();
                            "\u62be\u70ff\u70e9\u6fa5".length();
                            array5[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(-2068475753, 1978122729, "\u460a\u4654\u4620\u4652\u4239\u4623\u462c\u4658\u4602\u4622", -639387148, 1570089713);
                            final Component gold = StyleUtils.gold(array5);
                            final Object[] array6 = { null };
                            "\u70ee".length();
                            "\u6194\u547c\u6b2e".length();
                            "\u56cc\u711f".length();
                            "\u60fd".length();
                            array6[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(483720430, -1202585983, "\u780e", -152649439, -652297438);
                            s2 = invokedynamic(makeConcatWithConstants:(Lnet/kyori/adventure/text/Component;Lnet/kyori/adventure/text/Component;)Ljava/lang/String;, gold, StyleUtils.gray(array6));
                        }
                        else {
                            final Object[] array7 = { null };
                            "\u6e8a\u5c01\u6bc0\u5514\u5432".length();
                            "\u5db7\u5988\u682c\u6844".length();
                            array7[0] = double1;
                            final Component gold2 = StyleUtils.gold(array7);
                            final Object[] array8 = { null };
                            "\u6e9b\u595d\u6faf".length();
                            "\u5343\u593f\u5b1d\u5e77\u70fc".length();
                            array8[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(228307582, -782201010, "\u84a2", -502237114, -1802714698);
                            s2 = invokedynamic(makeConcatWithConstants:(Lnet/kyori/adventure/text/Component;Lnet/kyori/adventure/text/Component;)Ljava/lang/String;, gold2, StyleUtils.gray(array8));
                        }
                        array4[n2] = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s2);
                        commandSender.sendMessage(StyleUtils.gray(array4));
                        final Object[] array9 = { null };
                        "\u6e41\u6595\u5ad2\u5c4b\u557d".length();
                        "\u5f13\u6fa8".length();
                        "\u62ac\u570e".length();
                        final int n3 = 0;
                        final Object[] array10 = { null };
                        "\u65e7\u5a86\u54a7\u5d5c\u50b9".length();
                        "\u5e99\u6ab5".length();
                        array10[0] = i;
                        array9[n3] = invokedynamic(makeConcatWithConstants:(Lnet/kyori/adventure/text/Component;)Ljava/lang/String;, StyleUtils.gold(array10));
                        commandSender.sendMessage(StyleUtils.gray(array9));
                    }
                    else {
                        final Object[] array11 = new Object[2];
                        "\u6328".length();
                        "\u65ba\u556b\u4f5c".length();
                        "\u6934\u6887\u6864".length();
                        array11[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(-1217439590, -1245002959, "\u3b4d\u3f5c\u3b3e\u3b4e\u3b4a\u3b46\u3b34\u3b38\u3b6e\u3f69", -1157794473, 323080672);
                        "\u63f6".length();
                        "\u56ec\u62c3\u590f\u555e".length();
                        "\u6bd9\u5fdb".length();
                        final int n4 = 1;
                        final Object[] array12 = new Object[2];
                        "\u51dc".length();
                        "\u57b7\u6360\u6c0f\u51b3\u6be0".length();
                        "\u5e6f\u5556\u6da2\u6493\u704f".length();
                        array12[0] = double1;
                        "\u6a3c\u668e\u51c5\u599f\u582f".length();
                        final int n5 = 1;
                        final Object[] array13 = { null };
                        "\u4f2e\u6624".length();
                        "\u5aa2\u6f0c\u6c69\u51c6\u4f8b".length();
                        array13[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(36696729, 651637449, "\ue8b9\uec89\uec81\ue896\uec8d\uec86\uec84\uec85\ueca8\uec8c\uec88\ue884\uec9d\uec87\uecf5\uec9f\uecbf\ueca7\uec85\u8a17", 986469456, -1622770470);
                        array12[n5] = StyleUtils.gray(array13);
                        array11[n4] = StyleUtils.gold(array12);
                        commandSender.sendMessage(StyleUtils.gray(array11));
                    }
                    return true;
                }
                final Object[] array14 = new Object[2];
                "\u6293\u56a3".length();
                "\u67ce\u5202\u5e6f\u7054\u706e".length();
                array14[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(819606090, 1713768030, "\u3f2d\u3f6d\u3f6e\u3b09\u3f13\u3f13\u3f18\u3f16\u3f39\u3f1e\u3f6c\u3b1b\u3f00\u3f11\u3f1a\u3efb\u3ee2\u3ae2\u3ed6\u5c28\u5c5a\u5fa6\u5e1c\u54bb\u5998\u56b2\u69c5\u598e\u65c6\u65e6\u6b64\u5c7e\u6387\u5ff5\u510e\u68d3\u6eef\u5413\u5a6d\u5256\u64b0\u5657\u6778\u6513\u5e6b", -149836559, -322067546);
                "\u5669\u6e1c\u5cd1\u68de".length();
                "\u6072\u567f".length();
                "\u5828\u5f0b".length();
                "\u70db\u5bab\u6013".length();
                final int n6 = 1;
                final Object[] array15 = { null };
                "\u5ba3\u6594\u51f5".length();
                array15[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(1859394629, -358496050, "\ubd75", -556336611, -267611263);
                array14[n6] = StyleUtils.gray(array15);
                commandSender.sendMessage(StyleUtils.red(array14));
                return true;
            }
            else {
                final Object[] array16 = new Object[2];
                "\u6393\u6271".length();
                "\u6a4f".length();
                array16[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(2116655178, -1818914027, "\u83ae\u867e\u826e\u826c\u821d\u867c\u8268\u826e\u823b\u867b\u8261\u820e\u8279\u826c", -1842827009, -1270793106);
                "\u5b43".length();
                "\u51e7".length();
                final int n7 = 1;
                final Object[] array17 = { null };
                "\u5141\u5d4c\u6462\u655a".length();
                "\u52d2\u693b\u6e03".length();
                "\u6e34\u6849\u7082\u67bf\u64b7".length();
                array17[0] = \u5683\u5340\u5761\u4f4f\u6f70\u539b\u6c82\u6744\u5c66\u563e\u60ac\u56fb\u6d63\u6240\u5c51\u6072\u5f76\u6d33\u6989\u621f\u6d88\u544b\u52cf\u5139\u567e\u605c\u6e47\u6264\u5870\u5418\u52dc\u6758\u5cf7\u6102\u7130\u5106\u6bc8\u5d58\u4e24\u6b26\u5423(-1992202108, 265084435, "\ueada", 2015410612, -428350053);
                array16[n7] = StyleUtils.gray(array17);
                commandSender.sendMessage(StyleUtils.red(array16));
            }
        }
        return false;
    }
    
    public static int ColonialObfuscator_\u556b\u4f37\u5c47\u5376\u5dc1\u54cd\u5959\u6d46\u612c\u5394\u6810\u6eea\u6a96\u58c8\u5ac9\u6f2d\u68bb\u51cf\u5818\u57ad\u5975\u61fb\u505b\u53c1\u51f6\u54ac\u5f96\u54f5\u528c\u5241\u55fd\u55ca\u56c2\u5804\u66ea\u5c39\u67b9\u684d\u64a9\u664f\u5eb8(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
