package org.mplas.mplas.Commands.Others;

import cloud.commandframework.paper.*;
import org.bukkit.command.*;
import cloud.commandframework.*;
import cloud.commandframework.bukkit.parsers.*;
import org.mplas.mplas.Companents.*;
import cloud.commandframework.context.*;
import org.bukkit.*;
import org.mplas.mplas.*;
import net.kyori.adventure.text.*;
import org.bukkit.plugin.*;
import org.bukkit.potion.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import java.util.*;

public class Vanish implements Listener
{
    public Vanish(final PaperCommandManager<CommandSender> paperCommandManager) {
        final CommandSender commandSender;
        Object o;
        Object[] array;
        Object[] array2;
        final Object o2;
        final Object o3;
        paperCommandManager.command(paperCommandManager.commandBuilder(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(1113877847, -1012623445, "\uc73e\uc702\uc70f\uc708\uc712\uc701", 1883668083, 610878340), ArgumentDescription.of(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(264383893, 547458770, "\ua7c2\ua7c5\ua7c5\ua7c9\ua7c4\ua7cd\ua7c0\ua3de\ua7e8\ua7d5\ua7a4\ua3db\ua7ce\ua7db\ua7d5\ua7c6\ua7ac\ua7c6", 431013479, -937509189)), new String[] { \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(914084546, -963419810, "\uf0c9", -1337643995, 945581893) }).argument(OfflinePlayerArgument.builder(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(235997723, 1393307720, "\u91c0\u91f1\u91f0\u91ea\u91f4\u91e5", 784862790, 1159308774)).asOptional().build()).handler(commandContext -> {
            commandSender = commandContext.getSender();
            o = commandContext.getOrDefault(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(1688161059, -579095412, "\ue8e8\ue8d9\ue8c8\ue8d2\ue8cc\ue8dd", 140149902, 1887409146), (OfflinePlayer)null);
            if (o == null) {
                if (commandSender instanceof Player) {
                    o = commandSender;
                }
                else {
                    array = new Object[2];
                    "\u6823\u5118".length();
                    array[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-1687398190, -1748890227, "\ube1f\ube5d\ube2f\uba3d\ube21\ube23\ube2a\ube2a\ube0b\ube2e\ube2d\uba2f\ube3f\ube2a\ube29\uba2a\ube1e\ube72\ube2f\ud4f7\ud1f3\ue846\uebe2\ud79b\ue79f\ud07e\ud5d1\ueff4\uef97\ueea8\ud479\ue331\ue1b4\ud076\uf404\uda31\ued9e\ucf7c\ud595\ud133\uf1a2\udf16\ud8cd\uddd3\uf191\udc38\ue42e\ud863\uf199\uec45", -1066597104, 1447684670);
                    "\u5bc0\u5c8d\u54d3\u561f".length();
                    "\u5a3e\u6e59\u67a0".length();
                    "\u645f\u6cb7\u5480\u6c73".length();
                    array2 = new Object[] { null };
                    "\u526f".length();
                    "\u565d".length();
                    "\u6419".length();
                    array2[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(1594031067, -157004708, "\u2852", -433420518, -1794041683);
                    array[o2] = StyleUtils.gray(array2);
                    ((CommandSender)o3).sendMessage(StyleUtils.red(array));
                    return;
                }
            }
            this.handle(commandContext, (OfflinePlayer)o);
            return;
        }).permission(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-563800592, 1872168920, "\u6840\u6870\u6990\u699f\u698f\u69d4\u6983\u6998\u69b7\u699c\u698d\u6984", -722471170, 932482232)));
        final CommandSender commandSender2;
        Object o4;
        Object[] array3;
        Object[] array4;
        final Object o5;
        final Object o6;
        paperCommandManager.command(paperCommandManager.commandBuilder(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-604549254, -2076956433, "\u9d23\u9d1b\u9d01\u9d16\u9d19\u9d1e\u9d0d\u9d18", -1502706073, -848528153), ArgumentDescription.of(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-1351102078, 985633604, "\u05db\u05d2\u05d0\u05de\u05dd\u05d2\u05dd\u01c1\u05f1\u05d2\u05a1\u01dc\u05d5\u05c9\u05c7\u05d1\u05c0\u05d9\u0587\u6f57", -1139590396, -897288128)), new String[] { \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-1585801934, -1139445393, "\ude1e\ude32", -711689079, -1235925252) }).argument(OfflinePlayerArgument.builder(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-964391376, 1817552736, "\uf84c\uf87f\uf870\uf894\uf888\uf89b", 1799513213, 79344978)).asOptional().build()).handler(commandContext2 -> {
            commandSender2 = commandContext2.getSender();
            o4 = commandContext2.getOrDefault(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(1187628942, -1723817380, "\uce8a\ucebb\uceb6\uceac\uceb6\ucea7", -143908552, -1586656685), (OfflinePlayer)null);
            if (o4 == null) {
                if (commandSender2 instanceof Player) {
                    o4 = commandSender2;
                }
                else {
                    array3 = new Object[2];
                    "\u59e2".length();
                    "\u5ca5\u713d\u591c\u6147\u5d65".length();
                    array3[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(875028938, 878922379, "\uc46b\uc429\uc45f\uc04d\uc455\uc457\uc442\uc442\uc46f\uc44a\uc44d\uc04f\uc45b\uc44e\uc441\uc042\uc44a\uc426\uc47f\uaea7\uaba7\u9212\u904a\uac33\u9c3b\uabda\uae71\u9454\u9433\u950c\uafd1\u9899\u9a00\uabc2\u8fb4\ua181\u962a\ub4c8\uae3d\uaa9b\u8a06\ua4b2\ua36d\ua673\u8a35\ua79c\u9f86\ua3cb\u8a4d", 522509034, -1471172178);
                    "\u5c38".length();
                    "\u6f4d".length();
                    "\u66c6\u54d6\u6eef".length();
                    array4 = new Object[] { null };
                    "\u6a38\u5385\u524e".length();
                    "\u706f\u5285\u6d5d\u6ee4".length();
                    "\u6f00\u617e\u6c1e".length();
                    array4[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-689009924, 441687063, "\ud68c", -1759592151, 1980170540);
                    array3[o5] = StyleUtils.gray(array4);
                    ((CommandSender)o6).sendMessage(StyleUtils.red(array3));
                    return;
                }
            }
            this.unvanish(((OfflinePlayer)o4).getUniqueId(), false);
        }).permission(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(594759042, -134252567, "\u1d08\u1d06\u1d18\u1d15\u1d07\u1d5a\u1d0b\u1d12\u1d3f\u1d1a\u1d05\u1d0e", -952273825, -1928965358)));
    }
    
    public void handle(final CommandContext<CommandSender> commandContext, final OfflinePlayer offlinePlayer) {
        this.toggleVanish(offlinePlayer.getUniqueId());
        "\u6b53\u56b5\u6216\u60fa".length();
        "\u6040\u633f\u5885".length();
        "\u707d\u5a72\u6918".length();
        "\u5a35\u5ef7".length();
    }
    
    public boolean toggleVanish(final UUID uuid) {
        if (Vanish.vanishedUUIDS.contains(uuid)) {
            this.unvanish(uuid, false);
            return false;
        }
        this.vanish(uuid, false);
        return true;
    }
    
    public void vanish(final UUID uuid, final boolean b) {
        if (Bukkit.getPlayer(uuid) == null) {
            return;
        }
        Object[] array;
        final Player player;
        final Iterator<Player> iterator;
        Player player2;
        Component[] array2;
        Object[] array3;
        final Object o;
        Object[] array4;
        final Object o2;
        final Object o3;
        final PotionEffect potionEffect;
        final PotionEffect potionEffect2;
        Object[] array5;
        Object[] array6;
        Bukkit.getScheduler().runTask((Plugin)Mplas.getInstance(), () -> {
            if (!isVanished(uuid) && !b) {
                Vanish.vanishedUUIDS.add(uuid);
                "\u53d4".length();
                "\u65e0\u70fe".length();
                "\u6869\u5c45".length();
                array = new Object[] { null };
                "\u65f1\u6287\u6c78\u5944\u55c2".length();
                "\u5512".length();
                array[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(980413989, -1896981081, "\ua97a\ua90e\uad69\ua909\ua97c\ua970\ua975\ua90c\ua920\uad60\ua909\uad09\ua91e\ua90d\ua905\ua914\ua97c\ua91d\uad24", 1892037686, -30659937);
                player.sendMessage(StyleUtils.gold(array));
                Bukkit.getOnlinePlayers().iterator();
                while (iterator.hasNext()) {
                    player2 = iterator.next();
                    if (player2.hasPermission(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-96747509, 1690963906, "\u612b\u611b\u6107\u6108\u6114\u614f\u611c\u6107\u612c\u6107\u611a\u6113", -780968492, 1379267352))) {
                        array2 = new Component[2];
                        "\u64f3\u555e\u5c09".length();
                        "\u6f8b\u554a\u50de\u63a5".length();
                        array3 = new Object[] { null };
                        "\u66a5".length();
                        "\u55b8\u6a04\u63a7\u63f3".length();
                        array3[0] = player.getName();
                        array2[o] = StyleUtils.white(array3);
                        "\u5305\u533b".length();
                        "\u5a48\u6202\u6275\u6265".length();
                        array4 = new Object[] { null };
                        "\u65dd\u5a7b".length();
                        array4[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(672409088, 1378024313, "\ub90f\ubd40\ubd37\ubd3f\ubd2b\ubd58\ubd5f\ub93f\ubd09\ub937\ubd22\ubd32\ubd36\ubd22\ubd53\ubd3a\ub93d", 294648940, 1987680377);
                        array2[o2] = StyleUtils.gold(array4);
                        ((Player)o3).sendMessage(StyleUtils.single(array2));
                    }
                    else {
                        player2.hideEntity((Plugin)Mplas.getInstance(), (Entity)player);
                    }
                }
                player.setAffectsSpawning(false);
                player.setSleepingIgnored(true);
                // new(org.bukkit.potion.PotionEffect.class)
                "\u609b\u4e83\u6e2f\u579e\u5f21".length();
                "\u58d2\u5609\u6937\u6189".length();
                "\u511f\u6419\u518e\u4ef6\u52f2".length();
                "\u5e41\u6f25\u4e37\u6612\u5af9".length();
                "\u5f8f\u5374\u4f91\u63ca\u51eb".length();
                new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 17, false, false, false);
                player.addPotionEffect(potionEffect);
                "\u5105\u66bd\u5f46".length();
                "\u7011\u5344".length();
                "\u6b6d\u5803".length();
                "\u5cdb\u5ac9".length();
                "\u65e4\u628d".length();
                // new(org.bukkit.potion.PotionEffect.class)
                "\u5224\u5a32\u55da\u6dc3\u5bf7".length();
                "\u517e\u58f9\u4f45".length();
                "\u5b8c\u5c9b\u6ca2".length();
                "\u59c5\u6052\u51b0\u6dc1\u6a09".length();
                "\u62c2\u5f2c".length();
                new PotionEffect(PotionEffectType.GLOWING, Integer.MAX_VALUE, 1, false, false, false);
                player.addPotionEffect(potionEffect2);
                "\u67bf\u5da2\u6092\u6cf3".length();
                array5 = new Object[] { null };
                "\u683d\u641f\u64a3\u6c2c\u5a02".length();
                "\u6ef6\u6935\u5117\u636b".length();
                "\u66b9\u6210\u6ef3".length();
                "\u69c7".length();
                array5[0] = player.displayName();
                player.playerListName(StyleUtils.strikethrough(array5));
            }
            else {
                array6 = new Object[] { null };
                "\u66d0\u64fe".length();
                "\u5584\u5fd5\u6342\u6230\u5d34".length();
                array6[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(680676054, 722193862, "\uc7f0\uc7fa\uc393\uc7f0\uc785\uc786\uc39a\uc786\uc3b6\uc786\uc781\uc79c\uc79e\uc7f9\uc787\uc385", -1490330817, 2108759950);
                player.sendMessage(StyleUtils.gold(array6));
            }
            return;
        });
        "\u5ee7\u6e8f\u644a\u540f".length();
        "\u4ead\u632b\u7144\u597d".length();
        "\u5535\u6367\u5447".length();
    }
    
    public void unvanish(final UUID uuid, final boolean b) {
        if (Bukkit.getPlayer(uuid) == null) {
            return;
        }
        Object[] array;
        final Player player;
        final Iterator<Player> iterator;
        Player player2;
        Component[] array2;
        Object[] array3;
        final Object o;
        Object[] array4;
        final Object o2;
        final Object o3;
        Object[] array5;
        Object[] array6;
        final Object o4;
        Bukkit.getScheduler().runTask((Plugin)Mplas.getInstance(), () -> {
            if (isVanished(uuid) && !b) {
                Vanish.vanishedUUIDS.remove(uuid);
                "\u5dcb".length();
                "\u5e8b\u55d0\u6579".length();
                "\u7005\u60e7\u6e78".length();
                array = new Object[] { null };
                "\u59f6\u614f\u5764\u6058\u5e88".length();
                "\u6ca6\u56df\u70fe\u6ccc\u5a3c".length();
                array[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(361626856, 728539819, "\u5aed\u5a99\u5ef6\u5ae5\u5ae8\u5aeb\u5a9b\u5a93\u5ace\u5ef7\u5ae9\u5af3\u5ee3\u5ae0\u5ecf\u5ac9\u5ad3\u5ac2\u5aed\u3035\u3537\u0890", 235731410, 912062765);
                player.sendMessage(StyleUtils.gold(array));
                Bukkit.getOnlinePlayers().iterator();
                while (iterator.hasNext()) {
                    player2 = iterator.next();
                    if (player2.hasPermission(\u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-742296633, -215341158, "\u10b5\u1085\u1085\u108a\u109a\u10c1\u1096\u108d\u10a2\u1089\u1098\u1091", 1992540814, 2085586504))) {
                        array2 = new Component[2];
                        "\u6237\u5755\u5229\u5831".length();
                        "\u632c\u6edc".length();
                        "\u67f0\u5c6f".length();
                        "\u50a0\u6569\u558f\u61c7".length();
                        array3 = new Object[] { null };
                        "\u5cd5\u6627\u4eb2".length();
                        "\u63f6\u53d0".length();
                        "\u6554\u54ec\u711c".length();
                        array3[0] = player.getName();
                        array2[o] = StyleUtils.white(array3);
                        "\u597e\u6d48".length();
                        "\u60ad\u660e\u54ba\u6db9".length();
                        "\u690e\u5e96\u5f86\u7074".length();
                        array4 = new Object[] { null };
                        "\u552a".length();
                        "\u625a\u565a\u688c\u541c\u66f9".length();
                        array4[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-835163879, -1570141650, "\u5e9e\u5aa0\u5aad\u5ab4\u5ac3\u5ac3\u5ab7\u5ea8\u5a97\u5ab1\u5ea1\u5aaf\u5eba\u5abb\u5aba\u5aa5\u5aba\u5ad4\u5a85\u35c8", 175178477, -545079513);
                        array2[o2] = StyleUtils.gold(array4);
                        ((Player)o3).sendMessage(StyleUtils.single(array2));
                    }
                    player2.showEntity((Plugin)Mplas.getInstance(), (Entity)player);
                }
                player.setAffectsSpawning(true);
                player.setSleepingIgnored(false);
                player.removePotionEffect(PotionEffectType.INVISIBILITY);
                player.removePotionEffect(PotionEffectType.GLOWING);
                player.playerListName(player.displayName());
            }
            else {
                array5 = new Object[2];
                "\u5167\u59ea\u7052".length();
                "\u55eb".length();
                "\u6a3e\u5423\u5004".length();
                array5[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(-205597726, -1118346557, "\u7b7b\u7b01\u7f68\u7b75\u7b7d\u7f68\u7b73\u7f6f\u7b5f\u7b6f\u7b67\u7b72\u7b05\u7b6f", -1443854297, -1008777684);
                "\u68f0".length();
                array6 = new Object[] { null };
                "\u59c2".length();
                "\u59e5\u688d\u58cd".length();
                "\u53f6\u6d9d".length();
                array6[0] = \u53e4\u4f00\u6c6e\u4f4d\u5b56\u58e7\u6743\u70e4\u6cee\u506d\u61b4\u69a2\u520e\u69c3\u6632\u6cfa\u5014\u56bf\u63f8\u50c7\u590e\u6f9a\u5f95\u5e88\u56c7\u4e4a\u5818\u568e\u541e\u5811\u565c\u533d\u6b79\u50bb\u5859\u6e35\u692b\u5ba6\u687a\u5b90\u6592(862537211, -796790306, "\u119c", -1201163367, -1768483262);
                array5[o4] = StyleUtils.gray(array6);
                player.sendMessage(StyleUtils.red(array5));
            }
            return;
        });
        "\u6939".length();
        "\u660c".length();
        "\u5d5e\u6c8d\u5ff0\u5716".length();
    }
    
    public void revanishAll() {
        final Iterator<UUID> iterator = Vanish.vanishedUUIDS.iterator();
        while (iterator.hasNext()) {
            this.vanish(iterator.next(), true);
        }
    }
    
    @EventHandler
    public void onPlayerDie(final EntityDeathEvent entityDeathEvent) {
        final LivingEntity entity = entityDeathEvent.getEntity();
        if (entity instanceof Player && Vanish.vanishedUUIDS.contains(((Player)entity).getUniqueId())) {
            entityDeathEvent.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onPlayerHit(final EntityDamageEvent entityDamageEvent) {
        final Entity entity = entityDamageEvent.getEntity();
        if (entity instanceof Player && Vanish.vanishedUUIDS.contains(((Player)entity).getUniqueId())) {
            entityDamageEvent.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onEntityTarget(final EntityTargetEvent entityTargetEvent) {
        final Entity target = entityTargetEvent.getTarget();
        if (target instanceof Player && Vanish.vanishedUUIDS.contains(((Player)target).getUniqueId())) {
            entityTargetEvent.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onItemPickup(final EntityPickupItemEvent entityPickupItemEvent) {
        final LivingEntity entity = entityPickupItemEvent.getEntity();
        if (entity instanceof Player && Vanish.vanishedUUIDS.contains(((Player)entity).getUniqueId())) {
            entityPickupItemEvent.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onItemDrop(final EntityDropItemEvent entityDropItemEvent) {
        final Entity entity = entityDropItemEvent.getEntity();
        if (entity instanceof Player && Vanish.vanishedUUIDS.contains(((Player)entity).getUniqueId())) {
            entityDropItemEvent.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onPlayerJoin(final PlayerJoinEvent playerJoinEvent) {
        if (Vanish.vanishedUUIDS.contains(playerJoinEvent.getPlayer().getUniqueId())) {
            playerJoinEvent.joinMessage((Component)null);
        }
        this.revanishAll();
    }
    
    @EventHandler
    public void onPlayerQuit(final PlayerQuitEvent playerQuitEvent) {
        if (Vanish.vanishedUUIDS.contains(playerQuitEvent.getPlayer().getUniqueId())) {
            playerQuitEvent.quitMessage((Component)null);
        }
    }
    
    @EventHandler
    public void onAdvancementDone(final PlayerAdvancementDoneEvent playerAdvancementDoneEvent) {
        if (Vanish.vanishedUUIDS.contains(playerAdvancementDoneEvent.getPlayer().getUniqueId())) {
            playerAdvancementDoneEvent.message((Component)null);
        }
    }
    
    public static int ColonialObfuscator_\u6b72\u56d3\u6ca3\u51b8\u570a\u6418\u50be\u5ddd\u56bd\u5de7\u67b0\u510a\u6273\u7115\u61e1\u552e\u5655\u5ea5\u6e8d\u69f5\u5732\u63bb\u55bb\u5438\u6e9d\u605c\u55e8\u5062\u64cb\u6a41\u6239\u6e4d\u6bac\u4fb5\u6966\u602c\u5d5e\u5228\u5fbe\u6950\u51da(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
