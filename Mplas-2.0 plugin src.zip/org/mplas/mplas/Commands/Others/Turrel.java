package org.mplas.mplas.Commands.Others;

import org.mplas.mplas.*;
import org.bukkit.entity.*;
import java.util.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;
import org.bukkit.scheduler.*;
import org.bukkit.plugin.*;

public class Turrel implements CommandExecutor
{
    public Turrel(final Mplas plugin) {
        this.arrowRainTasks = new HashMap<Player, BukkitTask>();
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!command.getName().equalsIgnoreCase(\u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(-1821070579, 204797773, "\u6477\u6475\u6470\u6470\u6467\u646e", -1461289209, -1589360857))) {
            return false;
        }
        if (commandSender.hasPermission(\u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(-1012059778, 1303735822, "\u590e\u593c\u5922\u592b\u5939\u5960\u5926\u5921\u590a\u5920\u5922", -1714911023, -748253567)) && !commandSender.hasPermission(\u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(1522195533, -1466078599, "\u92d2\u92e4\u92fa\u92f7\u92e5\u92b0\u92e3\u92ec\u92c9\u92e3\u92f1\u92e8", -418576477, -2141969557))) {
            final Object[] array2 = new Object[2];
            "\u61d3\u534c".length();
            "\u6ba6\u5633\u512c\u6492".length();
            array2[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(485164096, 1030760418, "\ua47a\ua056\ua446\ua448\ua439\ua05c\ua448\ua44a\ua41f\ua053\ua449\ua41a\ua46d\ua47c", 1671435093, 705728749);
            "\u64b6\u6865".length();
            "\u603b\u5f86\u6f26".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u5626\u65df\u5b5f\u50c9".length();
            "\u6a4f\u5644\u6969\u5f9f".length();
            array3[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(1369663975, 1565673842, "\u6785", 1814800505, -786436341);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (!(commandSender instanceof Player)) {
            final Object[] array4 = new Object[2];
            "\u55e7\u6b36\u677c".length();
            "\u5e97".length();
            array4[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(1317536584, 2036946462, "\u3513\u351a\u351c\u3512\u351d\u3512\u3562\u310d\u3531\u351f\u3514\u350d\u350b\u3104\u3521\u354c\u352a\u3537\u3518\u4521\u6210\u5746\u4582\u6050\u5dce\u4598\u5060\u64d4\u6bb1\u6f0e\u574d\u6b44\u6b41\u52f2\u5687\u6a91\u56bf\u63e9\u683a\u511c\u4461\u520b\u5e7f\u6016\u68f4\u5b46\u45d3\u652c", -928063854, 1416870542);
            "\u5ce9\u54af\u5bf9\u60d4".length();
            "\u7013\u5d0d\u6b51\u58f7".length();
            "\u61f5\u5584".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u5cbb\u626a".length();
            array5[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(-910596893, -1228049928, "\u7514", 671582217, 1954343012);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
            return true;
        }
        final Player player = (Player)commandSender;
        if (array.length == 0) {
            this.toggleArrowTurrel(player);
            return true;
        }
        if (array.length == 1) {
            final Player player2 = Bukkit.getPlayer(array[0]);
            if (player2 != null) {
                this.toggleArrowTurrel(player2);
            }
            else {
                final Object[] array6 = new Object[2];
                "\u4e82".length();
                "\u5859".length();
                "\u687b\u5067".length();
                "\u4f4b\u6521".length();
                array6[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(295894807, 39178399, "\u4307\u4303\u4372\u43f0\u43f4\u47ea\u43fe\u43fc\u47cb\u43f8\u43f0\u43e5\u43ef\u43fd\u43f6", 1567612541, 114734761);
                "\u580e\u5f57\u6340".length();
                "\u6052\u5b29\u5fdb\u6775\u6d49".length();
                "\u6ec3\u5c64\u4f7d\u66a1\u5ddb".length();
                "\u6705\u558e".length();
                final int n3 = 1;
                final Object[] array7 = { null };
                "\u5618\u59f8\u554d".length();
                "\u641f\u4e74\u647a".length();
                "\u6ac9\u6588\u6271".length();
                array7[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(450737939, 1660002505, "\uc153", 1976282929, -845448742);
                array6[n3] = StyleUtils.gray(array7);
                commandSender.sendMessage(StyleUtils.red(array6));
            }
            return true;
        }
        final Object[] array8 = new Object[2];
        "\u4f76".length();
        "\u53d5\u70e3\u5e62\u55a7".length();
        "\u6200\u668f".length();
        array8[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(-1480659416, 2131282861, "\ubd6f\ubd1b\ubd61\ubd62\ubd65\ubd14\ubd68\ubd6d\ubd41\ubd6f\ubd61\ubd76\ubd7e\ub960", 1440507506, 767097539);
        "\u6f9f".length();
        "\u648c\u6bd3\u5d07\u6163".length();
        "\u69de".length();
        final int n4 = 1;
        final Object[] array9 = new Object[2];
        "\u623d\u5f58\u553c\u6185".length();
        "\u5e6e\u6076\u5aa5\u6ddb\u6942".length();
        array9[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(1717178030, -654977906, "\ua16e\ua14c\ua133\ua110\ua115\ua113\ua103\ua106\ua16a\ua15a\ua57d\ua544\ua532\ua55d\ua544\ua154", 1854924642, 1869323343);
        "\u627e\u6fad\u6adb\u5adc\u55cf".length();
        "\u68ea\u5e18\u60af".length();
        "\u6984\u60f7\u5fdd\u59b6".length();
        final int n5 = 1;
        final Object[] array10 = { null };
        "\u5672\u642d".length();
        "\u6a20\u67cc\u57f9".length();
        array10[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(623428542, -671584249, "\u7719", 2113031844, 1227197030);
        array9[n5] = StyleUtils.gray(array10);
        array8[n4] = StyleUtils.gold(array9);
        commandSender.sendMessage(StyleUtils.gray(array8));
        return true;
    }
    
    public void toggleArrowTurrel(final Player player) {
        if (this.arrowRainTasks.containsKey(player)) {
            this.arrowRainTasks.remove(player).cancel();
            final Object[] array = new Object[2];
            "\u6427\u5294\u5d5e\u5094".length();
            "\u70e8\u6f39\u59b4".length();
            "\u5fe0".length();
            "\u6a96\u6dda\u5599".length();
            array[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(94091576, -1219350928, "\u6005\u6023\u6022\u602c\u6028\u6434\u605f\u6050\u6071\u6026\u602d\u603e\u6421", -1616883345, -2033081791);
            "\u5b02\u6b65\u67ed\u66db\u672b".length();
            "\u6da0\u6d5f".length();
            final int n = 1;
            final Object[] array2 = new Object[2];
            "\u6b25\u5172\u6f67\u6b3a\u550d".length();
            "\u6bac\u5aef\u6b56\u4eea\u573f".length();
            array2[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(1851561939, -209622036, "\u86ab\u86ff\u86fe\u868c\u8681\u868a\u868f\u8688\u86a4\u8686", -314026381, -1564792678);
            "\u69e7\u6032".length();
            "\u56cb\u5fdb".length();
            final int n2 = 1;
            final Object[] array3 = { null };
            "\u681e\u4f12\u5ebe\u529c\u5373".length();
            "\u69c7\u509f".length();
            "\u6943\u6f32\u6e29".length();
            "\u5e77\u6b51\u648e".length();
            array3[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(1685621897, -2117655599, "\u472f", -1395034849, 2022415626);
            array2[n2] = StyleUtils.gray(array3);
            array[n] = StyleUtils.gold(array2);
            player.sendMessage(StyleUtils.gray(array));
        }
        else {
            "\u6ce7\u524c".length();
            "\u6e7d\u5a6c\u6e12\u5a0d".length();
            this.arrowRainTasks.put(player, new BukkitRunnable().runTaskTimer((Plugin)this.plugin, 0L, 1L));
            "\u595e\u67b3".length();
            "\u6937\u4f86".length();
            "\u6bc0\u6bda\u521e\u6102".length();
            final Object[] array4 = new Object[2];
            "\u50e1\u617b".length();
            "\u5630".length();
            array4[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(1265762679, 1285877576, "\u11d0\u11ea\u11eb\u11e9\u11ed\u15f5\u119e\u1195\u11b4\u11ef\u11e4\u11eb\u15f4", 1416237925, 1549920489);
            "\u540b\u5806\u68e6\u630d".length();
            final int n3 = 1;
            final Object[] array5 = new Object[2];
            "\u57be".length();
            "\u5572\u54ef\u5874\u6ffb\u57ed".length();
            array5[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(923971530, -1579913770, "\u58a6\u588c\u588f\u58f1\u58f9\u5883\u5884", -2120529578, 1501222808);
            "\u623e\u5234\u5ec4".length();
            "\u5650".length();
            "\u6cf2".length();
            final int n4 = 1;
            final Object[] array6 = { null };
            "\u62f6\u5e54\u6dc9".length();
            array6[0] = \u5107\u506f\u57f2\u6238\u5eed\u5586\u617a\u5f40\u691c\u62b0\u69f2\u5d73\u59ea\u5101\u66c2\u52ae\u70de\u5a6b\u5584\u6870\u6ce5\u4f56\u5401\u588a\u59ae\u6bee\u6347\u508f\u6de8\u59e4\u6b5c\u6322\u6501\u6dba\u57ad\u6f66\u6de0\u562a\u7038\u6452\u6beb(1520805591, -293396514, "\uba68\uba49\ube5d\ube50\ube22\uba4b\ube5e\ube2e\ube6a\ube47\ube35\ube2e\ube5d\ube44\ube40\ube23\uba58\ube56\ube78\uce31\ue97e\udc2d\uce93\ueb34\ud231\uce73\udfe7\uef33\ue022\ue495\udcb4\ue0bc\ue4d2\udd1e\udd0d\ue164\ud920\ue86f\ue7a2", -670903960, 1108857446);
            array5[n4] = StyleUtils.gray(array6);
            array4[n3] = StyleUtils.gold(array5);
            player.sendMessage(StyleUtils.gray(array4));
        }
    }
    
    public static int ColonialObfuscator_\u5412\u50b2\u5032\u636f\u4e35\u5e98\u53c0\u5a39\u6bb8\u6ba9\u6faa\u6557\u67f8\u6d34\u7077\u6092\u6fae\u5624\u5e4e\u644b\u6613\u501a\u609a\u5411\u6eaa\u5e33\u5c27\u561b\u5b91\u5c38\u5ca0\u7109\u523d\u5da4\u6073\u5ca4\u5428\u4fa1\u6a19\u5aac\u530d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
