package org.mplas.mplas.Commands.Others.troll;

import org.mplas.mplas.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;
import org.bukkit.scheduler.*;
import org.bukkit.*;
import org.bukkit.plugin.*;

public class Meteorite implements CommandExecutor
{
    public Meteorite(final Mplas plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender.hasPermission(\u64b7\u6202\u6cd3\u6b9c\u6bee\u5e48\u5a00\u5267\u5a23\u6338\u6a83\u633f\u6bda\u567c\u6419\u5064\u5284\u62fa\u61e8\u5cde\u5372\u4fc9\u5d7c\u6ba5\u57dc\u5a10\u55cd\u58b4\u4ea6\u6803\u6a6d\u54f2\u637f\u60af\u6ee7\u5719\u6351\u5dc6\u5d20\u70cd\u65ed(235585303, -236054869, "\u9f30\u9f00\u9f18\u9f17\u9f07\u9f5c\u9f04\u9f0d\u9f24\u9f0c\u9f08", 519485386, 1508409704)) && !commandSender.hasPermission(\u64b7\u6202\u6cd3\u6b9c\u6bee\u5e48\u5a00\u5267\u5a23\u6338\u6a83\u633f\u6bda\u567c\u6419\u5064\u5284\u62fa\u61e8\u5cde\u5372\u4fc9\u5d7c\u6ba5\u57dc\u5a10\u55cd\u58b4\u4ea6\u6803\u6a6d\u54f2\u637f\u60af\u6ee7\u5719\u6351\u5dc6\u5d20\u70cd\u65ed(-1297097880, -2041928636, "\u7604\u7634\u7628\u7627\u764b\u7610\u7658\u765c\u7669\u7654\u7659\u7656\u7644\u7648\u7658", -1897748036, -240279366))) {
            final Object[] array2 = new Object[2];
            "\u6e62\u63a9\u527d\u5c18\u680a".length();
            array2[0] = \u64b7\u6202\u6cd3\u6b9c\u6bee\u5e48\u5a00\u5267\u5a23\u6338\u6a83\u633f\u6bda\u567c\u6419\u5064\u5284\u62fa\u61e8\u5cde\u5372\u4fc9\u5d7c\u6ba5\u57dc\u5a10\u55cd\u58b4\u4ea6\u6803\u6a6d\u54f2\u637f\u60af\u6ee7\u5719\u6351\u5dc6\u5d20\u70cd\u65ed(-156820394, -1438003584, "\u6123\u650b\u611b\u6119\u6168\u6511\u6105\u6103\u6156\u651e\u6104\u616b\u611c\u6101", -989542645, 1691971742);
            "\u6af5".length();
            "\u53f8".length();
            "\u6e6f\u68e7\u5fff".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u5722\u6cb3\u631c\u5169".length();
            "\u6b4d".length();
            "\u6eed\u690d\u6ab2\u6314\u6e3f".length();
            array3[0] = \u64b7\u6202\u6cd3\u6b9c\u6bee\u5e48\u5a00\u5267\u5a23\u6338\u6a83\u633f\u6bda\u567c\u6419\u5064\u5284\u62fa\u61e8\u5cde\u5372\u4fc9\u5d7c\u6ba5\u57dc\u5a10\u55cd\u58b4\u4ea6\u6803\u6a6d\u54f2\u637f\u60af\u6ee7\u5719\u6351\u5dc6\u5d20\u70cd\u65ed(1104261488, 1148842967, "\ucdfa", 884950448, 635357839);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (!command.getName().equalsIgnoreCase(\u64b7\u6202\u6cd3\u6b9c\u6bee\u5e48\u5a00\u5267\u5a23\u6338\u6a83\u633f\u6bda\u567c\u6419\u5064\u5284\u62fa\u61e8\u5cde\u5372\u4fc9\u5d7c\u6ba5\u57dc\u5a10\u55cd\u58b4\u4ea6\u6803\u6a6d\u54f2\u637f\u60af\u6ee7\u5719\u6351\u5dc6\u5d20\u70cd\u65ed(1206335840, 1920120406, "\ufd1f\ufd38\ufd2b\ufd36\ufd3c\ufd25\ufd37\ufd20\ufd13", -198537243, -1506214430))) {
            return false;
        }
        if (array.length == 1) {
            final Player player = Bukkit.getPlayer(array[0]);
            if (player != null) {
                this.spawnMeteorite(player);
            }
            else {
                final Object[] array4 = new Object[2];
                "\u647e\u626f\u5600\u59a5\u68fe".length();
                "\u5d9f\u5b11".length();
                "\u65d4\u5027".length();
                "\u641d\u57bb\u5b23\u5d2d".length();
                array4[0] = \u64b7\u6202\u6cd3\u6b9c\u6bee\u5e48\u5a00\u5267\u5a23\u6338\u6a83\u633f\u6bda\u567c\u6419\u5064\u5284\u62fa\u61e8\u5cde\u5372\u4fc9\u5d7c\u6ba5\u57dc\u5a10\u55cd\u58b4\u4ea6\u6803\u6a6d\u54f2\u637f\u60af\u6ee7\u5719\u6351\u5dc6\u5d20\u70cd\u65ed(-905665307, -1033493787, "\ud147\ud143\ud132\ud150\ud154\ud54a\ud15e\ud15c\ud56b\ud158\ud150\ud145\ud14f\ud15d\ud156", -1616548307, -812303055);
                "\u6db9\u5e8d".length();
                "\u5a05\u5c4c\u53f3".length();
                final int n2 = 1;
                final Object[] array5 = { null };
                "\u61e2\u6a94\u6708\u6997\u5434".length();
                "\u633d\u63f2".length();
                array5[0] = \u64b7\u6202\u6cd3\u6b9c\u6bee\u5e48\u5a00\u5267\u5a23\u6338\u6a83\u633f\u6bda\u567c\u6419\u5064\u5284\u62fa\u61e8\u5cde\u5372\u4fc9\u5d7c\u6ba5\u57dc\u5a10\u55cd\u58b4\u4ea6\u6803\u6a6d\u54f2\u637f\u60af\u6ee7\u5719\u6351\u5dc6\u5d20\u70cd\u65ed(1825375614, 642182628, "\u8cfe", 44298972, 1430427354);
                array4[n2] = StyleUtils.gray(array5);
                commandSender.sendMessage(StyleUtils.red(array4));
            }
            return true;
        }
        final Object[] array6 = new Object[2];
        "\u5132\u6dcc".length();
        array6[0] = \u64b7\u6202\u6cd3\u6b9c\u6bee\u5e48\u5a00\u5267\u5a23\u6338\u6a83\u633f\u6bda\u567c\u6419\u5064\u5284\u62fa\u61e8\u5cde\u5372\u4fc9\u5d7c\u6ba5\u57dc\u5a10\u55cd\u58b4\u4ea6\u6803\u6a6d\u54f2\u637f\u60af\u6ee7\u5719\u6351\u5dc6\u5d20\u70cd\u65ed(1539242848, 873044538, "\ue7a3\ue7d5\ue7a9\ue7ac\ue7a9\ue7da\ue7a8\ue7a3\ue78d\ue7a1\ue7a9\ue7b8\ue7b2\ue3ae\ue3b7", -438867551, -1467094269);
        "\u5307\u6161\u52b0".length();
        "\u683a".length();
        final int n3 = 1;
        final Object[] array7 = { null };
        "\u5834\u5cc0".length();
        array7[0] = \u64b7\u6202\u6cd3\u6b9c\u6bee\u5e48\u5a00\u5267\u5a23\u6338\u6a83\u633f\u6bda\u567c\u6419\u5064\u5284\u62fa\u61e8\u5cde\u5372\u4fc9\u5d7c\u6ba5\u57dc\u5a10\u55cd\u58b4\u4ea6\u6803\u6a6d\u54f2\u637f\u60af\u6ee7\u5719\u6351\u5dc6\u5d20\u70cd\u65ed(31494732, 1802858314, "\ud152\ud13d\ud129\ud13a\ud129\ud125\ud137\ud120\ud11d\ud120\ud16e\ud160\ud129\ud124\ud12c\ud120\ud124\ud12f\ud171", 827129358, -1463823818);
        array6[n3] = StyleUtils.gold(array7);
        commandSender.sendMessage(StyleUtils.gray(array6));
        return true;
    }
    
    public void spawnMeteorite(final Player player) {
        final World world = player.getWorld();
        final Location add = player.getLocation().clone().add(0.0, 40.0, 0.0);
        "\u6438\u6698\u5b9e\u6480\u6e11".length();
        "\u52a1".length();
        "\u6b07\u52e2".length();
        new BukkitRunnable().runTaskTimer((Plugin)this.plugin, 0L, 10L);
    }
    
    public static int ColonialObfuscator_\u5001\u4e82\u5ca0\u60fd\u580b\u695e\u6da3\u6401\u5b11\u5da3\u63eb\u5b35\u6fb0\u61a2\u61d9\u63df\u6928\u682b\u6a72\u5119\u56b4\u6a7f\u5f95\u5309\u5255\u6c8d\u5e90\u5bca\u5748\u5457\u4eaa\u573d\u4fd8\u6578\u6ea2\u653b\u5f6f\u67a6\u4f8e\u4e66\u6063(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
