package org.mplas.mplas.Commands.Others.troll;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;
import org.bukkit.*;

public class ZombieApocalypse implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender.hasPermission(\u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(-1958321393, -1407586997, "\u12d5\u12e7\u12f9\u12f8\u12ea\u12b3\u12f5\u12fa\u12d1\u12fb\u12f9", 1235475637, -1666957302)) && !commandSender.hasPermission(\u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(-65735888, -1821927712, "\uc868\uc858\uc840\uc84f\uc85f\uc804\uc847\uc85e\uc87c\uc85f\uc857\uc849\uc848\uc848\uc85a\uc842\uc858\uc849\uc876\u86ec\ua773\u9974", 368122730, 1379645180))) {
            final Object[] array2 = new Object[2];
            "\u6fa6\u5028".length();
            "\u5220".length();
            "\u5e22\u5f51\u6fa0\u69ff".length();
            array2[0] = \u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(-2086186358, 1908005012, "\u7870\u7c50\u7840\u7842\u7833\u7c52\u7846\u7840\u7815\u7c25\u783f\u7850\u7827\u7832", 1768699575, 730972345);
            "\u5c8e\u52ac".length();
            "\u51b3\u68ae".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u622f".length();
            "\u582c\u62be\u59df".length();
            array3[0] = \u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(-1222193842, -1444898889, "\u849d", -1316510056, -650872674);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (!command.getName().equalsIgnoreCase(\u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(329642062, 57723452, "\u47ed\u47f5\u47fb\u47f6\u47ff\u47f5\u47de\u47e3\u47dc\u47fc\u47e5\u47fa\u47ea\u47f2\u47f4\u47f6", -1095789370, 1312287040))) {
            return false;
        }
        if (array.length == 1) {
            final Player player = Bukkit.getPlayer(array[0]);
            if (player != null) {
                this.spawnZombieApocalypse(commandSender, player);
            }
            else {
                final Object[] array4 = new Object[2];
                "\u5836\u63f4".length();
                "\u5046\u519a\u55d6".length();
                array4[0] = \u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(-373622724, 1362503168, "\u9f95\u9f93\u9fe0\u9f9c\u9fa6\u9bba\u9fac\u9fa8\u9b99\u9fa8\u9fa2\u9fb9\u9fbd\u9fad\u9fa4", 395348188, -1272853202);
                "\u6691\u5894".length();
                "\u5ab3".length();
                "\u622f".length();
                final int n2 = 1;
                final Object[] array5 = { null };
                "\u542e\u5e80\u5620\u69da".length();
                "\u54cd\u5869\u53bb\u5b7b".length();
                "\u5ecc\u6d4f\u5884".length();
                "\u60a0".length();
                array5[0] = \u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(-1627069666, 264389566, "\u7363", -1167860562, -523301105);
                array4[n2] = StyleUtils.gray(array5);
                commandSender.sendMessage(StyleUtils.red(array4));
            }
            return true;
        }
        final Object[] array6 = new Object[2];
        "\u68d9\u535e\u580b".length();
        "\u7035".length();
        "\u6027\u5efe\u6730\u630c".length();
        array6[0] = \u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(2031343880, 1053529746, "\ufd17\ufd63\ufd1d\ufd1e\ufd1d\ufd6c\ufd1c\ufd19\ufd29\ufd07\ufd0d\ufd1a\ufd16\uf908", -975712920, -1821279298);
        "\u67fb\u64d0\u6596\u5eb3\u6dbe".length();
        "\u52a5\u519a\u5112\u5a46".length();
        final int n3 = 1;
        final Object[] array7 = { null };
        "\u51bb\u6e1a\u688f".length();
        "\u523a\u5e35\u5037".length();
        "\u6a94\u5f71".length();
        "\u5f48".length();
        array7[0] = \u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(-577477115, 1483529679, "\u3cc0\u3ce0\u3cb7\u3ca6\u3ca4\u3caf\u3cad\u3c93\u3cb5\u3c8a\u3c90\u3c88\u3c8d\u3c93\u3c85\u3c96\u3c8f\u3c87\u3cee\u7200\u53b5\u6dba\u6bc9\u6c03\u6447\u6055\u4c50", -176109351, -579907664);
        array6[n3] = StyleUtils.gold(array7);
        commandSender.sendMessage(StyleUtils.gray(array6));
        return true;
    }
    
    public void spawnZombieApocalypse(final CommandSender commandSender, final Player target) {
        if (commandSender instanceof Player) {
            final Player player = (Player)commandSender;
            for (int i = 0; i < 25; i -= 9047, i += 9048) {
                final World world = target.getWorld();
                final Location location = target.getLocation();
                final double n = Math.random() * 10.0;
                final double n2 = 5.0;
                "\u5683\u6988\u5b7a".length();
                "\u5fbf\u52ec\u6332".length();
                "\u679d\u6863\u6f08\u51cf\u557e".length();
                "\u633e\u572a\u70d4\u52df\u57f0".length();
                final double n3 = n - n2;
                final double n4 = 0.0;
                final double n5 = Math.random() * 10.0;
                final double n6 = 5.0;
                "\u5afa\u5209\u66b7\u4f15\u538f".length();
                "\u5e86\u51cf\u64a8\u6b86\u6439".length();
                "\u645a\u5c6d\u576e".length();
                "\u5ef3\u500e".length();
                ((Zombie)world.spawn(location.add(n3, n4, n5 - n6), (Class)Zombie.class)).setTarget((LivingEntity)target);
            }
            final Player player2 = player;
            final Object[] array = new Object[3];
            "\u4e27\u6a5b\u6304\u6cc4\u614f".length();
            "\u53ec\u5bc8\u5d56\u6bac".length();
            "\u551c\u6bdb\u5050".length();
            array[0] = \u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(-1446257525, -1473131913, "\uac22\uac23\uac2a\uac2e\uac21\ua837\uac2f\uac2a\uac08\uac29\uaddb\ua9d1\uadc5\uadae\uaddb\uadc4\ua9cc\uadc2\uad99\ue376\uc2ef\ufcfc\ufa89\ufd48\uf102\uf118\udd21\uf08d\ufafc\uc7eb\udcc3\uf240\uf222\ufc11\uc168", 1280700150, 766857337);
            "\u59c7\u500b\u57a0\u6537\u5de4".length();
            final int n7 = 1;
            final Object[] array2 = { null };
            "\u4f56\u6616\u5ec5\u5363\u520b".length();
            array2[0] = target.getName();
            array[n7] = StyleUtils.gold(array2);
            "\u4e41".length();
            "\u6a15\u5e0b\u6272\u60c0\u616e".length();
            "\u6bb0".length();
            "\u4e46".length();
            "\u6e8f".length();
            final int n8 = 2;
            final Object[] array3 = { null };
            "\u62da\u5b32".length();
            "\u6776\u6194\u5665\u6d2f\u5ba0".length();
            "\u6871\u4fec".length();
            array3[0] = \u6415\u7020\u5e09\u6da3\u521f\u4e53\u6075\u5bcd\u4e93\u4e68\u61f0\u68c2\u5dc9\u6034\u6a25\u673c\u4f18\u6bf4\u50e5\u5a65\u66f8\u5c53\u6119\u69ce\u577b\u60d5\u6084\u6212\u5b1c\u608c\u534b\u5771\u5773\u6b04\u4f5b\u5f1f\u6d6f\u6f05\u4f74\u6b34\u6ef7(-1240184013, -204054883, "\u6227", -1891233441, 250046132);
            array[n8] = StyleUtils.gray(array3);
            player2.sendMessage(StyleUtils.gray(array));
        }
    }
    
    public static int ColonialObfuscator_\u6a84\u6d31\u664c\u5330\u5a7c\u6e6a\u51d9\u5e7b\u6e0b\u635a\u5051\u6671\u63b8\u5fca\u6ac7\u5e2f\u51c5\u6f41\u4e3c\u6efc\u5a3c\u5988\u4e51\u6d63\u5237\u6f28\u56d0\u6efc\u5536\u57bd\u61da\u5426\u6677\u6558\u637b\u50ce\u6b80\u5e3f\u4f12\u6538\u6472(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
