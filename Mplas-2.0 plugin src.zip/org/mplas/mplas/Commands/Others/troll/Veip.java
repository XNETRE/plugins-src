package org.mplas.mplas.Commands.Others.troll;

import org.jetbrains.annotations.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;

public class Veip implements CommandExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        final Object[] array2 = { null };
        "\u61e3\u519e\u620c".length();
        "\u7072\u4ffa\u6576\u6c56\u6096".length();
        array2[0] = \u519d\u66ed\u6246\u604f\u7108\u5fc3\u5369\u7113\u595e\u6408\u6970\u6cda\u5239\u68bf\u5656\u61b7\u6343\u555d\u5efe\u70c4\u5c95\u6946\u6b3c\u646c\u64fc\u6661\u63d5\u502f\u4f70\u63e1\u623c\u58c8\u6679\u69f6\u576f\u685b\u55be\u6afa\u6022\u5053\u5ecf(1927064420, -2020683067, "\u7e07\u7e05\u7e04\u7e06\u7e01\u7e04\u7a15\u7e06\u7e29\u7a6b\u7e72\u7e6b\u7e64\u7e01\u7a6d\u7a61\u7a68", 1464855479, -1311446968);
        commandSender.sendMessage(StyleUtils.openUrl(StyleUtils.gold(array2), \u519d\u66ed\u6246\u604f\u7108\u5fc3\u5369\u7113\u595e\u6408\u6970\u6cda\u5239\u68bf\u5656\u61b7\u6343\u555d\u5efe\u70c4\u5c95\u6946\u6b3c\u646c\u64fc\u6661\u63d5\u502f\u4f70\u63e1\u623c\u58c8\u6679\u69f6\u576f\u685b\u55be\u6afa\u6022\u5053\u5ecf(674137892, -1235209672, "\ufbc9\ufbf8\ufbf4\ufbf2\ufbf3\ufbbc\ufba6\ufbaa\ufbd2\ufbfe\ufbc5\ufb8e\ufbdc\ufbdb\ufbc4\ufbd1\ufbc8\ufbc3\ufbe6\u9d63\u9678\ua179\u9403\uadf7\ua650\u9ec2\uaaec\uaa56\u9309\u8be1\u9a54\u9374\u9d09\ua07c\uaada\u9faa\uafc5\ua3d3\ua5a8\ua16b\u9adb\ua9d7\u9b98", -1340233066, -1872763800)));
        return true;
    }
    
    public static int ColonialObfuscator_\u5b82\u7101\u7051\u7065\u5d61\u51e4\u5635\u5014\u5e0b\u6f87\u52da\u5328\u5070\u59d7\u5b3e\u5009\u6d98\u5158\u5987\u4fb3\u4f31\u4f9a\u6992\u5958\u6f1a\u5e09\u7063\u6ccc\u6598\u5cfa\u6a6d\u6bbe\u5d59\u6ddf\u6e7d\u626a\u5a49\u51f2\u6405\u6c05\u6f64(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
