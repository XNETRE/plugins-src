package org.mplas.mplas.Commands.Others.troll;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;
import org.bukkit.util.*;

public class Compass implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender.hasPermission(\u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(-1584376498, 567350341, "\u9a06\u9a36\u9a2a\u9a25\u9a31\u9a6a\u9a2e\u9a27\u9a12\u9a3a\u9a3a", -48305784, -2054802773)) && !commandSender.hasPermission(\u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(1077539774, -774734378, "\u9e1c\u9e2c\u9e34\u9e3b\u9e2b\u9e70\u9e3a\u9e3a\u9e18\u9e29\u9e3b\u9e3b\u9e3e", 1134350706, -238501592))) {
            final Object[] array2 = new Object[2];
            "\u50d0\u560c".length();
            "\u61d1\u5a25\u51e4\u68fe".length();
            array2[0] = \u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(-458349178, 1822019447, "\u13a0\u178c\u139c\u139a\u13eb\u178e\u139a\u1380\u13d5\u1799\u1383\u13e8\u139f\u138e", 170810249, -727079240);
            "\u6dd8\u56e7\u5339".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u5202\u66bb".length();
            "\u5509\u61cc\u6e27\u65a8".length();
            array3[0] = \u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(-1841341197, 571296793, "\u045f", 1995285057, 1772467862);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (!(commandSender instanceof Player)) {
            final Object[] array4 = { null };
            "\u64de\u52a8".length();
            "\u5e82".length();
            "\u62ed".length();
            "\u5dbf\u64c7".length();
            array4[0] = \u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(859354079, 681083750, "\ubd9e\ubd97\ubd95\ubd9b\ubd90\ubd9f\ubd90\ub98c\ubdb4\ubd92\ubdea\ubdfb\ubdfb\ubd96\ubd95\ubd8c\ub998\ubde6\ubdb4\ud3cd\ue35b\ud7e8\uef3b\uf662\ue00a\ud3dc\udfea\udd09\ue9e0\ue52d\ue027\ud15e\ue1db\ud939\ue9d7\ue20a\ud6a4\ue7f8\ue788", -151347328, -195684610);
            commandSender.sendMessage(StyleUtils.red(array4));
            return true;
        }
        final Player player = (Player)commandSender;
        final Vector direction = player.getLocation().getDirection();
        String s2;
        if (direction.getZ() < -0.5) {
            s2 = \u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(2052343893, -2133098881, "\u0280\u02bb\u02be\u02bd\u02c8", -1164231239, 1312427377);
        }
        else if (direction.getX() > 0.5) {
            s2 = \u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(692437860, -995394927, "\u69bb\u69b8\u69c5\u69ca\u69b6\u69b6", 1247999285, 373694762);
        }
        else if (direction.getZ() > 0.5) {
            s2 = \u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(-669079143, -1017642229, "\u29ff\u29cf", 248643802, -1856862246);
        }
        else if (direction.getX() < -0.5) {
            s2 = \u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(-656645643, -1880279435, "\uf329\uf323\uf330\uf33d\uf33b", -759855826, 1672422867);
        }
        else {
            s2 = \u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(-905594589, -887651066, "\u12a1\u12a4\u12a9\u12a4\u12af\u12ae\u12d1\u12de\u1285\u12aa", -1719280636, 987756254);
        }
        final Player player2 = player;
        final Object[] array5 = new Object[2];
        "\u6056\u6eef".length();
        "\u5ff1\u6eed".length();
        "\u5d80\u610a\u6aae".length();
        array5[0] = \u6f0c\u6a9b\u650c\u4ed5\u57a3\u6aa9\u50d3\u55e4\u4f4c\u6710\u535d\u6181\u6a24\u7046\u5700\u58f6\u6ae6\u57fc\u5280\u6343\u6e85\u547f\u57c5\u6648\u58cc\u5afe\u58be\u58a1\u6d32\u58f4\u6415\u5c67\u7098\u5f85\u6b90\u5ac6\u67cd\u684b\u605c\u5ad0\u56b9(973004771, 1464541800, "\u543d\u5449\u501e\u547d\u5402\u5406\u5475\u547b\u5423\u5475\u5409\u500e\u5416\u540a\u501f", -230416546, 2057286329);
        "\u5f0a\u525e".length();
        final int n2 = 1;
        final Object[] array6 = { null };
        "\u65a7\u69b7\u6b44".length();
        array6[0] = s2;
        array5[n2] = StyleUtils.gold(array6);
        player2.sendMessage(StyleUtils.gray(array5));
        return true;
    }
    
    public static int ColonialObfuscator_\u62d9\u67a5\u5837\u61ef\u5509\u57c2\u52be\u588d\u6a72\u6818\u6a89\u593a\u4ff6\u5c16\u6c18\u51e0\u6aff\u631c\u6e8b\u699e\u6614\u6a84\u548c\u5452\u6df5\u6f7e\u5f06\u4ec3\u58c7\u5990\u6c2d\u6765\u5758\u5b81\u56ae\u5db6\u5d10\u63f3\u5197\u6e3c\u5403(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
