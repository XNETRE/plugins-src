package org.mplas.mplas.Commands.Others.troll;

import org.mplas.mplas.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;

public class Nuke implements CommandExecutor
{
    public Nuke(final Mplas plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender.hasPermission(\u5297\u5640\u604c\u5dcc\u61e4\u5abd\u5b6b\u629b\u6b2b\u69df\u6748\u694c\u6791\u70fe\u5e25\u56a1\u50f0\u6027\u5270\u6f22\u616a\u690b\u5eb0\u5fb4\u6e55\u6092\u516a\u6b15\u6d52\u516c\u4ec1\u675b\u50cf\u55b5\u4e81\u5783\u5519\u6d11\u6fe9\u6375\u5512(-41968727, 568952632, "\u2003\u2033\u202b\u2024\u2034\u206f\u2037\u203e\u2017\u203f\u203b", 1455322570, 758860150)) && !commandSender.hasPermission(\u5297\u5640\u604c\u5dcc\u61e4\u5abd\u5b6b\u629b\u6b2b\u69df\u6748\u694c\u6791\u70fe\u5e25\u56a1\u50f0\u6027\u5270\u6f22\u616a\u690b\u5eb0\u5fb4\u6e55\u6092\u516a\u6b15\u6d52\u516c\u4ec1\u675b\u50cf\u55b5\u4e81\u5783\u5519\u6d11\u6fe9\u6375\u5512(-1253485717, -403094387, "\u080c\u083c\u082c\u0823\u0833\u0868\u0820\u082b\u0813\u083a\u0817\u0805", -2078934506, -192354862))) {
            final Object[] array2 = new Object[2];
            "\u5f68\u6e52\u63a8".length();
            array2[0] = \u5297\u5640\u604c\u5dcc\u61e4\u5abd\u5b6b\u629b\u6b2b\u69df\u6748\u694c\u6791\u70fe\u5e25\u56a1\u50f0\u6027\u5270\u6f22\u616a\u690b\u5eb0\u5fb4\u6e55\u6092\u516a\u6b15\u6d52\u516c\u4ec1\u675b\u50cf\u55b5\u4e81\u5783\u5519\u6d11\u6fe9\u6375\u5512(1243974151, 31444931, "\uccda\uc8f6\ucce6\ucce0\ucc91\uc8f4\ucce0\ucc9a\ucccf\uc883\ucc99\uccf2\ucc85\ucc94", 137956921, -215776441);
            "\u653e\u5dd9\u6fce\u56d3\u500a".length();
            "\u579f\u5cfe\u68a8\u7013\u51f2".length();
            "\u55dd\u611c\u60c2\u6943\u55b5".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u5dac\u6a3e\u4fbf\u4f64\u4f5a".length();
            array3[0] = \u5297\u5640\u604c\u5dcc\u61e4\u5abd\u5b6b\u629b\u6b2b\u69df\u6748\u694c\u6791\u70fe\u5e25\u56a1\u50f0\u6027\u5270\u6f22\u616a\u690b\u5eb0\u5fb4\u6e55\u6092\u516a\u6b15\u6d52\u516c\u4ec1\u675b\u50cf\u55b5\u4e81\u5783\u5519\u6d11\u6fe9\u6375\u5512(-1964882252, 141032630, "\u6d84", -1794348533, 1854324207);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (array.length != 1) {
            final Object[] array4 = new Object[2];
            "\u6cf7\u649d".length();
            "\u6e9c\u5324\u6641".length();
            "\u5252".length();
            array4[0] = \u5297\u5640\u604c\u5dcc\u61e4\u5abd\u5b6b\u629b\u6b2b\u69df\u6748\u694c\u6791\u70fe\u5e25\u56a1\u50f0\u6027\u5270\u6f22\u616a\u690b\u5eb0\u5fb4\u6e55\u6092\u516a\u6b15\u6d52\u516c\u4ec1\u675b\u50cf\u55b5\u4e81\u5783\u5519\u6d11\u6fe9\u6375\u5512(-885131536, 1329151986, "\u87e4\u8790\u87ea\u87e9\u87ee\u879f\u87e3\u87e6\u87ca\u87e4\u87ea\u87fd\u87f5\u83eb\u83ec", -993124670, -1466280833);
            "\u6bad".length();
            "\u7062\u5fd2\u6cad\u6894\u5da0".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u708f\u6172\u6688".length();
            "\u544c\u6786\u5f44\u5d32".length();
            array5[0] = \u5297\u5640\u604c\u5dcc\u61e4\u5abd\u5b6b\u629b\u6b2b\u69df\u6748\u694c\u6791\u70fe\u5e25\u56a1\u50f0\u6027\u5270\u6f22\u616a\u690b\u5eb0\u5fb4\u6e55\u6092\u516a\u6b15\u6d52\u516c\u4ec1\u675b\u50cf\u55b5\u4e81\u5783\u5519\u6d11\u6fe9\u6375\u5512(-984786240, 1325800753, "\ubbfa\ubb96\ubb8d\ubb91\ubb99\ubbda\ubbaa\ubb8d\ubbad\ubb8c\ubb93\ubb9d\ubb8b\ubbb5", 1450589768, 1229767215);
            array4[n2] = StyleUtils.gold(array5);
            commandSender.sendMessage(StyleUtils.gray(array4));
            return true;
        }
        final Player player = this.plugin.getServer().getPlayer(array[0]);
        if (player == null) {
            final Object[] array6 = { null };
            "\u61f0".length();
            "\u5d75\u6ac6".length();
            "\u6494".length();
            array6[0] = \u5297\u5640\u604c\u5dcc\u61e4\u5abd\u5b6b\u629b\u6b2b\u69df\u6748\u694c\u6791\u70fe\u5e25\u56a1\u50f0\u6027\u5270\u6f22\u616a\u690b\u5eb0\u5fb4\u6e55\u6092\u516a\u6b15\u6d52\u516c\u4ec1\u675b\u50cf\u55b5\u4e81\u5783\u5519\u6d11\u6fe9\u6375\u5512(-1794208759, 1249344877, "\u5b5b\u5b5d\u5b32\u5b4e\u5b48\u5f54\u5b46\u5b42\u5f77\u5b46\u5b40\u5b5b\u5b53\u5b43\u5b4e\u5f46", -328260562, 1482656330);
            commandSender.sendMessage(StyleUtils.red(array6));
            return true;
        }
        player.getWorld().spawn(player.getLocation(), (Class)TNTPrimed.class);
        "\u60b8".length();
        final Object[] array7 = new Object[2];
        "\u5c67\u5a53\u5dd7\u58eb\u6300".length();
        "\u6f6c".length();
        array7[0] = \u5297\u5640\u604c\u5dcc\u61e4\u5abd\u5b6b\u629b\u6b2b\u69df\u6748\u694c\u6791\u70fe\u5e25\u56a1\u50f0\u6027\u5270\u6f22\u616a\u690b\u5eb0\u5fb4\u6e55\u6092\u516a\u6b15\u6d52\u516c\u4ec1\u675b\u50cf\u55b5\u4e81\u5783\u5519\u6d11\u6fe9\u6375\u5512(721050799, -1134102692, "\u5075\u5079\u5073\u5465\u5063\u506e\u5016\u5064\u5044\u506c\u5069\u5467", 1718358572, 1575153142);
        "\u64b1\u5ae6\u5434\u60f6".length();
        "\u5cb4".length();
        "\u5364\u567a\u6ccb\u703f\u5fe2".length();
        "\u5b9a\u5de9\u54fe\u6a93\u550d".length();
        final int n3 = 1;
        final Object[] array8 = new Object[2];
        "\u4f10\u6e73\u6800\u6eb3\u69ca".length();
        "\u5a24\u5bf2\u6f0e\u60b4\u5dd2".length();
        "\u5178\u6277\u5632\u6f7f\u5b7d".length();
        array8[0] = player.getName();
        "\u5203".length();
        "\u5404\u6987\u4e22\u6560".length();
        final int n4 = 1;
        final Object[] array9 = { null };
        "\u6f91\u6310\u5120\u6f1f\u5fe1".length();
        "\u68a6".length();
        array9[0] = \u5297\u5640\u604c\u5dcc\u61e4\u5abd\u5b6b\u629b\u6b2b\u69df\u6748\u694c\u6791\u70fe\u5e25\u56a1\u50f0\u6027\u5270\u6f22\u616a\u690b\u5eb0\u5fb4\u6e55\u6092\u516a\u6b15\u6d52\u516c\u4ec1\u675b\u50cf\u55b5\u4e81\u5783\u5519\u6d11\u6fe9\u6375\u5512(1671985860, -1288629219, "\u3bd2\u3fee\u3f94\u3fe6\u3be3\u3ff2\u3ffe\u3f83\u3fd9\u3ffa\u3fff\u3fe4\u3fe3\u3ffa\u3be6\u3fe6\u3ff6\u3fef\u3fcc\u58cb\u6d8a\u7032\u5e3f", 997745868, -489606748);
        array8[n4] = StyleUtils.gray(array9);
        array7[n3] = StyleUtils.gold(array8);
        commandSender.sendMessage(StyleUtils.gray(array7));
        return true;
    }
    
    public static int ColonialObfuscator_\u6163\u69ee\u4ecd\u6f43\u6173\u7098\u6050\u5a56\u612f\u5f60\u571f\u5ecf\u57f4\u5063\u58e6\u6d1d\u511b\u6690\u50ef\u64f6\u665c\u6dc1\u530c\u703c\u5c0c\u549b\u6521\u5301\u587e\u606c\u6d9d\u53ed\u6b08\u610b\u4f19\u66e3\u52b8\u63a6\u699e\u61fc\u53e9(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
