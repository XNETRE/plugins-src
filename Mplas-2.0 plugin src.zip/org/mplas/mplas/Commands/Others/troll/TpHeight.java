package org.mplas.mplas.Commands.Others.troll;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;
import org.bukkit.*;

public class TpHeight implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender.hasPermission(\u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(1212747357, 1284558997, "\u05f6\u05c6\u05da\u05d5\u05f9\u05a2\u05e6\u05ef\u05c2\u05ea\u05ea", -1197398564, -23724340)) && !commandSender.hasPermission(\u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(1645767687, -284243401, "\uccbb\ucc8b\ucc97\ucc98\ucc84\uccdf\ucc93\ucc98\ucca4\ucc8d\ucc9c\ucc8e", -1688494812, -1045694591))) {
            final Object[] array2 = new Object[2];
            "\u6410\u6c87\u6f26".length();
            "\u6ad6\u5928\u60c6".length();
            "\u6771\u683e\u5225\u56ea\u5351".length();
            "\u5a97".length();
            array2[0] = \u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(-1413562588, 1781655982, "\ue0a4\ue48c\ue09c\ue09e\ue0ef\ue476\ue062\ue064\ue031\ue479\ue063\ue00c\ue07b\ue066", 1758603131, -1355901643);
            "\u4f8c\u699b\u5989\u5f97\u52d5".length();
            "\u6994".length();
            "\u597b".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u65ab\u637c\u5825\u5c8c\u637a".length();
            "\u67d2\u6b4e\u6c9f\u7015\u630f".length();
            array3[0] = \u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(423999310, -90727848, "\u421d", 927915416, 1355723505);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (!(commandSender instanceof Player)) {
            final Object[] array4 = { null };
            "\u65c9".length();
            "\u560d\u66c4\u4e36".length();
            array4[0] = \u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(-19019950, 1257238635, "\uc69d\uc696\uc696\uc686\uc68b\uc686\uc68b\uc291\uc6a7\uc683\uc6f9\uc6e6\uc6e0\uc68f\uc68e\uc691\uc29b\uc6e7\uc6b7\ua8ac\ua4f0\u9522\u9db6\u93c5\uacd6\u9161\uaead\u9694\ua517\u97e3\u92a5\uaa32\ua98b\u9983\uad01\ua4be\ua694\uade3\u8c9e\u9e4a", 840565709, -1055656400);
            commandSender.sendMessage(StyleUtils.red(array4));
            return true;
        }
        final Player player = (Player)commandSender;
        if (s.equalsIgnoreCase(\u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(1403351505, -1636538561, "\uc67a\uc652", -51248122, 1700058276))) {
            this.teleportUp(player);
        }
        else if (s.equalsIgnoreCase(\u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(1082585771, 237036671, "\u73f8\u73c0\u73da\u73c3", -910610481, -511161660))) {
            this.teleportDown(player);
        }
        return true;
    }
    
    public void teleportUp(final Player player) {
        if (!player.hasPermission(\u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(965896758, -1832211301, "\ue11a\ue12c\ue132\ue13f\ue12d\ue178\ue13e\ue135\ue11e\ue130\ue132", 1140470259, 1409422954)) || player.hasPermission(\u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(1409400281, -1486373896, "\ue33c\ue30e\ue310\ue301\ue313\ue34a\ue304\ue309\ue333\ue318\ue30b\ue317", -1101091379, 671893758))) {
            player.teleport(player.getWorld().getBlockAt((int)player.getLocation().getX(), ColonialObfuscator_\u5049\u5db6\u68b8\u5eb4\u532f\u58f2\u6d92\u588c\u6a66\u606f\u638e\u5a32\u6fd5\u6762\u4fb7\u551a\u5b32\u7067\u50cc\u55fb\u6eba\u6e2a\u59ef\u6d58\u62a3\u6ff9\u5366\u52bf\u6524\u6839\u700b\u60f0\u656a\u6177\u557c\u6e18\u521d\u6e1d\u565a\u5849\u65bc((int)player.getLocation().getY(), 365), (int)player.getLocation().getZ()).getLocation());
            "\u531f\u6f97\u5da8".length();
            final Object[] array = { null };
            "\u56f2".length();
            "\u66c8".length();
            "\u545c\u5ca0\u538b\u674d\u62d4".length();
            array[0] = \u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(1809535794, -2134397736, "\u9153\u9125\u954c\u9122\u9155\u915f\u9158\u9158\u917b\u912b\u912c\u913a\u9145\u9128\u9127\u9137\u9120\u9148\u950f\uff3c\uf31a\uc6ae\uce2d\uc445\uff4b\uc295\ufd2a\uc112\uf297\uc019\uc52d\uf9a6\ufa15\uce04\ufaf5\uf323\uf178\ufa00", 1627913141, -1494249123);
            player.sendMessage(StyleUtils.gray(array));
        }
        else {
            final Object[] array2 = new Object[2];
            "\u5ce4".length();
            "\u702b\u5635".length();
            "\u5ff8\u6f26\u5f80".length();
            array2[0] = \u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(-457296125, 1682229402, "\u5a35\u5e1d\u5a0d\u5a0f\u5a7e\u5e07\u5a13\u5a15\u5a40\u5e08\u5a12\u5a7d\u5a0a\u5a17", -1504417109, 426888039);
            "\u5b71\u5d26\u5dc5\u668a\u6685".length();
            "\u6664\u62ae\u5ce8\u5148".length();
            "\u693c\u64b6\u675d\u67a7".length();
            "\u5e50\u6d0c\u5de9".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u5710".length();
            "\u6efb\u551a".length();
            array3[0] = \u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(-1972166798, 1444006338, "\u028b", 496414812, -1557044219);
            array2[n] = StyleUtils.gray(array3);
            player.sendMessage(StyleUtils.red(array2));
        }
    }
    
    public void teleportDown(final Player player) {
        if (!player.hasPermission(\u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(-416784341, 240440453, "\u2318\u232e\u2330\u233d\u232f\u237a\u233c\u2337\u231c\u2332\u2330", 582154915, -1141740229)) || player.hasPermission(\u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(2046092419, 198232619, "\u6e47\u6e75\u6e6b\u6e5a\u6e48\u6e11\u6e5f\u6e52\u6e68\u6e43\u6e50\u6e4c", 530629917, -1471314468))) {
            final double x = player.getLocation().getX();
            final double y = player.getLocation().getY();
            final double z = player.getLocation().getZ();
            final World world = player.getWorld();
            final int n = (int)x;
            final int n2 = (int)y;
            final int n3 = 365;
            "\u636d\u6d3f".length();
            "\u4fef".length();
            "\u632e\u4ee7".length();
            player.teleport(world.getBlockAt(n, n2 - n3, (int)z).getLocation());
            "\u66e2\u651d\u66d1".length();
            "\u6570\u66a2\u5cae\u5247".length();
            "\u5ae5\u5431\u5292".length();
            final Object[] array = { null };
            "\u52fa\u6396\u5386\u6667".length();
            "\u5c9f\u521d".length();
            array[0] = \u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(1271390544, -1115865994, "\u387d\u3809\u3c62\u3802\u387b\u3873\u3876\u3870\u3855\u3807\u3802\u386a\u380b\u3864\u3869\u387f\u386e\u3804\u3c41\u567c\u5a54\u6fe2\u6763\u6d0d\u5605\u6bd9\u5464\u6842\u5bf9\u6975\u6c43\u50ce\u537b\u6768\u5394\u5a4e\u5861", -1756128380, 780892814);
            player.sendMessage(StyleUtils.gray(array));
        }
        else {
            final Object[] array2 = new Object[2];
            "\u53c6\u5587\u583f\u65de".length();
            "\u590b".length();
            "\u5db0\u6fad\u52c6\u6a73".length();
            "\u4fe1\u68c2\u59a4".length();
            array2[0] = \u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(-538800807, -601038478, "\u3d53\u397b\u3d6b\u3d69\u3d18\u3881\u3c95\u3c93\u3cc6\u388e\u3c94\u3cfb\u3c8c\u3c91", 1301778171, 1271782371);
            "\u50d8\u66aa\u66bf\u5f2d".length();
            "\u63dd\u5469".length();
            "\u5fbe\u5352\u54f3".length();
            final int n4 = 1;
            final Object[] array3 = { null };
            "\u603d\u6cea".length();
            array3[0] = \u707c\u6ef6\u54e9\u5bd1\u5a35\u7119\u571f\u526d\u50b1\u54ab\u65c7\u693d\u6a1a\u5745\u545a\u5da6\u6499\u664a\u6886\u6248\u6a03\u58d7\u6ae0\u507d\u5e5c\u67ec\u5f81\u63f8\u57cf\u6d01\u619f\u6940\u6a89\u5e55\u5f4b\u6429\u6b7d\u5987\u5dd7\u5492\u653a(-1075595710, 1972087796, "\ufac7", -1690603335, 795121578);
            array2[n4] = StyleUtils.gray(array3);
            player.sendMessage(StyleUtils.red(array2));
        }
    }
    
    public static int ColonialObfuscator_\u5049\u5db6\u68b8\u5eb4\u532f\u58f2\u6d92\u588c\u6a66\u606f\u638e\u5a32\u6fd5\u6762\u4fb7\u551a\u5b32\u7067\u50cc\u55fb\u6eba\u6e2a\u59ef\u6d58\u62a3\u6ff9\u5366\u52bf\u6524\u6839\u700b\u60f0\u656a\u6177\u557c\u6e18\u521d\u6e1d\u565a\u5849\u65bc(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
