package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;
import java.text.*;
import java.util.*;

public class PlayerInfo implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!commandSender.hasPermission(\u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(-534068028, 224698171, "\ue14a\ue178\ue166\ue16f\ue17d\ue124\ue162\ue165\ue14e\ue164\ue166", -264837679, -1208656054)) && !commandSender.hasPermission(\u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(-472421970, -1724359207, "\uea30\uea02\uea1c\uea6d\uea7f\uea26\uea71\uea67\uea48\uea7e\uea67\uea6c\uea70\uea64\uea6f\uea74", 264894653, -2086459692))) {
            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
            return true;
        }
        if (array.length == 1) {
            if (Bukkit.getPlayer(array[0]) != null || this.isOfflinePlayer(array[0])) {
                final Object[] array2 = new Object[2];
                "\u590e".length();
                array2[0] = \u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(148367233, 1987294909, "\u9089\u9087\u90fc\u9086\u90f8\u909c\u9099\u90e1\u90bd\u90e0\u948a\u9084\u908c\u9482\u9099\u9084\u90ed\u9089\u90a1\uc29e\ucdec", -530459253, -866447259);
                "\u5003".length();
                "\u5134\u5b16\u54eb\u5c5d".length();
                "\u59bd\u4ffc\u69cf".length();
                array2[1] = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, array[0]);
                commandSender.sendMessage(StyleUtils.gray(array2));
                final Object[] array3 = new Object[2];
                "\u5456\u63cb\u6429\u6af5\u5e27".length();
                "\u654b\u5c42".length();
                array3[0] = \u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(1443717843, 1840343822, "\ud06d\ud042\ud05c\ud04d\ud033\ud02d", 338145613, -803837717);
                "\u56a4\u51c5\u6514".length();
                "\u6fe3\u62af\u5639".length();
                final int n = 1;
                final Object[] array4 = { null };
                "\u6784\u5074\u5849".length();
                "\u61a9\u66fb\u6ee9".length();
                "\u5068\u5b8c".length();
                array4[0] = this.getUUID(array[0]);
                array3[n] = StyleUtils.gold(array4);
                commandSender.sendMessage(StyleUtils.gray(array3));
                final Object[] array5 = new Object[2];
                "\u5c8d\u5f15".length();
                "\u4e78".length();
                "\u584a\u6edf\u5d3f\u502c\u6c42".length();
                array5[0] = \u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(-27790049, -150888626, "\ua4c7\ua4c9\ua4c7\ua4bb\ua4c7\ua4cd\ua4a4\ua4d1\ua0fe\ua0c8", -1241178166, 1861014792);
                "\u6b51\u58fb\u655c".length();
                "\u5dee\u713b\u6acc\u588e\u6ec6".length();
                "\u690a".length();
                final int n2 = 1;
                final Object[] array6 = { null };
                "\u63d1\u52dc\u70a9\u6c0f\u7144".length();
                "\u6b82\u5ff2\u6e59\u50c7".length();
                array6[0] = this.getPlayerHealth(array[0]);
                array5[n2] = StyleUtils.gold(array6);
                commandSender.sendMessage(StyleUtils.gray(array5));
                final Object[] array7 = new Object[2];
                "\u5b63".length();
                "\u6ecb\u5226\u61c9\u6252\u577a".length();
                "\u63c6\u6b4d\u6187\u681f".length();
                array7[0] = \u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(63176681, 2132063181, "\u825a\u8254\u8222\u822f\u8657\u8649", -293220055, 1953176330);
                "\u6cb1\u5fb5\u4e91".length();
                "\u6ff8\u6ea5\u61ed\u6bdd\u6f97".length();
                final int n3 = 1;
                final Object[] array8 = { null };
                "\u4e5e".length();
                "\u58b4\u5ccb".length();
                "\u5dcb\u68a1\u5745\u61e4".length();
                "\u691e".length();
                array8[0] = this.getPlayerExp(array[0]);
                array7[n3] = StyleUtils.gold(array8);
                commandSender.sendMessage(StyleUtils.gray(array7));
                final Object[] array9 = new Object[2];
                "\u6610\u5106".length();
                array9[0] = \u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(-1844963089, 1619287883, "\uf70f\uf703\uf77c\uf704\uf6f4\uf6f3\uf6f1\uf6f8\uf6dd\uf2e8\uf68f\uf6ed\uf6e3\uf2e5\uf6f5\uf69b\uf6f7\uf2f0\uf6c0\ua4f1\uaf8e\ua002\u86e0\u8667\u9fe2\ua2ec", 457736444, 405091339);
                "\u5eac\u597d".length();
                "\u6ea0\u5ab4\u6e9b".length();
                "\u55db\u6bca\u5c1b\u521c\u6ee8".length();
                final int n4 = 1;
                final Object[] array10 = { null };
                "\u5fdb\u59f4\u5189\u5d78".length();
                "\u6ba9\u6487\u6bc3\u61ee\u6f39".length();
                "\u516d\u52c8\u5edc\u5218\u6b59".length();
                "\u6c4f\u4ea2".length();
                "\u54f5\u61c8\u6729\u6a05".length();
                array10[0] = this.getLastPlayed(array[0]);
                array9[n4] = StyleUtils.gold(array10);
                commandSender.sendMessage(StyleUtils.gray(array9));
                final Object[] array11 = new Object[2];
                "\u62d3\u639b".length();
                array11[0] = \u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(68359928, 1305260221, "\u9a76\u9a64\u9a6c\u9a19\u9a69\u9a1b\u9a6e\u9a1e\u9e46\u9e7e", 1433971695, -1571056767);
                "\u569a\u53f5\u691c\u6d73".length();
                final int n5 = 1;
                final Object[] array12 = { null };
                "\u5098\u614c".length();
                "\u55ee\u665d\u7100\u56c8\u68f0".length();
                "\u4ee8\u5c5b".length();
                "\u5755\u6f30\u5c86".length();
                array12[0] = this.isPlayerOp(array[0]);
                array11[n5] = StyleUtils.gold(array12);
                commandSender.sendMessage(StyleUtils.gray(array11));
                return true;
            }
        }
        else {
            final Object[] array13 = new Object[2];
            "\u5998\u549f\u4f71\u4f8b".length();
            "\u50b2\u6d47\u6f78\u56af\u6be2".length();
            "\u5285\u4e6c".length();
            array13[0] = \u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(238190141, -288542594, "\u6c76\u6c00\u6c7c\u6c79\u6c7c\u6c0f\u6c7d\u6c76\u6c58\u6c74\u6c7c\u6c6d\u6c67\u687b\u6862", 1672497841, 1225157855);
            "\u554f\u5532\u5ecb\u648a".length();
            "\u52df\u660a\u6bdb".length();
            final int n6 = 1;
            final Object[] array14 = { null };
            "\u6970\u6fa5\u5fc3\u6e37\u6b03".length();
            array14[0] = \u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(-1370052634, 234075914, "\u5c97\u5ce3\u5cfd\u5cf0\u5ce8\u5cec\u5cf2\u5ce7\u5cc2\u5ce0\u5cec\u5cb3\u5ccf\u5cfb\u5ce4\u5cff\u5cfd\u5cfb\u5cc0\u0edf", 120531243, 1180329276);
            array13[n6] = StyleUtils.gold(array14);
            commandSender.sendMessage(StyleUtils.gray(array13));
        }
        return false;
    }
    
    public boolean isOfflinePlayer(final String s) {
        return Bukkit.getOfflinePlayer(s).hasPlayedBefore();
    }
    
    public String getUUID(final String s) {
        return Bukkit.getOfflinePlayer(s).getUniqueId().toString();
    }
    
    public String getPlayerHealth(final String s) {
        final Player player = Bukkit.getPlayer(s);
        if (player != null) {
            return invokedynamic(makeConcatWithConstants:(DD)Ljava/lang/String;, player.getHealth(), player.getMaxHealth());
        }
        return \u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(1644011004, -7829413, "\u7e24\u7e6e\u7e02", -1789608277, 1830475045);
    }
    
    public String getPlayerExp(final String s) {
        final Player player = Bukkit.getPlayer(s);
        if (player != null) {
            return String.valueOf(player.getExp());
        }
        return \u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(-1756416188, 622073398, "\u293a\u2976\u2918", 624653196, -770278455);
    }
    
    public String getLastPlayed(final String s) {
        final long lastPlayed = Bukkit.getOfflinePlayer(s).getLastPlayed();
        "\u70e7".length();
        "\u6ec3\u5c75\u4fd6".length();
        "\u6176\u553b\u6b69".length();
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(\u6da1\u67ec\u5a5e\u58d3\u5f4b\u6c40\u6e2a\u702f\u65cc\u5bbf\u5068\u5fda\u578b\u576a\u5010\u5763\u6903\u590d\u5924\u60b1\u5ccd\u5376\u65e6\u4f9a\u67ff\u6774\u61cd\u6893\u5589\u50da\u5fd1\u56ad\u6680\u5ef1\u4efc\u610f\u63a7\u5a7e\u6393\u70c5\u699c(547099325, -803123789, "\u4aab\u4a86\u4a86\u4a84\u4ad6\u4ab0\u4abb\u4ad7\u4ac2\u4aee\u4aad\u4ad7\u4ad6\u4ab5\u4ae3\u4af7\u4ab4\u4ae1\u4acf", -1220333256, -490330969));
        "\u675a\u51dc\u62f5\u6896\u54ba".length();
        "\u710e".length();
        "\u6026\u64d6\u6ade\u5fe1".length();
        "\u6a22".length();
        return simpleDateFormat.format(new Date(lastPlayed));
    }
    
    public boolean isPlayerOp(final String s) {
        return Bukkit.getOfflinePlayer(s).isOp();
    }
    
    public static int ColonialObfuscator_\u62f8\u5387\u5364\u6016\u703a\u5a0b\u6423\u6e74\u58d2\u5646\u61fa\u6baf\u5467\u6ad0\u6d4c\u5931\u6ab6\u60e1\u6a46\u4e23\u611d\u519b\u53e0\u6037\u4eb8\u7114\u6c34\u62eb\u6974\u4ecd\u60dd\u6ca9\u5c50\u6cf2\u6432\u5fd5\u6e43\u6b99\u5857\u6109\u65ea(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
