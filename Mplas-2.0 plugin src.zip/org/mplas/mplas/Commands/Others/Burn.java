package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;

public class Burn implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        final Player player = (Player)commandSender;
        if (player.hasPermission(\u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(1292464756, 1845876175, "\uce10\uce22\uce3c\uce3d\uce2f\uce76\uce33\uce2e\uce0b\uce39", 1069721957, 1853735136))) {
            if (array.length == 0) {
                final Player player2 = player;
                final Object[] array2 = new Object[3];
                "\u5594\u6a49\u6c20\u6679".length();
                array2[0] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(869108172, 59701021, "\u5744\u5732\u574e\u574b\u574e\u573d\u574f\u5754\u577a\u5756\u575e\u574f\u5745\u5343\u575a\u5744\u575c\u574e\u576f\u3c9b\u045d\u1df1\u0371", -458554167, 426125575);
                "\u5335\u6040\u661c\u4e90\u5442".length();
                "\u6dd4\u5015".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u5c42\u544c".length();
                "\u5daa\u6b11".length();
                array3[0] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(-602165449, 910708810, "\u8063\u800d\u8018\u801f\u8003\u804d\u803f\u801a\u8024\u801b\u8006\u800a\u801a\u8022", -693410233, -693102283);
                array2[n] = StyleUtils.gold(array3);
                "\u6e64".length();
                "\u6ed8\u5b28\u6453\u6e95\u6b60".length();
                "\u6957\u4e53\u6085".length();
                array2[2] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(-1193565029, 1445844968, "\u3213", -1499431051, 1980972664);
                player2.sendMessage(StyleUtils.gray(array2));
            }
            if (array.length == 1) {
                if (player.getServer().getPlayer(array[0]) != null) {
                    final Player player3 = player.getServer().getPlayer(array[0]);
                    player3.setFireTicks(1000000);
                    final Player player4 = player3;
                    final Object[] array4 = new Object[3];
                    "\u6a25\u67b2\u57ef".length();
                    "\u6bf0\u6922\u5bcb".length();
                    array4[0] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(-1947944997, 780495554, "\u23a3\u23d7\u27b8\u23a5\u23a6\u23aa\u2397\u2393\u23b6\u2392\u2392\u2798", -944215526, 1191874801);
                    "\u69fc\u6af6".length();
                    "\u614a\u61fc\u67d6".length();
                    final int n2 = 1;
                    final Object[] array5 = { null };
                    "\u536c\u500e".length();
                    array5[0] = player3.getName();
                    array4[n2] = StyleUtils.gold(array5);
                    "\u5c04".length();
                    "\u5c97\u7034\u69f6\u711c".length();
                    array4[2] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(-8890559, 1144352141, "\ua77d", 773798244, -960977737);
                    player4.sendMessage(StyleUtils.gray(array4));
                    if (player.getName().equalsIgnoreCase(player3.getName())) {
                        final Object[] array6 = new Object[2];
                        "\u699c\u5ba4\u6ea9\u614e".length();
                        "\u61ba".length();
                        "\u60eb".length();
                        array6[0] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(1391038515, 1946284343, "\ub443\ub446\ub44c\ub439\ub440\ub43e\ub056\ub445\ub464\ub442\ub443\ub452\ub425\ub43f\ub0ae\ub4db\ub4b2\ub4a2\ub48a\udf7c\ue7ca\ufe0b\ue4fe\uee09\ue967\uec6c", -1357961358, -1494550933);
                        "\u66a6\u555e\u539c".length();
                        final int n3 = 1;
                        final Object[] array7 = { null };
                        "\u6407\u5400\u602c\u650b\u6e6d".length();
                        "\u59ac\u6b43".length();
                        array7[0] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(1347410037, 184654436, "\u788b", -1245078556, 1369612572);
                        array6[n3] = StyleUtils.gray(array7);
                        commandSender.sendMessage(StyleUtils.red(array6));
                        return false;
                    }
                }
                else {
                    final Player player5 = player;
                    final Object[] array8 = new Object[2];
                    "\u5407\u546d\u4f74\u649a\u667a".length();
                    "\u50c1\u4f87".length();
                    "\u5f86\u6d87\u6371".length();
                    "\u5a6c\u4fd6\u5ad4\u4e31".length();
                    array8[0] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(1346321520, -279011241, "\u2323\u2325\u2356\u232a\u2320\u273c\u232a\u232e\u271f\u232d\u2329\u233d\u232f\u2337\u2332", 193151876, 456325339);
                    "\u6dac\u65e9".length();
                    "\u58dd\u6976".length();
                    final int n4 = 1;
                    final Object[] array9 = { null };
                    "\u67a6\u599f\u6d8b".length();
                    "\u6c72".length();
                    "\u5685\u5e8f".length();
                    "\u5122".length();
                    array9[0] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(114218935, -247823736, "\uc5a6", -301746464, -1255397868);
                    array8[n4] = StyleUtils.gray(array9);
                    player5.sendMessage(StyleUtils.red(array8));
                }
            }
        }
        else {
            final Object[] array10 = new Object[2];
            "\u4ebf\u50a9\u5cac".length();
            "\u55a1\u58e4\u5c4a\u51fa\u70c7".length();
            array10[0] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(-822426188, -2064304090, "\u8528\u8104\u8514\u852a\u855b\u813e\u852a\u8528\u857d\u8131\u852b\u8548\u853f\u852e", 2049069277, -273404921);
            "\u4e40\u689e\u633d\u6f3a\u6ab9".length();
            "\u535c".length();
            "\u62ad\u4fd1\u643d\u50c1\u56fb".length();
            "\u68e7\u4e46\u554d\u5b10".length();
            final int n5 = 1;
            final Object[] array11 = { null };
            "\u66a4\u6c20\u4f12".length();
            "\u6fff\u614d".length();
            "\u6f48".length();
            "\u4e5f".length();
            array11[0] = \u5c37\u54b9\u60a8\u678e\u6b4c\u502e\u5622\u54b5\u5ef2\u6440\u633d\u59d8\u67e1\u5b91\u5098\u6a81\u6fd2\u6a56\u6e48\u5891\u6e04\u6374\u5703\u6540\u64ff\u643e\u6ad1\u5443\u5cc8\u66f0\u6938\u694e\u54f2\u6131\u56e3\u6c39\u668b\u6614\u5fe2\u7109\u6360(302809952, -2033861793, "\ufb01", -1845831076, -35383040);
            array10[n5] = StyleUtils.gray(array11);
            commandSender.sendMessage(StyleUtils.red(array10));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u706a\u5f20\u538d\u6edc\u4e72\u5c46\u6fa6\u6f5b\u5dba\u5400\u5827\u5de1\u65a9\u5eb6\u5105\u624a\u544c\u5801\u6e4d\u676b\u69e8\u6892\u6e86\u4fa2\u5cf5\u657e\u6bdc\u6144\u6276\u6d25\u68ed\u5610\u5f45\u6660\u6086\u65b8\u5765\u5934\u6703\u5bae\u69c8(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
