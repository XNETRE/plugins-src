package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;

public class Seen implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
            return true;
        }
        final Player player = (Player)commandSender;
        if (!player.hasPermission(\u5de8\u5b83\u6a0a\u5872\u6f85\u4eef\u67e6\u70b7\u57a4\u69d0\u6c31\u58ea\u66e0\u5628\u5e79\u5002\u67a2\u59a1\u6715\u6909\u6b2b\u4f2a\u5927\u692c\u681f\u59df\u51d1\u66af\u6013\u53f4\u5803\u676d\u5abd\u6468\u6116\u61ed\u52a2\u5763\u50e6\u5dfa\u5a8e(-1334759882, 1859548318, "\u77e8\u77d8\u77c4\u77cb\u7427\u747c\u7438\u7431\u741c\u7434\u7434", 847110652, 1405734034)) && !player.hasPermission(\u5de8\u5b83\u6a0a\u5872\u6f85\u4eef\u67e6\u70b7\u57a4\u69d0\u6c31\u58ea\u66e0\u5628\u5e79\u5002\u67a2\u59a1\u6715\u6909\u6b2b\u4f2a\u5927\u692c\u681f\u59df\u51d1\u66af\u6013\u53f4\u5803\u676d\u5abd\u6468\u6116\u61ed\u52a2\u5763\u50e6\u5dfa\u5a8e(1494908330, 593364097, "\u97e6\u97d6\u97ca\u97c5\u97d1\u978a\u97dc\u97c6\u97ea\u97cd", 1677061776, -146669453))) {
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
            return true;
        }
        if (array.length != 1) {
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
            return true;
        }
        final Player player2 = player.getServer().getPlayer(array[0]);
        if (player2.isOnline()) {
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, player2.getName(), ChatColor.GRAY));
        }
        else {
            final long lastPlayed = player2.getLastPlayed();
            if (lastPlayed == 0L) {
                player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;J)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, player2.getName(), ChatColor.GRAY, lastPlayed));
            }
            else {
                player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, player2.getName(), ChatColor.GRAY));
            }
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u6389\u6d1a\u610a\u646c\u6f0c\u6898\u591a\u5606\u5cab\u70a3\u67c0\u5963\u6d21\u5397\u5a5d\u6eea\u6932\u5b4e\u6d1d\u57dc\u56f0\u70ef\u5d94\u6d25\u500a\u58a1\u6efc\u50fc\u56f6\u5f7c\u64f2\u6bef\u6d66\u6955\u582f\u51c2\u4f63\u6a3c\u5b16\u5c56\u66e5(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
