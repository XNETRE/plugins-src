package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.*;
import org.mplas.mplas.Companents.*;

public class Broadcast implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!commandSender.hasPermission(\u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd(-630345008, -188818236, "\u36a8\u3698\u3680\u368f\u369f\u36c4\u368c\u3685\u36ac\u3684\u3680", 1085899986, 224779328)) || commandSender.hasPermission(\u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd(-642789604, -1990599736, "\u5328\u5318\u5308\u5307\u5317\u534c\u530f\u5313\u532e\u530c\u5312\u5307\u5300\u5303\u5301", 1164192102, 1393716916))) {
            if (array.length != 0) {
                String \u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd = \u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd(-1937806055, -1900951089, "", 135510261, 1343462942);
                for (int i = 0; i < array.length; i += 31527, i -= 31526) {
                    \u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, String.valueOf(\u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd), array[i]);
                }
                Bukkit.broadcastMessage(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, commandSender.getName(), ChatColor.translateAlternateColorCodes('&', \u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd)));
                "\u502d".length();
                "\u501a\u5189\u5b8e".length();
                "\u5225\u7103".length();
                "\u62b9\u5051".length();
            }
            else {
                final Object[] array2 = new Object[3];
                "\u52f4".length();
                "\u5112".length();
                "\u6474\u6949".length();
                array2[0] = \u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd(572796458, -1767782943, "\ud446\ud432\ud448\ud44b\ud44c\ud43d\ud451\ud429\ud473\ud424\ud450\ud04d\ud052", -413650134, -1318319876);
                "\u524d\u5652".length();
                "\u4edd\u4eb0\u5b28\u5e8d".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u6714".length();
                "\u4f38\u511a\u5d54\u6bd4".length();
                "\u6627\u66c7\u64e2".length();
                array3[0] = \u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd(-561825282, -526635805, "\u1f94\u1ff4\u1fe4\u1ffb\u1feb\u1fe8\u1fe4\u1fea\u1fdc\u1ff7\u1fa4\u1fcd\u1feb\u1feb\u1ff7\u1fef\u1fda", -933558484, 2048003529);
                array2[n] = StyleUtils.gold(array3);
                "\u57c8".length();
                "\u6ddf\u65b9\u6f86".length();
                "\u4f3c\u695f".length();
                array2[2] = \u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd(-877226967, -1559184765, "\ub724", -284451031, 782829258);
                commandSender.sendMessage(StyleUtils.gray(array2));
            }
        }
        else {
            final Object[] array4 = new Object[2];
            "\u5eca\u5ec4\u4fe5\u5f96\u6afb".length();
            array4[0] = \u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd(-737951946, 1670150874, "\u6906\u6d2e\u693e\u693c\u694d\u6d24\u6930\u6936\u6963\u6d2b\u6931\u695e\u6929\u6924", 195681507, 693728361);
            "\u50c3".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u695c\u53ee\u561e".length();
            "\u5ef0\u5018\u640e".length();
            array5[0] = \u68ad\u5ba2\u707a\u61dc\u62c4\u53f8\u4edf\u6e41\u4e3e\u7096\u4fc8\u5c05\u6c2a\u6ccf\u56d5\u6b4b\u6504\u5e5c\u6100\u574c\u661a\u51a2\u53fb\u66ac\u6f37\u63f8\u70eb\u6d0a\u6fc1\u54c1\u6e64\u6cee\u6bdd\u65c2\u5464\u657d\u6dd3\u5b9e\u5b64\u5807\u5fcd(-438335326, 326939823, "\u0fca", -2137018022, 15827711);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u5fd8\u6213\u63c5\u62ca\u678c\u5a19\u713a\u66cf\u6d4c\u5dc1\u6b3f\u648a\u64b7\u61b0\u5e75\u5028\u60f7\u6777\u6009\u70d7\u5d7f\u6631\u540f\u5bef\u678b\u56a6\u69ee\u547d\u5f6d\u6e12\u64f5\u6e26\u58aa\u5408\u6524\u67d1\u5d08\u51dc\u51f9\u6ac2\u576d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
