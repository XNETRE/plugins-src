package org.mplas.mplas.Commands.Others;

import org.jetbrains.annotations.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;
import org.bukkit.entity.*;

public class Gamemodes implements CommandExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (array.length == 0) {
            final Object[] array2 = new Object[2];
            "\u595c\u6bd3\u6a5d\u66d4".length();
            array2[0] = \u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(-2086571049, 1399086028, "\u1b58\u1b2c\u1b52\u1b51\u1b52\u1b23\u1b53\u1b56\u1b86\u1ba8\u1ba2\u1bb5\u1bb9\u1fbd\u1ba6\u1bb6\u1ba0\u1bbc\u1b9e\u47c3\u73d3\u4f11\u453d\u4425", -1392072584, 1909694304);
            "\u622e\u6fd3\u5e0b".length();
            "\u574a\u5225\u6c59".length();
            "\u5642\u585e\u67b6".length();
            final int n = 1;
            final Object[] array3 = new Object[2];
            "\u5a6e\u4f75\u57e3\u68d8\u5dd7".length();
            "\u6e63\u625a\u4fe3\u5802".length();
            array3[0] = \u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(-301443275, -1763146042, "\u7ffd\u7f9a\u7f92", -2072513691, -234201849);
            "\u4ee0\u6452\u6bd1\u6aa2".length();
            final int n2 = 1;
            final Object[] array4 = new Object[3];
            "\u5c3f\u5319".length();
            "\u619e\u6c0b\u5433\u6834".length();
            array4[0] = \u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(388238490, 1563947368, "\u2cb6\u2ce0", 1685034526, -73840839);
            "\u61a7\u6b4c\u608b\u5521\u58c6".length();
            array4[1] = \u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(317581270, -381225282, "\u01c1\u01be\u01f1\u01bc\u01f2\u01bc\u01fa", -1166261393, -1293593675);
            "\u6802\u4f46\u6975".length();
            "\u5082\u548c".length();
            final int n3 = 2;
            final Object[] array5 = new Object[2];
            "\u4ecb".length();
            "\u60a9".length();
            "\u6bdf\u529b".length();
            array5[0] = \u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(-1185316532, 2077631765, "\u194b\u191b", 358043320, 636089268);
            "\u4ef0".length();
            "\u6769\u6832".length();
            "\u5ba7\u69c7\u68a0\u5606".length();
            final int n4 = 1;
            final Object[] array6 = { null };
            "\u6465".length();
            array6[0] = \u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(1977141513, -921692667, "\u76f2", 611163049, 916009530);
            array5[n4] = StyleUtils.gray(array6);
            array4[n3] = StyleUtils.gray(array5);
            array3[n2] = StyleUtils.gray(array4);
            array2[n] = StyleUtils.gold(array3);
            commandSender.sendMessage(StyleUtils.gray(array2));
            return false;
        }
        if (commandSender.hasPermission(\u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(977882229, 1246743433, "\u50b2\u5080\u509e\u5097\u5085\u50dc\u509a\u509d\u50b6\u509c\u509e", -1610081983, 945737249))) {
            if (!commandSender.hasPermission(\u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(-642082650, -82486532, "\u0d15\u0d25\u0d39\u0d36\u0d2a\u0d71\u0d33\u0d39\u0d11\u0d35\u0d3a\u0d2a\u0d38\u0d28", -1550431516, 1063880069))) {
                final Object[] array7 = new Object[2];
                "\u4e23".length();
                "\u6414\u57e3".length();
                "\u5399\u52ed\u6701\u66bf".length();
                array7[0] = \u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(654779637, -231921543, "\uaa16\uae3e\uaa2e\uaa2c\uaa5d\uae34\uaa20\uaa26\uaa73\uae3b\uaa21\uaa4e\uaa39\uaad4", 1324975219, 1199777417);
                "\u6a4f\u4f8e\u5594".length();
                "\u5d9e\u65a6\u5d46".length();
                final int n5 = 1;
                final Object[] array8 = { null };
                "\u6478".length();
                "\u57a9\u59d1\u6760".length();
                array8[0] = \u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(-1021922208, -224115430, "\u6149", 1576751341, 783925436);
                array7[n5] = StyleUtils.gray(array8);
                commandSender.sendMessage(StyleUtils.red(array7));
            }
        }
        final String s2 = array[0];
        int n6 = -1;
        switch (s2.hashCode()) {
            case 49: {
                if (s2.equals(\u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(-794945478, 1190194201, "\u5ece", -1436074379, -1583704854))) {
                    n6 = 0;
                    break;
                }
                break;
            }
            case 1820422063: {
                if (s2.equals(\u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(1372777190, -1858359568, "\uedad\ued9f\ued8a\ued8e\ued9b\ued86\ued90\ued8d", 1397883159, 65251468))) {
                    n6 = 1;
                    break;
                }
                break;
            }
            case 48: {
                if (s2.equals(\u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(1140095248, -1430187072, "\u91ef", -1109642195, 758042465))) {
                    n6 = 2;
                    break;
                }
                break;
            }
            case -1600582850: {
                if (s2.equals(\u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(-2146342874, -351527103, "\u2199\u21b2\u21b5\u21b3\u21b2\u21ab\u21b7\u21b6", 297327564, 1392479490))) {
                    n6 = 3;
                    break;
                }
                break;
            }
            case 51: {
                if (s2.equals(\u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(865766, -1026287517, "\uf8e8", -1743522435, -1458298784))) {
                    n6 = 4;
                    break;
                }
                break;
            }
            case -1684593425: {
                if (s2.equals(\u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(909597157, -740769800, "\u4cf5\u4cdd\u4cca\u4ccc\u4cdb\u4cf6\u4cea\u4cff\u4cc0", 1702664859, -2012204989))) {
                    n6 = 5;
                    break;
                }
                break;
            }
            case 50: {
                if (s2.equals(\u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(1328295134, 1102207347, "\u63ed", 1372519088, -898438015))) {
                    n6 = 6;
                    break;
                }
                break;
            }
            case -694094064: {
                if (s2.equals(\u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(-654070529, 1836346857, "\u3277\u3259\u3249\u325a\u3251\u3273\u327b\u3272\u3247", 1989037403, 94813720))) {
                    n6 = 7;
                    break;
                }
                break;
            }
        }
        GameMode gameMode = null;
        switch (n6) {
            case 0:
            case 1: {
                gameMode = GameMode.CREATIVE;
                break;
            }
            case 2:
            case 3: {
                gameMode = GameMode.SURVIVAL;
                break;
            }
            case 4:
            case 5: {
                gameMode = GameMode.SPECTATOR;
                break;
            }
            case 6:
            case 7: {
                gameMode = GameMode.ADVENTURE;
                break;
            }
            default: {
                gameMode = GameMode.SURVIVAL;
                break;
            }
        }
        final GameMode gameMode2 = gameMode;
        if (commandSender instanceof Player) {
            final Player player = (Player)commandSender;
            player.setGameMode(gameMode2);
            final Player player2 = player;
            final Object[] array9 = new Object[2];
            "\u6946\u5db8\u6121\u4f18".length();
            "\u6ba7\u69ba\u4f13".length();
            "\u6a02\u51e7".length();
            array9[0] = \u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(-2041538681, 1084615810, "\u4afc\u4ab3\u4ab0\u4ac0\u4acb\u4ace\u4ac9\u4acc\u4aee\u4aca\u4ed0\u4aa2\u4ad6\u4ac4\u4acb\u4adb\u4ec3", 923059104, 597947961);
            "\u62e0".length();
            final int n7 = 1;
            final Object[] array10 = new Object[2];
            "\u618b\u6e08\u70ef\u5597\u668e".length();
            "\u642f\u563e\u6e9d\u52e2\u6f73".length();
            "\u5142\u5221\u5ecf\u6de5\u662a".length();
            "\u69b8\u5a2b\u6c24\u4f17\u5834".length();
            array10[0] = gameMode2.name().toLowerCase();
            "\u6c32\u551f".length();
            "\u56e2\u709f\u6631".length();
            "\u5e94\u52cc\u535a\u5898\u502d".length();
            "\u5cab\u6a94\u66ff".length();
            final int n8 = 1;
            final Object[] array11 = { null };
            "\u69b2\u6b00".length();
            "\u58ab\u689f\u619c\u5393\u6a50".length();
            array11[0] = \u5fd5\u5410\u6bad\u682f\u5857\u50ac\u581f\u6388\u4eab\u5267\u6255\u4e6c\u59b9\u552b\u5b02\u6db8\u68c5\u67ca\u5a4f\u5222\u6a57\u6f6e\u57c4\u60e4\u664d\u65e4\u4ee6\u5c4e\u4e6a\u67ae\u629d\u57ca\u50ee\u589b\u5f86\u6fba\u56aa\u6afc\u6567\u4f13\u61f5(922917221, -1670064500, "\ub7f0", 789218447, 878148859);
            array10[n8] = StyleUtils.gray(array11);
            array9[n7] = StyleUtils.gold(array10);
            player2.sendMessage(StyleUtils.gray(array9));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u55ba\u5eed\u5155\u680d\u5992\u61dd\u5d33\u626c\u5d3d\u53d0\u5358\u6097\u6116\u581a\u6687\u527e\u5f26\u5a31\u6602\u4ff3\u57e5\u628c\u6e85\u524b\u55ce\u5f0d\u70fa\u5461\u63a9\u4eff\u57bb\u67f4\u5b35\u61bf\u6db3\u61c5\u60ac\u5ee7\u69e7\u5921\u5c04(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
