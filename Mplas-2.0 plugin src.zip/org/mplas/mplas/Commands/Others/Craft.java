package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;

public class Craft implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!(commandSender instanceof Player)) {
            final Object[] array2 = new Object[2];
            "\u5a61\u6523\u51e1".length();
            "\u56b4\u62af\u5998\u6d4e".length();
            "\u5fe1\u60d9".length();
            "\u4ede\u575c\u569d".length();
            array2[0] = \u5030\u53db\u64f9\u65f3\u661c\u6113\u6fd7\u5116\u64e1\u66b1\u6aef\u5454\u4faf\u5159\u5f58\u5360\u63bc\u5810\u5b69\u547d\u602b\u5a12\u4fcb\u5aee\u5ae7\u58c0\u5b23\u6969\u52f1\u57fd\u543e\u52e4\u6361\u7038\u54e2\u70de\u6ab2\u6a4e\u52eb\u5a08\u6a06(599720963, -122100619, "\u33dc\u33d3\u33d3\u33df\u33d2\u33d3\u33ad\u37c0\u33fe\u33d6\u33db\u33c8\u33b8\u37d5\u33ce\u33a1\u33c5\u33de\u33f7\u42cc\u5cb3\u679b\u50c8\u5e2b\u5df8\u681c\u6365\u430e\u5a35\u6756\u5ce0\u6668\u57b2\u585d\u569f\u5ba3\u5aae\u43ce\u5d29", 1840779651, 634111600);
            "\u4fba\u5c19".length();
            "\u55dc\u6e7a".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u5418\u508e\u5829\u6ec6".length();
            "\u65dd\u5020\u5471\u5de4\u5079".length();
            array3[0] = \u5030\u53db\u64f9\u65f3\u661c\u6113\u6fd7\u5116\u64e1\u66b1\u6aef\u5454\u4faf\u5159\u5f58\u5360\u63bc\u5810\u5b69\u547d\u602b\u5a12\u4fcb\u5aee\u5ae7\u58c0\u5b23\u6969\u52f1\u57fd\u543e\u52e4\u6361\u7038\u54e2\u70de\u6ab2\u6a4e\u52eb\u5a08\u6a06(-221074919, 1274764133, "\udee5", -1003091516, 311174719);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        final Player player = (Player)commandSender;
        if (commandSender.hasPermission(\u5030\u53db\u64f9\u65f3\u661c\u6113\u6fd7\u5116\u64e1\u66b1\u6aef\u5454\u4faf\u5159\u5f58\u5360\u63bc\u5810\u5b69\u547d\u602b\u5a12\u4fcb\u5aee\u5ae7\u58c0\u5b23\u6969\u52f1\u57fd\u543e\u52e4\u6361\u7038\u54e2\u70de\u6ab2\u6a4e\u52eb\u5a08\u6a06(-1905250605, 2051574146, "\u5817\u5827\u583b\u5834\u5820\u587b\u583f\u5836\u5813\u583b\u583b", -280396752, 511738712)) && !commandSender.hasPermission(\u5030\u53db\u64f9\u65f3\u661c\u6113\u6fd7\u5116\u64e1\u66b1\u6aef\u5454\u4faf\u5159\u5f58\u5360\u63bc\u5810\u5b69\u547d\u602b\u5a12\u4fcb\u5aee\u5ae7\u58c0\u5b23\u6969\u52f1\u57fd\u543e\u52e4\u6361\u7038\u54e2\u70de\u6ab2\u6a4e\u52eb\u5a08\u6a06(-1596958014, 1202714493, "\udc4f\udc7d\udc63\udc6a\udc78\udc21\udc65\udc76\udc47\udc6e\udc79", -938357295, 119192591))) {
            final Object[] array4 = new Object[2];
            "\u4f03\u6c88\u5fab\u6a1e\u621e".length();
            array4[0] = \u5030\u53db\u64f9\u65f3\u661c\u6113\u6fd7\u5116\u64e1\u66b1\u6aef\u5454\u4faf\u5159\u5f58\u5360\u63bc\u5810\u5b69\u547d\u602b\u5a12\u4fcb\u5aee\u5ae7\u58c0\u5b23\u6969\u52f1\u57fd\u543e\u52e4\u6361\u7038\u54e2\u70de\u6ab2\u6a4e\u52eb\u5a08\u6a06(-1430562730, -2078458822, "\u4ca1\u488f\u4c81\u4c81\u4cf2\u4895\u4c87\u4c83\u4cd4\u489a\u4c8e\u4ce3\u4c96\u4c85", -961987346, -1784475581);
            "\u5441\u5e77\u5c18".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u5d20".length();
            "\u6812\u5b45\u5601".length();
            array5[0] = \u5030\u53db\u64f9\u65f3\u661c\u6113\u6fd7\u5116\u64e1\u66b1\u6aef\u5454\u4faf\u5159\u5f58\u5360\u63bc\u5810\u5b69\u547d\u602b\u5a12\u4fcb\u5aee\u5ae7\u58c0\u5b23\u6969\u52f1\u57fd\u543e\u52e4\u6361\u7038\u54e2\u70de\u6ab2\u6a4e\u52eb\u5a08\u6a06(106325695, -41477810, "\ud7be", -89965949, -2060348754);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
            return false;
        }
        if (command.getName().equalsIgnoreCase(\u5030\u53db\u64f9\u65f3\u661c\u6113\u6fd7\u5116\u64e1\u66b1\u6aef\u5454\u4faf\u5159\u5f58\u5360\u63bc\u5810\u5b69\u547d\u602b\u5a12\u4fcb\u5aee\u5ae7\u58c0\u5b23\u6969\u52f1\u57fd\u543e\u52e4\u6361\u7038\u54e2\u70de\u6ab2\u6a4e\u52eb\u5a08\u6a06(1037686793, 46772157, "\u9536\u950a\u9519\u951c\u9570", 1351234364, 1383518622))) {
            player.openWorkbench((Location)null, true);
            "\u6a92\u6a9e\u6361".length();
            "\u630c\u6d9c".length();
            "\u5f0d".length();
            return true;
        }
        return false;
    }
    
    public static int ColonialObfuscator_\u619d\u679d\u6606\u6305\u6b8f\u5635\u631c\u4f67\u6bb6\u6402\u6c9e\u6ba5\u656c\u5165\u5c23\u5db3\u5f0e\u6665\u673c\u522f\u4fe1\u6b8e\u56a8\u5d52\u694b\u6af9\u539d\u5ab7\u6da1\u6def\u6eff\u5016\u713e\u57a8\u5c2a\u521c\u6f4a\u6caf\u624b\u6a42\u6809(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
