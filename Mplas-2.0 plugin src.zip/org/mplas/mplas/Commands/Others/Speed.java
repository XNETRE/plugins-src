package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;

public class Speed implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!command.getName().equalsIgnoreCase(\u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-918959208, 1660535339, "\u4da4\u4d8a\u4d9b\u4d99\u4d9a", -277188094, -2090453467))) {
            return false;
        }
        if (!commandSender.hasPermission(\u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(643242069, -894762578, "\u34c2\u34f2\u34e2\u34ed\u34fd\u34a6\u34e6\u34ef\u34c6\u34ee\u34f2", 760715814, 1306179377)) || !commandSender.hasPermission(\u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-1815493769, 2013128799, "\u1c85\u1cbb\u1ca5\u1ca8\u1cba\u1ce7\u1cb3\u1cbe\u1c89\u1cbb\u1cbf", -757420505, 943364516))) {
            final Object[] array2 = new Object[2];
            "\u5be5\u6d2e\u5e65\u62b8\u639c".length();
            "\u55f5\u5da3\u5c8c".length();
            "\u6d3b\u6913\u6793".length();
            "\u6673".length();
            "\u6781".length();
            array2[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(974731120, -1183772680, "\u2322\u270c\u231e\u231e\u2311\u2776\u2360\u2364\u2337\u2779\u2361\u230c\u2375\u2366", -786358468, -1089863434);
            "\u688f\u6811\u654e".length();
            "\u57c1".length();
            "\u62ad".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u54c4\u55b1\u6355\u6ac7\u6ca3".length();
            "\u5bb5\u66ec\u6fe0".length();
            "\u5b33\u505e\u5f8f\u6703\u6a11".length();
            array3[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-1976485872, -1680089786, "\u1612", 712116724, -217711918);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return true;
        }
        if (!(commandSender instanceof Player)) {
            final Object[] array4 = new Object[2];
            "\u533d\u4e92\u5482\u544b".length();
            "\u6521\u6af5".length();
            "\u637e".length();
            array4[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-570220123, -354190882, "\u3c8b\u3c80\u3c80\u3cf0\u3cfd\u3cf0\u3c8e\u38e7\u3cd9\u3cf5\u3cf8\u3ce7\u3c97\u38e6\u3cfd\u3c96\u3cf2\u3ced\u3cc4\u6bc0\u73d4\u72d5\u5092\u69e1\u5d92\u66dc\u52b5\u6e28\u5c74\u568f\u6921\u58c2\u581d\u56b0\u7329\u5410\u5cf2\u7399\u6496", 60382141, 1162427156);
            "\u5d04\u554f\u69b9\u5adc\u5ae7".length();
            "\u5cdb\u6e6d\u58fb".length();
            "\u6ff7\u5ce4\u6eed\u5c86".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u693d\u5fc8".length();
            "\u5123".length();
            array5[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-23069651, -1752382634, "\u2754", -515793539, -1063877328);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
            return true;
        }
        final Player player = (Player)commandSender;
        if (array.length != 1) {
            final Object[] array6 = new Object[2];
            "\u571b\u70ed".length();
            array6[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-1954121678, -1022237031, "\u528a\u52fc\u5280\u5285\u5280\u52f3\u5281\u528a\u52a4\u5288\u5280\u5291\u529b\u5687", 1182681681, -512851413);
            "\u5a21\u6410\u5d13\u5288\u54ac".length();
            "\u6e65\u63c6\u51f4\u5b8a\u65e6".length();
            final int n3 = 1;
            final Object[] array7 = new Object[2];
            "\u6d68\u57ee\u68d7\u5cf3".length();
            "\u53a6\u5157\u6081\u55ba\u6dc4".length();
            array7[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-1315426511, -901531673, "\ubbe0\ubb91\ubb92\ubb85\ubb83\ubb84\ubbcb\ubbbc\ubfec\ubfdf\ubfa1\ubfc9\ubfcd\ubbbf", -1846005136, -559935190);
            "\u52b5\u6f4c\u4ea4\u5643".length();
            "\u5f04".length();
            "\u5eb9\u5900\u6f96\u68a7".length();
            final int n4 = 1;
            final Object[] array8 = { null };
            "\u61f2\u5893".length();
            array8[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-955250525, -1223532585, "\uceca", 1897281415, -542724517);
            array7[n4] = StyleUtils.gray(array8);
            array6[n3] = StyleUtils.gold(array7);
            commandSender.sendMessage(StyleUtils.gray(array6));
            return true;
        }
        try {
            final float float1 = Float.parseFloat(array[0]);
            if (float1 <= 0.0f) {
                final Object[] array9 = new Object[2];
                "\u6ca5\u5427\u56ad\u6ce6".length();
                "\u66a0\u4f33\u6928\u6b51".length();
                "\u5350".length();
                array9[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-1740956939, -568905610, "\uc5da\uc5ee\uc595\uc5ef\uc5ea\uc1fc\uc5e1\uc5e5\uc5c2\uc5e5\uc5eb\uc5f8\uc1e1\uc41f\uc466\uc479\uc46d\uc01b\uc428\u9346\u8b2c\u8a2d\ua86e\u9115\ua56e\u9e5d\uae56\u96d2\ua483\uae17\u91b9", 535930611, -758493746);
                "\u6ee3\u62f0\u5a10\u5aa8".length();
                "\u5673\u705f\u5d80\u672c".length();
                "\u6235".length();
                final int n5 = 1;
                final Object[] array10 = { null };
                "\u6b80".length();
                array10[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-1474509327, -1442908853, "\uab15", -1215501005, -873433346);
                array9[n5] = StyleUtils.gray(array10);
                commandSender.sendMessage(StyleUtils.red(array9));
                return true;
            }
            if (float1 > 5.0f) {
                final Object[] array11 = new Object[2];
                "\u6247\u63bf\u6b58\u5924\u4f71".length();
                "\u62d8\u6423\u631e\u704f".length();
                array11[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(1654380115, 84551424, "\u8ceb\u8cea\u8ce0\u8c99\u8ce6\u8ce4\u8ce3\u8ce4\u8caf\u8cf2\u8cf6\u8cef\u88fb\u8cfd\u8cf6\u8cef\u8c8c\u8ce2\u8cc4\udbac\uc3c8\uc6d7\ue0ff\ud9f3\uedc8\ud6f4\ue68d\ude03\uec26\ue6a0\udd63\uecfd\uec25\ue681\uc716", -1131017144, -2068548177);
                "\u5673\u60fc\u5a86\u5434\u5016".length();
                final int n6 = 1;
                final Object[] array12 = { null };
                "\u5f86\u59b4\u5e9a\u5eb3".length();
                "\u622a\u4e92\u5a9e".length();
                "\u5f20\u648c".length();
                "\u5a67\u5990\u6924\u5eca".length();
                array12[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-743271851, -424879594, "\u915e", -733034687, -508420546);
                array11[n6] = StyleUtils.gray(array12);
                commandSender.sendMessage(StyleUtils.red(array11));
                return true;
            }
            float walkSpeed = float1 / 10.0f * 2.0f;
            float flySpeed = float1 / 10.0f * 2.0f;
            if (float1 == 1.0f) {
                walkSpeed = 0.2f;
                flySpeed = 0.1f;
            }
            player.setWalkSpeed(walkSpeed);
            player.setFlySpeed(flySpeed);
            final Player player2 = player;
            final Object[] array13 = new Object[2];
            "\u6043\u7027\u6799\u648e".length();
            array13[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(549491899, 2140851646, "\u8fcc\u8ff8\u8ffe\u8f84\u8ffa\u8f81\u8f8b\u8fc3\u8bf9\u8fb4\u8fb3\u8fa4\u8fd1\u8fcf\u8fcf\u8fd9\u8fca\u8fda\u8ffe\ud8e3\uc4e7\uc1f2\ue3b4\udecd", -439000231, -1392725518);
            "\u5733\u5a74\u649c\u5c81\u7106".length();
            "\u4e59".length();
            "\u7009".length();
            final int n7 = 1;
            final Object[] array14 = new Object[2];
            "\u711b\u6e52".length();
            "\u568f\u5753\u5a66\u5a7f\u635a".length();
            "\u58bb".length();
            array14[0] = float1;
            "\u64b3\u60f9\u5763".length();
            "\u4f78\u602c".length();
            final int n8 = 1;
            final Object[] array15 = { null };
            "\u62c8\u61a4\u6592\u5aca".length();
            "\u53d3\u4f80\u5f57\u668a".length();
            "\u6118".length();
            array15[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(-1935780523, 559363421, "\u044d", 216035377, -1703013351);
            array14[n8] = StyleUtils.gray(array15);
            array13[n7] = StyleUtils.gold(array14);
            player2.sendMessage(StyleUtils.gray(array13));
        }
        catch (NumberFormatException ex) {
            final Object[] array16 = new Object[2];
            "\u5b61".length();
            "\u5e8f\u6327\u66d4\u5ca6\u707c".length();
            "\u6369\u510f\u6e5a".length();
            array16[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(481217316, -1525003084, "\u7cef\u7cea\u7ced\u7ce8\u7c93\u7ce8\u7c95\u7ceb\u78d6\u7c9e\u7ce3\u7c8f\u7cca\u7cd7\u7ca4\u78d2\u7ca9\u7cca\u7c9d\u2b8a\u33e0", 95671892, -804837003);
            "\u6be2\u6140\u4f94\u6b2e\u535c".length();
            "\u64e4\u63f4\u4f0d\u6594".length();
            "\u6b54\u5040".length();
            "\u4e49\u4f9c\u530c\u635c\u5161".length();
            final int n9 = 1;
            final Object[] array17 = { null };
            "\u6146\u4fb5\u4eaf\u5bb3\u5bb8".length();
            "\u651e".length();
            array17[0] = \u5a65\u6b62\u616f\u5dff\u542e\u5b33\u66b9\u6053\u56fb\u5f1f\u54de\u5172\u5f92\u6f28\u4ee4\u6275\u7146\u63d4\u6b6e\u5ea3\u66d7\u5640\u6fe1\u6fcb\u57db\u66f9\u50c5\u698f\u6735\u5440\u524e\u52a0\u6cb1\u673e\u6366\u4e43\u5f8e\u4edd\u6b43\u555e\u67f5(2033310429, 1367762095, "\u6d61", -1951502287, 1419420480);
            array16[n9] = StyleUtils.gray(array17);
            commandSender.sendMessage(StyleUtils.red(array16));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u5be0\u60d5\u5f08\u6fab\u4ecb\u547f\u6a08\u5a57\u540e\u5ecc\u705b\u6707\u5460\u62be\u5cce\u5326\u5b31\u5475\u65d1\u5f57\u6627\u607e\u64ba\u622c\u6e13\u59f4\u6556\u56e8\u534e\u555a\u6f58\u5689\u5496\u69fa\u6be9\u5786\u66fe\u5224\u5c66\u5ae9\u5d9a(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
