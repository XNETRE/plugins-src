package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import java.util.*;
import org.jetbrains.annotations.*;

public class Bolt implements TabExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (!commandSender.hasPermission(\u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(-1269844972, -1672550213, "\ub228\ub21e\ub200\ub20d\ub21f\ub25a\ub21c\ub217\ub23c\ub212\ub210", 592202187, 595306338)) || commandSender.hasPermission(\u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(-1443898862, 717684950, "\u0c1c\u0c2e\u0c30\u0c21\u0c33\u0c6a\u0c2f\u0c28\u0c09\u0c3f", 843115373, -1364574821))) {
            if (array.length == 0) {
                final Object[] array2 = new Object[3];
                "\u6b6c\u6b9a\u52f8\u6bce\u6514".length();
                "\u6004\u5b62".length();
                array2[0] = \u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(-1175295225, -1828632720, "\ub926\ub952\ub928\ub92b\ub92c\ub95d\ub921\ub924\ub908\ub926\ub928\ub93f\ub937\ubd33\ub914\ub904\ub91e\ub902\ub924\udc09\ue232\udf1c\udb21\ud76e", -182475118, 1078605720);
                "\u4fd6".length();
                "\u4f86\u5bed\u5896".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u5753".length();
                "\u635c\u5c5e\u5dad\u52c3".length();
                "\u5ee1".length();
                array3[0] = \u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(-1016763138, 276514291, "\u9e60\u9e02\u9e0d\u9e0a\u9e12\u9e42\u9e30\u9a64\u9a43\u9a6f\u9e70\u9a7c\u9a70\u9a10\u9a6d\u9a73\u9a63\u9e10", -1720691495, 1037558744);
                array2[n] = StyleUtils.gold(array3);
                "\u6a82\u53c1\u5753\u673b".length();
                "\u5824".length();
                array2[2] = \u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(-140587441, 1673412353, "\u3b74", 2070766242, 1802348789);
                commandSender.sendMessage(StyleUtils.gray(array2));
                return false;
            }
            if (commandSender instanceof Player) {
                final Player player = (Player)commandSender;
                final Player player2 = Bukkit.getPlayer(array[0]);
                if (player2 == null) {
                    final Player player3 = player;
                    final Object[] array4 = new Object[2];
                    "\u4faf\u50ce\u61f4".length();
                    "\u554f\u5cfa\u5af5".length();
                    "\u4f2f\u6d98\u5361".length();
                    "\u5d41\u6773\u6796\u5726".length();
                    array4[0] = \u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(979483499, -240455981, "\u9f23\u9f25\u9f56\u9f2a\u9f30\u9b2c\u9f3a\u9f3e\u9b0f\u9f3d\u9f39\u9f2d\u9f2f\u9f37\u9f32", 245827980, 393725772);
                    "\u5590\u6372".length();
                    "\u69cd\u625e\u6dfd".length();
                    "\u4e65\u5049\u4ef4\u70ff".length();
                    "\u5fa8\u6e5b".length();
                    final int n2 = 1;
                    final Object[] array5 = { null };
                    "\u55fe".length();
                    "\u5f95".length();
                    "\u6675\u6cd7".length();
                    "\u5c1c\u58ee\u69ce\u6734".length();
                    array5[0] = \u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(-43238958, -903996720, "\u9f42", 1981186568, -1041220059);
                    array4[n2] = StyleUtils.gray(array5);
                    player3.sendMessage(StyleUtils.red(array4));
                    return false;
                }
                final Player player4 = player;
                final Object[] array6 = new Object[2];
                "\u679a\u5bac\u5d36\u5dcd".length();
                "\u5b9c\u54c0\u52e4".length();
                "\u5f51\u64e5\u647c".length();
                array6[0] = \u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(-641386430, 596415904, "\ufcaa\ufcc0\uf8a9\ufcca\ufcbd\ufcb9\ufcc0\ufcb6\ufc97\ufcb6\uf8ab\ufca7\ufca2\ufcb0\ufcb5\ufca6\ufcb1\ufcdf\uf8ea\u99da\ua3f8\u9ab7\u9afe\u96da\u9a07\ua177\u9c3c", 102555695, -1831226058);
                "\u65b5\u661b".length();
                "\u6784\u5f3e".length();
                final int n3 = 1;
                final Object[] array7 = { null };
                "\u670a\u4ed9\u5192\u507d".length();
                array7[0] = \u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(1686673431, -64927817, "\u4786", -1607550808, 1593254115);
                array6[n3] = StyleUtils.gray(array7);
                player4.sendMessage(StyleUtils.gold(array6));
                player2.getWorld().strikeLightning(player2.getLocation());
                "\u5807\u67a9\u4eef\u6e82\u694b".length();
                "\u5ed2\u7098\u5a79\u53a5".length();
                "\u6ce8\u62fe\u5a54\u6f95\u5310".length();
                "\u64dc".length();
            }
        }
        else {
            final Object[] array8 = new Object[2];
            "\u5721\u6da5".length();
            "\u6b84\u5f61\u6084".length();
            "\u6809\u5cbc\u6b9e".length();
            "\u55dc\u66ec".length();
            array8[0] = \u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(-1252958603, 763724387, "\u4e20\u4a0e\u4e10\u4e10\u4e63\u4a04\u4e16\u4e12\u4e45\u4a0b\u4e0f\u4e62\u4e17\u4e04", -1442623706, -1884563088);
            "\u5723\u6ddc".length();
            final int n4 = 1;
            final Object[] array9 = { null };
            "\u5332\u6acc".length();
            "\u5b2c\u69f5\u6d95\u57be".length();
            array9[0] = \u6bef\u686f\u5a39\u5991\u536f\u67ad\u6611\u5015\u5812\u4ff3\u5c6e\u576a\u5100\u65c2\u6521\u4f95\u5fb0\u6e76\u6998\u5ea2\u5d0c\u6c65\u6fd4\u60f2\u4eef\u5312\u4fa1\u58db\u6fcb\u530f\u64cb\u5084\u5468\u5235\u5104\u6942\u5e65\u5c50\u6668\u6e52\u5d10(1603695330, 824557498, "\u88c8", -327547592, -1642053430);
            array8[n4] = StyleUtils.gray(array9);
            commandSender.sendMessage(StyleUtils.red(array8));
        }
        return true;
    }
    
    @Nullable
    public List<String> onTabComplete(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        "\u5d1e".length();
        "\u529f\u6460\u6f74\u5956".length();
        "\u6741\u54cb\u5866\u633d\u6d5e".length();
        "\u5b2c\u642a".length();
        final ArrayList<String> list = new ArrayList<String>();
        Bukkit.getOnlinePlayers().forEach(player -> {
            list.add(player.getName());
            "\u6e55\u6adf".length();
            return;
        });
        return list;
    }
    
    public static int ColonialObfuscator_\u5bd7\u61e9\u5ec1\u6ed6\u5879\u6f4c\u6259\u5cfd\u5559\u6fb0\u662f\u6c14\u5143\u616e\u5e7a\u62b0\u66ff\u6bd0\u4e31\u59c1\u624a\u5e18\u551a\u6aa7\u60a2\u52f6\u50ab\u6431\u6a08\u6ef5\u697b\u5562\u5c0d\u5225\u63c3\u4e87\u5278\u5580\u62f1\u6d5f\u5b85(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
