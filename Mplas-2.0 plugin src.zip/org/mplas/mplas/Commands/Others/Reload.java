package org.mplas.mplas.Commands.Others;

import org.jetbrains.annotations.*;
import org.bukkit.command.*;
import org.mplas.mplas.*;
import org.mplas.mplas.Companents.*;

public class Reload implements CommandExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (!commandSender.hasPermission(\u56c2\u559f\u60c3\u606f\u5065\u6f9e\u6f16\u534d\u6c29\u61f0\u6896\u6e73\u6e82\u698b\u54ea\u53fc\u5b0f\u560d\u527e\u521e\u534d\u60b6\u54ee\u503c\u5848\u6918\u6d74\u6d97\u6077\u5676\u7127\u6078\u5fe3\u5456\u5b8f\u666c\u6ccb\u67b1\u5a2b\u6f2b\u6e99(-2147174537, -1916337123, "\ucad5\ucae5\ucafd\ucaf2\ucae2\ucab9\ucaf1\ucaf8\ucad1\ucaf9\ucafd", 167104114, -1384007709)) || commandSender.hasPermission(\u56c2\u559f\u60c3\u606f\u5065\u6f9e\u6f16\u534d\u6c29\u61f0\u6896\u6e73\u6e82\u698b\u54ea\u53fc\u5b0f\u560d\u527e\u521e\u534d\u60b6\u54ee\u503c\u5848\u6918\u6d74\u6d97\u6077\u5676\u7127\u6078\u5fe3\u5456\u5b8f\u666c\u6ccb\u67b1\u5a2b\u6f2b\u6e99(32252377, -1637285053, "\u7ec8\u7efe\u7ee0\u7eed\u7eff\u7eba\u7eef\u7ef6\u7edd", 1474634635, -575242249))) {
            Mplas.getInstance().getServer().reload();
            final Object[] array2 = { null };
            "\u5cef\u61a1".length();
            array2[0] = \u56c2\u559f\u60c3\u606f\u5065\u6f9e\u6f16\u534d\u6c29\u61f0\u6896\u6e73\u6e82\u698b\u54ea\u53fc\u5b0f\u560d\u527e\u521e\u534d\u60b6\u54ee\u503c\u5848\u6918\u6d74\u6d97\u6077\u5676\u7127\u6078\u5fe3\u5456\u5b8f\u666c\u6ccb\u67b1\u5a2b\u6f2b\u6e99(-441856711, -649913109, "\u4ed5\u4ea1\u4ac6\u4edb\u4ed3\u4ea0\u4eda\u4ed4\u4ef3\u4ed0\u4eb7\u4ea7\u4ea1\u4eca\u4ecc\u4edb\u4adb\u4ea6\u4ef0\u2d89\u1f4c\u1b10\u1b86\u0548", 554837350, -545866192);
            commandSender.sendMessage(StyleUtils.gold(array2));
        }
        else {
            final Object[] array3 = new Object[2];
            "\u6d68".length();
            "\u5cc6\u6db2\u4e74\u591f\u5302".length();
            array3[0] = \u56c2\u559f\u60c3\u606f\u5065\u6f9e\u6f16\u534d\u6c29\u61f0\u6896\u6e73\u6e82\u698b\u54ea\u53fc\u5b0f\u560d\u527e\u521e\u534d\u60b6\u54ee\u503c\u5848\u6918\u6d74\u6d97\u6077\u5676\u7127\u6078\u5fe3\u5456\u5b8f\u666c\u6ccb\u67b1\u5a2b\u6f2b\u6e99(-898085798, 295445888, "\u5267\u5649\u525f\u525f\u522c\u564b\u5251\u5255\u5202\u564c\u5250\u523d\u5248\u525b", -1286353662, 920187615);
            "\u685a\u524f".length();
            final int n = 1;
            final Object[] array4 = { null };
            "\u5f32\u6d31\u6a61\u68ff\u53a5".length();
            array4[0] = \u56c2\u559f\u60c3\u606f\u5065\u6f9e\u6f16\u534d\u6c29\u61f0\u6896\u6e73\u6e82\u698b\u54ea\u53fc\u5b0f\u560d\u527e\u521e\u534d\u60b6\u54ee\u503c\u5848\u6918\u6d74\u6d97\u6077\u5676\u7127\u6078\u5fe3\u5456\u5b8f\u666c\u6ccb\u67b1\u5a2b\u6f2b\u6e99(1185287723, 723139844, "\u0a0f", 1045668616, 748526154);
            array3[n] = StyleUtils.gray(array4);
            commandSender.sendMessage(StyleUtils.red(array3));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u6087\u6ecd\u6847\u61d3\u672e\u520e\u6608\u6555\u612c\u60cc\u64ac\u5a67\u6629\u5040\u54de\u4e9f\u6331\u507d\u6f95\u6af4\u529d\u6bb0\u50d5\u6048\u6b72\u6125\u5b04\u6e34\u547b\u6cdf\u63a4\u5e0e\u5a9d\u5657\u612c\u5376\u6b97\u6229\u6592\u6d4f\u61a7(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
