package org.mplas.mplas.Commands.Others.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.mplas.mplas.Companents.*;
import java.util.*;
import org.jetbrains.annotations.*;

public class Feed implements TabExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(\u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-734986767, 106813569, "\u6d8c\u6dce\u6db0\u69a2\u6dba\u6db8\u6db5\u6db5\u6d98\u6dbd\u6d82\u6980\u6d99\u6d8a\u6d87\u6d90\u6dff\u6981\u6db2\u3940}\u0d80\u3d4a\u312a\u3065\u1ce0\u086b\u38bf\u019f\u3823\u0403\u0c5a\u38b1\u0299\u020a\u3510\u0dda\u05d4m\u05c3\u22ce\u0d3b\u3b3b\u3c77\u32f7\u2dbb\u3f7b", -1992194090, -527119548));
            return false;
        }
        final Player player = (Player)commandSender;
        if (array.length > 0) {
            final Player player2 = Bukkit.getPlayer(array[0]);
            if (player2 == null || !player2.isOnline()) {
                final Player player3 = player;
                final Object[] array2 = new Object[2];
                "\u5390\u7061\u6db6\u6313\u5dca".length();
                "\u61b9\u5a11\u6a54".length();
                "\u6abe\u6255\u528b".length();
                "\u6892\u6efa\u5af7".length();
                array2[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-1766059817, 418972805, "\uf982\uf984\uf9fb\uf987\uf981\ufd9d\uf98f\uf98b\ufdbe\uf98f\uf879\uf862\uf86a\uf87a\uf877", 198642934, 1303700861);
                "\u60ad\u5755\u6fb7\u6368".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u6e5b\u5ba1\u5bb2".length();
                "\u6dc0".length();
                array3[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-1917987071, -1617350316, "\u9b80", -1326064960, 477865847);
                array2[n] = StyleUtils.gray(array3);
                player3.sendMessage(StyleUtils.red(array2));
                return false;
            }
            if (!commandSender.hasPermission(\u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-1480701933, 894737958, "\u6c20\u6c10\u6c10\u6c1f\u6c0f\u6c54\u6c14\u6c1d\u6c34\u6c1c\u6c10", 1256494510, 1213083541)) || commandSender.hasPermission(\u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-1168181917, -35249900, "\u2280\u22b0\u22ac\u22a3\u22af\u22f4\u22b7\u22b8\u229c\u22b1\u22fc\u22af\u22bd\u22b0\u22bc\u22bf\u22a2", -1028213236, 182075605))) {
                player2.setFoodLevel(20);
                final Player player4 = player2;
                final Object[] array4 = new Object[2];
                "\u65bf\u66b1\u5c37\u5c32".length();
                "\u6198\u6078\u5a60\u506d\u6dce".length();
                "\u5647".length();
                array4[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(2069398446, -1034857979, "\ud03b\ud036\ud045\ud420\ud03f\ud03a\ud037\ud031\ud06d\ud03f\ud03e\ud029\ud435", 996647297, -988896192);
                "\u57b7\u6408\u626a\u5684\u5e14".length();
                final int n2 = 1;
                final Object[] array5 = new Object[2];
                "\u6855\u6b8e\u60be".length();
                "\u6ef5\u6226\u5539\u6726\u5f57".length();
                "\u5b5e\u4e2e\u69b3\u5989".length();
                array5[0] = player.getName();
                "\u676b\u4feb".length();
                "\u7112\u6aec\u6629\u5e70\u583e".length();
                "\u58a4\u58c6\u6f21\u6277".length();
                final int n3 = 1;
                final Object[] array6 = { null };
                "\u66db\u66b3\u4fa1\u629a\u6958".length();
                "\u5f71\u6a3b".length();
                array6[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(2006436600, 854136752, "\u66bf", 1101396853, 163004640);
                array5[n3] = StyleUtils.gray(array6);
                array4[n2] = StyleUtils.gold(array5);
                player4.sendMessage(StyleUtils.gray(array4));
                final Player player5 = player;
                final Object[] array7 = new Object[2];
                "\u6733\u6ecf\u60cc\u5f0d\u58bd".length();
                "\u6228\u5d6a\u55ac\u5efc".length();
                array7[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-252749180, -1117483802, "\u6c26\u6c52\u6835\u6c28\u6c2b\u6c29\u6c22\u6c50\u6c0c\u6c24\u6c3c\u6c2d\u6830\u6c39\u6c37\u6c50\u6c36\u6c2e\u6c06\u3c9e", -791553658, 845506451);
                "\u656b\u4ed9\u518b".length();
                final int n4 = 1;
                final Object[] array8 = new Object[2];
                "\u59de\u6da5\u57dc".length();
                "\u654d\u6ca7\u5987\u6439\u6d69".length();
                "\u4fd4\u630a\u6924\u669f".length();
                "\u5486\u67aa\u5079\u6a2e\u5c46".length();
                array8[0] = player2.getName();
                "\u5ce5\u6431\u4fe8\u64fa".length();
                "\u6535\u70c5\u6fed".length();
                "\u69ea".length();
                "\u6b22\u5a12\u56f9\u6c43\u6db6".length();
                final int n5 = 1;
                final Object[] array9 = { null };
                "\u58d3\u5307\u6d48".length();
                array9[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-1428848838, 1854454007, "\u7916", 858213592, 757002849);
                array8[n5] = StyleUtils.gray(array9);
                array7[n4] = StyleUtils.gold(array8);
                player5.sendMessage(StyleUtils.gray(array7));
                return true;
            }
            final Player player6 = player;
            final Object[] array10 = new Object[2];
            "\u5a6b\u5263".length();
            "\u5831".length();
            array10[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-2030544713, 1353599443, "\u8a24\u8e04\u8a14\u8a16\u8a67\u8e06\u8a12\u8a14\u8a41\u8ff1\u8beb\u8b84\u8bf3\u8be6", -245437705, -359303721);
            "\u57a8\u6111\u53dc\u58de".length();
            "\u4feb\u6712".length();
            "\u5b85\u5eed\u55c6\u5c04".length();
            final int n6 = 1;
            final Object[] array11 = { null };
            "\u5ae5\u5876".length();
            "\u6431\u6b3d".length();
            array11[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-177385422, 1741364244, "\u325b", 2059317612, 1053282163);
            array10[n6] = StyleUtils.gray(array11);
            player6.sendMessage(StyleUtils.red(array10));
            return false;
        }
        else {
            if (!commandSender.hasPermission(\u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(1683229946, 1884327553, "\udf4e\udf7e\udf62\udf6d\udf71\udf2a\udf6e\udf67\udf4a\udf62\udf62", 96343972, 848251583)) || commandSender.hasPermission(\u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(1609627617, 870048192, "\u2ae4\u2ad6\u2ac8\u2ac1\u2ad3\u2a8a\u2acb\u2aca\u2ae8\u2ac7", -743591295, 365268586))) {
                player.setFoodLevel(20);
                final Player player7 = player;
                final Object[] array12 = new Object[2];
                "\u50cf\u5a67".length();
                "\u56aa".length();
                "\u5317\u6fa7".length();
                array12[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-1683387107, -2103003232, "\ud65e\ud62a\ud25d\ud64e\ud636\ud640\ud64c\ud258\ud667\ud64a\ud645\ud653\ud628\ud645\ud647\ud65d\ud64d\ud627", 333567214, -1403503524);
                "\u58de".length();
                final int n7 = 1;
                final Object[] array13 = { null };
                "\u576d".length();
                "\u6b86\u64e6\u6b4f\u6b15".length();
                "\u64e0".length();
                "\u5623\u552c\u6f08\u5fae".length();
                array13[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-551670374, 189456369, "\u5f7d", -1920616930, -150398102);
                array12[n7] = StyleUtils.gray(array13);
                player7.sendMessage(StyleUtils.gold(array12));
                return true;
            }
            final Player player8 = player;
            final Object[] array14 = new Object[2];
            "\u5e32\u621b\u4e46\u5206".length();
            array14[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(-1132834329, -1714678286, "\uc16a\uc544\uc156\uc156\uc129\uc54e\uc158\uc15c\uc10f\uc541\uc159\uc134\uc15d\uc14e", 599023268, -1057169477);
            "\u643d\u6909\u4f3b\u565e".length();
            "\u691b".length();
            final int n8 = 1;
            final Object[] array15 = { null };
            "\u6f96\u5f24\u70d5\u5a66".length();
            "\u55ec\u69b0\u4ea2\u6d37".length();
            "\u6264\u6ec5\u6e73\u5d7e\u5fc0".length();
            "\u65b7\u58d3\u5cc3\u643b".length();
            array15[0] = \u625f\u4e2f\u6132\u7087\u5a86\u4fd8\u6edd\u5a38\u63b8\u525f\u6a06\u5459\u6f21\u6827\u6d20\u5bbd\u57fb\u5dab\u4fa6\u5b9c\u6c41\u68d9\u5524\u58de\u6705\u62d6\u6823\u543b\u613e\u6e6f\u4fd2\u55c0\u6d2b\u6e8f\u511d\u5b32\u63a2\u59ba\u6a52\u68af\u4eb3(1198383418, 194896782, "\uff61", 782405937, 1482321030);
            array14[n8] = StyleUtils.gray(array15);
            player8.sendMessage(StyleUtils.red(array14));
            return false;
        }
    }
    
    @Nullable
    public List<String> onTabComplete(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        "\u65f1\u64ad\u5d92\u58b1".length();
        "\u6bb2\u67da\u64f0".length();
        "\u6ef9\u52f0\u57e7\u4fd4\u635a".length();
        "\u6400\u66f8\u647f\u63ec".length();
        final ArrayList<String> list = new ArrayList<String>();
        Bukkit.getOnlinePlayers().forEach(player -> {
            list.add(player.getName());
            "\u676c\u6d1b\u683c\u57a3\u5adf".length();
            "\u69cf\u50f6\u4f3f\u50a4\u6ded".length();
            return;
        });
        return list;
    }
    
    public static int ColonialObfuscator_\u6dd7\u6dc2\u5c14\u67b4\u6d8d\u5c31\u6f93\u6386\u5d94\u6810\u5077\u6c09\u68a8\u55cd\u61f8\u6489\u4f36\u52cc\u64df\u6c1a\u6ad7\u5966\u5e50\u6bd3\u5565\u60d0\u5b4e\u6523\u69ef\u50dc\u4e5b\u5376\u628d\u63b0\u5298\u5ca0\u6074\u69cc\u6d42\u6a9d\u5ed3(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
