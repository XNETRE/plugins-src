package org.mplas.mplas.Commands.Others.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.mplas.mplas.Companents.*;
import java.util.*;
import org.jetbrains.annotations.*;

public class ext implements TabExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(\u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-1705821661, -299849876, "\uc4d7\uc493\uc4e3\uc0f3\uc4e9\uc4d5\uc4de\uc4dc\uc4f3\uc4d0\uc4d1\uc0d1\uc4ca\uc4d7\uc4dc\uc4c9\uc4a4\uc0dc\uc4e1\u99c4\u92e4\u96b3\u9c3c\uac53\u9eda\u9832\ub4a9\u9210\u99b9\u945b\ua413\ua1e3\u9645\ua664\ua934\u9d30\ua2cb\u9d2f\u9650\u936a\ua05d\u9630\uaccf\ua373\ua536\uad0e\ua1dc", -1079084133, 536356461));
            return false;
        }
        final Player player = (Player)commandSender;
        if (array.length > 0) {
            final Player player2 = Bukkit.getPlayer(array[0]);
            if (player2 == null || !player2.isOnline()) {
                final Player player3 = player;
                final Object[] array2 = new Object[2];
                "\u691a\u710d".length();
                "\u70fa\u6ba0\u6f0e".length();
                array2[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-1780392478, 587591744, "\ua46f\ua46b\ua41a\ua418\ua41c\ua002\ua416\ua414\ua023\ua410\ua418\ua40d\ua407\ua415\ua41e", 835203645, -2043658325);
                "\u6ec7\u4e37".length();
                "\u6d2d\u5a4a".length();
                "\u6567\u5abf\u4fb8\u6589\u7109".length();
                "\u5c34".length();
                "\u5016".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u554f\u4f86\u5aa1".length();
                "\u64e5\u6443\u7130\u646d\u6092".length();
                "\u6ad3\u6146\u5acb".length();
                array3[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(2147288845, -1606286365, "\ua99f", -30579286, -1156986695);
                array2[n] = StyleUtils.gray(array3);
                player3.sendMessage(StyleUtils.red(array2));
                return false;
            }
            if (!commandSender.hasPermission(\u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-638028662, -1914598412, "\uf5d7\uf5e7\uf5ff\uf5f0\uf5e0\uf5bb\uf583\uf58a\uf5a3\uf58b\uf58f", -109974726, -1194401347)) || commandSender.hasPermission(\u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(112061824, -1414600715, "\ud28b\ud2bb\ud2a7\ud2a8\ud2bc\ud2e7\ud2a4\ud2ab\ud287\ud2aa\ud2e7\ud2b4\ud2ae\ud2a3\ud2af\ud2ac\ud2a9", -401154720, -1336932944))) {
                player.setFireTicks(0);
                final Player player4 = player2;
                final Object[] array4 = new Object[2];
                "\u5cef\u6c96\u58d2\u5d7d".length();
                array4[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-837193876, 885289916, "\ud37d\ud372\ud303\ud760\ud379\ud37e\ud309\ud304\ud333\ud36f\ud36b\ud762", -346292920, -1209911628);
                "\u6626\u52dd".length();
                "\u6914\u6b86\u5070".length();
                "\u67e9\u6bbf".length();
                "\u582f\u564e\u5c7c".length();
                "\u5a9a\u5199\u61d8".length();
                final int n2 = 1;
                final Object[] array5 = new Object[2];
                "\u63d8\u6085".length();
                array5[0] = player.getName();
                "\u6b16".length();
                "\u68c5\u634f".length();
                "\u6a11\u5fb7\u5d0d".length();
                final int n3 = 1;
                final Object[] array6 = { null };
                "\u659d\u5994\u68b3".length();
                array6[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-1948830375, -990487639, "\u0509", 1931303200, -330616133);
                array5[n3] = StyleUtils.gray(array6);
                array4[n2] = StyleUtils.gold(array5);
                player4.sendMessage(StyleUtils.gray(array4));
                final Player player5 = player;
                final Object[] array7 = new Object[2];
                "\u5e82\u5b4f\u5b97\u5830\u5533".length();
                array7[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-29457150, 685671160, "\u37c3\u37b7\u33dc\u37c1\u37fe\u3784\u378e\u3789\u37dd\u37f2\u37f6\u33fc\u37ed\u37f7\u3785\u37ef\u37f7\u37e1\u33df", 2092709340, 245105076);
                "\u6d85\u648e\u69f3\u5d40".length();
                "\u610c".length();
                final int n4 = 1;
                final Object[] array8 = new Object[2];
                "\u62c4".length();
                "\u4ecb".length();
                "\u5c55\u6e97\u706d\u6808\u65f8".length();
                "\u555f\u5e83\u6e5f\u5e85".length();
                array8[0] = player2.getName();
                "\u5fae\u4e53\u6fb3\u5c38".length();
                "\u6740\u6876\u54fd\u5c41\u4f6e".length();
                "\u6208\u6a65\u6277\u6de6".length();
                final int n5 = 1;
                final Object[] array9 = { null };
                "\u6aa8\u5dd6".length();
                "\u549c\u69c7\u4eb0\u4f37".length();
                "\u6eef\u4fd4\u665f\u52e4\u5a80".length();
                array9[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-1332134973, -401607581, "\ua09e", -647971814, -558378170);
                array8[n5] = StyleUtils.gray(array9);
                array7[n4] = StyleUtils.gold(array8);
                player5.sendMessage(StyleUtils.gray(array7));
                return true;
            }
            final Player player6 = player;
            final Object[] array10 = new Object[2];
            "\u555a\u5a07\u6836\u5efd".length();
            "\u5c0a\u63dd\u6afd\u562e\u5297".length();
            "\u5139\u6da0\u5ab1\u5922\u5cbe".length();
            "\u4fae\u6021".length();
            array10[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-720320871, -1635511573, "\u655b\u6175\u6567\u6567\u6508\u616f\u6579\u657d\u652e\u6160\u6578\u6515\u656c\u657f", 1311093324, 1405486853);
            "\u53ff".length();
            "\u58f9".length();
            "\u61b2".length();
            "\u5ea0\u6199\u5d2a\u58e4\u5d37".length();
            final int n6 = 1;
            final Object[] array11 = { null };
            "\u6abf\u545b".length();
            "\u5d3e".length();
            "\u5c88\u674c\u6f37\u654e".length();
            array11[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(756761938, -499455538, "\u613d", 265988909, 828073710);
            array10[n6] = StyleUtils.gray(array11);
            player6.sendMessage(StyleUtils.red(array10));
            return false;
        }
        else {
            if (!commandSender.hasPermission(\u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-1743465793, 2120638273, "\uc9f0\uc9c0\uc9dc\uc9d3\uc9bf\uc9e4\uc9a0\uc9a9\uc984\uc9ac\uc9ac", 1168891708, -855139556)) || commandSender.hasPermission(\u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-732698637, 1912457372, "\ua0ff\ua0cf\ua0ef\ua0e0\ua0f0\ua0ab\ua0ec\ua0e3\ua0c3\ua0ee", -1536593634, 2051604128))) {
                player.setFireTicks(0);
                final Player player7 = player;
                final Object[] array12 = new Object[2];
                "\u4fc6\u6c0f".length();
                "\u5088\u5231\u51ac\u5b9a".length();
                array12[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(1277269867, -600639870, "\uf2d4\uf2a0\uf6cf\uf2dc\uf2a4\uf2d2\uf2d6\uf6c2\uf2fd\uf2d0\uf2af\uf2bc\uf2b2\uf2de\uf2cb\uf2a9", 1198661122, 1487767918);
                "\u50bc".length();
                "\u6585\u5ea4".length();
                "\u5ec8\u5e92\u66b4\u5607\u66a9".length();
                final int n7 = 1;
                final Object[] array13 = { null };
                "\u5b2e\u6922\u51df\u6fa4\u5037".length();
                "\u6aac\u6a3a\u64e4\u62b4\u61c0".length();
                "\u5897\u6ddb\u5e27\u5935\u5ad5".length();
                array13[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(-506421992, 1483051278, "\u1c50", 586088946, 1689391574);
                array12[n7] = StyleUtils.gray(array13);
                player7.sendMessage(StyleUtils.gold(array12));
                return true;
            }
            final Player player8 = player;
            final Object[] array14 = new Object[2];
            "\u6246\u555d".length();
            "\u60ed\u60eb\u6f9d\u64e3\u53a7".length();
            array14[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(847174698, 54090854, "\u6c45\u686b\u6c65\u6c65\u6c16\u6871\u6c63\u6c67\u6c30\u687e\u6c6a\u6c07\u6c72\u6c61", -1339065266, -663055321);
            "\u6c5d\u6dd6\u5ebb\u6409".length();
            final int n8 = 1;
            final Object[] array15 = { null };
            "\u6d5e\u5123\u6776".length();
            "\u6d25\u53e9".length();
            "\u57c0\u5c42\u522e\u6db9".length();
            array15[0] = \u59e0\u57c6\u6aa1\u6a5c\u5740\u50c2\u5c76\u5a50\u517c\u5d56\u65fe\u6a93\u664c\u5a3c\u6ecb\u6659\u6c90\u6b3e\u59d2\u6d2f\u5a50\u506a\u6499\u522a\u4e9a\u61d5\u4e28\u7066\u6142\u6138\u5d3e\u63f1\u6e93\u68fb\u638c\u61c8\u536f\u52f4\u5584\u5bc1\u539b(498690344, 877603800, "\u2ff2", -407182577, 1761381999);
            array14[n8] = StyleUtils.gray(array15);
            player8.sendMessage(StyleUtils.red(array14));
            return false;
        }
    }
    
    @Nullable
    public List<String> onTabComplete(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        "\u5d71".length();
        "\u644b\u70c5\u57d9\u676b".length();
        "\u62be".length();
        "\u53ee\u63d9".length();
        final ArrayList<String> list = new ArrayList<String>();
        Bukkit.getOnlinePlayers().forEach(player -> {
            list.add(player.getName());
            "\u5132".length();
            "\u5a7a".length();
            return;
        });
        return list;
    }
    
    public static int ColonialObfuscator_\u52cf\u6330\u6801\u6d66\u5121\u6c6c\u4f66\u68e6\u5e1a\u5843\u5794\u5ff4\u65a5\u596c\u6888\u60da\u6e24\u6f7c\u6b82\u5e7a\u6345\u6c33\u571f\u620e\u559a\u5a71\u7008\u6329\u63a0\u58f9\u5cb8\u5c14\u6716\u6d16\u57c0\u4fdf\u69d4\u5eae\u63ff\u5447\u5f74(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
