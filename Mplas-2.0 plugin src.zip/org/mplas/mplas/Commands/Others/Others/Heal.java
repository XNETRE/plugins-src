package org.mplas.mplas.Commands.Others.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.mplas.mplas.Companents.*;
import java.util.*;
import org.jetbrains.annotations.*;

public class Heal implements TabExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(\u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(1455386831, 1376165044, "\u41af\u41ef\u419f\u4583\u4199\u4199\u4192\u4194\u41bb\u419c\u419d\u4461\u407a\u406b\u4060\u4071\u401c\u4460\u405d\u11ce\u0f8c\u2a61\u1f5d\u250e\u14fe\u30fb\u1265\u28d2\u2c77\u264f\u2b62\u155c\u163f\u240b\u1fa4\u256f\u227a\u1ebe\u1ed9\u2472\u276e\u204b\u2998\u1a5f\u0f67\u3004\u17d0", 1021209845, 1449313615));
            return false;
        }
        final Player player = (Player)commandSender;
        if (array.length > 0) {
            final Player player2 = Bukkit.getPlayer(array[0]);
            if (player2 == null || !player2.isOnline()) {
                final Player player3 = player;
                final Object[] array2 = new Object[2];
                "\u610c\u678e\u5abd".length();
                "\u5fb0".length();
                "\u5f94".length();
                "\u5c75".length();
                "\u6405\u5f8b\u526c".length();
                array2[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(-1151697310, 328995019, "\ue50b\ue50d\ue57e\ue502\ue500\ue11c\ue50a\ue50e\ue137\ue506\ue50c\ue517\ue51b\ue50b\ue502", -1606542000, -54291799);
                "\u4e98\u7075\u5303\u6eaf".length();
                "\u518c\u5cc2\u6bba\u6169\u711f".length();
                "\u647c\u5f06\u4eea".length();
                "\u6525".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u651d\u5b4e\u66c3".length();
                "\u501b\u5e0a\u5580\u5b22".length();
                "\u648f\u5126\u52e8\u4ff0\u5e65".length();
                "\u7049\u5aae\u6e6c\u5347\u54c1".length();
                "\u5220".length();
                array3[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(-2028190948, -1461734562, "\u3c73", -1714445008, -1208129181);
                array2[n] = StyleUtils.gray(array3);
                player3.sendMessage(StyleUtils.red(array2));
                return false;
            }
            if (!commandSender.hasPermission(\u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(1960783737, -541574850, "\u9285\u92b7\u92a9\u92a8\u92ba\u92e3\u92a5\u92aa\u9281\u92ab\u92a9", -969527259, 1505408201)) || commandSender.hasPermission(\u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(-1083829071, 991967707, "\u55a0\u5590\u5580\u558f\u559f\u55c4\u5583\u558c\u55ac\u5581\u55d0\u5583\u559d\u5590\u5598\u559b\u5582", -1479901786, 1158350146))) {
                player.setHealth(20.0);
                final Player player4 = player2;
                final Object[] array4 = new Object[2];
                "\u56d0".length();
                array4[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(478925213, 1606647371, "\u15f2\u15fd\u158c\u11ef\u1583\u15fc\u1587\u1585\u15d3\u1580\u1584\u1595\u1184", -1558635972, 382444617);
                "\u54ae\u5fe8\u6c9f\u6166".length();
                "\u4e85\u5116".length();
                final int n2 = 1;
                final Object[] array5 = new Object[2];
                "\u6a46\u5be1".length();
                array5[0] = player.getName();
                "\u6d92\u4f21".length();
                "\u4fcd\u696d\u5efd".length();
                final int n3 = 1;
                final Object[] array6 = { null };
                "\u6069\u54c9\u6db7".length();
                "\u6fee\u61d1\u4f86\u5302\u527e".length();
                "\u5b21\u66fb\u6435".length();
                "\u5da0\u62cf\u6d41\u680a\u65e8".length();
                array6[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(756710470, -386804440, "\ue324", -1584868566, 359373058);
                array5[n3] = StyleUtils.gray(array6);
                array4[n2] = StyleUtils.gold(array5);
                player4.sendMessage(StyleUtils.gray(array4));
                final Player player5 = player;
                final Object[] array7 = new Object[2];
                "\u6b42\u5e54".length();
                "\u6259\u5f33\u57fd".length();
                "\u5dc5\u4fb7\u657c\u6a0b".length();
                "\u57f0\u5f82\u5d12".length();
                array7[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(1047338419, -889162263, "\u085c\u0828\u0c43\u0853\u082c\u085a\u085f\u0821\u0862\u084d\u0849\u0c43\u085a\u0840\u0832\u0858\u0848\u085e\u0c60", -598918072, 1622038559);
                "\u5c20\u6ad1\u5930\u6098".length();
                "\u61c2\u5a91\u6851".length();
                "\u6293".length();
                "\u7143\u5fed\u6920".length();
                final int n4 = 1;
                final Object[] array8 = new Object[2];
                "\u68df".length();
                "\u6017".length();
                "\u6939\u5ae8\u6cb3\u6840".length();
                "\u655b\u51b6".length();
                array8[0] = player2.getName();
                "\u6b7f\u5cee\u6d08\u6329".length();
                "\u67fa\u5e19\u6ed0".length();
                final int n5 = 1;
                final Object[] array9 = { null };
                "\u5cf9\u5beb\u52bb\u5d34\u5326".length();
                array9[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(476169373, -1277844108, "\u2798", -710992279, 2012436602);
                array8[n5] = StyleUtils.gray(array9);
                array7[n4] = StyleUtils.gold(array8);
                player5.sendMessage(StyleUtils.gray(array7));
                return true;
            }
            final Player player6 = player;
            final Object[] array10 = new Object[2];
            "\u613b\u5d7e\u6bc4\u4e5a\u67ea".length();
            array10[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(1971205326, -527040831, "\u1063\u144d\u105f\u105f\u1020\u1447\u1051\u1055\u1006\u1448\u1050\u103d\u1054\u1047", 1373874020, -253920920);
            "\u4fe6\u6a57\u70db\u6695".length();
            final int n6 = 1;
            final Object[] array11 = { null };
            "\u6441\u6d31".length();
            "\u5257\u6005".length();
            "\u6827".length();
            "\u620f\u5bb0\u61b0\u6d70\u5939".length();
            array11[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(-2008901181, -257776956, "\ued9b", -1962690492, 1557163706);
            array10[n6] = StyleUtils.gray(array11);
            player6.sendMessage(StyleUtils.red(array10));
            return false;
        }
        else {
            if (!commandSender.hasPermission(\u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(482816935, -1058243983, "\uf17c\uf14c\uf154\uf15b\uf14b\uf110\uf158\uf151\uf178\uf150\uf154", -2142154862, -2053441770)) || commandSender.hasPermission(\u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(-313551900, -1356334126, "\ufdb3\ufd85\ufd9b\ufd96\ufd84\ufd21\ufd60\ufd6d\ufd4f\ufd64", 1683742587, 499927760))) {
                player.setHealth(20.0);
                final Player player7 = player;
                final Object[] array12 = new Object[2];
                "\u6d3c\u5562\u5aca\u5279".length();
                "\u6bcd\u654d\u5c7f\u50c9\u5bd1".length();
                array12[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(-1833695117, 1063825238, "\u5788\u57fc\u539b\u5788\u57f0\u5786\u578a\u539e\u57ac\u5787\u5772\u576e\u5719\u5777\u5777\u5715", -1737124490, 1592484234);
                "\u656b\u6a0f".length();
                final int n7 = 1;
                final Object[] array13 = { null };
                "\u4fb5\u6d21\u6e6f\u54c9".length();
                "\u6325\u5628\u6ceb".length();
                array13[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(1874317587, 1874019315, "\udfc9", -1442583547, -659840690);
                array12[n7] = StyleUtils.gray(array13);
                player7.sendMessage(StyleUtils.gold(array12));
                return true;
            }
            final Player player8 = player;
            final Object[] array14 = new Object[2];
            "\u5129".length();
            "\u6747\u6c34\u5b62\u5cba\u6348".length();
            "\u5daf".length();
            array14[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(168566958, 1717679755, "\u3498\u30b8\u34a8\u34aa\u34db\u30ba\u34ae\u34a8\u34fd\u314d\u3557\u3538\u354f\u355a", -1971022601, 821703210);
            "\u5b6b\u5bb5\u6dc0\u557f".length();
            "\u63b6\u6b61\u6034".length();
            "\u59cf\u5dbf\u545e\u6be2\u5e31".length();
            final int n8 = 1;
            final Object[] array15 = { null };
            "\u6309\u5b51\u50c1\u53e5\u6434".length();
            "\u5c97\u6247\u54f3".length();
            "\u64d5".length();
            "\u6aec\u5134\u6e9a\u5717\u627f".length();
            array15[0] = \u6d0e\u705e\u57bb\u61a9\u6431\u5844\u65f0\u65ec\u677c\u5dac\u5897\u4e45\u65b8\u50ac\u55bd\u6d20\u5179\u7048\u686c\u5e49\u5979\u6ab3\u5426\u6b10\u6411\u6b64\u58bb\u6c84\u5c0e\u53b3\u6e0a\u6e9c\u5b43\u66f1\u6c9c\u6be1\u684f\u652a\u62b2\u6990\u5ef0(749114568, 143987228, "\u72f0", -1724046184, -98381602);
            array14[n8] = StyleUtils.gray(array15);
            player8.sendMessage(StyleUtils.red(array14));
            return false;
        }
    }
    
    @Nullable
    public List<String> onTabComplete(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        "\u51b7\u4f95".length();
        "\u6e0d\u53ab\u5ee4".length();
        final ArrayList<String> list = new ArrayList<String>();
        Bukkit.getOnlinePlayers().forEach(player -> {
            list.add(player.getName());
            "\u5bfc\u5e39\u4f51".length();
            "\u68d2\u6d43\u50fe\u4f75\u51fb".length();
            "\u557b\u5b2a".length();
            return;
        });
        return list;
    }
    
    public static int ColonialObfuscator_\u5467\u631b\u5689\u4f2d\u6ad7\u5ea1\u6a9a\u70c1\u6707\u6f19\u6441\u6f15\u50c3\u699e\u5370\u653f\u4ec2\u53ea\u6f93\u59bb\u6489\u5942\u5305\u583d\u55ec\u6814\u6e9b\u6bc2\u67ae\u6130\u5c8c\u5716\u60a1\u54c0\u6e59\u540f\u56c9\u51a8\u5307\u6811\u55b8(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
