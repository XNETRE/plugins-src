package org.mplas.mplas.Commands.Others.Others;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import java.util.*;
import org.jetbrains.annotations.*;

public class getpos implements TabExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(\u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(-1818524708, 532011724, "\u4e8c\u4ecc\u4ebc\u4aa8\u4eb2\u4eb2\u4eb9\u4eb7\u4e98\u4ebf\u4ebe\u4aba\u4ea1\u4eb0\u4ebb\u4e92\u4eff\u4a83\u4ebe\u1524\u01ed\u1109\u1b06\u2fbc\u112d\u183c\u1cf7\u1df0\u1249\u17b7\u1698\u2ce3\u1efb\u1def\u0101\u287c\u3e23\u22a1\u1a6c\u1ce5\u23fe\u1389\u3e2c\u1a8c\u234c\u2b81\u2bc5", -1830279215, 1751462947));
            return false;
        }
        final Player player = (Player)commandSender;
        if (array.length > 0) {
            final Player player2 = Bukkit.getPlayer(array[0]);
            if (player2 == null || !player2.isOnline()) {
                final Player player3 = player;
                final Object[] array2 = new Object[2];
                "\u4e7c\u6dcd".length();
                array2[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(-1356096841, -228976394, "\ud3b0\ud3b6\ud3c5\ud3b9\ud3a3\ud7bf\ud3a9\ud3ad\ud79c\ud3ad\ud3a7\ud3bc\ud3b8\ud3a8\ud3a1", -1999088692, 1431176806);
                "\u65cc".length();
                "\u702d\u6e9a\u647e\u694f".length();
                "\u6a5e\u4e63\u5117\u514f".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u664c".length();
                "\u6d47\u6af9\u6614\u5d7c\u5728".length();
                "\u6887\u7059\u6b8a".length();
                "\u6d95".length();
                array3[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(951526890, -1410739009, "\u5baf", 1590754532, 1611683452);
                array2[n] = StyleUtils.gray(array3);
                player3.sendMessage(StyleUtils.red(array2));
                return false;
            }
            if (!commandSender.hasPermission(\u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(1261264786, 971214940, "\u49c1\u49f1\u49ed\u49e2\u49f6\u49ad\u49e9\u49e0\u49d5\u49fd\u49fd", 1565363592, 1426197417)) || commandSender.hasPermission(\u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(664412124, 1899488891, "\uf247\uf271\uf26f\uf262\uf270\uf225\uf265\uf269\uf25a\uf274\uf26e\uf262\uf238\uf596\uf58e\uf584\uf593\uf59e\uf5b3", 634399731, 1935679549))) {
                final Player player4 = (Player)commandSender;
                final Location location = player4.getLocation();
                ((Entity)commandSender).getLocation();
                "\u6d39\u5e61\u59b7".length();
                "\u701f\u5c1f".length();
                "\u525f".length();
                final Player player5 = player4;
                final Object[] array4 = new Object[2];
                "\u585f\u5c36\u5d73".length();
                "\u5d72".length();
                "\u701c".length();
                "\u6c08\u6f68\u5b67\u6417\u4e87".length();
                "\u6154\u532d".length();
                array4[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(-1678364363, 900913347, "\u93e3\u93e8\u9394\u93e4\u93e8\u93e9\u93ed\u939d\u93b6\u97f3\u93ee\u93f1\u9385\u93e8\u93ef\u920f\u9605", 1838440689, 890511037);
                "\u53f6\u6dc3\u6681\u5ebc".length();
                final int n2 = 1;
                final Object[] array5 = new Object[2];
                "\u70de\u5b7f\u6aec\u5b71\u5ce4".length();
                "\u4f79\u5688\u4ea4\u5f4e".length();
                array5[0] = player.getName();
                "\u5ef9\u5829\u6a4d\u6a26\u50fa".length();
                "\u5bca\u5c7d\u67eb".length();
                "\u5cf1\u550a\u5736".length();
                "\u4f4c".length();
                final int n3 = 1;
                final Object[] array6 = new Object[3];
                "\u6d69\u6144\u5b04\u5b41\u5ec1".length();
                "\u50dd\u5bc5\u697b\u63ce".length();
                array6[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(-326820367, -1005957947, "\u13fe\u13dc\u13d3", -848516787, -1136595996);
                "\u6ab5\u5de1\u6a5c\u529f".length();
                "\u4fc7\u56bf".length();
                "\u6eed\u62a8\u53b2".length();
                "\u61d8\u5d1b\u6704\u6458\u5efc".length();
                array6[1] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(-631305349, -919738708, "\u2570\u253f", -470667406, -640882738);
                "\u6f14".length();
                final int n4 = 2;
                final Object[] array7 = new Object[3];
                "\u5029\u70fe\u5c95\u6bca".length();
                "\u519b\u658a\u6bc5\u5e16\u5ae3".length();
                array7[0] = (int)location.getX();
                "\u5646".length();
                array7[1] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(1670481041, -1052643193, "\ua261", -1960512667, 237577585);
                "\u5e82".length();
                "\u6740\u5b58\u50e9\u60fa\u5d0a".length();
                "\u712a\u56dc".length();
                "\u6dc0\u587c".length();
                final int n5 = 2;
                final Object[] array8 = new Object[2];
                "\u646c\u4fad\u623f\u6211".length();
                "\u5ba0\u630b".length();
                array8[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(674106148, 233768085, "\u125a\u1214", -1421796092, 124780789);
                "\u696b\u59f6\u635c".length();
                "\u59d7\u5897\u53e0".length();
                "\u6929".length();
                final int n6 = 1;
                final Object[] array9 = new Object[3];
                "\u58a3\u6fbc\u5e8e\u6991\u54a8".length();
                "\u6581\u6406".length();
                "\u66fb\u5d94".length();
                "\u4e5f".length();
                array9[0] = (int)location.getY();
                "\u5d8b\u6cf4\u622b".length();
                "\u6046\u4e4c\u6313\u6b17".length();
                array9[1] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(389338338, 1762912970, "\uce22", 102263560, -2131453087);
                "\u53ea\u64fe\u578b\u5e99".length();
                final int n7 = 2;
                final Object[] array10 = new Object[2];
                "\u6326".length();
                "\u5902".length();
                "\u6205\u6b52\u5474\u56c7\u66d3".length();
                "\u54e8\u5b05\u52c5".length();
                array10[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(1006145768, 1553917555, "\u572a\u5767", -1172281962, 1263551550);
                "\u6a7d".length();
                "\u6277\u5473\u66d8".length();
                "\u4eb9\u5270\u534f\u6f85".length();
                final int n8 = 1;
                final Object[] array11 = { null };
                "\u5d1d\u6b16\u5e48\u65b0".length();
                "\u548a".length();
                array11[0] = (int)location.getZ();
                array10[n8] = StyleUtils.gold(array11);
                array9[n7] = StyleUtils.gray(array10);
                array8[n6] = StyleUtils.gold(array9);
                array7[n5] = StyleUtils.gray(array8);
                array6[n4] = StyleUtils.gold(array7);
                array5[n3] = StyleUtils.gray(array6);
                array4[n2] = StyleUtils.gold(array5);
                player5.sendMessage(StyleUtils.gray(array4));
                ((Entity)commandSender).getLocation();
                "\u60ef".length();
                return true;
            }
            final Player player6 = player;
            final Object[] array12 = new Object[2];
            "\u612c\u6583".length();
            "\u67f3\u4e29\u5de8\u5476".length();
            "\u5b13\u5c2a\u629b\u645d".length();
            "\u6488\u5923\u6282".length();
            array12[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(646341101, -928452382, "\u5abd\u5e93\u5a85\u5a85\u5af6\u5e91\u5a8b\u5a8f\u5ad8\u5e96\u5a8a\u5ae7\u5a92\u5a81", 82798562, 1521657904);
            "\u5c14".length();
            final int n9 = 1;
            final Object[] array13 = { null };
            "\u60e1\u6c88\u68ec\u5576\u6c86".length();
            "\u6e96\u70bc\u6f21\u50c8".length();
            array13[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(-739580102, -755486156, "\u5bb1", -1999090755, 1957938528);
            array12[n9] = StyleUtils.gray(array13);
            player6.sendMessage(StyleUtils.red(array12));
            return false;
        }
        else {
            if (!commandSender.hasPermission(\u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(1499806691, -950726201, "\uf0a5\uf097\uf089\uf080\uf092\uf0cb\uf08d\uf09a\uf0b1\uf09b\uf099", 1699352553, -1696410298)) || commandSender.hasPermission(\u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(-621925665, -453193489, "\u9332\u9300\u931e\u930f\u931d\u9344\u9304\u930c\u933f\u9315\u930f\u930f", 1847959309, 1577514529))) {
                final Player player7 = (Player)commandSender;
                final Location location2 = player7.getLocation();
                ((Entity)commandSender).getLocation();
                "\u6dab".length();
                "\u5671".length();
                final Player player8 = player7;
                final Object[] array14 = new Object[3];
                "\u6f7d\u6107\u6815\u696e".length();
                "\u6c4b\u5e25".length();
                "\u6f66".length();
                "\u6b51\u6446".length();
                "\u5a4d\u4f93\u6615".length();
                array14[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(-654218897, 498425558, "\u5774\u577d\u5707\u5777\u536f\u576d\u5760\u5710\u5746\u5760\u5760\u577d\u5708\u571e\u5376\u536d\u537a", -556534197, 468947671);
                "\u5a29\u684a\u6cc3\u5f8c\u61e5".length();
                array14[1] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(1214164538, -2069836008, "\u2856\u281b", 913016829, 275107474);
                "\u5ca5".length();
                "\u5afc".length();
                "\u6454".length();
                final int n10 = 2;
                final Object[] array15 = new Object[3];
                "\u4fd1\u625c".length();
                "\u69c1\u6335\u6fbf\u66c3\u55c1".length();
                "\u6d8d\u6990\u6eb1".length();
                "\u5d96\u5d2e\u5a41\u6257\u6d27".length();
                array15[0] = (int)location2.getX();
                "\u6cd9\u55fb\u6b51".length();
                "\u60cd\u6b35\u5907".length();
                "\u62f1\u6d72".length();
                "\u6458\u6c01\u6779\u6305".length();
                array15[1] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(516771695, 744143981, "\ufa66", -1654162019, 579433626);
                "\u563f\u53b8\u5c81\u4ea3\u62b9".length();
                "\u5d76\u5520\u57fc".length();
                final int n11 = 2;
                final Object[] array16 = new Object[2];
                "\u553b".length();
                "\u5207\u5a60".length();
                array16[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(1942968820, -1503746294, "\u57f9\u57b7", 1294904238, -1798372685);
                "\u594c".length();
                final int n12 = 1;
                final Object[] array17 = new Object[3];
                "\u5b69".length();
                "\u6b9a\u6dba\u6ffc".length();
                "\u5e9f\u6a1c\u67a8\u5b83".length();
                array17[0] = (int)location2.getY();
                "\u6edb\u5fd3".length();
                "\u6433\u6ddf\u631c\u6d0f".length();
                array17[1] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(-1253425010, 998977525, "\u63f0", 1973276579, 1503576907);
                "\u614f\u5787\u679d\u5da5\u5bf2".length();
                "\u6a1c\u6745\u5d41\u5888\u5000".length();
                "\u5f2a\u703e\u57c5\u7057\u6278".length();
                "\u5e1c\u5680\u6e69".length();
                final int n13 = 2;
                final Object[] array18 = new Object[2];
                "\u5bb4\u5923\u57f4".length();
                array18[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(921160650, -1139010252, "\uf676\uf639", -2070364803, -1336764948);
                "\u664a".length();
                final int n14 = 1;
                final Object[] array19 = { null };
                "\u5202\u64fd\u63c5\u5af0".length();
                array19[0] = (int)location2.getZ();
                array18[n14] = StyleUtils.gold(array19);
                array17[n13] = StyleUtils.gray(array18);
                array16[n12] = StyleUtils.gold(array17);
                array15[n11] = StyleUtils.gray(array16);
                array14[n10] = StyleUtils.gold(array15);
                player8.sendMessage(StyleUtils.gray(array14));
                ((Entity)commandSender).getLocation();
                "\u5b74\u61a7\u59ca\u59d4".length();
                "\u6cd4\u55b5\u4f75\u5693".length();
                "\u6dd5\u5d16\u57ba\u588d".length();
                return true;
            }
            final Player player9 = player;
            final Object[] array20 = new Object[2];
            "\u5f56".length();
            "\u5d1e\u6cf9".length();
            "\u5d37".length();
            array20[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(1484726722, 1123213169, "\uf716\uf338\uf72a\uf72a\uf75d\uf33a\uf72c\uf728\uf763\uf32d\uf735\uf758\uf729\uf73a", -1418510360, -799788499);
            "\u5774\u6485\u55ff\u6bdb\u5f83".length();
            "\u5b74\u6bde".length();
            final int n15 = 1;
            final Object[] array21 = { null };
            "\u6448\u6362\u6c03\u6064".length();
            "\u516a\u5db2\u61b1".length();
            "\u5e58".length();
            "\u7020\u61fd\u54da\u6c7c".length();
            array21[0] = \u5211\u4e8e\u5680\u58a3\u5556\u5832\u6a82\u51dc\u5ca5\u6e58\u5ab0\u6d49\u4e80\u5252\u53df\u62ce\u6f3b\u58af\u6543\u50f4\u635e\u5f94\u70ee\u6db0\u501a\u511e\u61b9\u664a\u6e64\u6172\u5600\u6c4f\u58f0\u6550\u6087\u619d\u6a06\u5e34\u5e34\u6f7e\u69d9(1694688887, -543359679, "\ueaaf", 511645845, 555542894);
            array20[n15] = StyleUtils.gray(array21);
            player9.sendMessage(StyleUtils.red(array20));
            return false;
        }
    }
    
    @Nullable
    public List<String> onTabComplete(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        "\u6152".length();
        "\u6a64\u5061\u5e17".length();
        final ArrayList<String> list = new ArrayList<String>();
        Bukkit.getOnlinePlayers().forEach(player -> {
            list.add(player.getName());
            "\u6328".length();
            "\u5b56\u6068\u6498\u69d3\u6303".length();
            "\u61cc\u70bf\u5080\u59f1\u551b".length();
            "\u6b75\u61f2\u6f54\u6669\u6d1c".length();
            return;
        });
        return list;
    }
    
    public static int ColonialObfuscator_\u60c4\u63f4\u5600\u6293\u5db1\u70d7\u6a79\u4e7b\u5d9e\u5d9f\u6c0b\u54d7\u66af\u64c6\u6701\u6039\u5167\u5db2\u6883\u6c35\u5003\u5699\u64a9\u5f88\u703c\u4f6c\u5e43\u5a71\u576c\u6464\u4e2c\u557d\u6943\u70e8\u5350\u6cee\u57f3\u5140\u6719\u59ad\u61ba(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
