package org.mplas.mplas.Commands.Others.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.mplas.mplas.Companents.*;
import java.util.*;
import org.jetbrains.annotations.*;

public class Inventory implements TabExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (!(commandSender instanceof Player)) {
            commandSender.sendMessage(\u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(1937730075, 69799649, "\u13d7\u1397\u13e7\u17fb\u13e1\u13e1\u13ea\u13ec\u13c3\u13e4\u13e5\u17d9\u13c2\u13d3\u13d8\u13c9\u13a4\u17d8\u13e5\u413b\u7526\u434e\u409b\u4776\u76e1\u7b7c\u4179\u4553\u4926\u7ca2\u439b\u6339\u7e44\u49dd\u7576\u4ff3\u71f3\u4348\u7b10\u488d\u4013\u4050\u5c4b\u449c\u7de5\u7dd2\u4267", 578724629, -14233514));
            return false;
        }
        final Player player = (Player)commandSender;
        if (array.length > 0) {
            final Player player2 = Bukkit.getPlayer(array[0]);
            if (player2 == null || !player2.isOnline()) {
                final Player player3 = player;
                final Object[] array2 = new Object[2];
                "\u660b\u6e22".length();
                "\u639d\u6bd0\u574f\u6cf7".length();
                array2[0] = \u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(-158474124, -2083815785, "\uf7e1\uf7e5\uf794\uf7ee\uf7ea\uf3f4\uf7e0\uf61a\uf22d\uf61e\uf616\uf60b\uf601\uf613\uf618", 838867193, 884045216);
                "\u57ce\u51f9".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u6c05\u672e\u629e\u670e".length();
                "\u51ca".length();
                array3[0] = \u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(-626744526, -1763322831, "\u1b13", 255790818, -442998128);
                array2[n] = StyleUtils.gray(array3);
                player3.sendMessage(StyleUtils.red(array2));
                return false;
            }
            if (!commandSender.hasPermission(\u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(-266438939, 902260403, "\ue45c\ue46c\ue474\ue47b\ue46b\ue430\ue478\ue471\ue458\ue470\ue474", -1705473982, 1264352358)) || commandSender.hasPermission(\u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(-336172308, -299041169, "\u7914\u7924\u7938\u7937\u7923\u7978\u793b\u7934\u7908\u7925\u7968\u793b\u7921\u792c\u7920\u7923\u7936", -719239896, -2086623087))) {
                player2.getInventory().clear();
                final Player player4 = player;
                final Object[] array4 = new Object[2];
                "\u6b62\u562c\u7129".length();
                "\u60bd\u4f2c\u5714\u50d3\u4ecc".length();
                "\u7056\u5e8d".length();
                array4[0] = \u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(11487547, -1737937909, "\ueedd\ueea9\ueac2\ueede\ueeac\ueeaf\ueedb\ueeae\uee89\ueedf\ueedb\ueeca\ueaab\ueea2\ueea6\ueebd\ueea6\ueeb2\ueee3\ubc3b\u8851\ube39\ubdee\uba0f\u8bec\u8674\ubc0c\ub839\ub45e\u85c0", 1119105204, -1329938680);
                "\u6c2a\u676f\u66fd\u4efe".length();
                "\u5d92\u539e\u55bc\u659f\u55e8".length();
                "\u6c46".length();
                final int n2 = 1;
                final Object[] array5 = new Object[2];
                "\u5155".length();
                "\u5bb9\u7132".length();
                "\u5dc4\u538a\u5efd".length();
                array5[0] = player2.getName();
                "\u6d81\u6277\u6b6c\u676e\u4fec".length();
                "\u5aef".length();
                "\u6e97".length();
                "\u6c67\u629f\u5a09\u58ae\u565c".length();
                final int n3 = 1;
                final Object[] array6 = { null };
                "\u5192\u6c5c\u58e1\u5488".length();
                array6[0] = \u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(-397015780, -1219383076, "\u29fc", -103761968, -1693701234);
                array5[n3] = StyleUtils.gray(array6);
                array4[n2] = StyleUtils.gold(array5);
                player4.sendMessage(StyleUtils.gray(array4));
                return true;
            }
            final Player player5 = player;
            final Object[] array7 = new Object[2];
            "\u6f5a\u6ca2\u6d41".length();
            array7[0] = \u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(582588497, 344167903, "\ud801\udc2f\ud839\ud839\ud84a\udc2d\ud837\ud833\ud864\udc2a\ud836\ud85b\ud82e\ud83d", 127272274, -1960717123);
            "\u6bb8\u5143\u4e8b\u5ed9".length();
            "\u5bfd\u5f6b\u5db8".length();
            "\u5526\u6bd4\u5afd".length();
            final int n4 = 1;
            final Object[] array8 = { null };
            "\u60d9\u6e1f\u679f\u58c9\u6919".length();
            "\u5c3c\u633b\u6ae7".length();
            array8[0] = \u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(396952354, -422238470, "\u09b1", -551110989, 2101385912);
            array7[n4] = StyleUtils.gray(array8);
            player5.sendMessage(StyleUtils.red(array7));
            return false;
        }
        else {
            if (!commandSender.hasPermission(\u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(-1200528094, -363258497, "\u31a4\u319a\u3184\u3189\u319b\u31c6\u3180\u318b\u31a0\u31b6\u31b4", -140563753, 238117632)) || commandSender.hasPermission(\u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(843175928, -1623932329, "\u13b6\u1384\u139a\u139b\u1389\u13d0\u1394\u1394\u13b1\u1387", 201222997, -1578472094))) {
                player.getInventory().clear();
                final Player player6 = player;
                final Object[] array9 = new Object[2];
                "\u6aed\u5d3e\u567a\u6e9e\u4f52".length();
                "\u6bd8\u66f6\u5ba1\u530f".length();
                "\u6948\u5dc0\u6868".length();
                "\u6393\u70b6\u6399\u57e9".length();
                array9[0] = \u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(-1027989470, 387518064, "\u6743\u674c\u6734\u635e\u6758\u675b\u675f\u6754\u6778\u672b\u675e\u673c\u6739\u6344\u675b\u6733\u672a\u6749\u671e\u35b7\u01aa\u37c6", -1420249684, 1272576236);
                "\u5c3f\u5e5e\u654f".length();
                "\u595b\u708a\u5d6b".length();
                final int n5 = 1;
                final Object[] array10 = { null };
                "\u6c9f\u50ae\u6cad".length();
                "\u51b4".length();
                "\u593a\u5b4b".length();
                "\u5ed6\u57d6".length();
                array10[0] = \u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(-2057171529, 38040724, "\ub1c8", 271549470, -1581233001);
                array9[n5] = StyleUtils.gray(array10);
                player6.sendMessage(StyleUtils.gray(array9));
                return true;
            }
            final Player player7 = player;
            final Object[] array11 = new Object[2];
            "\u5231\u6b75\u5f5e".length();
            "\u6970\u69dd\u4ee4\u5c6c".length();
            "\u6540".length();
            "\u6ffe\u6277\u6fcc\u6c6a\u5534".length();
            array11[0] = \u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(-236478898, -748912550, "\u494e\u4d60\u4972\u4972\u4905\u4d62\u4974\u4970\u492b\u4d65\u497d\u4910\u4961\u4972", -1588530688, -723738310);
            "\u59ea\u6c42".length();
            "\u671a\u5672\u67f9\u63a5".length();
            final int n6 = 1;
            final Object[] array12 = { null };
            "\u60c0\u569e".length();
            "\u6b4c".length();
            "\u615d".length();
            array12[0] = \u64a9\u626e\u5b4f\u7055\u6899\u70aa\u5500\u6caa\u5a88\u612a\u65aa\u4efc\u6a2e\u6e97\u6de5\u5da7\u5532\u50cc\u6415\u5b6c\u6cbf\u5da1\u69df\u5a89\u5635\u6f79\u5782\u581e\u5d3a\u6210\u51bc\u70ee\u4e3f\u60d1\u51ab\u6c1f\u5887\u5736\u586b\u63c6\u672e(109617299, -1768601077, "\uedfc", 1363790106, -1773089252);
            array11[n6] = StyleUtils.gray(array12);
            player7.sendMessage(StyleUtils.red(array11));
            return false;
        }
    }
    
    @Nullable
    public List<String> onTabComplete(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        "\u712b\u68de\u59b5\u5916".length();
        "\u66dd\u6789".length();
        final ArrayList<String> list = new ArrayList<String>();
        Bukkit.getOnlinePlayers().forEach(player -> {
            list.add(player.getName());
            "\u65da\u5a69\u6790\u545a".length();
            "\u5393\u609d\u5d2c".length();
            "\u6e63\u55f0".length();
            return;
        });
        return list;
    }
    
    public static int ColonialObfuscator_\u5ae5\u5d23\u623b\u57b5\u56d4\u5037\u6fee\u63c2\u6f7d\u6c0d\u701f\u5001\u5fb9\u4f69\u6aee\u6c16\u5d3e\u705e\u5121\u6866\u5b63\u6a70\u6224\u6f5a\u58f8\u5545\u6e41\u6b0e\u553c\u6305\u5954\u6a95\u6a12\u55ea\u6995\u6e31\u5a92\u69cc\u64ec\u70bc\u5965(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
