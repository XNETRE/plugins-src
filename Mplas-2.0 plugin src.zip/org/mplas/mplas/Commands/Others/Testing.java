package org.mplas.mplas.Commands.Others;

import org.jetbrains.annotations.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;

public class Testing implements CommandExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        final Object[] array2 = new Object[2];
        "\u4e90\u5d5a\u62cd\u4fd5".length();
        array2[0] = \u4fd7\u6475\u6b66\u5538\u62ae\u57fe\u5e75\u5dc1\u5ad1\u6555\u589b\u68f9\u65b5\u5d39\u65b2\u5118\u54f6\u5c11\u6019\u66f0\u5d28\u5eab\u5fec\u5ebe\u60ac\u70a0\u5c34\u6ac9\u56a8\u5a73\u6bc0\u6c37\u6fef\u57ec\u54b2\u56a6\u5f03\u6bc9\u5ddc\u6cac\u4e9f(-919135401, 1206510919, "\u3a96\u3ad2\u3aac\u3eb2\u3aa8\u3aa4\u3aaf\u3aad\u3a82\u3aa1\u3aa0\u3ea0\u3ab2\u3ac1\u3abe\u3ebd\u3ab5\u3ebd\u3af3\u675e\u63e2\u59f7\u5679", 895037507, 1291514027);
        "\u55ff".length();
        "\u697e\u6023\u5ff8\u5de3".length();
        final int n = 1;
        final Object[] array3 = { null };
        "\u5d7c\u5ca5".length();
        "\u6be4".length();
        "\u5eeb\u6f6e\u685e".length();
        array3[0] = \u4fd7\u6475\u6b66\u5538\u62ae\u57fe\u5e75\u5dc1\u5ad1\u6555\u589b\u68f9\u65b5\u5d39\u65b2\u5118\u54f6\u5c11\u6019\u66f0\u5d28\u5eab\u5fec\u5ebe\u60ac\u70a0\u5c34\u6ac9\u56a8\u5a73\u6bc0\u6c37\u6fef\u57ec\u54b2\u56a6\u5f03\u6bc9\u5ddc\u6cac\u4e9f(856435741, -1364946576, "\u4c5d", 661267272, 887018010);
        array2[n] = StyleUtils.gray(array3);
        commandSender.sendMessage(StyleUtils.red(array2));
        return true;
    }
    
    public static int ColonialObfuscator_\u4f41\u5c31\u6176\u5370\u6846\u6c7e\u5e51\u6f48\u69e6\u5c7b\u6379\u52b5\u6bfc\u6968\u5284\u5179\u4efb\u6a77\u693c\u6d80\u6646\u5786\u6b63\u5b7b\u5605\u5e62\u59a3\u646a\u679c\u67bd\u5030\u5a9d\u697b\u69f8\u5edb\u5b50\u5b7c\u6e22\u5537\u6ac9\u5424(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
