package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;

public class EnderChest implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!(commandSender instanceof Player)) {
            final Object[] array2 = new Object[2];
            "\u5f2b\u68a8\u59b5".length();
            array2[0] = \u6b19\u5d6c\u63c0\u54bb\u6d4c\u61ec\u5333\u6a26\u634a\u5e01\u576d\u53f5\u6e55\u516a\u575a\u6859\u67d2\u4e40\u5edc\u5444\u4f4f\u5c58\u62ad\u59ff\u7038\u5603\u51f7\u6d51\u67c4\u5d91\u6f25\u5ec6\u4e26\u5d70\u4e44\u5bb4\u5800\u6bfe\u67a7\u58f0\u5903(778604818, -2145400292, "\ud295\ud29c\ud292\ud29c\ud293\ud29c\ud2e4\ud68b\ud2b7\ud299\ud28a\ud29b\ud2e9\ud69a\ud287\ud2ea\ud28c\ud291\ud2b6\u8d14\u8c38\u8b39\ub269\u8d99\u8296\u8876\u86a5\ub974\ub380\ub38b\ub039\u8bab\u9c48\u8a2f\u8384\u86cb\ubf55\u8d1c\u8c25", -896209978, 472081924);
            "\u65b0\u5427\u5738\u6742".length();
            "\u6894\u5ccd\u4e76\u5bc1".length();
            "\u5ba2\u6aec\u5029\u4f11".length();
            "\u7018\u6502\u6662\u5a28".length();
            "\u5adf\u63fc\u6988".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u64eb\u58eb\u5a44\u5985\u61fd".length();
            "\u6a2c\u6ac2".length();
            "\u5c24".length();
            "\u4f9c\u6748".length();
            array3[0] = \u6b19\u5d6c\u63c0\u54bb\u6d4c\u61ec\u5333\u6a26\u634a\u5e01\u576d\u53f5\u6e55\u516a\u575a\u6859\u67d2\u4e40\u5edc\u5444\u4f4f\u5c58\u62ad\u59ff\u7038\u5603\u51f7\u6d51\u67c4\u5d91\u6f25\u5ec6\u4e26\u5d70\u4e44\u5bb4\u5800\u6bfe\u67a7\u58f0\u5903(-1636936209, 1848500000, "\uefc4", -124719808, 405571625);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        final Player player = (Player)commandSender;
        if (commandSender.hasPermission(\u6b19\u5d6c\u63c0\u54bb\u6d4c\u61ec\u5333\u6a26\u634a\u5e01\u576d\u53f5\u6e55\u516a\u575a\u6859\u67d2\u4e40\u5edc\u5444\u4f4f\u5c58\u62ad\u59ff\u7038\u5603\u51f7\u6d51\u67c4\u5d91\u6f25\u5ec6\u4e26\u5d70\u4e44\u5bb4\u5800\u6bfe\u67a7\u58f0\u5903(-2055529390, -827807657, "\u4253\u4263\u4273\u427c\u426c\u4237\u4277\u427e\u4257\u427f\u4283", 1442112374, 656741646)) && !commandSender.hasPermission(\u6b19\u5d6c\u63c0\u54bb\u6d4c\u61ec\u5333\u6a26\u634a\u5e01\u576d\u53f5\u6e55\u516a\u575a\u6859\u67d2\u4e40\u5edc\u5444\u4f4f\u5c58\u62ad\u59ff\u7038\u5603\u51f7\u6d51\u67c4\u5d91\u6f25\u5ec6\u4e26\u5d70\u4e44\u5bb4\u5800\u6bfe\u67a7\u58f0\u5903(-1826725812, -1786909777, "\ueaf2\ueac0\ueade\ueaef\ueafd\ueaa4\ueae6\ueae7\ueacf\ueae0\ueaf2\ueaff\ueaf3\ueaed\ueaf8\ueaed", -569957347, 1488405794))) {
            final Object[] array4 = new Object[2];
            "\u5511\u711d\u59c6\u6964".length();
            array4[0] = \u6b19\u5d6c\u63c0\u54bb\u6d4c\u61ec\u5333\u6a26\u634a\u5e01\u576d\u53f5\u6e55\u516a\u575a\u6859\u67d2\u4e40\u5edc\u5444\u4f4f\u5c58\u62ad\u59ff\u7038\u5603\u51f7\u6d51\u67c4\u5d91\u6f25\u5ec6\u4e26\u5d70\u4e44\u5bb4\u5800\u6bfe\u67a7\u58f0\u5903(-209528788, -1085068972, "\ufe13\ufa3d\ufe2f\ufe2f\ufe58\ufa3f\ufe29\ufe2d\ufe06\ufa48\ufe50\ufe3d\ufe4c\ufe5f", -309210824, -1923032525);
            "\u6a13\u5ac4\u70da".length();
            "\u6cb7\u6564\u5612".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u6347\u6c5f\u5397\u5f8f".length();
            "\u6038".length();
            array5[0] = \u6b19\u5d6c\u63c0\u54bb\u6d4c\u61ec\u5333\u6a26\u634a\u5e01\u576d\u53f5\u6e55\u516a\u575a\u6859\u67d2\u4e40\u5edc\u5444\u4f4f\u5c58\u62ad\u59ff\u7038\u5603\u51f7\u6d51\u67c4\u5d91\u6f25\u5ec6\u4e26\u5d70\u4e44\u5bb4\u5800\u6bfe\u67a7\u58f0\u5903(-1494817467, -167308637, "\ub926", -1044599104, 2008932450);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
            return false;
        }
        if (command.getName().equalsIgnoreCase(\u6b19\u5d6c\u63c0\u54bb\u6d4c\u61ec\u5333\u6a26\u634a\u5e01\u576d\u53f5\u6e55\u516a\u575a\u6859\u67d2\u4e40\u5edc\u5444\u4f4f\u5c58\u62ad\u59ff\u7038\u5603\u51f7\u6d51\u67c4\u5d91\u6f25\u5ec6\u4e26\u5d70\u4e44\u5bb4\u5800\u6bfe\u67a7\u58f0\u5903(-564852457, 728620281, "\ucab5\uca93\uca95\uca96\uca83\uca94\uca90\uca91\ucaa7\uca8c", 552836982, -946634741))) {
            player.openInventory(player.getEnderChest());
            "\u706c\u5611".length();
            "\u52e0\u5657\u54ae".length();
            return true;
        }
        return false;
    }
    
    public static int ColonialObfuscator_\u596b\u50c3\u5752\u4f4b\u6b7e\u6564\u57ac\u68e1\u6d3d\u6643\u55ea\u64ba\u6f46\u6f13\u513a\u54dc\u5cd2\u6e79\u51df\u5ad6\u69de\u55ca\u70de\u5d14\u6871\u5284\u5d56\u5469\u5402\u6fe3\u6898\u56f7\u565b\u5e28\u567a\u60a3\u6900\u70b0\u66c1\u5109\u4f85(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
