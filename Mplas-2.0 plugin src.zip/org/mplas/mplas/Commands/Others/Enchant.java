package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.bukkit.enchantments.*;
import org.mplas.mplas.Companents.*;
import java.util.*;
import org.bukkit.inventory.*;
import org.bukkit.*;
import org.apache.commons.lang3.text.*;

public class Enchant implements TabCompleter, CommandExecutor
{
    public List<String> onTabComplete(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (command.getName().equalsIgnoreCase(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-626563974, -1383486082, "\u41c1\u41e7\u41ea\u41e3\u41e4\u41ed\u41fc", -1740622540, -377504297))) {
            if (!commandSender.hasPermission(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(511041799, 124443952, "\u7f77\u7f47\u7f5b\u7f54\u7f38\u7f63\u7f27\u7f2e\u7f03\u7f2b\u7f2b", -298055876, -1199094702)) || commandSender.hasPermission(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-912632042, 1848935106, "\u4deb\u4ddb\u4dcb\u4dc4\u4dd4\u4d8f\u4dcb\u4dcc\u4de1\u4dc6\u4df4\u4de9\u4df6", 183980758, -1584936249))) {
                if (array.length == 1) {
                    final String lowerCase = array[0].toLowerCase();
                    "\u60db\u6b4d\u62fb".length();
                    "\u70af".length();
                    "\u6837\u6121\u6ea6\u6755".length();
                    "\u6dd9\u54ca\u6636\u652d".length();
                    final ArrayList<String> list = new ArrayList<String>();
                    final ItemStack itemInMainHand = ((Player)commandSender).getInventory().getItemInMainHand();
                    final Enchantment[] values = Enchantment.values();
                    for (int length = values.length, i = 0; i < length; i += 4874, i -= 4873) {
                        final Enchantment enchantment = values[i];
                        final String name = enchantment.getName();
                        if (enchantment.canEnchantItem(itemInMainHand) && name.toLowerCase().startsWith(lowerCase)) {
                            list.add(name);
                            "\u5999\u681e\u5bae".length();
                            "\u6e8f\u68db\u6648".length();
                            "\u6d1a\u6f77\u5189\u6914\u6865".length();
                        }
                    }
                    return list;
                }
                if (array.length == 2) {
                    ((Player)commandSender).getInventory().getItemInMainHand();
                    final Enchantment byName = Enchantment.getByName(array[0].toUpperCase());
                    if (byName != null) {
                        "\u5736\u5b7c\u5a4a".length();
                        "\u5cee".length();
                        "\u562e\u57fb\u69aa\u54d2\u708b".length();
                        "\u4f9a".length();
                        final ArrayList<String> list2 = new ArrayList<String>();
                        for (int maxLevel = byName.getMaxLevel(), j = 1; j <= maxLevel; j -= 12740, j += 12741) {
                            list2.add(String.valueOf(j));
                            "\u5fd8\u5bb3\u51ce".length();
                            "\u6dff\u6150\u5260\u4e94".length();
                            "\u6103\u552a\u50d7\u6d2b".length();
                        }
                        return list2;
                    }
                }
            }
        }
        else {
            final Object[] array2 = new Object[2];
            "\u6353\u58ad\u5543".length();
            array2[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(1596823574, -1408764712, "\u0c4d\u0865\u0c75\u0c77\u0c06\u087f\u0c6b\u0c6d\u0c38\u0870\u0c6a\u0c05\u0c72\u0c6f", -252764533, 2118875752);
            "\u5a53\u6f04\u4e24".length();
            "\u50bc\u6a09".length();
            "\u58fc\u4eaf".length();
            "\u6d8f\u5356\u5a65".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u5a96\u66bf\u65dd".length();
            "\u6e56\u64c4\u56e4\u55f4".length();
            "\u519d\u6f3f\u6b89\u52b6".length();
            "\u65c1\u6dfd\u647c".length();
            array3[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(1252090782, 1508483912, "\u0e61", 673576311, -2024195166);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
        }
        return Collections.emptyList();
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!command.getName().equalsIgnoreCase(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(1280426421, 5581203, "\u5622\u5606\u5609\u560e\u5607\u560c\u561f", -1206256843, 1538868503))) {
            return false;
        }
        if (!(commandSender instanceof Player)) {
            final Object[] array2 = new Object[2];
            "\u61e7\u50fc\u5da4".length();
            "\u5bc4\u69f4\u6c94\u5aa3\u6564".length();
            array2[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-586877312, -1794876456, "\u7f16\u7f1d\u7f1d\u7f2d\u7f20\u7f2d\u7f53\u7b3a\u7f04\u7f28\u7f25\u7f32\u7f36\u7b3b\u7f2a\u7f41\u7f2f\u7f30\u7f19\u2c09\u121d\u1c5a\u171a\u341c\u2fee\u2e33\u2270\u22ce\u2da9\u21da\u252d\u2fa9\u115c\u198f\u1267\u15b9\u1a81\u22e0\u187e\u22e0\u2304\u15fc\u27f3\u1e02\u2588", -224887139, 1803987082);
            "\u68c3\u55e9\u6f3f".length();
            "\u56e2\u6fd5\u648b\u5045\u5d2f".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u6508\u706f".length();
            "\u5b63\u7052\u5b0d".length();
            array3[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-193168653, -376402884, "\u141c", 551756896, -1844328751);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return true;
        }
        final Player player = (Player)commandSender;
        if (array.length < 1) {
            final Player player2 = player;
            final Object[] array4 = new Object[2];
            "\u6eb5\u59e4\u562d".length();
            "\u577f\u6fc1\u5b37\u5145".length();
            "\u682f\u6c0b\u55e8\u5aa7".length();
            "\u52dc".length();
            array4[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(1332239871, -411865212, "\u194e\u193a\u1948\u194b\u194c\u193d\u1949\u194c\u1960\u194e\u1978\u196f\u1967\u1d79\u1d66", 1235318294, 549935480);
            "\u4e5b\u5cef\u6bae".length();
            "\u516b\u603c\u583f\u4f73\u6fd4".length();
            "\u66b3\u67a1".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u6da9\u6932".length();
            "\u6cb7\u6e68\u5219\u6f95\u6c34".length();
            "\u6c40\u6559\u4f93\u5d2e\u5842".length();
            "\u6b43".length();
            array5[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-2013916492, -1058954951, "\u0a4b\u0a2c\u0a27\u0a28\u0a25\u0a2a\u0a2e\u0a38\u0bb0\u0b80\u0fac\u0f99\u0fef\u0f89\u0ff8\u0f92\u0f8a\u0f94\u0fb7\u5cba\u62a0\u6894\u63c6\u44d1\u5f47\u5ee7\u52dd\u5216\u5d06\u517b\u51e1\u5b6c", -784199944, -820463790);
            array4[n2] = StyleUtils.gold(array5);
            player2.sendMessage(StyleUtils.gray(array4));
            return true;
        }
        final String s2 = array[0];
        int int1 = 1;
        if (array.length >= 2) {
            try {
                int1 = Integer.parseInt(array[1]);
            }
            catch (NumberFormatException ex) {
                final Player player3 = player;
                final Object[] array6 = new Object[2];
                "\u5c4c\u50c4\u65d0".length();
                "\u5ca4\u5ecd\u5263".length();
                "\u53c6".length();
                array6[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-590761558, -1852731009, "\u3983\u39cf\u39b3\u39b3\u39b4\u39b8\u39c0\u3da6\u3993\u39ba\u39c8\u39b3\u39c4\u39a9\u39a6\u39b6\u39a1\u39ba\u39e1\u6e88\u548d\u5aba\u51f1\u7696\u6905\u68ac\u60f7\u641f\u6b74\u670a\u67ed\u6d1b\u57f5\u5b3b\u54b1\u5366\u5c25\u6430", 228959877, -1571505229);
                "\u6189\u6211\u5fb1".length();
                "\u546d".length();
                final int n3 = 1;
                final Object[] array7 = { null };
                "\u67a4\u6c4d".length();
                "\u5478\u70d2".length();
                "\u59a1\u6d96".length();
                array7[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(1297527696, -978112646, "\u91bc", 792036920, 1549110028);
                array6[n3] = StyleUtils.gray(array7);
                player3.sendMessage(StyleUtils.red(array6));
                return true;
            }
        }
        if (array.length < 2) {
            int1 = 1;
        }
        final Enchantment byName = Enchantment.getByName(s2.toUpperCase());
        if (byName == null) {
            final Player player4 = player;
            final Object[] array8 = new Object[4];
            "\u6ed5\u5672\u61d3\u5b48".length();
            array8[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-375641965, 1422450322, "\ucb3f\ucb35\ucb46\ucb33\ucb41\ucb39\ucb02\ucb0c\ucb21\ucb08\ucb06\ucf01\ucb65\ucf15\ucb00\ucb10\ucb01\ucb15\ucb37\u9836\ua239", 313275226, 709823024);
            "\u6263\u6e8f".length();
            "\u55f4\u5463\u6484\u709a".length();
            "\u5c75\u6862\u51b1\u6058".length();
            final int n4 = 1;
            final Object[] array9 = { null };
            "\u6c5b\u5af3".length();
            "\u61ee".length();
            "\u5d42\u6317\u5bb4".length();
            "\u6f37\u6c38\u57d5".length();
            array9[0] = s2;
            array8[n4] = StyleUtils.gold(array9);
            "\u6e7a\u504a\u54b5\u6302\u67ce".length();
            "\u6401".length();
            array8[2] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(2013330335, 1871599191, "\u8de8\u89d8\u89ac\u8dbb\u89a4\u89af\u89a9\u89a8\u8989\u89ad\u89a5", -1251713730, -1210942083);
            "\u4f80\u69f6\u6cc6\u5152".length();
            "\u6371".length();
            final int n5 = 3;
            final Object[] array10 = { null };
            "\u5ec6\u5fb1\u6fc9".length();
            array10[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-1961748539, 590970365, "\ud278", -417989777, -1649917107);
            array8[n5] = StyleUtils.gray(array10);
            player4.sendMessage(StyleUtils.red(array8));
            return true;
        }
        final ItemStack itemInMainHand = player.getInventory().getItemInMainHand();
        final Material type = itemInMainHand.getType();
        if (type.isItem()) {
            if (type.toString().endsWith(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(2032907273, 141535994, "\u8c14\u8c34\u8c2f\u8c19\u8c11\u8c1f\u8c0f\u8c18", -1102850467, -1473952602)) || type.toString().endsWith(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-208051831, 1294459622, "\u34d3\u34ee\u34f5\u34e8", 1046092023, 2011148119)) || type.toString().endsWith(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(2021642055, 550551192, "\ufdad\ufd8e\ufd88\ufd9c\ufd81\ufd93", -379878315, -411760581)) || type.toString().endsWith(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-823175458, -1624953704, "\u6abd\u6a9a\u6a83\u6a84\u6a9d\u6a76\u6a76", 693591675, -93565284)) || type.toString().endsWith(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-1342145699, 1652592159, "\u6472\u6448\u64b3\u64bb", -2103302786, 55096402)) || type == Material.ELYTRA || type == Material.BRUSH || type == Material.FLINT_AND_STEEL || type == Material.FISHING_ROD || type.toString().endsWith(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(1829430537, -9542050, "\ub4e8\ub4d0\ub4df\ub4da\ub4db\ub4d7\ub4cf", -2008946587, 1105059782)) || type.toString().endsWith(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(1822420924, -992201742, "\ue9fe\ue9c9\ue9c0\ue9cd\ue9db\ue9a4\ue9a9\ue9bb\ue994\ue9ab\ue9bf", -652349381, -418331241)) || type.toString().endsWith(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-1173154337, 2091978783, "\u2d46\u2d78\u2d71\u2d71\u2d7f\u2d77\u2d7b\u2d7e\u2d4e", 751881220, -1786059618)) || type.toString().endsWith(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-517089239, -74953080, "\ua649\ua667\ua668\ua668\ua673\ua674", -1546391249, -1702837797)) || type == Material.TRIDENT || type == Material.CROSSBOW || type == Material.BOW || type == Material.SHIELD || type == Material.SHEARS || type == Material.WARPED_FUNGUS_ON_A_STICK || type == Material.CARROT_ON_A_STICK) {
                itemInMainHand.addUnsafeEnchantment(byName, int1);
                final String capitalizeFully = WordUtils.capitalizeFully(type.name().replace(\u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(1561871334, 1110419377, "\u80df", -1311289298, 743453882), \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-1135752826, 1438285617, "\udc39", 971380921, 1032548948)));
                final String replace = byName.getKey().getKey().replace('_', ' ');
                final String roman = RomanNumeralConverter.toRoman(int1);
                final Player player5 = player;
                final Object[] array11 = new Object[7];
                "\u65a6\u5807".length();
                array11[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(2113176031, -934181897, "\u1ec3\u1eb1\u1ec4\u1ec7\u1ec9\u1ec6\u1eba\u1ad4", 974227952, 1236046151);
                "\u69df\u58b7".length();
                "\u5f3d\u6e91".length();
                "\u6b0d\u5d35\u6217\u4f8c".length();
                final int n6 = 1;
                final Object[] array12 = { null };
                "\u5357\u5650\u58e1".length();
                array12[0] = capitalizeFully;
                array11[n6] = StyleUtils.gold(array12);
                "\u59b3\u6d3c".length();
                "\u4f71\u6d61".length();
                "\u5d86\u5563\u56e8".length();
                "\u5fb0\u66e2\u6007".length();
                array11[2] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(412184104, -1155658967, "\u17d1\u139d\u139d\u13e7\u13ed\u1394\u13e8\u13f9\u17c5\u13fc\u13fe\u139d\u13ed\u138e\u13f3\u13e5\u13fd\u13ee\u17df\u40cc\u7ed0\u74fd", 1973115177, -752735334);
                "\u5fbd\u67aa\u6db2\u699b\u6da2".length();
                "\u7103\u6325\u6aac".length();
                "\u6d61\u6e13".length();
                "\u7136\u6fe9\u6c21\u5f72".length();
                final int n7 = 3;
                final Object[] array13 = { null };
                "\u6bba\u5453\u5f5c\u5ef9".length();
                array13[0] = replace;
                array11[n7] = StyleUtils.gold(array13);
                "\u6c3f".length();
                "\u5bc4\u50c7".length();
                array11[4] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-1354103737, -1603630878, "\ufb10", -1186821890, 1894711080);
                "\u5a16\u5ef1".length();
                "\u556d\u5333".length();
                "\u60b1".length();
                final int n8 = 5;
                final Object[] array14 = { null };
                "\u65d7\u6a0a".length();
                array14[0] = roman;
                array11[n8] = StyleUtils.gold(array14);
                "\u6cce\u69a9\u50e0\u4ff7\u7130".length();
                "\u62be\u69dc\u4fdc".length();
                "\u5b9b\u5a6d\u5671\u63f4\u6d62".length();
                final int n9 = 6;
                final Object[] array15 = { null };
                "\u6112\u6996\u6d5b\u6864".length();
                "\u5ae4".length();
                array15[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-2106374803, -1796099597, "\uba1f", -1978941706, -381620203);
                array11[n9] = StyleUtils.gray(array15);
                player5.sendMessage(StyleUtils.gray(array11));
            }
            else {
                final Player player6 = player;
                final Object[] array16 = new Object[2];
                "\u7024\u5e42\u6803\u5b9d\u5008".length();
                array16[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(385059287, 1092130624, "\u0d02\u0d07\u0d0d\u0d78\u0d01\u0d7f\u0917\u0d0c\u0d2b\u0d70\u0d04\u0d66\u0d1d\u0d00\u0d04\u0d69\u0d73\u0d1d\u0d39\u5a5d\u6023\u6e13\u652f\u423f\u59cf\u5c0e\u5034\u50f4\u5bf8\u5392\u531a\u5df3\u6379\u6fc2\u603e\u67ea\u68dc", -1383978062, 1390886009);
                "\u5413\u581d\u5964".length();
                "\u54c7\u6a02\u590a".length();
                "\u5edc\u5078".length();
                final int n10 = 1;
                final Object[] array17 = { null };
                "\u4f41\u570a\u6ae3\u5aa9".length();
                "\u51cb\u4f91\u6e33\u56bc".length();
                array17[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-402660132, -2061479013, "\ud525", -1387604292, -599477069);
                array16[n10] = StyleUtils.gray(array17);
                player6.sendMessage(StyleUtils.red(array16));
            }
        }
        else {
            final Player player7 = player;
            final Object[] array18 = new Object[2];
            "\u6466\u6d21".length();
            array18[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(-1606666233, 350931256, "\udaa8\udaaa\udade\udeb3\udaa2\udaa3\udadf\udaa4\udaf8\udaaa\udaa1\udab1\udabd\udaa9\udadf\udea4\udabd\udadf\uda84\u8987\ub793\ubdb2\ub2ea\u9587\u8a6c\u8bb9\u87fb\u874e\u8857\u804e\u84ba\u8a27\ub4da\ub818\ub792\ub03b\ubf00\u8713\ub9ee\u876f\u8297\ub001\u820d\ubb83\u8004\ub39e\u88c8\u88cc\ubec7\u8f76\u80c7\ubecd\u9446\u8ac2\ubb1a", 130844832, -1923242144);
            "\u5311".length();
            "\u54e0\u6c84\u5e40\u5e74".length();
            "\u55a7\u58db\u5bad\u5ceb".length();
            final int n11 = 1;
            final Object[] array19 = { null };
            "\u682e".length();
            "\u5beb".length();
            "\u698e\u512e\u6dc8".length();
            "\u5cd6".length();
            "\u5663".length();
            array19[0] = \u52a8\u658a\u5fc3\u4f1a\u5c23\u51b2\u4e3b\u64c8\u6241\u7097\u5005\u4f27\u5a28\u6747\u535c\u5463\u5f62\u6bcf\u69e0\u616d\u6323\u5384\u6ccd\u6bd4\u5c95\u6b2f\u6bd2\u617f\u5f8d\u5c65\u5eea\u5361\u6613\u5780\u66e3\u6e51\u6183\u5b87\u548d\u53a0\u5e89(659363068, 1573521985, "\u5a4a", -1664237859, 2047277640);
            array18[n11] = StyleUtils.gray(array19);
            player7.sendMessage(StyleUtils.red(array18));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u4ef4\u53ad\u6243\u4e90\u59b9\u6a48\u5399\u6ff2\u509e\u5c32\u5b2a\u5342\u6e2e\u6455\u6cd0\u6dc8\u6e0f\u6187\u6312\u603b\u7134\u6b53\u5556\u4ec5\u6241\u5d3d\u5b1a\u70b3\u54e0\u5207\u5156\u56bb\u6c1d\u7085\u535b\u5517\u54b7\u6f66\u5b6e\u61a1\u70d7(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
