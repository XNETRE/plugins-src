package org.mplas.mplas.Commands.Others;

import org.mplas.mplas.*;
import java.io.*;
import org.bukkit.configuration.file.*;
import org.jetbrains.annotations.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;

public class Mplasplugin implements CommandExecutor
{
    public Mplasplugin(final Mplas plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (!commandSender.hasPermission(\u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1215416440, -11377445, "\u5e89\u5eb9\u5ea9\u5ea6\u5eb6\u5eed\u5ead\u5ea4\u5e8d\u5ea5\u5eb9", -412272634, -1546766862)) || commandSender.hasPermission(\u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-957252849, -878960110, "\ue59d\ue5af\ue5b1\ue5a0\ue5b2\ue5eb\ue5a4\ue5a3\ue588\ue5ba", 2102229389, 1340982563))) {
            final Player player = (Player)commandSender;
            if (array.length == 0) {
                if (!commandSender.hasPermission(\u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1136701527, -193842095, "\u56a1\u5693\u568d\u56bc\u56ae\u56f7\u56b1\u56be\u5695\u56bf\u56bd", 1484690333, 2037465364)) || commandSender.hasPermission(\u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(136515850, 827621048, "\u463f\u460d\u4613\u461a\u4608\u4651\u461b\u4614", 2098544777, 1460824362))) {
                    final Object[] array2 = new Object[2];
                    "\u61cb".length();
                    "\u6ef0\u54ff\u68b5\u570f".length();
                    "\u7053\u58c4\u63db".length();
                    array2[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(950961404, 1779529905, "\u8d3f\u8d3d\u8d49\u8924\u8d25\u8d22\u8d2b\u8d25\u8d76\u8d2b\u8934\u8d39\u8d4f\u8d20\u8d20\u8d33\u8d5f\u8d33\u8d67\udbb5\ud7eb\ud764", -996403380, -1766825367);
                    "\u50cf\u57a6\u6b18\u6785\u6561".length();
                    final int n = 1;
                    final Object[] array3 = { null };
                    "\u5b77\u5ae2\u5d21\u512e\u5ab0".length();
                    "\u6e6e\u5b5b\u6bf6".length();
                    "\u5e36\u4e4c\u5ef7\u558d\u51ef".length();
                    array3[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1611722210, -120883798, "\u66ed\u6684\u669b\u6687\u668a\u6680\u66da\u669c\u66b3\u6690\u6689", 1941871211, 1252091042);
                    array2[n] = StyleUtils.gold(array3);
                    commandSender.sendMessage(StyleUtils.gray(array2));
                    return false;
                }
                final Object[] array4 = { null };
                "\u64d4\u657b".length();
                "\u5123\u61c5\u5115\u68a9\u5dc6".length();
                "\u626d\u54dd".length();
                array4[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-849704165, 173209514, "\u83c9\u87e1\u83f1\u83f3\u8382\u87fb\u83ef\u83e9\u83bc\u87f4\u83ee\u8381\u83f6\u83eb\u87fb", -1872656181, -1676708909);
                commandSender.sendMessage(StyleUtils.red(array4));
            }
            if (array[0].equals(\u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1861661619, -49306264, "\u9ff3\u9fd3\u9fd6\u9fc8", -1604342250, 1026369301))) {
                final Player player2 = player;
                final Object[] array5 = { null };
                "\u523f".length();
                array5[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1543344453, 100621797, "\ud189\ud1a6\ud1a2\ud1a0\ud1a2\ud1a4\ud1a3\ud1af\ud18f\ud1a3\ud1a0\ud1b2", 843508562, 533081284);
                player2.sendMessage(StyleUtils.gray(array5));
                final Player player3 = player;
                final Object[] array6 = new Object[2];
                "\u5de9\u7112\u6fb5\u51d3".length();
                "\u58ae\u6135".length();
                "\u63cf".length();
                "\u57ed\u61fd\u6554\u5d3a".length();
                array6[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1788287009, 1493292670, "\u077c\u227d", 22274471, -860287547);
                "\u5fff\u54cd".length();
                "\u5bce\u55a1".length();
                "\u5e3f\u5dc5\u5e5e\u4f5f\u6b68".length();
                final int n2 = 1;
                final Object[] array7 = { null };
                "\u6cbe\u6800\u5df7\u7146".length();
                array7[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1497500851, 658037640, "\u9ca4", 268203138, -1830754364);
                array6[n2] = StyleUtils.runCommand(StyleUtils.red(array7), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-292900773, -828550447, "\u8ed7\u8eba\u8ea5\u8ebd\u8eb0\u8ea6\u8efc\ua9ca", -1199741767, -990771064));
                player3.sendMessage(StyleUtils.gray(array6));
                final Player player4 = player;
                final Object[] array8 = { null };
                "\u4fd7\u7088".length();
                "\u6c83\u5910\u5251".length();
                "\u59fd".length();
                "\u5ec0\u6af8\u64f3\u64d3\u509b".length();
                array8[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1169896166, 1783691938, "\uc023\uc00e\uc00c\uc008\uc008\uc00c\uc005\uc017\uc035\uc01b\uc01e\uc00a", 200150953, -1809195661);
                player4.sendMessage(StyleUtils.gray(array8));
                final Player player5 = player;
                final Object[] array9 = new Object[2];
                "\u622d\u5c9d".length();
                array9[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-569104940, 733870691, "\u265d\u0352", 78955250, -758047143);
                "\u6d41\u5717\u5c62".length();
                final int n3 = 1;
                final Object[] array10 = { null };
                "\u60be\u693a\u68e1\u5830".length();
                "\u6b73\u6d9e\u6bd4\u62b1\u6c87".length();
                array10[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1052275514, 371186604, "\ue402\ue47e\ue408\ue019\ue403\ue403\ue408\ue406\ue429\ue40e\ue474\ue011\ue00c", 1117857777, 663187252);
                array9[n3] = StyleUtils.openUrl(StyleUtils.gold(array10), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1429047192, 1621332506, "\u387d\u384c\u384c\u384a\u3847\u3808\u3816\u381a\u3861\u385c\u3849\u385c\u3854\u3842\u3848\u385b\u3807\u3856\u3874\u6ed3\u66f0\u6638\u5492\u62b9\u5dae\u5c65\u6c88\u6918\u6402\u5eb5\u684c\u501a\u5472", 654686052, 76454576));
                player5.sendMessage(StyleUtils.gray(array9));
                final Player player6 = player;
                final Object[] array11 = { null };
                "\u6c11\u5ffb\u5124\u5d02".length();
                "\u59cd\u5e65\u6ab9".length();
                "\u5d09\u57de\u5f34\u6c15".length();
                "\u660b\u5d73\u68d4\u5e49".length();
                "\u5bb0\u5860".length();
                array11[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1465389782, 1180088208, "\uf8b3\uf888\uf88a\uf88e\uf88e\uf88a\uf883\uf881\uf8a3\uf88d\uf888\uf89c", -1285223887, 993030803);
                player6.sendMessage(StyleUtils.gray(array11));
            }
            if (array[0].equals(\u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(2008348590, 2064387523, "\u1faa", -1653146583, 1443970761))) {
                final Player player7 = player;
                final Object[] array12 = { null };
                "\u533a".length();
                array12[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1364415527, -2000860070, "\ued2b", 938683837, -1416298446);
                player7.sendMessage(StyleUtils.runCommand(StyleUtils.red(array12), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(528202820, 1048478473, "\u3703\u376e\u3771\u3761\u376c\u377a\u3720\u106e", -1523975899, 829092103)));
                final Player player8 = player;
                final Object[] array13 = { null };
                "\u4ef9\u4e75\u664d\u5529\u585a".length();
                "\u6b27\u6691\u66b7\u51e8".length();
                array13[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1374219966, 1058025139, "\u5899\u58b4\u58b6\u58ba\u58ba\u58be\u58b7\u58bd\u589f\u58b1\u58b4\u58b8", 1977588677, 833365520);
                player8.sendMessage(StyleUtils.gray(array13));
                final Player player9 = player;
                final Object[] array14 = new Object[10];
                "\u5463\u5027\u690b\u6964".length();
                array14[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-506803887, 960310690, "\u27af\u029e", 1290873055, 2039008962);
                "\u5a44\u5aa1\u5d98".length();
                "\u6b51\u6667".length();
                "\u618f".length();
                "\u6cd0\u613e\u6c7a\u6c53".length();
                final int n4 = 1;
                final Object[] array15 = { null };
                "\u528d".length();
                "\u6e30\u62fe\u6506\u5e1e".length();
                array15[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1170771148, -649816527, "\uee90", 1731269096, 280150438);
                array14[n4] = StyleUtils.runCommand(StyleUtils.gold(array15), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-533096850, -1208985021, "\ub948\ub927\ub93a\ub924\ub92f\ub93b\ub963\ub927\ub916\ub933\ub928", 560272008, -1675663487));
                "\u6c91\u6d8d\u5dbe".length();
                "\u6c33\u5cb3\u50d1\u7019\u67f7".length();
                "\u6124".length();
                "\u6738\u5abd\u66c4\u6744\u55a3".length();
                final int n5 = 2;
                final Object[] array16 = { null };
                "\u59d5\u70f2".length();
                "\u6290\u6d1d\u70e5".length();
                array16[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-839532412, 232178728, "\ua0eb", 1366086970, -1446357665);
                array14[n5] = StyleUtils.runCommand(StyleUtils.red(array16), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(32918839, 145231721, "\u393a\u3955\u3948\u3956\u395d\u3949\u3911\u3955\u3974\u3951\u394a\u391a", -28660912, 988336216));
                "\u6ee9".length();
                "\u6ff3\u541f".length();
                final int n6 = 3;
                final Object[] array17 = { null };
                "\u5620\u6044\u6361\u5e24\u5080".length();
                array17[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1165762668, 82689443, "\u95b7", 1201846945, -1704171264);
                array14[n6] = StyleUtils.runCommand(StyleUtils.gold(array17), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1029908766, 80515771, "\ue577\ue51a\ue505\ue51d\ue510\ue506\ue55c\ue516\ue539\ue51e\ue507\ue550", 2355185, -1136177485));
                "\u6568\u5154\u5711\u6003\u521d".length();
                "\u62a3\u53cd\u6e9b\u644a\u4f4a".length();
                final int n7 = 4;
                final Object[] array18 = { null };
                "\u5785\u666e\u6aec".length();
                "\u5aa4\u53fb".length();
                "\u54ea\u5154".length();
                array18[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(221348967, -163945736, "\ub4d9", -1632221223, 450376127);
                array14[n7] = StyleUtils.runCommand(StyleUtils.red(array18), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1638492296, 1351049936, "\u9038\u9057\u90b6\u90a8\u90a7\u90b3\u90ef\u90ab\u9086\u90a3\u90b4\u90e2", 61228414, 133226354));
                "\u4e31\u6e05\u56b9\u6794".length();
                final int n8 = 5;
                final Object[] array19 = { null };
                "\u4e3e\u5d30\u553c\u638e\u62bc".length();
                "\u5496\u4e48".length();
                array19[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1549783788, -1938860944, "\u26d2", 1739445572, 563261141);
                array14[n8] = StyleUtils.runCommand(StyleUtils.gold(array19), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-392855105, 1551786598, "\u6bab\u6bc4\u6bd9\u6bc7\u6bc4\u6bd0\u6b88\u6bcc\u6be5\u6bc0\u6bdb\u6b8c", -654647132, 554985658));
                "\u706e\u5057".length();
                final int n9 = 6;
                final Object[] array20 = { null };
                "\u65f7\u5b0a\u4e25\u5a13".length();
                "\u5bb5\u63b4\u5766\u5769".length();
                "\u51a2\u51a0\u671d\u6dae".length();
                "\u6649\u61be\u5ac8\u6684\u5236".length();
                array20[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(639582477, -1238203326, "\u22e4", -1571901651, 1873177760);
                array14[n9] = StyleUtils.runCommand(StyleUtils.red(array20), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-498192996, 1166702523, "\u1c51\u1c3c\u1c23\u1c3b\u1c36\u1c20\u1c7a\u1c30\u1c1f\u1c38\u1c21\u1c73", 1759554961, -620303477));
                "\u7040".length();
                "\u6465".length();
                "\u6dd5\u6ea4".length();
                final int n10 = 7;
                final Object[] array21 = { null };
                "\u6e65\u4ff1".length();
                "\u69ac\u5c47\u6071\u5941\u55b5".length();
                array21[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1646182642, -7839139, "\u44f3", -1524301260, -1593262003);
                array14[n10] = StyleUtils.runCommand(StyleUtils.gold(array21), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-69068075, 55656019, "\uc0eb\uc084\uc095\uc08b\uc084\uc090\uc0cc\uc088\uc0a5\uc080\uc067\uc032", 66111094, -1142087049));
                "\u4f9e\u6df1".length();
                final int n11 = 8;
                final Object[] array22 = { null };
                "\u61dc\u5f17\u51a2\u648e\u4f3b".length();
                "\u64c3\u6a01\u6f96\u6138".length();
                array22[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(585921350, -1151833108, "\u8d1b", 619775876, -112019951);
                array14[n11] = StyleUtils.runCommand(StyleUtils.red(array22), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(1530284479, -2104539434, "F)4*9-u1\u0018=&|", -1993391572, 812207471));
                "\u661e\u6df5".length();
                "\u6b4f\u60ab\u584d\u531c".length();
                "\u5614".length();
                final int n12 = 9;
                final Object[] array23 = { null };
                "\u4f1a\u6d07\u7092\u57d5\u60ae".length();
                "\u6d0e\u5b82".length();
                array23[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1267714699, 843515965, "\u8ed8", -1617358313, -627538516);
                array14[n12] = StyleUtils.runCommand(StyleUtils.gold(array23), \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1130664451, -1799542202, "\u947b\u942a\u9435\u9429\u9424\u9436\u946c\u942a\u9405\u942e\u9437\u946e", -608757601, 1580059443));
                player9.sendMessage(StyleUtils.gray(array14));
                final Player player10 = player;
                final Object[] array24 = { null };
                "\u6dc0".length();
                "\u61ef".length();
                "\u6f7f\u5331".length();
                "\u5227\u6dc9\u4f91\u6077\u629a".length();
                array24[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(301187620, 1403612734, "\u1bbf\u1b90\u1b90\u1b92\u1b94\u1b92\u1b99\u1b95\u1bb9\u1b95\u1b92\u1b80", -562344480, -894378236);
                player10.sendMessage(StyleUtils.gray(array24));
                final Player player11 = player;
                final Object[] array25 = new Object[2];
                "\u5102".length();
                "\u52b9\u5d0b\u55a7".length();
                "\u5781\u5621\u5ba1\u6a35".length();
                "\u6c3f\u5541\u62c7".length();
                array25[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-1386322345, 849796142, "\u5948\u7c47", -1803249050, 1867340822);
                "\u68d9".length();
                "\u5a67\u6d2e\u599a\u54d6\u6cea".length();
                final int n13 = 1;
                final Object[] array26 = { null };
                "\u6c94\u6531".length();
                "\u5a93\u6967\u544b\u5ecd\u513c".length();
                "\u5222\u66d7".length();
                array26[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(-314051230, -848152251, "\ub29e\ub2ad\ub2a2\ub2d1\ub2a6\ub2a9\ub2ad\ub6bf\ub2fc\ub2d5\ub2ae\ub6a2\ub2a9\ub2c1\ub2ba\ub2df\ub2b3\ub2a4\ub289\ue034\uec48\uecd0\ude18\uec45", 1471233028, -381925665);
                array25[n13] = StyleUtils.red(array26);
                player11.sendMessage(StyleUtils.gray(array25));
                final Player player12 = player;
                final Object[] array27 = { null };
                "\u67dd\u6895\u5669\u5290\u5866".length();
                "\u5a36\u5da2\u6b97".length();
                array27[0] = \u6f27\u5e54\u5e70\u576c\u60a8\u51bf\u562b\u54da\u6fef\u5407\u5558\u59f6\u4e5c\u6da2\u4eae\u6ca1\u6869\u5429\u69bc\u52af\u5fc1\u5d93\u6c80\u552f\u5902\u621b\u52c8\u58d0\u6ff2\u5470\u6ac4\u7137\u5bd1\u6a1c\u6ebb\u61d5\u541a\u5d2f\u6a0b\u6253\u57d7(670303297, -1284228534, "\uf4d2\uf4e9\uf4eb\uf4e7\uf4e7\uf4e3\uf4ea\uf4e0\uf4c2\uf4ec\uf4e9\uf4c5", 2064106261, 800271515);
                player12.sendMessage(StyleUtils.gray(array27));
            }
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u572f\u5b4e\u7104\u6d1d\u6165\u5ba6\u6e60\u6f53\u5ba5\u63ed\u6cc4\u5f8c\u6e38\u5a3f\u4ee5\u577a\u664c\u61fb\u6fb7\u6f0a\u5e32\u62cb\u62ae\u4edc\u63c2\u555d\u644d\u60b6\u6ed2\u6fe7\u58e4\u6aee\u66f4\u6447\u5ba7\u6e35\u53f6\u699d\u543c\u5af2\u6f5b(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
