package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.bukkit.enchantments.*;
import org.bukkit.inventory.*;

public class EnchantAll implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender.hasPermission(\u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(1292127883, 1902273442, "\ue0fc\ue0cc\ue0d0\ue0df\ue0cb\ue090\ue0d4\ue0dd\ue088\ue0a0\ue0a0", 614870072, 1311236547)) && !commandSender.hasPermission(\u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(1782024073, 508987636, "\u50b8\u5088\u5094\u509b\u508f\u50d4\u5094\u5093\u50b2\u5095\u509b\u5086\u509d\u5099\u5095\u5081", -1132087376, -932845477))) {
            final Object[] array2 = new Object[2];
            "\u5a90\u563b\u6b93\u5acd\u58f1".length();
            array2[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(1718081218, -1472227408, "\u16cb\u12e5\u16f7\u16f7\u1698\u12ff\u16e9\u16ed\u16be\u12f0\u16e8\u1685\u16fc\u16ef", -193477812, -1730375531);
            "\u5adc".length();
            "\u4e30\u4fec\u5a55".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u6d12\u6287\u670d\u6123\u4f95".length();
            "\u6e5c\u5ae5".length();
            array3[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(-1432328721, 1922420965, "\u21e5", 1003971083, -1886914938);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (!command.getName().equalsIgnoreCase(\u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(-376339980, -52972259, "sKDOFIZAnL", 1544232591, -325965261))) {
            return false;
        }
        if (!(commandSender instanceof Player)) {
            final Object[] array4 = new Object[2];
            "\u69c3\u504d\u6657\u500f".length();
            array4[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(750771439, -729161485, "\u4822\u4829\u4829\u4829\u4824\u4829\u4857\u4c3e\u4800\u482c\u4821\u4846\u4842\u4c4f\u485e\u4835\u485b\u4844\u486d\u11d5\u16b4\u1d14\u282d\u183a\u2aa7\u1056\u2c29\u11e7\u1aec\u2d82\u2c58\u1179\u1029\u1b81\u16f6\u1c21\u19b9\u1a61\u11df\u251f\u21c3\u1197\u15f5\u2e0b\u17c0", -1522389323, -2126881070);
            "\u6227\u70ce\u70d6\u4f36\u5d52".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u5b93\u58c1\u6b7c\u5671".length();
            "\u69b7".length();
            array5[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(2091104984, -492404139, "\u4a05", -1325992949, -1675655455);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
            return true;
        }
        final ItemStack itemInMainHand = ((Player)commandSender).getInventory().getItemInMainHand();
        if (itemInMainHand == null || itemInMainHand.getType() == Material.AIR) {
            final Object[] array6 = new Object[2];
            "\u69fe\u6124\u6db1".length();
            "\u5bdd\u668f\u6335".length();
            "\u5966\u6d91".length();
            array6[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(1589440098, 1997526449, "\ud627\ud628\ud623\ud658\ud628\ud62c\ud65f\ud626\ud211\ud63c\ud646\ud623\ud625\ud63a\ud630\ud651\ud229\ud629\ud217\u8fc5\u88a2\u8305\ub64b\u8657\ub4b2\u8e07\ub201\u8fd8\u84db\ub3be\ub608\u8b2a\u8e63\u81de\u88ce\u826c\u87f0\u842d\u8f96\ubb5d\ubf8d\u8fc1\u8baa\ub01c\u89a3\ubcb4\ubfee\u874e\ub7f2", -1262777849, -1886231646);
            "\u5495\u617e".length();
            "\u5025\u59e1\u6bc5\u52fb".length();
            "\u6de1\u5ebc\u5975\u6fdf\u63ad".length();
            "\u542b\u552a".length();
            final int n3 = 1;
            final Object[] array7 = { null };
            "\u70b8".length();
            "\u7119\u6f6f\u6949\u503e".length();
            "\u5e04\u69cf\u7140".length();
            array7[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(1663102891, -155301173, "\u9e5e", -42619338, 663131498);
            array6[n3] = StyleUtils.gray(array7);
            commandSender.sendMessage(StyleUtils.red(array6));
            return true;
        }
        boolean b = false;
        final Enchantment[] values = Enchantment.values();
        for (int length = values.length, i = 0; i < length; i -= 32602, i += 32603) {
            final Enchantment enchantment = values[i];
            if (enchantment.canEnchantItem(itemInMainHand)) {
                final int maxLevel = enchantment.getMaxLevel();
                if (maxLevel > 0) {
                    itemInMainHand.addEnchantment(enchantment, maxLevel);
                    b = true;
                }
            }
        }
        if (!b) {
            final Object[] array8 = new Object[2];
            "\u5553".length();
            "\u5edf\u6570\u5167\u5796".length();
            "\u68b2\u5d5d\u5f6a\u6e4e\u5656".length();
            array8[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(1085449258, -1963865318, "\u91fb\u918b\u91fc\u91f9\u91f1\u91fc\u9182\u95e2\u91d2\u95ee\u918b\u919c\u91e2\u91fe\u95e8\u91df\u91cd\u95c6\u91f5\uc842\ucf2c\uc4f6\uf1c0\uc5c6\uf34f\uc9cc\uf5bc\uc81f\uc367\uf47a\uf5dc\uc8ec\uc9c7\uc67a\ucf61\uc5cd\uc055\uc3f7\ucc5b\ufc86\uf854\uc804", -810353583, 499320518);
            "\u4f9c".length();
            "\u6ca4".length();
            final int n4 = 1;
            final Object[] array9 = { null };
            "\u5710\u67e3\u666b".length();
            "\u5622\u5500\u6793\u68b6\u64d2".length();
            "\u53ce\u6d88\u5cba\u6aa2".length();
            "\u652f\u5266".length();
            array9[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(-1089045519, 886736680, "\uf9ef", 1265485033, -832912963);
            array8[n4] = StyleUtils.gray(array9);
            commandSender.sendMessage(StyleUtils.red(array8));
            return true;
        }
        final Object[] array10 = new Object[2];
        "\u5c45\u66d5\u5d0a\u6c9c\u585a".length();
        "\u54ed\u5966\u6ea8".length();
        "\u7141\u661f\u556d\u5d64".length();
        "\u5e93".length();
        array10[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(-771443423, -1953852132, "\u1387\u13f5\u1380\u1383\u1385\u138a\u13f6\u1798\u13ab\u1380\u13f0\u1395\u13fc\u1393\u139e\u1388\u1399\u1798\u13ab\u4a16", -1960696924, -1695345598);
        "\u6ac5".length();
        final int n5 = 1;
        final Object[] array11 = new Object[2];
        "\u6eab\u57ff\u6dd4".length();
        "\u5300\u5ce7\u706f\u5cb3".length();
        array11[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(939892442, 1998650834, "\ueb6b\uef44\uef4a\uef40\uef3b\uef42\uef4f\uef4d\uef64\uef31\uef45\uef23\uef5a\ueb58", -793769393, -951680433);
        "\u50a0".length();
        "\u59eb\u4fde\u5a63".length();
        "\u531e\u6107\u6225\u68d2\u6e3d".length();
        final int n6 = 1;
        final Object[] array12 = { null };
        "\u5237\u6eb3\u5c45\u4f7a".length();
        "\u5b02\u5aaa\u61d5".length();
        array12[0] = \u5fbc\u4e28\u674b\u5c12\u6318\u4fd0\u60b0\u50a0\u5e68\u5d61\u5d8b\u6be0\u59ce\u5b7e\u6a58\u6b74\u6cb0\u60eb\u5157\u539a\u612b\u544c\u5251\u516d\u4e82\u60fe\u5520\u519a\u633a\u54d1\u5db3\u6fc9\u4f1f\u531b\u4f6a\u6e82\u69da\u603b\u5052\u57b1\u66c5(-503423452, -912545408, "\ud5c0\ud5e7\ud598\ud599\ud59e\ud5e4\ud5ed\ud597\ud5d5\ud1ec\ud5ff\ud5e2\ud597\ud1e9\ud5f5\ud5e9\ud5fb\ud5ea\ud1da\u8c7d\u8b18\u80b7\ub5f5\u81f8\ub747\u8dc4\ub1be\u8c14\u876a\ub075\ub1dd", 1023580040, 218673563);
        array11[n6] = StyleUtils.gray(array12);
        array10[n5] = StyleUtils.gold(array11);
        commandSender.sendMessage(StyleUtils.gray(array10));
        return true;
    }
    
    public static int ColonialObfuscator_\u60f4\u643f\u5a0c\u64da\u5075\u6a9f\u4fc5\u65ed\u4e9a\u65f6\u6936\u69c1\u6d8a\u5cd7\u5401\u6b69\u6af5\u67d9\u6da5\u5c8e\u6659\u6bac\u6c4b\u6bb0\u6565\u61ca\u5f6c\u5d01\u62ac\u6f2d\u6b40\u51d3\u60f6\u60d0\u5e5c\u5b0a\u6d26\u6384\u586f\u675d\u577d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
