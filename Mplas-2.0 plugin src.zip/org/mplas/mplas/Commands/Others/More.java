package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;
import org.bukkit.inventory.*;

public class More implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!commandSender.hasPermission(\u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(-1684415747, 1230561702, "\ucc2e\ucc1e\ucc02\ucc0d\ucc01\ucc5a\ucc1e\ucc17\ucc3a\ucc12\ucc12", 181660940, 704518743)) || commandSender.hasPermission(\u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(32804839, -1659274089, "\u315f\u3169\u3177\u317a\u3168\u313d\u3177\u317b\u3144\u3179", -1611436045, 712289778))) {
            if (!(commandSender instanceof Player)) {
                final Object[] array2 = new Object[2];
                "\u6feb\u50ec".length();
                "\u57f6\u6025".length();
                "\u6e77".length();
                "\u5172\u64a5\u6d2e\u5efd\u5497".length();
                array2[0] = \u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(-36076035, 1507417173, "\u1c4a\u1c43\u1c41\u1c4f\u1c4c\u1c43\u1c3f\u1850\u1c68\u1c46\u1c49\u1c58\u1c16\u1865\u1c7c\u1c11\u1c73\u1c6e\u1c45\u7085\u7cf7\u6c92\u46ff\u707c\u4140\u4e4c\u4e81\u5207\u7151\u4def\u42fe\u7d52\u72bb\u48e7\u53c3\u4054\u47a8\u78a3\u4ace", -134431276, 126057583);
                "\u5333\u6b3f\u5fe0\u63ab\u554b".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u6980\u6e8e\u515f\u582b".length();
                array3[0] = \u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(-346352816, 173634137, "\u9f0e", 240075707, -1627144738);
                array2[n] = StyleUtils.gray(array3);
                commandSender.sendMessage(StyleUtils.red(array2));
                return true;
            }
            final Player player = (Player)commandSender;
            if (command.getName().equalsIgnoreCase(\u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(-1129035492, -1441545570, "\u3ae5\u3aca\u3ad3\u3ac6", -1134020942, 1775929339))) {
                final ItemStack itemInMainHand = player.getInventory().getItemInMainHand();
                if (itemInMainHand.getType() != Material.AIR) {
                    final int maxStackSize = itemInMainHand.getMaxStackSize();
                    final int amount = itemInMainHand.getAmount();
                    "\u5f1b\u5a0e\u4ecb\u6365\u6dbd".length();
                    "\u5a01\u6379\u65da\u5739".length();
                    "\u5f2c".length();
                    "\u587d\u5ca6\u5c53\u5bd0".length();
                    final int i = maxStackSize - amount;
                    itemInMainHand.setAmount(maxStackSize);
                    final String replace = itemInMainHand.getType().toString().toLowerCase().replace(\u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(851089899, -1627945038, "\u1520", -2120025758, -342822393), \u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(-874656726, -1358499479, "\u363c", -2049010189, 795713263));
                    final Player player2 = player;
                    final Object[] array4 = new Object[2];
                    "\u523f".length();
                    "\u59d1\u4f2d\u64d1\u5ef4".length();
                    array4[0] = \u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(1975360601, -1069074101, "\u2b58\u0cc0", 1603863990, -1260213206);
                    "\u511d\u6275\u6f79\u51c7\u58c3".length();
                    "\u60ee\u61cc\u5f2d\u5bea".length();
                    "\u4e88\u6c56\u6e66\u5296".length();
                    final int n2 = 1;
                    final Object[] array5 = new Object[2];
                    "\u5079".length();
                    array5[0] = \u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(-1664795908, -1127831144, "\u0e67\u0ed1\u0ae3\u0ab8\u0edd\u0ab8\u0ac2\u0ac9\u0ae3\u0acc\u0ab4\u0ad9\u0ac3\u0ad1\u0ec8\u0ac6\u0ade\u0ac7\u0aea\u6622\u6a59\u7a41\u5023\u66d2\u5790\u5c8c", -969595548, -1832994657);
                    "\u6490".length();
                    final int n3 = 1;
                    final Object[] array6 = new Object[2];
                    "\u6240".length();
                    array6[0] = replace;
                    "\u61c7\u6faf".length();
                    "\u57e2\u56ad\u6e38\u6214".length();
                    final int n4 = 1;
                    final Object[] array7 = new Object[2];
                    "\u62ad\u528f\u6b62\u6217".length();
                    "\u6ce5".length();
                    "\u4f5b\u5e8c\u607c\u6270\u5f3f".length();
                    "\u69d2\u6b3f\u5391".length();
                    array7[0] = \u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(1142029101, 2015248947, "\ub456\ub066\ub06b\ub479", -1514945696, 1185992267);
                    "\u51e5\u5223\u5b07\u5604".length();
                    "\u539d\u5169\u5784".length();
                    "\u6aa5\u5d1d\u6137\u4fbf\u6447".length();
                    "\u644a\u548e".length();
                    final int n5 = 1;
                    final Object[] array8 = { null };
                    "\u4edc".length();
                    "\u64f9\u57ff\u61e1\u5103\u63b9".length();
                    "\u5037".length();
                    "\u4f42\u640d".length();
                    array8[0] = i;
                    array7[n5] = StyleUtils.gold(array8);
                    array6[n4] = StyleUtils.gray(array7);
                    array5[n3] = StyleUtils.gold(array6);
                    array4[n2] = StyleUtils.gray(array5);
                    player2.sendMessage(StyleUtils.gold(array4));
                }
                else {
                    final Player player3 = player;
                    final Object[] array9 = new Object[2];
                    "\u5918".length();
                    "\u7006\u52b8".length();
                    "\u50e5".length();
                    array9[0] = \u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(-1039330989, 1519130556, "\ua1f0\ua1f1\ua1f8\ua181\ua1ff\ua1fd\ua18c\ua1f7\ua5c6\ua1f5\ua18d\ua1ea\ua1d2\ua1cb\ua1c3\ua1a0\ua5de\ua1d0\ua5ec\ucd3b\uc131\ud124\ufb47", -417106092, 173331482);
                    "\u57ad\u6a11".length();
                    "\u6241\u5672\u6b3c\u4ff4\u6635".length();
                    "\u6db0".length();
                    final int n6 = 1;
                    final Object[] array10 = { null };
                    "\u67da".length();
                    "\u4f66\u575d\u524e".length();
                    "\u59bc\u53d4".length();
                    array10[0] = \u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(1427950032, -1090291891, "\u76ac", 1562427283, -906397760);
                    array9[n6] = StyleUtils.gray(array10);
                    player3.sendMessage(StyleUtils.red(array9));
                }
            }
        }
        else {
            final Object[] array11 = new Object[2];
            "\u5b4a\u5a1c\u6c83".length();
            "\u651d\u594e\u6924\u5b37".length();
            array11[0] = \u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(1200874702, 1346442910, "\u89ab\u8d83\u8993\u8991\u89e0\u8d89\u899d\u899b\u89ce\u8d86\u899c\u89f3\u8984\u89a9", 1117796499, 856377096);
            "\u641d\u624f\u567b".length();
            "\u51f8\u4e9b\u5099\u64a5\u6754".length();
            "\u64c2\u6253\u5252\u50bf".length();
            final int n7 = 1;
            final Object[] array12 = { null };
            "\u5629\u5029".length();
            "\u7000\u67c0\u5a31".length();
            array12[0] = \u5b32\u5495\u57d1\u6356\u5273\u54bf\u6dbd\u6d68\u5278\u6ca6\u6d47\u6a2d\u6913\u66dc\u5602\u4ea4\u6efe\u5e38\u6502\u6110\u665c\u5daf\u7126\u6093\u6bf2\u6637\u54e4\u6358\u670d\u5663\u4e44\u711d\u6d6f\u6507\u54eb\u52f4\u4e42\u6519\u6dc5\u53fe\u6eeb(1263551537, 777051502, "\u61dd", -1213148060, -1755108220);
            array11[n7] = StyleUtils.gray(array12);
            commandSender.sendMessage(StyleUtils.red(array11));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u7021\u5d59\u6502\u67de\u63cf\u4f2c\u5ecf\u5f99\u5ceb\u6950\u6223\u6dfe\u6c97\u57fb\u6a4b\u5400\u6ae6\u6bf1\u6f15\u5123\u58e9\u5a77\u53c8\u558a\u60df\u5ae3\u66ed\u62f3\u561a\u5e0c\u54f7\u6973\u66c0\u5085\u66a1\u52f5\u6e46\u586f\u6161\u5240\u63dd(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
