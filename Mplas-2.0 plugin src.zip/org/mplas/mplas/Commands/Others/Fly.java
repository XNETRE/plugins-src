package org.mplas.mplas.Commands.Others;

import org.jetbrains.annotations.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;

public class Fly implements CommandExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (!commandSender.hasPermission(\u55c6\u51ca\u534b\u689a\u6695\u50cf\u56f0\u61f0\u7024\u502a\u5bb7\u5699\u6864\u5ec4\u641f\u6013\u6616\u6e6f\u571c\u4fb3\u6eb0\u6960\u5dcf\u5058\u6765\u68dc\u59ca\u6ea6\u6468\u5c94\u67c5\u65d6\u58f8\u5f3a\u655a\u663a\u6973\u60ed\u6e70\u50a1\u7004(430955350, -843885293, "\u5ff9\u5fc9\u5fd5\u5fda\u5fc6\u5f9d\u5fd9\u5fd0\u5ffd\u5fd5\u5fd5", -532684236, -1802554458)) || commandSender.hasPermission(\u55c6\u51ca\u534b\u689a\u6695\u50cf\u56f0\u61f0\u7024\u502a\u5bb7\u5699\u6864\u5ec4\u641f\u6013\u6616\u6e6f\u571c\u4fb3\u6eb0\u6960\u5dcf\u5058\u6765\u68dc\u59ca\u6ea6\u6468\u5c94\u67c5\u65d6\u58f8\u5f3a\u655a\u663a\u6973\u60ed\u6e70\u50a1\u7004(-2077145569, -1249222180, "\u371c\u3722\u373c\u3731\u3723\u377e\u373f\u373b\u370c", 726658999, -1137115322))) {
            if (commandSender instanceof Player) {
                final Player player = (Player)commandSender;
                if (player.isFlying()) {
                    final Player player2 = player;
                    final Object[] array2 = new Object[3];
                    "\u625c\u56f3\u5aaf\u693c".length();
                    "\u58c1\u5f77\u5c36\u558a\u5326".length();
                    array2[0] = \u55c6\u51ca\u534b\u689a\u6695\u50cf\u56f0\u61f0\u7024\u502a\u5bb7\u5699\u6864\u5ec4\u641f\u6013\u6616\u6e6f\u571c\u4fb3\u6eb0\u6960\u5dcf\u5058\u6765\u68dc\u59ca\u6ea6\u6468\u5c94\u67c5\u65d6\u58f8\u5f3a\u655a\u663a\u6973\u60ed\u6e70\u50a1\u7004(-927582573, -265668392, "\ubc4b\ubc79\ubc72\ubc79\ub81e", -1435201604, 1901607387);
                    "\u686b\u642b\u5ab3\u5a05\u522b".length();
                    final int n = 1;
                    final Object[] array3 = { null };
                    "\u5d7f\u7084".length();
                    array3[0] = \u55c6\u51ca\u534b\u689a\u6695\u50cf\u56f0\u61f0\u7024\u502a\u5bb7\u5699\u6864\u5ec4\u641f\u6013\u6616\u6e6f\u571c\u4fb3\u6eb0\u6960\u5dcf\u5058\u6765\u68dc\u59ca\u6ea6\u6468\u5c94\u67c5\u65d6\u58f8\u5f3a\u655a\u663a\u6973\u60ed\u6e70\u50a1\u7004(-863137798, 679174251, "\ua693\ua6c5\ua6b6\ua6bb\ua6ce\ua6c3\ua6b8\ua6ba", 1615274277, -1062638506);
                    array2[n] = StyleUtils.red(array3);
                    "\u59fa\u582b\u677d\u4fc4".length();
                    "\u5561".length();
                    array2[2] = \u55c6\u51ca\u534b\u689a\u6695\u50cf\u56f0\u61f0\u7024\u502a\u5bb7\u5699\u6864\u5ec4\u641f\u6013\u6616\u6e6f\u571c\u4fb3\u6eb0\u6960\u5dcf\u5058\u6765\u68dc\u59ca\u6ea6\u6468\u5c94\u67c5\u65d6\u58f8\u5f3a\u655a\u663a\u6973\u60ed\u6e70\u50a1\u7004(710229012, 1262629759, "\ua071", 549713845, -1454876478);
                    player2.sendMessage(StyleUtils.gray(array2));
                    player.setAllowFlight(false);
                }
                else {
                    player.setAllowFlight(true);
                    final Player player3 = player;
                    final Object[] array4 = new Object[3];
                    "\u6121\u5df7\u6e13".length();
                    array4[0] = \u55c6\u51ca\u534b\u689a\u6695\u50cf\u56f0\u61f0\u7024\u502a\u5bb7\u5699\u6864\u5ec4\u641f\u6013\u6616\u6e6f\u571c\u4fb3\u6eb0\u6960\u5dcf\u5058\u6765\u68dc\u59ca\u6ea6\u6468\u5c94\u67c5\u65d6\u58f8\u5f3a\u655a\u663a\u6973\u60ed\u6e70\u50a1\u7004(-1144481274, 1895912327, "\u8781\u87b1\u87b8\u87b5\u83ac", 1577725025, -210868730);
                    "\u6694".length();
                    "\u6fe7\u4e63\u51bb".length();
                    "\u6b3d".length();
                    final int n2 = 1;
                    final Object[] array5 = { null };
                    "\u5881\u598d\u57d6\u6807\u6bde".length();
                    "\u6649\u565a\u6166\u5921\u514c".length();
                    array5[0] = \u55c6\u51ca\u534b\u689a\u6695\u50cf\u56f0\u61f0\u7024\u502a\u5bb7\u5699\u6864\u5ec4\u641f\u6013\u6616\u6e6f\u571c\u4fb3\u6eb0\u6960\u5dcf\u5058\u6765\u68dc\u59ca\u6ea6\u6468\u5c94\u67c5\u65d6\u58f8\u5f3a\u655a\u663a\u6973\u60ed\u6e70\u50a1\u7004(1815427943, 276521279, "\u9a9c\u9ab9\u9abc\u9acb\u9ac0\u9ab4\u9abb", -1795688446, -531350345);
                    array4[n2] = StyleUtils.gold(array5);
                    "\u7085".length();
                    "\u6635\u70eb".length();
                    array4[2] = \u55c6\u51ca\u534b\u689a\u6695\u50cf\u56f0\u61f0\u7024\u502a\u5bb7\u5699\u6864\u5ec4\u641f\u6013\u6616\u6e6f\u571c\u4fb3\u6eb0\u6960\u5dcf\u5058\u6765\u68dc\u59ca\u6ea6\u6468\u5c94\u67c5\u65d6\u58f8\u5f3a\u655a\u663a\u6973\u60ed\u6e70\u50a1\u7004(-444564962, -1647304660, "\ufe8c", 108154245, 499181910);
                    player3.sendMessage(StyleUtils.gray(array4));
                }
            }
        }
        else {
            final Object[] array6 = new Object[2];
            "\u55b4".length();
            "\u6979\u6bda\u57d2".length();
            array6[0] = \u55c6\u51ca\u534b\u689a\u6695\u50cf\u56f0\u61f0\u7024\u502a\u5bb7\u5699\u6864\u5ec4\u641f\u6013\u6616\u6e6f\u571c\u4fb3\u6eb0\u6960\u5dcf\u5058\u6765\u68dc\u59ca\u6ea6\u6468\u5c94\u67c5\u65d6\u58f8\u5f3a\u655a\u663a\u6973\u60ed\u6e70\u50a1\u7004(950077371, 1860791757, "\u7e2f\u7a0f\u7e1f\u7e1d\u7e6c\u7a0d\u7e19\u7e1f\u7e4a\u7a3a\u7e20\u7e4f\u7e38\u7e2d", -2071502121, -121736466);
            "\u5c8f\u5cda".length();
            "\u59cd\u62d2\u70ef".length();
            final int n3 = 1;
            final Object[] array7 = { null };
            "\u4eb8".length();
            "\u6d3e".length();
            array7[0] = \u55c6\u51ca\u534b\u689a\u6695\u50cf\u56f0\u61f0\u7024\u502a\u5bb7\u5699\u6864\u5ec4\u641f\u6013\u6616\u6e6f\u571c\u4fb3\u6eb0\u6960\u5dcf\u5058\u6765\u68dc\u59ca\u6ea6\u6468\u5c94\u67c5\u65d6\u58f8\u5f3a\u655a\u663a\u6973\u60ed\u6e70\u50a1\u7004(-740389146, -371141974, "\u797b", -1529582322, -438810533);
            array6[n3] = StyleUtils.gray(array7);
            commandSender.sendMessage(StyleUtils.red(array6));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u655f\u554c\u6b19\u5f75\u65cd\u55c6\u5b04\u6678\u6b7b\u6467\u70ad\u58b2\u647b\u5a41\u6b8b\u66f2\u61a3\u59c1\u541a\u6882\u5aee\u57fa\u580e\u552f\u54f1\u6993\u5a3d\u5116\u5836\u6639\u6011\u4e68\u6ef2\u67f5\u6e1b\u617f\u58c9\u66fd\u634a\u568f\u6e94(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
