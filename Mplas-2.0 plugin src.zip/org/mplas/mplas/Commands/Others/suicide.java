package org.mplas.mplas.Commands.Others;

import org.jetbrains.annotations.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.bukkit.inventory.meta.*;

public class suicide implements CommandExecutor
{
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (!commandSender.hasPermission(\u511b\u6f69\u61ea\u6612\u6af4\u4f35\u60fc\u6e29\u70c2\u58bb\u679c\u5e41\u6056\u55b5\u6c54\u674c\u5486\u5e27\u6fec\u592e\u6063\u6749\u5b8c\u59de\u5697\u69da\u5f75\u701b\u5208\u5835\u5e96\u667b\u52fd\u5600\u6129\u6c89\u6df9\u5082\u6fb6\u594b\u4ffc(927678670, -2015780124, "\ue8bf\ue88f\ue893\ue89c\ue888\ue8d3\ue897\ue89e\ue88b\ue8a3\ue8a3", 399361048, -2054697309)) || commandSender.hasPermission(\u511b\u6f69\u61ea\u6612\u6af4\u4f35\u60fc\u6e29\u70c2\u58bb\u679c\u5e41\u6056\u55b5\u6c54\u674c\u5486\u5e27\u6fec\u592e\u6063\u6749\u5b8c\u59de\u5697\u69da\u5f75\u701b\u5208\u5835\u5e96\u667b\u52fd\u5600\u6129\u6c89\u6df9\u5082\u6fb6\u594b\u4ffc(-713857784, 1949310840, "\ua6ee\ua6de\ua6c6\ua6c9\ua6d9\ua682\ua6d8\ua6d2\ua6ee\ua6c8\ua6c1\ua6de\ua6da", -1676091246, -596820958))) {
            final Player player = (Player)commandSender;
            player.setHealth(0.0);
            this.spawnFirework(player.getLocation());
            final Object[] array2 = new Object[2];
            "\u537f\u5b55".length();
            "\u5b1b\u616f".length();
            "\u5275\u6169\u69d5\u6bb4\u4e9a".length();
            array2[0] = \u511b\u6f69\u61ea\u6612\u6af4\u4f35\u60fc\u6e29\u70c2\u58bb\u679c\u5e41\u6056\u55b5\u6c54\u674c\u5486\u5e27\u6fec\u592e\u6063\u6749\u5b8c\u59de\u5697\u69da\u5f75\u701b\u5208\u5835\u5e96\u667b\u52fd\u5600\u6129\u6c89\u6df9\u5082\u6fb6\u594b\u4ffc(-597318172, -453820575, "\u05c8\u05be\u01d7\u05a8\u05aa\u05d0\u05d3\u05a4\u05f3\u05de\u01c5\u05c6\u05c0\u05d7\u05d0\u05c1\u05a1\u05c0\u05ef\u5058\u6ad9\u556c\u4ecd\u4b76\u537f\u5438\u6656\u6ba3", -1912190227, 1076154865);
            "\u4fc6\u6264\u591d\u63d0\u632e".length();
            "\u6528".length();
            "\u6782\u58ad\u58f5".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u6239\u6f65\u6c76".length();
            "\u6769\u653a\u5ba5\u7027\u629f".length();
            "\u65a5\u694a\u5836\u51d9".length();
            array3[0] = \u511b\u6f69\u61ea\u6612\u6af4\u4f35\u60fc\u6e29\u70c2\u58bb\u679c\u5e41\u6056\u55b5\u6c54\u674c\u5486\u5e27\u6fec\u592e\u6063\u6749\u5b8c\u59de\u5697\u69da\u5f75\u701b\u5208\u5835\u5e96\u667b\u52fd\u5600\u6129\u6c89\u6df9\u5082\u6fb6\u594b\u4ffc(-657544459, -2052180486, "\u0bda", -1480007048, 1428846287);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.gold(array2));
        }
        else {
            final Object[] array4 = new Object[2];
            "\u60f1\u68f0".length();
            "\u5a57\u5503\u5eb6\u6498".length();
            "\u6e8f".length();
            array4[0] = \u511b\u6f69\u61ea\u6612\u6af4\u4f35\u60fc\u6e29\u70c2\u58bb\u679c\u5e41\u6056\u55b5\u6c54\u674c\u5486\u5e27\u6fec\u592e\u6063\u6749\u5b8c\u59de\u5697\u69da\u5f75\u701b\u5208\u5835\u5e96\u667b\u52fd\u5600\u6129\u6c89\u6df9\u5082\u6fb6\u594b\u4ffc(1542292013, -852138793, "\uef85\uebab\uef85\uef85\ueff6\ueb91\uef83\uef87\uefd0\ueb9e\uef8a\uefe7\uef92\uef81", 952232094, -838146687);
            "\u57e1\u4fcd\u6c11".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u6cd9\u5178\u5165".length();
            "\u5401\u6369".length();
            "\u5cbb\u5d97\u579a".length();
            array5[0] = \u511b\u6f69\u61ea\u6612\u6af4\u4f35\u60fc\u6e29\u70c2\u58bb\u679c\u5e41\u6056\u55b5\u6c54\u674c\u5486\u5e27\u6fec\u592e\u6063\u6749\u5b8c\u59de\u5697\u69da\u5f75\u701b\u5208\u5835\u5e96\u667b\u52fd\u5600\u6129\u6c89\u6df9\u5082\u6fb6\u594b\u4ffc(-2136931445, -2141605455, "\u62ef", -367008976, 941241223);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
        }
        return true;
    }
    
    public void spawnFirework(final Location location) {
        final Firework firework = (Firework)location.getWorld().spawn(location, (Class)Firework.class);
        final FireworkMeta fireworkMeta = firework.getFireworkMeta();
        final FireworkEffect.Builder builder = FireworkEffect.builder();
        builder.with(FireworkEffect.Type.BALL_LARGE);
        "\u596f\u4ff9\u54ce\u5d45\u6c3c".length();
        "\u5e1d\u6df5\u6d68\u6a48".length();
        "\u4fe2\u61e7\u4e70\u5c5c\u4e24".length();
        builder.withColor(Color.GREEN);
        "\u6ab9\u6337".length();
        "\u6477\u54f4\u605b".length();
        builder.withFade(Color.RED);
        "\u685e\u5f41".length();
        "\u53c1".length();
        "\u6d2f\u522a\u54fb\u4f31\u6363".length();
        builder.withTrail();
        "\u6038\u5e76\u66fd\u5114\u708e".length();
        "\u6716\u6ab1".length();
        builder.withFlicker();
        "\u5fd9".length();
        "\u5a5e".length();
        "\u6224\u62d4\u60d6\u569e".length();
        fireworkMeta.addEffect(builder.build());
        fireworkMeta.setPower(2);
        firework.setFireworkMeta(fireworkMeta);
    }
    
    public static int ColonialObfuscator_\u6d1b\u549c\u6a87\u6287\u5548\u6273\u6a3a\u6aaf\u5e66\u6611\u6277\u5ccf\u597f\u6e87\u516d\u52da\u5a4c\u51e4\u4ec0\u66cd\u6dfc\u4fc0\u64c6\u641b\u70e5\u6c27\u5b15\u557c\u6b1f\u5a23\u5a47\u4e52\u6b22\u6d2a\u68eb\u6905\u5b35\u53f7\u4ffe\u6f75\u5f21(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
