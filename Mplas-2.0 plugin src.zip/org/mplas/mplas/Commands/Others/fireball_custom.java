package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;

public class fireball_custom implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!(commandSender instanceof Player)) {
            final Object[] array2 = new Object[2];
            "\u6a41\u6241".length();
            array2[0] = \u6055\u6299\u6529\u5204\u653c\u5aa1\u6bcd\u4e7e\u5d5d\u5779\u50f1\u65a8\u5d26\u6a9e\u5dec\u6fa8\u4f36\u6261\u6a20\u6f5a\u69b7\u5a78\u687d\u6316\u64c0\u6e16\u4f22\u53fe\u5283\u6272\u500c\u5049\u6451\u5c11\u5bc9\u6905\u6475\u4ea4\u6ac0\u6a4a\u4eb0(-244932437, -1132386674, "\u2fe1\u2fe8\u2fee\u2fe0\u2fef\u2fe0\u2f90\u2bff\u2fc3\u2fed\u2fe6\u2ff7\u2f85\u2bf6\u2ff3\u2f9e\u2ff8\u2fe5\u2fca\u760b\u7fde\u6114\u4ca2\u4db0\u7e5e\u4729\u7acb\u42c5\u42ba\u498b\u4013\u4eec\u438d\u728e\u4137\u79a5\u7a54\u4aa0\u7249", -1186276350, -1015909985);
            "\u53f3\u63f2\u5d35\u6086".length();
            "\u657e".length();
            "\u53c8\u58a7\u7067".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u4edb\u61da\u6f41\u6f3e".length();
            "\u6cbe".length();
            "\u6260\u5c28\u5c40\u4f93\u66db".length();
            "\u6a95".length();
            array3[0] = \u6055\u6299\u6529\u5204\u653c\u5aa1\u6bcd\u4e7e\u5d5d\u5779\u50f1\u65a8\u5d26\u6a9e\u5dec\u6fa8\u4f36\u6261\u6a20\u6f5a\u69b7\u5a78\u687d\u6316\u64c0\u6e16\u4f22\u53fe\u5283\u6272\u500c\u5049\u6451\u5c11\u5bc9\u6905\u6475\u4ea4\u6ac0\u6a4a\u4eb0(-1299413345, 774070507, "\ubf43", 327060787, 1037489254);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        final Player player = (Player)commandSender;
        if (commandSender.hasPermission(\u6055\u6299\u6529\u5204\u653c\u5aa1\u6bcd\u4e7e\u5d5d\u5779\u50f1\u65a8\u5d26\u6a9e\u5dec\u6fa8\u4f36\u6261\u6a20\u6f5a\u69b7\u5a78\u687d\u6316\u64c0\u6e16\u4f22\u53fe\u5283\u6272\u500c\u5049\u6451\u5c11\u5bc9\u6905\u6475\u4ea4\u6ac0\u6a4a\u4eb0(-2090679859, 1170101330, "\u4b52\u4b60\u4b7e\u4b7f\u4b6d\u4b34\u4b72\u4b7d\u4b56\u4b7c\u4b7e", -951661067, -282127594)) && !commandSender.hasPermission(\u6055\u6299\u6529\u5204\u653c\u5aa1\u6bcd\u4e7e\u5d5d\u5779\u50f1\u65a8\u5d26\u6a9e\u5dec\u6fa8\u4f36\u6261\u6a20\u6f5a\u69b7\u5a78\u687d\u6316\u64c0\u6e16\u4f22\u53fe\u5283\u6272\u500c\u5049\u6451\u5c11\u5bc9\u6905\u6475\u4ea4\u6ac0\u6a4a\u4eb0(514462151, 2091225935, "\u1776\u1746\u175a\u1755\u1749\u1712\u1751\u1752\u176d\u1756\u1756\u1747\u1753\u1742", 1633254244, -1678971212))) {
            final Object[] array4 = new Object[2];
            "\u566e\u70f6\u6b12".length();
            "\u5d11\u6e3b\u50b1\u5f9d".length();
            "\u7080\u6ea0\u56a5\u4f07\u5b15".length();
            "\u565b\u5a78\u6856\u5b4b\u66b3".length();
            "\u6ba3".length();
            array4[0] = \u6055\u6299\u6529\u5204\u653c\u5aa1\u6bcd\u4e7e\u5d5d\u5779\u50f1\u65a8\u5d26\u6a9e\u5dec\u6fa8\u4f36\u6261\u6a20\u6f5a\u69b7\u5a78\u687d\u6316\u64c0\u6e16\u4f22\u53fe\u5283\u6272\u500c\u5049\u6451\u5c11\u5bc9\u6905\u6475\u4ea4\u6ac0\u6a4a\u4eb0(-732642964, 857956183, "\u271d\u2335\u2725\u2727\u2756\u233f\u272b\u272d\u2778\u2330\u272a\u2745\u2732\u275f", 13180339, 1968939253);
            "\u5c92\u5242\u69f2\u6352".length();
            "\u5c88\u5990\u566d\u70f9\u61ca".length();
            "\u6e09\u6cbc".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u5755".length();
            "\u574e\u5a06\u6cc5\u534b".length();
            "\u5e10\u54dc\u5856\u655a\u5260".length();
            "\u5d08\u59af".length();
            array5[0] = \u6055\u6299\u6529\u5204\u653c\u5aa1\u6bcd\u4e7e\u5d5d\u5779\u50f1\u65a8\u5d26\u6a9e\u5dec\u6fa8\u4f36\u6261\u6a20\u6f5a\u69b7\u5a78\u687d\u6316\u64c0\u6e16\u4f22\u53fe\u5283\u6272\u500c\u5049\u6451\u5c11\u5bc9\u6905\u6475\u4ea4\u6ac0\u6a4a\u4eb0(927504615, -506302370, "\u9c03", 949082123, 1605807315);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
            return false;
        }
        if (command.getName().equalsIgnoreCase(\u6055\u6299\u6529\u5204\u653c\u5aa1\u6bcd\u4e7e\u5d5d\u5779\u50f1\u65a8\u5d26\u6a9e\u5dec\u6fa8\u4f36\u6261\u6a20\u6f5a\u69b7\u5a78\u687d\u6316\u64c0\u6e16\u4f22\u53fe\u5283\u6272\u500c\u5049\u6451\u5c11\u5bc9\u6905\u6475\u4ea4\u6ac0\u6a4a\u4eb0(1812192610, 588606131, "\u9d97\u9db5\u9dae\u9dbb\u9dba\u9dbf\u9db9\u9db5", 1131111216, 927222099))) {
            ((Fireball)player.launchProjectile((Class)Fireball.class)).setIsIncendiary(false);
            return true;
        }
        return false;
    }
    
    public static int ColonialObfuscator_\u5781\u4fba\u581c\u63c5\u6a2b\u4ede\u5be4\u5624\u4f3a\u6d7c\u7056\u5700\u6a6b\u68e1\u5316\u608b\u70d4\u5ef8\u5111\u596d\u6cbb\u52ee\u57be\u5786\u6b7e\u5adf\u6e95\u6061\u6561\u5329\u55aa\u590f\u55f2\u5254\u6020\u5e62\u4eb6\u6b4b\u61ea\u5044\u60e9(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
