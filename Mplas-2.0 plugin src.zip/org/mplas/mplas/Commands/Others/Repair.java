package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.inventory.*;

public class Repair implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!commandSender.hasPermission(\u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(-640322542, -2129198605, "\u7d82\u7db0\u7dae\u7dbf\u7dad\u7df4\u7db2\u7dbd\u7d96\u7dbc\u7dbe", -562141587, -1517982176)) || commandSender.hasPermission(\u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(-673175509, 1573415520, "\ucde7\ucdd7\ucdcf\ucdc0\ucdd0\ucd8b\ucdd0\ucdcb\ucde2\ucdcd\ucdc0\ucdd7", 538332722, -1768963664))) {
            if (!(commandSender instanceof Player)) {
                final Object[] array2 = new Object[2];
                "\u5685\u5b2b\u4e38\u62d4".length();
                "\u59ef\u663a\u58e6\u630d".length();
                array2[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(1725786835, -1162144859, "\u6591\u659a\u659a\u6592\u659f\u6592\u65ec\u5e7d\u5a43\u5a6f\u5a62\u5a75\u5a05\u5e74\u5a6f\u5a0c\u5a68\u5a77\u5a5e\u073b\u366e\u15a6\u3692\u31b4\u2b4a\u0fdb\u3f0f\u0742\u3c31\u063a\u329b\u1428\u2b09\u0f0a\u34c0\u36b6\u3739\u1465\u39b3", -1799086087, -1063909561);
                "\u6d2e".length();
                "\u6f4c\u6d44\u60ba\u705d\u687e".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u509b\u5e7a".length();
                "\u6084".length();
                array3[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(-283272308, 505906981, "\u6846", 410802547, -1053348354);
                array2[n] = StyleUtils.gray(array3);
                commandSender.sendMessage(StyleUtils.red(array2));
                return true;
            }
            final Player player = (Player)commandSender;
            if (command.getName().equalsIgnoreCase(\u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(-1213289613, -370659349, "\u74e2\u74d8\u74d1\u74c2\u74c8\u74d5", -1681965138, 2106904549))) {
                final ItemStack itemInMainHand = player.getInventory().getItemInMainHand();
                if (itemInMainHand.getType().getMaxDurability() <= 0 || itemInMainHand.getDurability() == 0) {
                    final Player player2 = player;
                    final Object[] array4 = new Object[2];
                    "\u4f28\u7005".length();
                    "\u68ac\u6ea8".length();
                    "\u54eb\u64dc".length();
                    array4[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(365817321, -1330745187, "\u5c63\u5c21\u5c59\u5c27\u5847\u5c5e\u5c36\u5c4f\u5c6e\u5c4a\u5c40\u5c25\u5842\u5c4e\u5c4b\u5c51\u5c3e\u5c59\u5c0b\u0570\u3043\u1381\u30be\u37fb\u2d70\u09e8\u3d2c\u010b", -777274454, -1833664813);
                    "\u6b64\u6ede\u5e5e".length();
                    "\u5e22\u5286\u60f9\u5d8a\u5914".length();
                    "\u608c\u5713".length();
                    final int n2 = 1;
                    final Object[] array5 = { null };
                    "\u4eac\u5d8c".length();
                    array5[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(147633985, 866409730, "\uade3", 1721032201, 741317067);
                    array4[n2] = StyleUtils.gray(array5);
                    player2.sendMessage(StyleUtils.red(array4));
                    return true;
                }
                boolean b = false;
                if (array.length > 0 && array[0].equalsIgnoreCase(\u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(-397119601, 511458390, "\uae66\uae44\uae46", -47316231, 2101149540))) {
                    b = true;
                }
                int i = 0;
                "\u6be0\u6cc9\u671b\u6f3f".length();
                "\u6040".length();
                "\u6ae3\u52aa\u5bb0\u63df\u7127".length();
                final ArrayList<String> elements = new ArrayList<String>();
                if (b) {
                    final ItemStack[] contents = player.getInventory().getContents();
                    for (int length = contents.length, j = 0; j < length; j -= 24023, j += 24024) {
                        final ItemStack itemStack = contents[j];
                        if (itemStack != null && itemStack.getType().getMaxDurability() > 0 && itemStack.getDurability() > 0) {
                            itemStack.setDurability((short)0);
                            i -= 1926;
                            i += 1927;
                            elements.add(itemStack.getType().toString());
                            "\u5ea4\u6c62\u5a02\u6d9f".length();
                            "\u5ba8\u5834\u5e79".length();
                            "\u64c4\u5991\u708d".length();
                        }
                    }
                }
                else if (itemInMainHand.getDurability() > 0) {
                    itemInMainHand.setDurability((short)0);
                    i -= 9904;
                    i += 9905;
                    elements.add(itemInMainHand.getType().toString());
                    "\u511a\u507f".length();
                    "\u691c\u556b".length();
                }
                if (i > 0) {
                    final Player player3 = player;
                    final Object[] array6 = new Object[2];
                    "\u68ba".length();
                    "\u6b6d\u5205".length();
                    "\u6db0\u6fb8\u4f86\u6e51".length();
                    array6[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(1532046137, 1202774297, "\ud074\ud00e\ud467\ud078\ud079\ud000\ud076\ud07d\ud05a\ud00b\ud00d\ud405", 1901229751, 2007197874);
                    "\u6a84\u64fb".length();
                    final int n3 = 1;
                    final Object[] array7 = new Object[2];
                    "\u5b2b\u6d27\u64bf\u6af2\u6340".length();
                    "\u688a".length();
                    "\u5099\u62df\u60a0\u4fa1\u691b".length();
                    array7[0] = i;
                    "\u66e8\u6a2e\u5a49\u6550".length();
                    "\u5ea4\u5b0b\u55e2\u5ec5".length();
                    "\u6e58\u6cb7\u4e5e\u4ff3".length();
                    "\u612b\u6e65\u4fbe\u5e46".length();
                    final int n4 = 1;
                    final Object[] array8 = { null };
                    "\u5877\u6da4\u51be\u5033".length();
                    "\u6a27".length();
                    "\u6600\u614f\u65d9".length();
                    array8[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(-108516881, 304039466, "\u7567\u7157\u712a\u715b\u715a\u7156\u7156\u7123\u717d\u715f\u7546", 1671738129, -450319920);
                    array7[n4] = StyleUtils.gray(array8);
                    array6[n3] = StyleUtils.gold(array7);
                    player3.sendMessage(StyleUtils.gray(array6));
                    if (!elements.isEmpty()) {
                        final String join = String.join(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY), (Iterable<? extends CharSequence>)elements);
                        final Player player4 = player;
                        final Object[] array9 = new Object[2];
                        "\u5db6\u4eae\u5d76".length();
                        "\u6174\u5d14\u51e5\u59a4\u619c".length();
                        "\u6fb1\u6a2b".length();
                        array9[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(1155865640, 1351952835, "\u68f0\u68c3\u68c4\u68bf\u68ce\u68cc\u6cdd\u68ce\u6895\u68cc\u68ca\u68d0\u68c0\u68a6\u68db\u68c3\u6cd7\u6cd1", 1441759108, -1032509699);
                        "\u6232\u5a75".length();
                        "\u5606\u6fc7\u610f\u4e96".length();
                        final int n5 = 1;
                        final Object[] array10 = { null };
                        "\u52b0".length();
                        array10[0] = join;
                        array9[n5] = StyleUtils.gold(array10);
                        player4.sendMessage(StyleUtils.gray(array9));
                    }
                }
                else {
                    final Player player5 = player;
                    final Object[] array11 = new Object[2];
                    "\u6e05".length();
                    array11[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(-1381848066, -1360415030, "\u40ae\u40ab\u40dc\u44bc\u40a5\u40dc\u40a2\u40af\u408b\u40ae\u40de\u40b0\u40bd\u44be\u40ab\u40b0\u40c0\u44b3\u4082\u1d97\u2cc6\u0f7a\u2c45\u2b78\u31f8", 86162528, -2006850140);
                    "\u6dbe\u4fd9".length();
                    "\u5466\u4f91".length();
                    "\u6ab7\u5900".length();
                    "\u51d9\u50d9\u5f07".length();
                    final int n6 = 1;
                    final Object[] array12 = { null };
                    "\u5db1".length();
                    "\u6826\u6adf\u5ecc".length();
                    "\u50ea\u522b\u5cfd".length();
                    array12[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(135843459, -274314392, "\u7b02", -1338158703, 1011134234);
                    array11[n6] = StyleUtils.gray(array12);
                    player5.sendMessage(StyleUtils.red(array11));
                }
            }
        }
        else {
            final Object[] array13 = new Object[2];
            "\u5410\u689b\u5a8f\u6caf\u710d".length();
            "\u70fd\u666d\u672e".length();
            "\u5377\u6948\u4fba".length();
            array13[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(1208830213, 2110675624, "\u0a32\u0e1a\u0a0a\u0a08\u0a79\u0e10\u0a04\u0a02\u0a57\u0e1f\u0a05\u0a6a\u0a1d\u0a10", -1454309981, -613490596);
            "\u54c3\u54c0".length();
            "\u6da5\u574f\u62ee".length();
            "\u7058\u4e89\u4e96\u6633\u6263".length();
            final int n7 = 1;
            final Object[] array14 = { null };
            "\u693b\u63b0\u6c7b\u4e2a".length();
            "\u6c3c\u6fb6\u5d31\u5f72".length();
            "\u69e9".length();
            array14[0] = \u6b67\u6cc6\u5d0b\u64c8\u4fbb\u642e\u54e5\u6af7\u6bf0\u66f5\u6b0f\u5e75\u6bc3\u53e1\u69ec\u6863\u6548\u614e\u5875\u5dca\u5478\u6f3a\u6b46\u5c92\u6685\u6b8e\u54fd\u6cb4\u69f7\u5a15\u6df9\u57e2\u5d85\u5026\u6964\u66b3\u5181\u6317\u7040\u5424\u6d1c(-407570053, -285116344, "\u1632", 544280762, -785414183);
            array13[n7] = StyleUtils.gray(array14);
            commandSender.sendMessage(StyleUtils.red(array13));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u5888\u6bb2\u654a\u64e2\u6a53\u5eec\u5cf2\u6216\u5f9e\u686d\u621c\u5ca1\u6838\u6d92\u57ad\u5b58\u6ae0\u70c6\u514f\u6833\u56c3\u6e15\u6134\u6c68\u5d40\u5d51\u692d\u50a1\u5142\u5a6d\u5beb\u67ae\u54f5\u67b5\u7110\u5396\u5157\u554d\u4e3a\u6e3b\u671a(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
