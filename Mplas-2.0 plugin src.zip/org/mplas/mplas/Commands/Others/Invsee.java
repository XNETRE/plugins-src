package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;
import org.bukkit.event.inventory.*;
import org.bukkit.event.*;
import org.bukkit.inventory.*;

public class Invsee implements CommandExecutor, Listener
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        final Player player = (Player)commandSender;
        if (commandSender.hasPermission(\u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(2135135331, 1256590459, "\u0d92\u0da2\u0da2\u0dad\u0dbd\u0de6\u0da6\u0daf\u0d86\u0dae\u0da2", 1144408878, -1247093110)) && !commandSender.hasPermission(\u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(-1092588132, 1382020599, "\u2bbf\u2b8f\u2b97\u2b98\u2b88\u2bd3\u2b93\u2b98\u2ba0\u2b89\u2b9c\u2b8e", 1573888914, 2024673384))) {
            final Object[] array2 = new Object[2];
            "\u5fb7".length();
            array2[0] = \u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(-951032226, -952580033, "\u61ab\u6585\u619b\u619b\u61e8\u658f\u619d\u6199\u61ce\u6580\u6184\u61e9\u619c\u618f", -1992088922, 249686284);
            "\u5ed7\u699a".length();
            "\u6183".length();
            "\u6666\u5b54\u525b".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u5417\u69c7\u624b\u5008\u53f6".length();
            "\u5d87\u662a\u558d\u53c9".length();
            "\u570b\u64cf\u54a9\u667d".length();
            array3[0] = \u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(-753891799, -1087670508, "\ub4d4", 352822743, 8183900);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (!command.getName().equalsIgnoreCase(\u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(-1304111253, 809572983, "\u3ef1\u3ed9\u3ec3\u3ec2\u3ed4\u3ed0", -994243879, -472385250))) {
            return false;
        }
        if (array.length != 1) {
            final Object[] array4 = new Object[2];
            "\u5efb\u6493\u639d\u7030\u59f2".length();
            "\u6469\u6247\u69aa\u5ee5".length();
            "\u5b3b\u65ab".length();
            "\u6a82\u4fde\u5006".length();
            array4[0] = \u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(1944194569, 550605616, "\u4565\u4511\u456f\u456c\u4577\u4506\u4576\u4573\u455b\u4575\u457f\u4568\u456c\u4172\u4169\u4172\u4128\u4133\u4105\u2fda\u260e\u306e\u1ed8\u0f92\u1fff\u21e9\u1222\u28e6\u25ef\u2cfa", 978441292, 1778124875);
            "\u6cbe\u67fd\u6516".length();
            "\u6bb4\u6b12\u70c7".length();
            "\u4fe2\u5874".length();
            final int n2 = 1;
            final Object[] array5 = { null };
            "\u4e53\u5541\u57c2\u6153\u4ef5".length();
            "\u5df9".length();
            array5[0] = \u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(1078710252, 1100227955, "\u24be", -890364504, -322776085);
            array4[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.red(array4));
            return false;
        }
        final Player player2 = Bukkit.getServer().getPlayer(array[0]);
        if (player2 != null) {
            this.openInventoryWithArmorAndHand(player, player2);
            return true;
        }
        final Object[] array6 = new Object[2];
        "\u5277\u6d0f".length();
        "\u536c".length();
        "\u6a9f\u5d96".length();
        array6[0] = \u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(1420366755, 1443197326, "\uf729\uf72f\uf758\uf724\uf722\uf33e\uf734\uf730\uf305\uf734\uf73a\uf721\uf729\uf739\uf73c", 1120739114, -29585803);
        "\u6669".length();
        "\u5b88\u5ba4".length();
        "\u4f9f".length();
        final int n3 = 1;
        final Object[] array7 = { null };
        "\u5f2d\u7026\u6606".length();
        "\u55d9\u6314\u6e20\u6229\u684c".length();
        "\u5753\u53d5\u6bf1".length();
        array7[0] = \u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(105952774, -1472676976, "\u6240", -141383457, 897369963);
        array6[n3] = StyleUtils.gray(array7);
        commandSender.sendMessage(StyleUtils.red(array6));
        return false;
    }
    
    @EventHandler
    public void onInventoryClick(final InventoryClickEvent inventoryClickEvent) {
        final Inventory clickedInventory = inventoryClickEvent.getClickedInventory();
        if (clickedInventory != null && clickedInventory.getHolder() instanceof Player) {
            final Player player = (Player)inventoryClickEvent.getWhoClicked();
            final Player obj = (Player)clickedInventory.getHolder();
            if (player.equals(obj)) {
                final String title = inventoryClickEvent.getView().getTitle();
                final Object[] array = new Object[2];
                "\u659f\u7036".length();
                "\u6dca\u6e9c".length();
                array[0] = \u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(-245701517, 717482297, "\u66a6\u66a0\u66ad\u66aa\u66a2\u66dd\u66a6\u66d8\u66f6\u62a8\u66b5\u66ae\u66da\u66b3\u66b4\u66a8\u62a2", 812241223, 1797177072);
                "\u6dc5\u6cf0\u6a0d\u6f46\u511f".length();
                "\u5d40\u6e54\u5d46\u4f4f".length();
                final int n = 1;
                final Object[] array2 = { null };
                "\u61ea\u6ca1\u6dff".length();
                "\u6c35\u652a\u6763".length();
                "\u64e8".length();
                array2[0] = obj.getName();
                array[n] = StyleUtils.gold(array2);
                if (title.equals(StyleUtils.darkGray(array))) {
                    inventoryClickEvent.setCancelled(true);
                }
            }
        }
    }
    
    public void openInventoryWithArmorAndHand(final Player player, final Player player2) {
        final int n = 45;
        final Object[] array = new Object[2];
        "\u635f\u67bf\u617e\u53a9\u6eca".length();
        array[0] = \u640b\u5ce9\u4f83\u6f8c\u6308\u6367\u596e\u5a9c\u5b40\u68a6\u5387\u5057\u6979\u582f\u5a64\u6166\u5477\u6f4e\u552d\u6274\u584f\u6753\u556e\u53f7\u65c2\u5aec\u5804\u5aa5\u6bef\u6e4c\u6068\u5eb2\u4edb\u642a\u593d\u56f8\u6f95\u6611\u62ab\u4f00\u705f(1262467887, 2070359271, "\u1e74\u1e7c\u1e4f\u1e4a\u1e40\u1e39\u1e44\u1e38\u1e14\u1a54\u1e47\u1e5e\u1e28\u1e47\u1e46\u1e58\u1a50", 2097675550, 547254521);
        "\u5834\u57e9".length();
        "\u70fd\u631c".length();
        "\u57af".length();
        final int n2 = 1;
        final Object[] array2 = { null };
        "\u711a".length();
        "\u5808".length();
        "\u6062".length();
        "\u5821\u5105".length();
        "\u4f0d".length();
        array2[0] = player2.getName();
        array[n2] = StyleUtils.gold(array2);
        final Inventory inventory = Bukkit.createInventory((InventoryHolder)player, n, StyleUtils.darkGray(array));
        final ItemStack[] contents = player2.getInventory().getContents();
        final ItemStack[] armorContents = player2.getInventory().getArmorContents();
        for (int i = 0; i < contents.length; i += 10578, i -= 10577) {
            inventory.setItem(i, contents[i]);
        }
        for (int j = 36; j < 40; j += 706, j -= 705) {
            final Inventory inventory2 = inventory;
            final int n3 = j;
            final ItemStack[] array3 = armorContents;
            final int n4 = j;
            final int n5 = 36;
            "\u6691".length();
            "\u6232\u5140\u5364\u5192\u620c".length();
            inventory2.setItem(n3, array3[n4 - n5]);
        }
        player.openInventory(inventory);
        "\u5bd0\u6298".length();
        "\u59a4\u5a49\u4ff4".length();
    }
    
    public static int ColonialObfuscator_\u5c97\u52be\u631c\u66d3\u6f08\u694e\u5308\u5c95\u63c3\u5004\u65ee\u52e7\u5a38\u59ea\u56f5\u5ad3\u62a5\u5f50\u6703\u6ca4\u517b\u6aae\u57d9\u5428\u6ee5\u67b3\u553e\u52de\u527e\u57fa\u7035\u51a6\u5501\u5ec2\u6f28\u6fe3\u508e\u6560\u6966\u515e\u5133(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
