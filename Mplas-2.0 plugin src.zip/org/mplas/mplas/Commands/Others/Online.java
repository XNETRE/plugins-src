package org.mplas.mplas.Commands.Others;

import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;
import java.util.*;

public class Online implements CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        final Player player = (Player)commandSender;
        if (commandSender.hasPermission(\u5615\u5924\u5760\u68a4\u5e4d\u51ea\u5f0c\u4f13\u7128\u7073\u6e87\u5b00\u5fa8\u5f0c\u5ec6\u4edb\u64d8\u50dd\u6312\u514d\u4f97\u5a55\u5992\u6dcd\u6614\u5aed\u5c92\u6f86\u4e94\u634a\u5103\u6f30\u6801\u6ada\u5059\u55f7\u6750\u5336\u6c19\u5efc\u65c6(-2121179927, 2041671195, "\ua061\ua053\ua04d\ua05c\ua04e\ua017\ua051\ua05e\ua075\ua05f\ua05d", 993709005, 1818974576)) && !commandSender.hasPermission(\u5615\u5924\u5760\u68a4\u5e4d\u51ea\u5f0c\u4f13\u7128\u7073\u6e87\u5b00\u5fa8\u5f0c\u5ec6\u4edb\u64d8\u50dd\u6312\u514d\u4f97\u5a55\u5992\u6dcd\u6614\u5aed\u5c92\u6f86\u4e94\u634a\u5103\u6f30\u6801\u6ada\u5059\u55f7\u6750\u5336\u6c19\u5efc\u65c6(-706700497, -603146895, "\u0c9f\u0caf\u0cb3\u0cbc\u0ca8\u0cf3\u0cb9\u0cb4\u0c9a\u0cb3\u0cb3\u0caa", -1999775024, -123668417))) {
            final Object[] array2 = new Object[2];
            "\u6b2e\u5867\u6151\u4ecf".length();
            "\u58df".length();
            array2[0] = \u5615\u5924\u5760\u68a4\u5e4d\u51ea\u5f0c\u4f13\u7128\u7073\u6e87\u5b00\u5fa8\u5f0c\u5ec6\u4edb\u64d8\u50dd\u6312\u514d\u4f97\u5a55\u5992\u6dcd\u6614\u5aed\u5c92\u6f86\u4e94\u634a\u5103\u6f30\u6801\u6ada\u5059\u55f7\u6750\u5336\u6c19\u5efc\u65c6(738154752, -339416234, "\uaa18\uae36\uaa24\uaa24\uaa5b\uae3c\uaa2a\uaa2e\uaa7d\uae33\uaa2b\uaa46\uaa0f\uaa1c", 1608440340, -2062563782);
            "\u6431\u6c52\u5a5a\u542c".length();
            "\u4e98\u5f43\u576d\u5e8a\u7054".length();
            "\u5a70".length();
            "\u6ceb\u61ab".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u6503\u5c65\u6c07".length();
            "\u6ddf\u6c6b".length();
            "\u6f65".length();
            "\u576b\u60e2\u5424\u5a3b".length();
            array3[0] = \u5615\u5924\u5760\u68a4\u5e4d\u51ea\u5f0c\u4f13\u7128\u7073\u6e87\u5b00\u5fa8\u5f0c\u5ec6\u4edb\u64d8\u50dd\u6312\u514d\u4f97\u5a55\u5992\u6dcd\u6614\u5aed\u5c92\u6f86\u4e94\u634a\u5103\u6f30\u6801\u6ada\u5059\u55f7\u6750\u5336\u6c19\u5efc\u65c6(-431999954, 1513746270, "\ud681", -818299134, 2072949393);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (command.getName().equalsIgnoreCase(\u5615\u5924\u5760\u68a4\u5e4d\u51ea\u5f0c\u4f13\u7128\u7073\u6e87\u5b00\u5fa8\u5f0c\u5ec6\u4edb\u64d8\u50dd\u6312\u514d\u4f97\u5a55\u5992\u6dcd\u6614\u5aed\u5c92\u6f86\u4e94\u634a\u5103\u6f30\u6801\u6ada\u5059\u55f7\u6750\u5336\u6c19\u5efc\u65c6(839505022, -973222881, "\u4f3c\u4f10\u4f16\u4f11\u4f14\u4f19", -489411630, 433028259))) {
            this.showOnlinePlayers(player);
            return true;
        }
        return false;
    }
    
    public void showOnlinePlayers(final Player player) {
        final int size = Bukkit.getServer().getOnlinePlayers().size();
        "\u6b41\u61ae\u66d6\u509a\u6932".length();
        "\u6501\u561b\u6adb\u67b3\u599c".length();
        final StringBuilder sb = new StringBuilder();
        for (final Player player2 : Bukkit.getServer().getOnlinePlayers()) {
            if (sb.length() > 0) {
                final StringBuilder sb2 = sb;
                final Object[] array = new Object[2];
                "\u5a8d\u5667\u6bee\u62cb\u6f68".length();
                "\u65dc\u5135".length();
                "\u5251\u61e0\u6155\u6748\u57ec".length();
                array[0] = \u5615\u5924\u5760\u68a4\u5e4d\u51ea\u5f0c\u4f13\u7128\u7073\u6e87\u5b00\u5fa8\u5f0c\u5ec6\u4edb\u64d8\u50dd\u6312\u514d\u4f97\u5a55\u5992\u6dcd\u6614\u5aed\u5c92\u6f86\u4e94\u634a\u5103\u6f30\u6801\u6ada\u5059\u55f7\u6750\u5336\u6c19\u5efc\u65c6(-941177432, -1501596045, "\ua66b\ua64a", -1705184872, 441181255);
                "\u5437\u5b6a".length();
                "\u605b".length();
                "\u618b\u64b8\u661b\u56ba\u6f5a".length();
                array[1] = StyleUtils.gold(new Object[0]);
                sb2.append(StyleUtils.gray(array));
                "\u6ae9\u5fb1".length();
                "\u5be5\u6319\u6ec5\u6f8f\u5781".length();
                "\u5431\u51a6\u4e49\u684a".length();
            }
            sb.append(player2.getName());
            "\u6f52\u552e".length();
            "\u64e2\u5d9b\u6b05".length();
        }
        final Object[] array2 = new Object[2];
        "\u5195\u705f\u565d".length();
        "\u6bad\u4f4d\u555f\u5e9e\u6789".length();
        "\u5552".length();
        "\u54c1\u705d\u6de5\u6766".length();
        array2[0] = \u5615\u5924\u5760\u68a4\u5e4d\u51ea\u5f0c\u4f13\u7128\u7073\u6e87\u5b00\u5fa8\u5f0c\u5ec6\u4edb\u64d8\u50dd\u6312\u514d\u4f97\u5a55\u5992\u6dcd\u6614\u5aed\u5c92\u6f86\u4e94\u634a\u5103\u6f30\u6801\u6ada\u5059\u55f7\u6750\u5336\u6c19\u5efc\u65c6(2000028428, -1979380882, "\u87c8\u87ce\u87bd\u87c1\u87c3\u87c7\u83d4\u87c6\u87f9\u87d3\u87df\u87c4\u87c1\u83cd\u83c4", 1106878024, -1837165127);
        "\u6be4\u5698".length();
        "\u5f8b\u670d\u6fb2\u5781\u5d5b".length();
        "\u67f6\u6344\u4e57\u5699".length();
        "\u5ba3\u70cf\u51be\u5e86".length();
        final int n = 1;
        final Object[] array3 = new Object[2];
        "\u4f8e".length();
        "\u6c5e\u50ba\u6478\u5bed\u7079".length();
        "\u535f\u5171\u6643".length();
        array3[0] = size;
        "\u5e79\u702b\u6dc2".length();
        "\u6637\u59ed".length();
        "\u5fac\u63cb".length();
        final int n2 = 1;
        final Object[] array4 = new Object[2];
        "\u53de".length();
        "\u584b\u5c5e\u6226".length();
        "\u5beb\u5a4f\u602b".length();
        array4[0] = \u5615\u5924\u5760\u68a4\u5e4d\u51ea\u5f0c\u4f13\u7128\u7073\u6e87\u5b00\u5fa8\u5f0c\u5ec6\u4edb\u64d8\u50dd\u6312\u514d\u4f97\u5a55\u5992\u6dcd\u6614\u5aed\u5c92\u6f86\u4e94\u634a\u5103\u6f30\u6801\u6ada\u5059\u55f7\u6750\u5336\u6c19\u5efc\u65c6(-1279793400, -691262643, "\uabed\uabd5\uabcd", -1028121301, -649954583);
        "\u6c85\u6852\u6e24\u57e4".length();
        "\u59da\u5620\u61ad".length();
        final int n3 = 1;
        final Object[] array5 = { null };
        "\u69b4\u680c\u579a\u60bb".length();
        "\u589a\u60c8\u6130".length();
        "\u60d6\u5fbc\u5a54\u5f28".length();
        "\u6d19\u6405".length();
        "\u6e14\u6b72\u5bc6\u6ff5\u6de1".length();
        array5[0] = sb.toString();
        array4[n3] = StyleUtils.gold(array5);
        array3[n2] = StyleUtils.gray(array4);
        array2[n] = StyleUtils.gold(array3);
        player.sendMessage(StyleUtils.gray(array2));
    }
    
    public static int ColonialObfuscator_\u6896\u6362\u662d\u6b73\u613d\u684d\u5bae\u6b0f\u69ba\u5241\u60c7\u5121\u6372\u5085\u50d7\u6229\u6207\u5ab2\u65c1\u5c7b\u6cc4\u70c2\u5ae8\u69c0\u69f5\u656b\u6944\u59d0\u5ea5\u6450\u50d0\u4e73\u6184\u708e\u609f\u4f1b\u62c6\u5ec1\u6f99\u6bc4\u6157(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
