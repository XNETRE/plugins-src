package org.mplas.mplas.Commands.Warp;

import org.mplas.mplas.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;
import org.bukkit.*;

public class Warp implements CommandExecutor
{
    public Warp(final Mplas plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] elements) {
        if (elements.length == 0) {
            final Object[] array = new Object[2];
            "\u522b\u694f\u6fe1".length();
            "\u6160\u6a3d\u62e0\u67c4\u6b69".length();
            "\u685e\u5c3b\u5b95\u5797".length();
            "\u6dea\u55ef\u6da7\u5366\u508e".length();
            array[0] = \u6056\u58e9\u5e60\u55f7\u63f1\u6b51\u56a0\u6483\u576e\u62c2\u67b4\u6187\u5878\u6e42\u5191\u5f7f\u648d\u5d34\u6dd8\u589d\u691b\u6812\u6632\u525e\u62a3\u56b3\u6fa5\u5937\u7144\u59e4\u6c36\u5177\u67f5\u551b\u53aa\u5a72\u5223\u69cc\u63b2\u599e\u5c09(1817143245, 1974196831, "\u5949\u593a\u593f\u593e\u5932\u5948\u5936\u5d2d\u5912\u593d\u593f\u592a\u592f\u5935\u5933\u5928\u5d27\u5937\u5919\u3289\u09a6\u0a28", 105384383, 1126820149);
            "\u62df\u6580\u58b1".length();
            final int n = 1;
            final Object[] array2 = new Object[2];
            "\u623d\u5639\u5678\u4ecd\u54df".length();
            "\u5f4a".length();
            array2[0] = \u6056\u58e9\u5e60\u55f7\u63f1\u6b51\u56a0\u6483\u576e\u62c2\u67b4\u6187\u5878\u6e42\u5191\u5f7f\u648d\u5d34\u6dd8\u589d\u691b\u6812\u6632\u525e\u62a3\u56b3\u6fa5\u5937\u7144\u59e4\u6c36\u5177\u67f5\u551b\u53aa\u5a72\u5223\u69cc\u63b2\u599e\u5c09(1721735252, -1756146686, "\u971e\u97c1", -839243649, -2126548136);
            "\u5d5a\u6084\u6c99".length();
            final int n2 = 1;
            final Object[] array3 = new Object[2];
            "\u50fe\u50b6\u5435\u5df5\u6587".length();
            "\u6d44\u6d68\u5ac2\u4ebb\u705c".length();
            "\u63f1\u701f\u6baa\u58ea\u7133".length();
            "\u6955".length();
            array3[0] = \u6056\u58e9\u5e60\u55f7\u63f1\u6b51\u56a0\u6483\u576e\u62c2\u67b4\u6187\u5878\u6e42\u5191\u5f7f\u648d\u5d34\u6dd8\u589d\u691b\u6812\u6632\u525e\u62a3\u56b3\u6fa5\u5937\u7144\u59e4\u6c36\u5177\u67f5\u551b\u53aa\u5a72\u5223\u69cc\u63b2\u599e\u5c09(804451679, -84655642, "\u9813\u983d\u9c2f\u9835\u9831\u984d\u9838\u9848\u9814\u982d\u9c3d\u9848\u9834\u985f\u9826\u984a\u9827\u9c20\u986e\uf3f9\uc8a7\ucb28\uccad\uff96\uc1b0\uf1d8\uf32d\ud7f9\uc56b\uf6b1\uc2d2\uf92b\ucaa7\ucecf\ufd9b", 1617782279, -892711213);
            "\u6bc9".length();
            "\u4fe6".length();
            "\u5781\u5848".length();
            final int n3 = 1;
            final Object[] array4 = { null };
            "\u7144\u6884\u6914".length();
            "\u6cab\u5d74\u4ffb".length();
            array4[0] = \u6056\u58e9\u5e60\u55f7\u63f1\u6b51\u56a0\u6483\u576e\u62c2\u67b4\u6187\u5878\u6e42\u5191\u5f7f\u648d\u5d34\u6dd8\u589d\u691b\u6812\u6632\u525e\u62a3\u56b3\u6fa5\u5937\u7144\u59e4\u6c36\u5177\u67f5\u551b\u53aa\u5a72\u5223\u69cc\u63b2\u599e\u5c09(-1672644034, 299884470, "\u76ff", 1995400353, -1422346316);
            array3[n3] = StyleUtils.gray(array4);
            array2[n2] = StyleUtils.red(array3);
            array[n] = StyleUtils.gray(array2);
            commandSender.sendMessage(StyleUtils.red(array));
            return false;
        }
        if (commandSender instanceof Player) {
            final Player player = (Player)commandSender;
            final String join = String.join(\u6056\u58e9\u5e60\u55f7\u63f1\u6b51\u56a0\u6483\u576e\u62c2\u67b4\u6187\u5878\u6e42\u5191\u5f7f\u648d\u5d34\u6dd8\u589d\u691b\u6812\u6632\u525e\u62a3\u56b3\u6fa5\u5937\u7144\u59e4\u6c36\u5177\u67f5\u551b\u53aa\u5a72\u5223\u69cc\u63b2\u599e\u5c09(122202903, 540176484, "\ud265", 1565974847, 982968394), (CharSequence[])elements);
            final Location location = this.plugin.getWarpLog().getLocation(join);
            if (location != null) {
                player.teleport(location);
                "\u681b\u4fd4\u56da\u50d1\u5443".length();
                final Player player2 = player;
                final Object[] array5 = new Object[2];
                "\u6733\u5bc2\u515f\u6906\u58b4".length();
                "\u524a\u4e73\u5fd7\u6551".length();
                array5[0] = \u6056\u58e9\u5e60\u55f7\u63f1\u6b51\u56a0\u6483\u576e\u62c2\u67b4\u6187\u5878\u6e42\u5191\u5f7f\u648d\u5d34\u6dd8\u589d\u691b\u6812\u6632\u525e\u62a3\u56b3\u6fa5\u5937\u7144\u59e4\u6c36\u5177\u67f5\u551b\u53aa\u5a72\u5223\u69cc\u63b2\u599e\u5c09(-499345598, 1056836815, "\u04d0\u04a4\u00cb\u04aa\u04aa\u04d2\u04cf\u04be\u04eb\u04c4\u00d9\u04a9\u04db\u04c4\u04c7\u04d9\u04c0\u04a2\u048a\u6f12\u5438\u57c1\u507c\u6346\u5d17\u6d40\u6fb0\u4b13\u5d91\u6a5c\u5e3e\u61a7\u5635\u525c\u6170\u5795\u6675\u5269", -73957430, 785179846);
                "\u5ebe\u602e".length();
                "\u5d7e\u5a95".length();
                "\u523a\u56a8\u5e9e\u5f94".length();
                "\u587e".length();
                final int n4 = 1;
                final Object[] array6 = new Object[2];
                "\u4fc4".length();
                "\u6a00".length();
                array6[0] = join;
                "\u6198\u6b89\u4fbc".length();
                "\u6d35\u6cd4\u50a9".length();
                final int n5 = 1;
                final Object[] array7 = { null };
                "\u710b\u4efb\u5777\u5527\u6677".length();
                array7[0] = \u6056\u58e9\u5e60\u55f7\u63f1\u6b51\u56a0\u6483\u576e\u62c2\u67b4\u6187\u5878\u6e42\u5191\u5f7f\u648d\u5d34\u6dd8\u589d\u691b\u6812\u6632\u525e\u62a3\u56b3\u6fa5\u5937\u7144\u59e4\u6c36\u5177\u67f5\u551b\u53aa\u5a72\u5223\u69cc\u63b2\u599e\u5c09(1542722054, 1503164065, "\ue641", 1788502712, 108847164);
                array6[n5] = StyleUtils.gray(array7);
                array5[n4] = StyleUtils.gold(array6);
                player2.sendMessage(StyleUtils.gray(array5));
            }
            else {
                final Player player3 = player;
                final Object[] array8 = new Object[3];
                "\u63de\u5779".length();
                "\u5e81\u521c".length();
                array8[0] = \u6056\u58e9\u5e60\u55f7\u63f1\u6b51\u56a0\u6483\u576e\u62c2\u67b4\u6187\u5878\u6e42\u5191\u5f7f\u648d\u5d34\u6dd8\u589d\u691b\u6812\u6632\u525e\u62a3\u56b3\u6fa5\u5937\u7144\u59e4\u6c36\u5177\u67f5\u551b\u53aa\u5a72\u5223\u69cc\u63b2\u599e\u5c09(723541767, -156659396, "\u93e5\u93f4\u9386\u93f9\u97e6", -1235899505, -2054884864);
                "\u6659\u615e\u505d\u6f42".length();
                "\u682c\u54e3\u683c\u5653".length();
                final int n6 = 1;
                final Object[] array9 = { null };
                "\u52fd\u617a\u545f\u6a8c\u5ff4".length();
                "\u6b91\u54e8\u6e23\u70a7".length();
                array9[0] = join;
                array8[n6] = StyleUtils.gold(array9);
                "\u60d2\u575c\u5434\u61a4\u6763".length();
                "\u5b9f\u5637".length();
                "\u6aef".length();
                final int n7 = 2;
                final Object[] array10 = { null };
                "\u60ed\u69cc\u635a\u6fb0".length();
                "\u68b7\u58fc\u4e4f".length();
                "\u6a98\u595d\u514b\u70cd\u4e30".length();
                array10[0] = \u6056\u58e9\u5e60\u55f7\u63f1\u6b51\u56a0\u6483\u576e\u62c2\u67b4\u6187\u5878\u6e42\u5191\u5f7f\u648d\u5d34\u6dd8\u589d\u691b\u6812\u6632\u525e\u62a3\u56b3\u6fa5\u5937\u7144\u59e4\u6c36\u5177\u67f5\u551b\u53aa\u5a72\u5223\u69cc\u63b2\u599e\u5c09(1435556425, -1373640700, "\ub8c6\ubcf6\ubcfe\ub8e9\ubcca\ubcc1\ubcc3\ubcc2\ubce7\ubcc3\ub8d8", -1083795044, -176286860);
                array8[n7] = StyleUtils.red(array10);
                player3.sendMessage(StyleUtils.red(array8));
            }
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u5c6b\u6785\u584f\u5fce\u5415\u67f6\u554a\u5d42\u505b\u5ed2\u6694\u6b81\u52cf\u63a8\u6302\u57dd\u61e4\u550b\u6a91\u50de\u5f3e\u53c6\u6b26\u7139\u56a8\u5bca\u5870\u64bf\u59b4\u6ea6\u60c5\u6bd8\u6bc6\u618d\u6063\u4e9f\u4fa6\u56bd\u6950\u591e\u6d4f(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
