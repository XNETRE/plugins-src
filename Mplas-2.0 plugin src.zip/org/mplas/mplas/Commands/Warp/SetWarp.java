package org.mplas.mplas.Commands.Warp;

import org.mplas.mplas.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;

public class SetWarp implements CommandExecutor
{
    public SetWarp(final Mplas plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (array.length == 0) {
            final Object[] array2 = new Object[2];
            "\u535c".length();
            "\u6a1a\u705a\u65ff\u6db1".length();
            "\u5280\u6f56\u5f58\u5db3\u52dd".length();
            "\u67d2\u5f8b\u6304\u68b1".length();
            array2[0] = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03(-1373957619, -1774527258, "\u73e9\u73e4\u73ef\u73ec\u73e2\u739e\u73e6\u77ff\u73c2\u73e3\u731f\u7308\u730f\u7313\u7313\u730a\u7707\u7309\u7329\u2afd\u22b7\u192d", -507494282, 1502345509);
            "\u60b1\u5591\u56a5".length();
            final int n = 1;
            final Object[] array3 = new Object[2];
            "\u69d5\u68e2\u5a89\u6b12".length();
            array3[0] = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03(236869342, -1962579549, "\u44fb\u44d8", -1089337523, 1153662116);
            "\u5dce".length();
            "\u5f10\u7096\u62d5\u66dd".length();
            "\u4ee2".length();
            final int n2 = 1;
            final Object[] array4 = new Object[2];
            "\u54dd\u6436".length();
            "\u6196".length();
            array4[0] = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03(876811192, 2027333305, "\uf0fe\uf0d5\uf0a9\uf0db\uf0a7\uf0df\uf0a8\uf0dc\uf0f5\uf4ce\uf0ae\uf0d9\uf0a2\uf0cb\uf0b2\uf0d7\uf4d8\uf0a7\uf0f4\ua957\ua163\u9af0\u9461\u921c", 555417157, 206028739);
            "\u5aa7".length();
            "\u6791\u5323\u67e7\u6c1e\u4fac".length();
            "\u67a0\u54aa".length();
            final int n3 = 1;
            final Object[] array5 = { null };
            "\u687b\u6d96\u5abd\u68eb".length();
            "\u6b5c\u6bbc\u66a7\u66ba\u5700".length();
            "\u53f0\u558c\u550a".length();
            "\u57d2\u6bc2\u5c0f".length();
            array5[0] = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03(-1639870073, -1984878151, "\u3fcd", 2139388470, 961805735);
            array4[n3] = StyleUtils.gray(array5);
            array3[n2] = StyleUtils.red(array4);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (commandSender instanceof Player) {
            final Player player = (Player)commandSender;
            String \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03 = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03(-1843281790, 1597535368, "", 1155815778, -204407466);
            for (int i = 0; i < array.length; i -= 30913, i += 30914) {
                \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03 = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, String.valueOf(\u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03), array[i]);
            }
            if (player.hasPermission(\u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03(1408202866, 1767795236, "\ue477\ue447\ue45b\ue454\ue4b8\ue4e3\ue4b5\ue4af\ue49a\ue4b5\ue4a4\ue4a5\ue4ae", 1627480700, -1347382157))) {
                this.plugin.getWarpLog().set(\u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03, (Object)player.getLocation());
                this.plugin.saveWarpLog();
                final Player player2 = player;
                final Object[] array6 = new Object[2];
                "\u4fe9\u6e6f".length();
                "\u527f".length();
                array6[0] = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03(-832511778, 2005210695, "\u536e\u531a\u5771\u5310\u530c\u5374\u5375\u5304\u5355\u537a\u5763\u536e\u5366\u5308\u530a\u536c\u5372\u5364\u5349\u0aee\u06ff\u3978\u379b\u319e\u1c6e\u05d8\u0521", 727971340, 1480677290);
                "\u645d\u60fb".length();
                final int n4 = 1;
                final Object[] array7 = new Object[2];
                "\u7018\u6c10\u6a6a\u5ab2".length();
                "\u65d6\u629c\u54ea".length();
                "\u4e78".length();
                array7[0] = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03;
                "\u59bd\u6207\u6f4c".length();
                final int n5 = 1;
                final Object[] array8 = { null };
                "\u53c8\u60ad\u4fd7\u67c2\u6679".length();
                "\u6fa7\u647a\u703b\u4e60".length();
                "\u6879\u6aaa\u6d38".length();
                array8[0] = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03(-967476566, 323129752, "\u8110", -982245172, 902580876);
                array7[n5] = StyleUtils.gray(array8);
                array6[n4] = StyleUtils.gold(array7);
                player2.sendMessage(StyleUtils.gray(array6));
            }
            else {
                final Player player3 = player;
                final Object[] array9 = new Object[2];
                "\u58b4".length();
                "\u5c79".length();
                "\u6757\u6c50\u6555\u53d6".length();
                "\u7138".length();
                array9[0] = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03(476994907, 1513787590, "\ua190\ua1e4\ua58b\ua194\ua19e\ua58d\ua1eb\ua19a\ua1b8\ua199\ua192\ua183\ua59e\ua1ec\ua193\ua184\ua1ee\ua1ff\ua1d6\uf87e\uf041\ucbae\uc54d\uc754\ueecd\uf37c\uf3eb\ucba0\uf96c\uf033", -1409175118, 50584046);
                "\u51a3\u6722\u66c5\u66ee".length();
                "\u5f28\u6430\u6451".length();
                "\u60af\u5a8e\u6dc9".length();
                "\u682b\u51c0\u54f7\u6844".length();
                final int n6 = 1;
                final Object[] array10 = new Object[2];
                "\u70dd\u5902".length();
                "\u6086\u5743".length();
                "\u6d0f\u6f14".length();
                "\u56fe\u559c\u6c82\u6596".length();
                array10[0] = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03;
                "\u686a\u6730".length();
                final int n7 = 1;
                final Object[] array11 = { null };
                "\u6bb9\u4f4c\u6c2f\u522e\u7087".length();
                "\u5b02\u4e22\u5d92\u6af4".length();
                "\u6c4b\u5ce2\u6fe2".length();
                "\u5c59\u5d31\u5275\u6242\u6ad1".length();
                array11[0] = \u5f00\u6c4c\u5b67\u515e\u63a8\u5828\u6114\u54a9\u5996\u51c5\u53d4\u53eb\u5826\u5cfe\u5d08\u4f7a\u6a63\u586b\u58ca\u5ff2\u616c\u5078\u67e7\u59c0\u5e5c\u64b2\u5f53\u5961\u6703\u6d9d\u5f8b\u6680\u6d0a\u5266\u6687\u4eca\u5157\u6167\u5bd3\u62cb\u6f03(1211597111, -553030293, "\u2180", -676263380, -1152202862);
                array10[n7] = StyleUtils.gray(array11);
                array9[n6] = StyleUtils.gold(array10);
                player3.sendMessage(StyleUtils.red(array9));
            }
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u700e\u553e\u54c9\u57eb\u601d\u6ab8\u5f13\u6bd0\u55f3\u7046\u6a02\u4f94\u7079\u5724\u5adb\u50d6\u515c\u5645\u60a2\u6ebd\u50d5\u6634\u5a5b\u562a\u4f31\u5b42\u5bd6\u5c44\u6f33\u6675\u5071\u6f15\u4fdf\u5781\u60b6\u50c2\u5f29\u634e\u5075\u5e22\u56b5(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
