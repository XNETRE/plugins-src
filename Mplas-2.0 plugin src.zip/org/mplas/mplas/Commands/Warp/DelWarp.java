package org.mplas.mplas.Commands.Warp;

import org.mplas.mplas.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.entity.*;

public class DelWarp implements CommandExecutor
{
    public DelWarp(final Mplas plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (array.length == 0) {
            final Object[] array2 = new Object[2];
            "\u6168\u50ed\u7014".length();
            "\u5a82\u5b0e".length();
            "\u6a22\u65b1\u5b15\u5b8a\u578d".length();
            "\u6194".length();
            "\u4ef2".length();
            array2[0] = \u649d\u5b87\u5ccc\u635d\u635d\u68b6\u6522\u68fa\u582c\u5258\u6b37\u6eb8\u6e69\u5531\u68ba\u5527\u6866\u662c\u6dca\u601b\u614d\u6046\u5f8c\u5283\u5279\u56af\u5ee7\u5ef2\u6db7\u5b7b\u67c7\u5549\u6149\u5752\u53b5\u6156\u51e5\u6377\u5b41\u50b6\u52db(675328903, -120856641, "\u08a9\u08a4\u08af\u08ac\u08a2\u08de\u08a6\u0cbf\u0882\u08a3\u095f\u0948\u094f\u0953\u0953\u094a\u0d47\u0949\u0969\u5c8a\u6925\u6e31\u50b9\u57d6\u511f\u5e1c\u425e\u6e1b\u50e9\u6e50\u5184\u59ed\u648e\u6d0f\u68c9", 450673910, -153363402);
            "\u5d39\u64ed".length();
            "\u6a9e".length();
            "\u5cdf".length();
            final int n = 1;
            final Object[] array3 = { null };
            "\u5907\u67e8\u6dfb".length();
            "\u6bf8\u69e4\u6d0f".length();
            "\u68bf".length();
            array3[0] = \u649d\u5b87\u5ccc\u635d\u635d\u68b6\u6522\u68fa\u582c\u5258\u6b37\u6eb8\u6e69\u5531\u68ba\u5527\u6866\u662c\u6dca\u601b\u614d\u6046\u5f8c\u5283\u5279\u56af\u5ee7\u5ef2\u6db7\u5b7b\u67c7\u5549\u6149\u5752\u53b5\u6156\u51e5\u6377\u5b41\u50b6\u52db(1108653579, -1942059338, "\uc644", -2026240355, 148697094);
            array2[n] = StyleUtils.gray(array3);
            commandSender.sendMessage(StyleUtils.red(array2));
            return false;
        }
        if (commandSender instanceof Player) {
            final Player player = (Player)commandSender;
            final String s2 = array[0];
            if (player.hasPermission(\u649d\u5b87\u5ccc\u635d\u635d\u68b6\u6522\u68fa\u582c\u5258\u6b37\u6eb8\u6e69\u5531\u68ba\u5527\u6866\u662c\u6dca\u601b\u614d\u6046\u5f8c\u5283\u5279\u56af\u5ee7\u5ef2\u6db7\u5b7b\u67c7\u5549\u6149\u5752\u53b5\u6156\u51e5\u6377\u5b41\u50b6\u52db(1193818880, -692337410, "\uf902\uf932\uf92e\uf921\uf92d\uf976\uf937\uf93a\uf917\uf920\uf931\uf930\uf93b", -750170580, -532854530))) {
                if (this.plugin.getWarpLog().contains(s2)) {
                    this.plugin.getWarpLog().set(s2, (Object)null);
                    this.plugin.saveWarpLog();
                    final Player player2 = player;
                    final Object[] array4 = new Object[2];
                    "\u67ef\u5a71".length();
                    "\u5358\u6708\u5689\u6b68".length();
                    "\u6ef2\u6ef3\u6f36".length();
                    array4[0] = \u649d\u5b87\u5ccc\u635d\u635d\u68b6\u6522\u68fa\u582c\u5258\u6b37\u6eb8\u6e69\u5531\u68ba\u5527\u6866\u662c\u6dca\u601b\u614d\u6046\u5f8c\u5283\u5279\u56af\u5ee7\u5ef2\u6db7\u5b7b\u67c7\u5549\u6149\u5752\u53b5\u6156\u51e5\u6377\u5b41\u50b6\u52db(-585190232, 467664320, "\u2121\u2155\u253e\u215f\u2163\u211b\u211a\u216b\u213a\u2115\u250c\u217d\u2103\u2116\u211c\u210b\u2114\u210b\u253d\u74bc\u4172\u4619\u7cfa\u7b84\u7d5c", 733577500, 152235268);
                    "\u6bf2\u5eab\u61f3\u5ceb\u64ed".length();
                    "\u5690\u56e5\u5d89\u6b33".length();
                    final int n2 = 1;
                    final Object[] array5 = new Object[2];
                    "\u58fc\u5c58\u6ef0".length();
                    "\u6070\u6a73\u4eba\u6d0d".length();
                    "\u5c57\u5cd3".length();
                    array5[0] = s2;
                    "\u5c86\u6627\u6bc1\u5271\u6c63".length();
                    final int n3 = 1;
                    final Object[] array6 = { null };
                    "\u5d7b\u560d\u5424".length();
                    "\u691d\u5d84\u65c2\u57a7\u5ace".length();
                    array6[0] = \u649d\u5b87\u5ccc\u635d\u635d\u68b6\u6522\u68fa\u582c\u5258\u6b37\u6eb8\u6e69\u5531\u68ba\u5527\u6866\u662c\u6dca\u601b\u614d\u6046\u5f8c\u5283\u5279\u56af\u5ee7\u5ef2\u6db7\u5b7b\u67c7\u5549\u6149\u5752\u53b5\u6156\u51e5\u6377\u5b41\u50b6\u52db(78658390, -1785351370, "\uac4d", 1636524445, 1283343826);
                    array5[n3] = StyleUtils.gray(array6);
                    array4[n2] = StyleUtils.gold(array5);
                    player2.sendMessage(StyleUtils.gray(array4));
                }
                else {
                    final Player player3 = player;
                    final Object[] array7 = new Object[2];
                    "\u5129".length();
                    "\u5095\u63af\u6f64".length();
                    "\u61a3".length();
                    array7[0] = \u649d\u5b87\u5ccc\u635d\u635d\u68b6\u6522\u68fa\u582c\u5258\u6b37\u6eb8\u6e69\u5531\u68ba\u5527\u6866\u662c\u6dca\u601b\u614d\u6046\u5f8c\u5283\u5279\u56af\u5ee7\u5ef2\u6db7\u5b7b\u67c7\u5549\u6149\u5752\u53b5\u6156\u51e5\u6377\u5b41\u50b6\u52db(-1150134546, 1158093212, "\u9fdf\u9fd2\u9fa0\u9fd3\u9bcc\u9fa9\u9bc1\u9fd6\u9ff9\u9fd0\u9fd0\u9fbe\u9fb4\u9fa2\u9fac\u9fb7\u9bb1", 1296023093, -2052625719);
                    "\u6646\u6de5\u577b".length();
                    "\u6e06".length();
                    "\u50c3\u5b84\u600c\u6c57".length();
                    final int n4 = 1;
                    final Object[] array8 = new Object[2];
                    "\u6e29\u5470\u703b".length();
                    "\u6f60\u52fb".length();
                    "\u54ba\u5c09\u5f7a".length();
                    array8[0] = s2;
                    "\u7078\u64e4".length();
                    final int n5 = 1;
                    final Object[] array9 = { null };
                    "\u5156\u70ff\u4edd".length();
                    "\u68d3\u6030\u7063\u5299\u5097".length();
                    array9[0] = \u649d\u5b87\u5ccc\u635d\u635d\u68b6\u6522\u68fa\u582c\u5258\u6b37\u6eb8\u6e69\u5531\u68ba\u5527\u6866\u662c\u6dca\u601b\u614d\u6046\u5f8c\u5283\u5279\u56af\u5ee7\u5ef2\u6db7\u5b7b\u67c7\u5549\u6149\u5752\u53b5\u6156\u51e5\u6377\u5b41\u50b6\u52db(-162743781, -165890200, "", -2147397047, -151751891);
                    array8[n5] = StyleUtils.red(array9);
                    array7[n4] = invokedynamic(makeConcatWithConstants:(Lnet/kyori/adventure/text/Component;)Ljava/lang/String;, StyleUtils.gold(array8));
                    player3.sendMessage(StyleUtils.red(array7));
                }
            }
            else {
                final Player player4 = player;
                final Object[] array10 = { null };
                "\u5792\u64b5\u58c7\u6043".length();
                "\u512b\u6213".length();
                array10[0] = \u649d\u5b87\u5ccc\u635d\u635d\u68b6\u6522\u68fa\u582c\u5258\u6b37\u6eb8\u6e69\u5531\u68ba\u5527\u6866\u662c\u6dca\u601b\u614d\u6046\u5f8c\u5283\u5279\u56af\u5ee7\u5ef2\u6db7\u5b7b\u67c7\u5549\u6149\u5752\u53b5\u6156\u51e5\u6377\u5b41\u50b6\u52db(-1985005209, -886487250, "\ud7dd\ud3f1\ud7e1\ud7e7\ud796\ud3f3\ud7e7\ud7fd\ud7a8\ud3e4\ud7fe\ud795\ud7e2\ud7f3\ud3e2\ud7ec\ud7f9\ud793\ud3d0\u8226\ub783\ub09e\u8a0b\u8900\u8fcc\u80bc\u98f8\ub4b7\u8e22\ub09f\u8f36\u8720\uba48\ub3c2", 504118569, -1875668771);
                player4.sendMessage(StyleUtils.red(array10));
            }
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u547d\u6de4\u558d\u58ee\u66a1\u705a\u6f50\u6ed0\u5d35\u62fb\u6876\u675e\u5f8d\u5f23\u5e5d\u627a\u6ebe\u4f3a\u6376\u5937\u6725\u7011\u696d\u6e16\u5ce5\u5d61\u6d42\u6c02\u6c28\u6169\u51e1\u598d\u60a3\u5f9c\u70e3\u6bfe\u5b97\u4f34\u61d9\u67e3\u6953(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
