package org.mplas.mplas.Commands.Weather;

import org.bukkit.event.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;

public class EditWeathers implements Listener, CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (!commandSender.hasPermission(\u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(1155019998, -1077119499, "\ub194\ub1a4\ub1b8\ub1b7\ub1a3\ub1f8\ub1bc\ub1b5\ub190\ub1b8\ub1b8", -301622816, -570005135)) || commandSender.hasPermission(\u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(1344499766, 222792142, "\ua0fe\ua0ce\ua0d2\ua0dd\ua331\ua36a\ua338\ua326\ua306\ua33f\ua324\ua33b\ua325\ua335", -83280388, 90006740))) {
            if (command.getName().equalsIgnoreCase(\u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(188468175, 2100308324, "\u7255\u727e\u7261", -973482974, 1191134444))) {
                if (commandSender instanceof Player) {
                    final Player player = (Player)commandSender;
                    player.getWorld().setWeatherDuration(0);
                    player.getWorld().setThundering(false);
                    player.getWorld().setStorm(false);
                    final Object[] array2 = new Object[2];
                    "\u6310\u5ba1".length();
                    "\u5a6d\u625b\u52b7\u55c8".length();
                    array2[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-2003987079, 1006552552, "\u7f81\u5b4a", 1355900807, 1281649692);
                    "\u4fce\u6125".length();
                    final int n = 1;
                    final Object[] array3 = new Object[2];
                    "\u5a27\u688e\u7050\u534c".length();
                    "\u5268\u5f3a\u60b0\u70e2\u6cac".length();
                    "\u6ead\u6642".length();
                    "\u5086\u5ef6\u54cf\u6959\u513c".length();
                    array3[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(250718819, 973606555, "\ud7c9\ud77f\ud35c\ud37f\ud370\ud37b\ud37e\ud376\ud746\ud309\ud300\ud311\ud366\ud37a\ud37c\ud364\ud375\ud367\ud2bd\ub6b8\ub181\u8d3c\ub53b", 1088561390, 1005540135);
                    "\u6b06".length();
                    final int n2 = 1;
                    final Object[] array4 = new Object[2];
                    "\u61c7".length();
                    array4[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-1993696857, 1372265112, "\u612d\u656f\u6512\u6517\u6511\u6519\u6562\u6516\u654a\u6575", 1897026183, 1335800054);
                    "\u58af".length();
                    "\u5067\u4f59\u667b\u6e47".length();
                    "\u64e6\u6be0\u570c\u4e8e".length();
                    "\u6eea\u6ff6\u5063\u6848".length();
                    final int n3 = 1;
                    final Object[] array5 = { null };
                    "\u6fbf\u6d2a\u6b49".length();
                    array5[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-1268900948, 1195131823, "\ud5a8", -1493353828, -85215403);
                    array4[n3] = StyleUtils.gray(array5);
                    array3[n2] = StyleUtils.gold(array4);
                    array2[n] = StyleUtils.gray(array3);
                    commandSender.sendMessage(StyleUtils.yellow(array2));
                }
                else {
                    final Object[] array6 = new Object[2];
                    "\u62c1\u67cd\u5b9d\u57b3".length();
                    "\u52ac\u55de\u69a5\u5d8d".length();
                    "\u5d7a\u6802\u6cbb\u6446\u6859".length();
                    array6[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(1948576432, -646010635, "\ud0f4\ud0b4\ud0b7\ud4c8\ud0d2\ud0d2\ud0d9\ud0df\ud0f0\ud0d7\ud0a5\ud4da\ud0c1\ud0d0\ud0db\ud0c2\ud0db\ud4db\ud0ef\ub460\ub735\u8f96\ub79f\ub872\ubede\ub4b3\u8e8b\ub689\u8226\u88df\u8adf\u8439\ub8b3\ua079\u8e63\ub42b\ubb34\u8f62\ube5a\ub227\ua083\ub172\u8960\ua06f", 432226925, 623826098);
                    "\u515f\u67ab\u6833\u6174".length();
                    final int n4 = 1;
                    final Object[] array7 = { null };
                    "\u5cdd\u5b73\u5db4\u50a3".length();
                    "\u5f38\u5aed\u5188".length();
                    "\u548c\u58d8\u565d".length();
                    array7[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-1171621147, -987649252, "\u6748", 1712688228, 1695824567);
                    array6[n4] = StyleUtils.gray(array7);
                    commandSender.sendMessage(StyleUtils.red(array6));
                }
            }
            if (command.getName().equalsIgnoreCase(\u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(599921400, -1032267337, "\ueb8d\uebb3\uebbb\uebbe", -1111804552, -1602742901))) {
                if (commandSender instanceof Player) {
                    final Player player2 = (Player)commandSender;
                    player2.getWorld().setWeatherDuration(0);
                    player2.getWorld().setThundering(false);
                    player2.getWorld().setStorm(true);
                    final Object[] array8 = new Object[2];
                    "\u5ade\u6316".length();
                    "\u5a20\u596f".length();
                    array8[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(630367447, 1864236632, "\ud12a\uf5e2", 278705177, -741991624);
                    "\u59c5\u6426".length();
                    final int n5 = 1;
                    final Object[] array9 = new Object[2];
                    "\u6fcd\u5aa0\u58f6\u6dc2".length();
                    "\u597c\u6ec9\u585b".length();
                    "\u6328\u5c67\u5f94\u5658\u5776".length();
                    array9[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-1567111858, 608570100, "\u6f3b\u6f93\u6bae\u6b8f\u6b82\u6b8f\u6b8c\u6b86\u6fb4\u6bf5\u6bf2\u6be1\u6b94\u6b8e\u6b8e\u6b94\u6b87\u6bab\u6b8f\u0f88\u08b3\u3408\u0c09", 1499858767, -1258838218);
                    "\u6db5".length();
                    final int n6 = 1;
                    final Object[] array10 = new Object[2];
                    "\u5831\u679f".length();
                    "\u6a3f\u655d\u5aa2\u5a35".length();
                    "\u5d01\u5b54\u510e".length();
                    array10[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-1628699718, 816986453, "\uf861\ufc56\ufc5e\ufc56\ufc54\ufc5b\ufc51\ufc55\ufc06\ufc19", 1780049303, 852993914);
                    "\u5063\u690d\u6d76".length();
                    final int n7 = 1;
                    final Object[] array11 = { null };
                    "\u65f7\u5ced".length();
                    "\u6905\u62a5\u682e\u69df\u6131".length();
                    array11[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(1986086005, 703920374, "\ub58a", -1712517519, 1809647386);
                    array10[n7] = StyleUtils.gray(array11);
                    array9[n6] = StyleUtils.gold(array10);
                    array8[n5] = StyleUtils.gray(array9);
                    commandSender.sendMessage(StyleUtils.aqua(array8));
                }
                else {
                    final Object[] array12 = new Object[2];
                    "\u5c6e\u584e\u4f6d".length();
                    "\u5433\u5167".length();
                    "\u68a6".length();
                    "\u512b\u58ef".length();
                    array12[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-375307107, -1657514838, "\u44b2\u44f2\u44f1\u409e\u4484\u4484\u448f\u4489\u44a6\u4481\u44f3\u40fc\u44e7\u44f6\u44fd\u44e4\u44fd\u40fd\u44c9\u20b6\u23e3\u1b40\u2349\u2ca4\u2a08\u2065\u1a5d\u224f\u16e0\u1c19\u1e19\u10ff\u2c75\u34bf\u1aa5\u20fd\u2fe2\u1bb4\u2a8c\u26f1\u3455\u25a4\u1db6\u3489", 1798953397, 1551468894);
                    "\u6e8c\u50f8\u6ed6\u65fd".length();
                    "\u4f65\u68e2".length();
                    "\u6ae2".length();
                    final int n8 = 1;
                    final Object[] array13 = { null };
                    "\u6166\u6a21\u50dd".length();
                    "\u62b8\u5987\u66da".length();
                    "\u548b\u59a0\u568e".length();
                    array13[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-45641767, 1642706480, "\u6317", -1228746531, -1465742783);
                    array12[n8] = StyleUtils.gray(array13);
                    commandSender.sendMessage(StyleUtils.red(array12));
                }
            }
            if (command.getName().equalsIgnoreCase(\u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(2119537768, 201383840, "\u1b5e\u1b4a\u1b53\u1b4e\u1b51", 1934191711, -1305002759))) {
                if (commandSender instanceof Player) {
                    final Player player3 = (Player)commandSender;
                    player3.getWorld().setWeatherDuration(1);
                    player3.getLocation().getWorld().setThundering(true);
                    player3.getWorld().setStorm(true);
                    final Object[] array14 = new Object[2];
                    "\u681e\u63f2".length();
                    "\u531a\u5bf7".length();
                    "\u6af3\u5190".length();
                    array14[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-709561329, -561501109, "\u5789\u734e", 1799961937, -1743415785);
                    "\u5f7a\u6e23\u5fc5".length();
                    "\u680f\u556c\u63eb".length();
                    final int n9 = 1;
                    final Object[] array15 = new Object[2];
                    "\u6160\u5b07".length();
                    "\u5bc6\u63e4\u58b5\u6c56\u68e6".length();
                    array15[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-1375249429, -192894348, "\uf6e2\uf654\uf277\uf254\uf25b\uf250\uf255\uf25d\uf66d\uf222\uf22b\uf23a\uf24d\uf251\uf257\uf24f\uf25e\uf24c\uf256\u9653\u916a\uadd7\u95d0", -450625778, -1662060405);
                    "\u615e\u6985\u5a24".length();
                    final int n10 = 1;
                    final Object[] array16 = new Object[2];
                    "\u6172\u619e".length();
                    array16[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(1692685522, -939568954, "\u4f36\u4b71\u4b79\u4b7c\u4b7f\u4b07\u4b0c\u4b02\u4b51\u4b72", -284311871, -1762855552);
                    "\u5dc1\u680b\u63e0\u6631".length();
                    "\u51b8\u5ce9\u69a5\u55e2\u5b9b".length();
                    "\u6846\u68b4\u5dba".length();
                    "\u62ea\u5588\u6869\u6e7f\u5aa8".length();
                    final int n11 = 1;
                    final Object[] array17 = { null };
                    "\u6c8b".length();
                    "\u5680\u506d\u6603\u5fc2\u6c77".length();
                    array17[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-1332294117, 1582938646, "\ud9fd", -1679507238, -1674220216);
                    array16[n11] = StyleUtils.gray(array17);
                    array15[n10] = StyleUtils.gold(array16);
                    array14[n9] = StyleUtils.gray(array15);
                    commandSender.sendMessage(StyleUtils.darkGray(array14));
                }
                else {
                    final Object[] array18 = new Object[2];
                    "\u6305".length();
                    array18[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(1408639206, -2007427573, "\u2881\u28c1\u28c2\u2cad\u28b7\u28b7\u28bc\u28ba\u2895\u28b2\u28c0\u2c8f\u2894\u2885\u288e\u2897\u288e\u2c8e\u28ba\u4cc5\u4f90\u7733\u4f3a\u40d7\u467b\u4c16\u762e\u4e3c\u7a93\u706a\u726a\u7c8c\u4006\u58cc\u76d6\u4c8e\u4391\u77c7\u46ff\u4a82\u5826\u49d7\u71c5\u58ba", -173102699, 1549382551);
                    "\u59a9\u536f\u55bf\u5ad3\u518f".length();
                    "\u6d75".length();
                    "\u5af0\u6fe4\u5088\u56ee".length();
                    final int n12 = 1;
                    final Object[] array19 = { null };
                    "\u63e0\u5e74".length();
                    array19[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-1331273181, 1136023958, "\u0604", 1690179570, 1803233825);
                    array18[n12] = StyleUtils.gray(array19);
                    commandSender.sendMessage(StyleUtils.red(array18));
                }
            }
        }
        else {
            final Object[] array20 = new Object[2];
            "\u53a6".length();
            "\u6759\u5ec4\u5d23".length();
            "\u6e52".length();
            array20[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(-650806701, -1686532614, "\u5a42\u5e6c\u5a62\u5a62\u5a11\u5e76\u5a64\u5a60\u5a37\u5e79\u5a6d\u5a00\u5a75\u5a66", 518419982, -821043323);
            "\u6cce\u53f5\u6869\u5251".length();
            "\u5703\u6e90\u5cde".length();
            "\u6240\u4fc0\u6a31\u5608".length();
            "\u6372\u5e74\u5fd5".length();
            final int n13 = 1;
            final Object[] array21 = { null };
            "\u5e9f\u693a\u6afa".length();
            "\u4e20\u4fd0\u4e79\u6648".length();
            array21[0] = \u5097\u6289\u6a54\u5606\u697f\u5ccb\u5707\u6f22\u54e0\u5a7f\u6958\u5618\u6e0d\u562d\u518d\u4f91\u6138\u7035\u5cf7\u64ed\u591c\u6253\u6e62\u6564\u6a08\u559c\u5e40\u61a8\u6b8b\u5282\u6a0a\u6775\u5dcb\u5846\u6447\u6279\u5f92\u56e2\u555a\u4fc3\u6d0f(630312492, 1787216327, "\u80f9", -329848322, 1958700686);
            array20[n13] = StyleUtils.gray(array21);
            commandSender.sendMessage(StyleUtils.red(array20));
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u6175\u6044\u6ffc\u6a04\u629e\u6bc4\u59b6\u51d8\u6a01\u5ac4\u5b51\u6688\u5afa\u6de7\u6053\u7117\u6f4a\u66a1\u6ddf\u5ffe\u583d\u5c80\u4f34\u5104\u50b5\u56fc\u53d8\u5c1b\u5155\u5e87\u58ce\u5096\u610a\u570f\u5ea6\u64e9\u62be\u609c\u514c\u6fca\u6f86(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
