package org.mplas.mplas.Commands.Times;

import org.bukkit.event.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;

public class EditTimes implements Listener, CommandExecutor
{
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        final Player player = (Player)commandSender;
        if (command.getName().equalsIgnoreCase(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(564332705, -531658093, "\u7a75\u7a5f\u7a51\u7a5c\u7a4e", 1676369028, 413050094)) || command.getName().equalsIgnoreCase(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-198223733, 345113972, "\u56c1\u56e8\u56e5\u56ed\u56ec\u56e4\u56e0\u56f0", 1999702504, 362021624)) || command.getName().equalsIgnoreCase(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(2105693710, -1978990820, "\u4075\u4043\u4059\u404d", 648898144, 321163062)) || command.getName().equalsIgnoreCase(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-1155386959, -355232433, "\u816a\u8142\u815a", -1332352160, 1754713811))) {
            if (command.getName().equalsIgnoreCase(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-498986310, 737172479, "\ue40f\ue425\ue42b\ue426\ue434", 161082436, -2130820829))) {
                if (!commandSender.hasPermission(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-1651322182, 2045715042, "\u33c4\u33f6\u33e8\u33f9\u33eb\u33b2\u33f4\u33fb\u33d0\u33fa\u33f8", -1313632275, -972075809)) || !commandSender.hasPermission(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(660288114, 1852446864, "\ubae5\ubacb\ubad5\ubad8\ubaca\uba97\ubade\ubad7\ubafb\ubad6\ubacf", -1160492273, 2055461670))) {
                    final Player player2 = player;
                    final Object[] array2 = new Object[2];
                    "\u6768\u55f7\u6a94\u6d6d".length();
                    "\u55d7\u6e47\u548b".length();
                    "\u657a\u6d3a\u512d".length();
                    array2[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(331751377, 1623436698, "\u8a55\u8e7d\u8a6d\u8a6f\u8a1e\u8e77\u8a63\u8a65\u8a30\u8e78\u8a62\u8a0d\u8a7a\u8a77", -781297117, -18848163);
                    "\u535a".length();
                    "\u6b43\u6d41\u53be\u5e45\u6e7a".length();
                    "\u630b\u4e94\u5a20\u58a5\u62fc".length();
                    "\u5266\u508a".length();
                    final int n = 1;
                    final Object[] array3 = { null };
                    "\u6a28".length();
                    "\u61d6\u5901".length();
                    "\u6fdd\u61c3".length();
                    array3[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-876383437, -1472197785, "\u0813", -1264458023, -697329924);
                    array2[n] = StyleUtils.gray(array3);
                    player2.sendMessage(StyleUtils.red(array2));
                    return false;
                }
                player.getWorld().setTime(13000L);
                final Player player3 = player;
                final Object[] array4 = new Object[3];
                "\u5243\u612c\u6797\u6b0c\u5a11".length();
                array4[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(1812853663, -1713401973, "\u5103\u5105\u5517\u5176\u5102\u517f\u5104\u510d\u515a\u5105\u5515\u5166\u5163\u5112\u511b\u5170\u511f\u5106\u5534\u36d6\u33fc\u06e9\u3705\u042b\u0471\u0c74\u0d19\u01bc\u3824\u02bd", -566507229, -379330454);
                "\u639f".length();
                "\u52a0\u5194\u5f9d\u68b8\u5dc9".length();
                final int n2 = 1;
                final Object[] array5 = { null };
                "\u577a\u66e5".length();
                "\u5028".length();
                array5[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-1076921923, -146753199, "\u438d\u4783\u4782\u47fb\u47f0", 2082882335, -1221804003);
                array4[n2] = StyleUtils.gold(array5);
                "\u5e45".length();
                final int n3 = 2;
                final Object[] array6 = { null };
                "\u4f70\u6500\u706f\u5f9c".length();
                "\u512a\u5a5c".length();
                "\u683c\u677e\u6f1a".length();
                array6[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(727134780, -1006552522, "\u88f6", 1373883968, -441299234);
                array4[n3] = StyleUtils.gray(array6);
                player3.sendMessage(StyleUtils.gray(array4));
            }
            else if (command.getName().equalsIgnoreCase(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(278007033, 929334981, "\u5090\u50b9\u50b4\u50bc\u50a5\u50ad\u50a9\u50b9", -1953145300, -818838354))) {
                if (!commandSender.hasPermission(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-1653972442, -965464731, "\u0b62\u0b52\u0b42\u0b4d\u0b5d\u0b06\u0b46\u0b4f\u0b66\u0b4e\u0b52", 2098608806, -1521254743)) || !commandSender.hasPermission(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-371105042, -516303454, "\u0af6\u0ac6\u0ada\u0ad5\u0ac1\u0a9a\u0ad2\u0ada\u0a8b\u0aad\u0aad\u0ab1\u0abf\u0ab2", 1958699832, -634003796))) {
                    final Player player4 = player;
                    final Object[] array7 = new Object[2];
                    "\u6863\u6a69\u60ab".length();
                    array7[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(1265741478, 527304850, "\uc1f1\uc5df\uc1cd\uc1cd\uc1a2\uc5c5\uc1d3\uc1d7\uc184\uc5ca\uc1d2\uc1bf\uc1c6\uc1d5", -1759882836, 1158558217);
                    "\u533c\u5763\u5231\u66b7\u6a38".length();
                    "\u6fea\u5b67".length();
                    final int n4 = 1;
                    final Object[] array8 = { null };
                    "\u5f92\u6464\u697f\u5d67".length();
                    "\u6157\u65a4".length();
                    "\u5431\u53c6".length();
                    "\u5b87\u565a\u6008".length();
                    array8[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(65955367, 1999516676, "\u1ce1", -1583417790, 1735964898);
                    array7[n4] = StyleUtils.gray(array8);
                    player4.sendMessage(StyleUtils.red(array7));
                    return false;
                }
                player.getWorld().setTime(18000L);
                final Player player5 = player;
                final Object[] array9 = new Object[3];
                "\u5421\u5e44\u6113\u531b\u6ec4".length();
                "\u65ad".length();
                array9[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(2043218264, 897626527, "\uf36c\uf36c\uf77c\uf31f\uf375\uf306\uf37f\uf374\uf325\uf37c\uf76e\uf31f\uf314\uf37b\uf370\uf319\uf370\uf36f\uf75f\u94bf\u91ab\ua4b0\u955e\ua672\ua62e\uae2d\uaf42\ua3e5\u9a73\ua094", -453493044, -352030407);
                "\u6eff".length();
                "\u6f05\u6355\u6bd2".length();
                "\u6f9c".length();
                "\u711b".length();
                final int n5 = 1;
                final Object[] array10 = { null };
                "\u6cb0\u6227\u51de".length();
                array10[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-1908958134, -1042199044, "\udbd5\udfe7\udfe6\udfe1\udff9\udffc\udf8e\udf89", -628770324, -1372736532);
                array9[n5] = StyleUtils.gold(array10);
                "\u57ea".length();
                final int n6 = 2;
                final Object[] array11 = { null };
                "\u6a53\u708a".length();
                "\u5ac9\u64d6\u50e9\u642d\u6f0d".length();
                "\u5be4\u6251\u6d3f\u59ef\u696b".length();
                array11[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-76040781, -2003821100, "\ud08c", -900908952, 2080456929);
                array9[n6] = StyleUtils.gray(array11);
                player5.sendMessage(StyleUtils.gray(array9));
            }
            else if (command.getName().equalsIgnoreCase(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(1162140357, 1181430360, "\ub1f3\ub1c5\ub1df\ub1cb", -771356276, -1277538093))) {
                if (!commandSender.hasPermission(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(869017867, -861368396, "\ufcc9\ufcf9\ufce9\ufce6\ufcf6\ufcad\ufced\ufce4\ufccd\ufce5\ufcd9", 1212096534, -943424946)) || !commandSender.hasPermission(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(407120281, 451039319, "\ud614\ud624\ud638\ud637\ud623\ud678\ud62f\ud638\ud60e\ud634", 1872397680, -284546428))) {
                    final Player player6 = player;
                    final Object[] array12 = new Object[2];
                    "\u4ffc\u4fc2".length();
                    array12[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-98706434, -1798339625, "\u1ffc\u1bec\u1ffc\u1ffe\u1f8f\u1bee\u1ffa\u1ffc\u1fa9\u1be9\u1ff3\u1f9c\u1feb\u1ffe", -1663107745, 793886442);
                    "\u64ed\u4e34\u63ec\u4fa0\u63b4".length();
                    "\u5375\u66dc\u661f".length();
                    "\u5af9".length();
                    final int n7 = 1;
                    final Object[] array13 = { null };
                    "\u58e5".length();
                    "\u55c7".length();
                    "\u5a42\u6b50".length();
                    "\u58fc\u6fe3\u5c88\u52dc\u5437".length();
                    "\u6256\u6b25\u6995\u6bf9\u6080".length();
                    array13[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-1351819943, -1130511548, "\uc09f", 1573971733, 1981037045);
                    array12[n7] = StyleUtils.gray(array13);
                    player6.sendMessage(StyleUtils.red(array12));
                    return false;
                }
                player.getWorld().setTime(0L);
                final Player player7 = player;
                final Object[] array14 = new Object[3];
                "\u70ac\u63cc\u5915\u5e18".length();
                "\u588e\u578b\u6ea3".length();
                array14[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(1006210620, 189484159, "\uc26d\uc26d\uc671\uc212\uc264\uc217\uc26a\uc261\uc234\uc26d\uc643\uc232\uc235\uc25a\uc255\uc23c\uc251\uc24e\uc672\ua592\ua0ba\u95a1\ua44b\u9767\u973f\u9f3c\u9e4f\u92e8\uab72", 2022101590, -1805658586);
                "\u523d\u7073".length();
                "\u60a4\u5318".length();
                final int n8 = 1;
                final Object[] array15 = { null };
                "\u5bb5".length();
                "\u5163\u665a\u6c88\u6712".length();
                "\u5802\u5212\u5651\u66a6\u5ced".length();
                array15[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-1215312248, -1215130459, "\u607f\u642c\u645e\u642f\u642f\u645c\u6452\u642b", -1033690001, -677306786);
                array14[n8] = StyleUtils.gold(array15);
                "\u596e".length();
                "\u67e4\u7109\u5797".length();
                "\u5d8b\u6373\u5ec9\u648c".length();
                final int n9 = 2;
                final Object[] array16 = { null };
                "\u63de\u5a69\u6d0e\u624d".length();
                array16[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(20267909, -201621700, "\u96ab", 1188114974, 868980846);
                array14[n9] = StyleUtils.gray(array16);
                player7.sendMessage(StyleUtils.gray(array14));
            }
            else if (command.getName().equalsIgnoreCase(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-1136174129, 2113879239, "\uc96d\uc943\uc959", -1738584789, 81126249))) {
                if (!commandSender.hasPermission(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-918890647, -447137700, "\ub1e0\ub1d0\ub1d0\ub1df\ub1cf\ub194\ub1d4\ub1dd\ub1f4\ub1dc\ub1d0", 39081230, 497355765)) || !commandSender.hasPermission(\u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(34748613, -290100384, "\ufaf4\ufac4\ufad8\ufad7\ufafb\ufaa0\ufae1\ufae8\ufad4", -1222503140, -191120285))) {
                    final Player player8 = player;
                    final Object[] array17 = new Object[2];
                    "\u5188\u508b\u688f\u5acc".length();
                    "\u5280\u6e72\u4feb\u5274".length();
                    array17[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(1111493410, 533529350, "\u1f15\u1b3b\u1f2d\u1f2d\u1f5e\u1b39\u1f33\u1f37\u1f60\u1b2e\u1f32\u1f5f\u1f2a\u1f39", 1366747114, -2135362373);
                    "\u585d\u6a4f".length();
                    "\u643f\u59fe\u560c\u5a44".length();
                    final int n10 = 1;
                    final Object[] array18 = { null };
                    "\u65fa\u624b\u6676\u5bdb".length();
                    "\u6651\u52d6\u61b0\u6384\u6554".length();
                    array18[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(-324404698, 136148723, "\ub8ae", 358556061, -1771891324);
                    array17[n10] = StyleUtils.gray(array18);
                    player8.sendMessage(StyleUtils.red(array17));
                    return false;
                }
                player.getWorld().setTime(1000L);
                final Player player9 = player;
                final Object[] array19 = new Object[3];
                "\u5b28\u5495\u67a9\u6a9c\u54a9".length();
                "\u6ac5".length();
                "\u5847\u5d38\u583f\u5ec9\u6d06".length();
                "\u6e73\u5472\u6140".length();
                "\u5742\u5667\u5eb0".length();
                array19[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(2046026653, 1589517669, "\ud9b1\ud9b1\udda1\ud9c2\ud9b0\ud9c3\ud9ba\ud9b1\ud9d8\ud981\udd93\ud9e2\ud9e1\ud98e\ud985\ud9ec\ud98d\ud992\udda2\ube42\ubb6e\u8e75\ubf9b\u8cb7\u8cf3\u84f0\u859f\u8938\ub0a6", -68491048, -204158001);
                "\u6813\u5c8a".length();
                "\u6cb3\u5ed6\u54a2".length();
                "\u56c8\u5800\u5f48".length();
                final int n11 = 1;
                final Object[] array20 = { null };
                "\u4ed1\u5258\u5c0c\u4e4d".length();
                "\u6c88\u62b8".length();
                array20[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(278123090, -1379592334, "\u6e65\u6a5c\u6a59\u6a53\u6a20", 1943845074, 1651643380);
                array19[n11] = StyleUtils.gold(array20);
                "\u55a6".length();
                "\u5067\u5365\u684e\u5456".length();
                "\u6394\u6d97\u6a63\u577a\u4f65".length();
                "\u5e60\u68da\u5658\u7047\u66f9".length();
                final int n12 = 2;
                final Object[] array21 = { null };
                "\u590b\u60e5\u56ac\u6809\u5141".length();
                "\u5edf\u6507\u6af3\u63ad\u689f".length();
                array21[0] = \u67e8\u5a79\u6407\u6762\u5273\u5331\u67a1\u6acf\u6acb\u59fe\u701a\u58ca\u55ec\u6841\u61df\u59ad\u5d1c\u6add\u70c4\u6278\u6439\u6611\u699b\u5f22\u61c4\u5ea0\u612c\u51cc\u634d\u70ba\u6a31\u5c03\u6fcb\u6808\u7141\u6c50\u66b9\u515e\u51b2\u6da9\u5018(79935510, 69636137, "\ub4b0", 2078615728, -219630499);
                array19[n12] = StyleUtils.gray(array21);
                player9.sendMessage(StyleUtils.gray(array19));
            }
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u53c4\u5916\u6cc1\u4e2b\u682b\u5cae\u6b76\u5637\u547d\u712e\u51a4\u6848\u5a77\u5be7\u51e4\u6656\u5daa\u558b\u53bb\u61bf\u6831\u5204\u64a4\u5d5f\u5582\u6ef7\u6ee8\u54fc\u64ad\u5db8\u693f\u6598\u5282\u6eaa\u5c3f\u67d0\u543a\u6aad\u5f5c\u69fd\u63ff(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
