package org.mplas.mplas.Commands.Spawn;

import org.mplas.mplas.*;
import org.bukkit.event.player.*;
import org.bukkit.entity.*;
import org.bukkit.*;
import org.bukkit.event.*;

public class FirstJoin implements Listener
{
    public FirstJoin(final Mplas plugin) {
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onFirstJoin(final PlayerJoinEvent playerJoinEvent) {
        final Player player = playerJoinEvent.getPlayer();
        final Location location = this.plugin.getSpawnLog().getLocation(\u685c\u5fea\u6ac5\u518b\u5c29\u6aa3\u52d0\u6f96\u5cfe\u547a\u65f7\u58cc\u4f85\u5516\u66c4\u4ea8\u4e7b\u6c53\u5445\u6952\u5b15\u4f35\u5aa5\u7141\u6ec9\u599c\u4f68\u6fb9\u663e\u6541\u6245\u4fa3\u703f\u5eb9\u511e\u6e8b\u50e9\u66d2\u604f\u51d7\u65b1(-385970470, -252108371, "\u428d\u42a1\u42b2\u42d8\u42c1", 317748925, 1989188471));
        if (!player.hasPlayedBefore()) {
            player.teleport(location);
            "\u5b5f\u5257\u6694\u5bf7\u5f75".length();
            "\u698c\u552a".length();
        }
    }
    
    public static int ColonialObfuscator_\u5efc\u6f8f\u5708\u704c\u7070\u66b7\u6d03\u630d\u6c9f\u56d1\u6105\u6bbf\u539e\u5b58\u66a4\u5484\u6dc8\u6a06\u70f4\u6f0b\u4fa1\u63da\u4f3d\u6315\u5968\u6aa5\u5ef0\u5923\u5102\u5938\u6f88\u528f\u6459\u6571\u5809\u5ace\u7007\u6290\u7035\u511d\u5422(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
