package org.mplas.mplas.Commands.Spawn;

import org.mplas.mplas.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;

public class Spawn implements CommandExecutor
{
    public Spawn(final Mplas plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender instanceof Player) {
            final Player player = (Player)commandSender;
            final Location location = this.plugin.getSpawnLog().getLocation(\u68eb\u6ef3\u6f61\u6a47\u5357\u6eb0\u63f7\u5736\u64b3\u5fb2\u68e8\u4fc6\u5c8c\u7020\u6a70\u6350\u648f\u64e4\u5433\u6046\u5ad5\u6f90\u626d\u6cbf\u5a11\u4e78\u59d8\u5acd\u51b3\u5a5f\u6ef4\u57da\u69ab\u5ddb\u66c3\u6d2f\u69b2\u603e\u60d6\u6664\u6115(18918633, 2034782901, "\ud1c9\ud1f9\ud1ea\ud1fc\ud1e5", -1103784241, -547178134));
            if (location != null) {
                player.teleport(location);
                "\u597d\u61e9\u694c\u526a".length();
                "\u68be\u7144\u697e\u5d16\u630a".length();
                final Player player2 = player;
                final Object[] array2 = new Object[2];
                "\u6884\u569d\u5417\u6617".length();
                "\u64b2".length();
                "\u5870".length();
                array2[0] = \u68eb\u6ef3\u6f61\u6a47\u5357\u6eb0\u63f7\u5736\u64b3\u5fb2\u68e8\u4fc6\u5c8c\u7020\u6a70\u6350\u648f\u64e4\u5433\u6046\u5ad5\u6f90\u626d\u6cbf\u5a11\u4e78\u59d8\u5acd\u51b3\u5a5f\u6ef4\u57da\u69ab\u5ddb\u66c3\u6d2f\u69b2\u603e\u60d6\u6664\u6115(1776045913, -278336311, "\u34fb\u348f\u3018\u340b\u3473\u3405\u3409\u301d\u345f\u3404\u3401\u341d\u3412\u3402\u3479\u346f\u340d\u3469\u3425\u598d\u6252\u5308\u7b00\u6ed4\u5b3a\u6226\u58c6\u5dab\u6009\u5cfe\u6ef8\u7a8a", 996210558, 430138436);
                "\u7071\u66a0\u696a".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u5b22".length();
                array3[0] = \u68eb\u6ef3\u6f61\u6a47\u5357\u6eb0\u63f7\u5736\u64b3\u5fb2\u68e8\u4fc6\u5c8c\u7020\u6a70\u6350\u648f\u64e4\u5433\u6046\u5ad5\u6f90\u626d\u6cbf\u5a11\u4e78\u59d8\u5acd\u51b3\u5a5f\u6ef4\u57da\u69ab\u5ddb\u66c3\u6d2f\u69b2\u603e\u60d6\u6664\u6115(1726746018, 178769403, "\ubae7", 1169382134, 1812668458);
                array2[n] = StyleUtils.gray(array3);
                player2.sendMessage(StyleUtils.gold(array2));
            }
            else {
                final Player player3 = player;
                final Object[] array4 = new Object[2];
                "\u601e\u6e20\u6ba8\u6c12".length();
                "\u5c0c\u4f23\u60be\u6553\u514b".length();
                array4[0] = \u68eb\u6ef3\u6f61\u6a47\u5357\u6eb0\u63f7\u5736\u64b3\u5fb2\u68e8\u4fc6\u5c8c\u7020\u6a70\u6350\u648f\u64e4\u5433\u6046\u5ad5\u6f90\u626d\u6cbf\u5a11\u4e78\u59d8\u5acd\u51b3\u5a5f\u6ef4\u57da\u69ab\u5ddb\u66c3\u6d2f\u69b2\u603e\u60d6\u6664\u6115(1838066325, -472870117, "\u7881\u78b6\u78cd\u78b0\u78ba\u7cb2\u78da\u78aa\u7887\u78af\u78a5\u78b8\u7caf\u78ad\u78a6\u7ca5\u78dc\u78c4\u78eb\u153f\u2eed\u1e47\u3633\u2787\u1678\u2f67\u1194\u148b", 1217513195, -369327227);
                "\u5a74\u5cd2\u5caf\u6026\u6f09".length();
                "\u58d7\u69b4\u6bf5\u6318\u6942".length();
                "\u5797".length();
                final int n2 = 1;
                final Object[] array5 = { null };
                "\u528d\u55a8".length();
                "\u6c91\u6bb6".length();
                "\u67bb\u4eb4\u683f\u6188\u62fb".length();
                "\u61dc\u5e29\u5a35".length();
                "\u67c6\u5820\u6ab0\u5c8c".length();
                array5[0] = \u68eb\u6ef3\u6f61\u6a47\u5357\u6eb0\u63f7\u5736\u64b3\u5fb2\u68e8\u4fc6\u5c8c\u7020\u6a70\u6350\u648f\u64e4\u5433\u6046\u5ad5\u6f90\u626d\u6cbf\u5a11\u4e78\u59d8\u5acd\u51b3\u5a5f\u6ef4\u57da\u69ab\u5ddb\u66c3\u6d2f\u69b2\u603e\u60d6\u6664\u6115(1118035246, 824221164, "\ube62", 654592095, -934758755);
                array4[n2] = StyleUtils.gray(array5);
                player3.sendMessage(StyleUtils.red(array4));
            }
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u55e8\u7020\u5296\u68b5\u692e\u5eda\u7132\u5b7d\u56e6\u63d1\u512a\u58c4\u6dba\u6245\u63d3\u50a6\u53bd\u6028\u6918\u59eb\u5ab8\u4fd5\u5edf\u6dda\u6d93\u6013\u59b4\u6b35\u5c4e\u658d\u68e3\u54b6\u51f8\u70d3\u704f\u5c65\u5e90\u550c\u6734\u62bb\u6432(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
