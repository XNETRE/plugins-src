package org.mplas.mplas.Commands.Spawn;

import org.mplas.mplas.*;
import org.bukkit.command.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Companents.*;

public class SetSpawn implements CommandExecutor
{
    public SetSpawn(final Mplas plugin) {
        this.plugin = plugin;
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (commandSender instanceof Player) {
            final Player player = (Player)commandSender;
            if (player.hasPermission(\u60b3\u5c68\u5e02\u5130\u60a9\u6836\u6284\u595a\u4ebd\u690f\u6cb0\u5921\u5301\u64ff\u5cac\u6dd9\u654f\u62b6\u51e3\u6c21\u5aef\u523e\u6de1\u52bd\u5408\u5b7d\u5837\u6e68\u5ee4\u6599\u664d\u5d8f\u684d\u5c3d\u569b\u60da\u5333\u5271\u6759\u6ede\u5c84(-100871399, -810776867, "\ua63d\ua60f\ua611\ua618\ua60a\ua653\ua607\ua613\ua620\ua609\ua60f\ua60a\ua61b\ua611", 1954095265, 1094636406))) {
                this.plugin.getSpawnLog().set(\u60b3\u5c68\u5e02\u5130\u60a9\u6836\u6284\u595a\u4ebd\u690f\u6cb0\u5921\u5301\u64ff\u5cac\u6dd9\u654f\u62b6\u51e3\u6c21\u5aef\u523e\u6de1\u52bd\u5408\u5b7d\u5837\u6e68\u5ee4\u6599\u664d\u5d8f\u684d\u5c3d\u569b\u60da\u5333\u5271\u6759\u6ede\u5c84(-69397742, 2075084412, "\ue9a4\ue98a\ue99f\ue98b\ue990", 47423218, -2103565816), (Object)player.getLocation());
                this.plugin.saveSpawnLog();
                final Player player2 = player;
                final Object[] array2 = new Object[2];
                "\u6546\u5a47\u5c08".length();
                "\u713c\u67ca\u6562\u6a28\u4f39".length();
                "\u61fc\u5994".length();
                "\u5498\u5669\u58b0\u69ef".length();
                array2[0] = \u60b3\u5c68\u5e02\u5130\u60a9\u6836\u6284\u595a\u4ebd\u690f\u6cb0\u5921\u5301\u64ff\u5cac\u6dd9\u654f\u62b6\u51e3\u6c21\u5aef\u523e\u6de1\u52bd\u5408\u5b7d\u5837\u6e68\u5ee4\u6599\u664d\u5d8f\u684d\u5c3d\u569b\u60da\u5333\u5271\u6759\u6ede\u5c84(-497019842, -1965560834, "\ubfa4\ubf95\ubfe8\ubf97\ubf9f\ubb89\ubfef\ubf9d\ubfb2\ubf9c\ubf90\ubf8f\ubb9a\ubf9a\ubffd\ubf99\ubf8a\ubb86\ubfcf\ud751\ude9c\ud3c9\ud202\uef8e\ud9e5\ue5f3\ud2c4\ue5a5\ue962", -2111000254, -1183386297);
                "\u5087\u6eec\u5567".length();
                "\u4ee2\u5be2\u70d9".length();
                final int n = 1;
                final Object[] array3 = { null };
                "\u6029\u7034\u6a07\u5b9f\u5e28".length();
                "\u60e0\u5806\u523b\u6374".length();
                "\u5bf2\u62c0\u5d05\u4f81".length();
                array3[0] = \u60b3\u5c68\u5e02\u5130\u60a9\u6836\u6284\u595a\u4ebd\u690f\u6cb0\u5921\u5301\u64ff\u5cac\u6dd9\u654f\u62b6\u51e3\u6c21\u5aef\u523e\u6de1\u52bd\u5408\u5b7d\u5837\u6e68\u5ee4\u6599\u664d\u5d8f\u684d\u5c3d\u569b\u60da\u5333\u5271\u6759\u6ede\u5c84(1698846004, -1444190274, "\u7c5f", -2128748337, -1874416008);
                array2[n] = StyleUtils.gray(array3);
                player2.sendMessage(StyleUtils.gold(array2));
            }
            else {
                final Object[] array4 = new Object[2];
                "\u5bc0".length();
                array4[0] = \u60b3\u5c68\u5e02\u5130\u60a9\u6836\u6284\u595a\u4ebd\u690f\u6cb0\u5921\u5301\u64ff\u5cac\u6dd9\u654f\u62b6\u51e3\u6c21\u5aef\u523e\u6de1\u52bd\u5408\u5b7d\u5837\u6e68\u5ee4\u6599\u664d\u5d8f\u684d\u5c3d\u569b\u60da\u5333\u5271\u6759\u6ede\u5c84(-936911425, 1853996604, "\u5da9\u5985\u5d95\u5d9b\u5dea\u598f\u5d9b\u5d99\u5dcc\u5980\u5d9a\u5de9\u5d9e\u5d8f", 1554791717, -1782053009);
                "\u579e".length();
                final int n2 = 1;
                final Object[] array5 = { null };
                "\u5adf\u5f83\u5f6c\u6641\u5096".length();
                "\u663f\u5836\u5fe7\u5dff".length();
                "\u5c9a\u6201\u68de".length();
                array5[0] = \u60b3\u5c68\u5e02\u5130\u60a9\u6836\u6284\u595a\u4ebd\u690f\u6cb0\u5921\u5301\u64ff\u5cac\u6dd9\u654f\u62b6\u51e3\u6c21\u5aef\u523e\u6de1\u52bd\u5408\u5b7d\u5837\u6e68\u5ee4\u6599\u664d\u5d8f\u684d\u5c3d\u569b\u60da\u5333\u5271\u6759\u6ede\u5c84(-1826757909, -1934388979, "\u097c", -329313106, -1432129962);
                array4[n2] = StyleUtils.gray(array5);
                commandSender.sendMessage(StyleUtils.red(array4));
            }
        }
        return true;
    }
    
    public static int ColonialObfuscator_\u68e2\u6bd7\u5924\u50a1\u63d3\u692c\u70ce\u6c0d\u5e33\u5205\u50f7\u63f9\u551b\u6729\u5513\u623c\u6015\u58b0\u698a\u51be\u5c06\u5a68\u4f6f\u561e\u5cf4\u5dbb\u6962\u6ce5\u5d78\u556d\u6472\u5b1a\u6538\u6044\u5241\u5deb\u6a7b\u677b\u4ff6\u58d3\u5834(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
