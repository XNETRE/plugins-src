package org.mplas.mplas.Companents;

import net.kyori.adventure.text.*;
import org.jetbrains.annotations.*;
import java.util.*;
import java.util.function.*;
import net.kyori.adventure.text.serializer.plain.*;
import net.kyori.adventure.text.minimessage.*;
import net.kyori.adventure.text.minimessage.tag.resolver.*;
import net.kyori.adventure.text.event.*;
import net.kyori.adventure.text.format.*;

public class StyleUtils
{
    public static int ColonialObfuscator_\u58e5\u5d8f\u669c\u5815\u58e9\u5dcf\u53fd\u5bf8\u6f20\u7083\u6746\u70f5\u54fb\u6f0f\u59ee\u5c2d\u5fc1\u5ae0\u644e\u4f02\u5b10\u5eca\u5bc8\u6dee\u4f87\u64b9\u61f1\u6d07\u5e19\u4eec\u5656\u63ce\u6cb1\u5774\u59d6\u6deb\u5c39\u5840\u5420\u5d79\u69a6(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
