package org.mplas.mplas.Events;

import org.bukkit.event.server.*;
import org.jetbrains.annotations.*;
import org.bukkit.command.*;
import org.mplas.mplas.Companents.*;
import net.kyori.adventure.text.*;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.mplas.mplas.*;
import java.time.*;
import org.bukkit.event.player.*;
import org.bukkit.event.entity.*;
import java.util.*;

public class Events implements Listener, CommandExecutor
{
    @EventHandler
    public void onPlayerUseTab(final TabCompleteEvent tabCompleteEvent) {
        if (!tabCompleteEvent.getSender().hasPermission(\u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(-1368073468, -239212714, "\u28c1\u28f1\u28e9\u28e6\u28f6\u28ad\u28e5\u28ec\u28c5\u28ed\u28e9", -197074478, -729614993)) || !tabCompleteEvent.getSender().isOp()) {
            tabCompleteEvent.setCancelled(true);
        }
    }
    
    public boolean onCommand(@NotNull final CommandSender commandSender, @NotNull final Command command, @NotNull final String s, @NotNull final String[] array) {
        if (commandSender instanceof Player) {
            final Player player = (Player)commandSender;
            if (commandSender.hasPermission(\u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(-2053835763, 301335817, "\u91fa\u91ca\u91d6\u91d9\u91c5\u919e\u91dc\u91d8\u91f7", -1804477084, -1664369228))) {
                if (Events.GODS.contains(player.getUniqueId())) {
                    Events.GODS.remove(player.getUniqueId());
                    "\u59f2\u589a\u6070\u5b48\u520b".length();
                    "\u5c71".length();
                    "\u6fcc\u592b\u6f94\u5024\u66bf".length();
                }
                else {
                    Events.GODS.add(player.getUniqueId());
                    "\u5acf\u50c8\u56e0\u4ea0\u53bc".length();
                    "\u67de\u510c\u61e6\u66f5\u4fc0".length();
                }
            }
            final Object[] array2 = new Object[3];
            "\u68e0\u51f0\u67c1".length();
            "\u59b0\u5a58\u60d1\u51c4".length();
            "\u5db0\u5425".length();
            array2[0] = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(-1378832252, 698553969, "\uab2b\uab2e\uab21\uab0a\uab2a\uab27\uab21\uab68", -2119419390, 1456682968);
            "\u5202".length();
            "\u6405\u50d4".length();
            final int n = 1;
            Component component;
            if (Events.GODS.contains(player.getUniqueId())) {
                final Object[] array3 = { null };
                "\u5e23\u5f28\u696e\u6d80".length();
                "\u59e4".length();
                "\u6230\u5a4e\u5f04\u704c\u552b".length();
                array3[0] = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(514765489, -577056337, "\u6649\u666a\u6669\u661c\u6615\u665f\u665e", -1783864357, 760046333);
                component = StyleUtils.gold(array3);
            }
            else {
                final Object[] array4 = { null };
                "\u6f5a".length();
                "\u70f3\u66fd".length();
                array4[0] = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(-263747337, 1947584483, "\u3431\u347e\u3404\u3405\u3470\u3479\u3402\u3404", 361631887, -1504481321);
                component = StyleUtils.red(array4);
            }
            array2[n] = component;
            "\u6326".length();
            final int n2 = 2;
            final Object[] array5 = { null };
            "\u50a6\u66ac".length();
            "\u64bd\u6cba".length();
            array5[0] = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(-1709484106, -1432435281, "\ua298", 1319574100, 951462584);
            array2[n2] = StyleUtils.gray(array5);
            commandSender.sendMessage(StyleUtils.gray(array2));
        }
        else {
            final Object[] array6 = new Object[2];
            "\u6abf".length();
            "\u6e73".length();
            "\u5c1c\u584e".length();
            array6[0] = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(1382823149, -2018458906, "\uee16\uea36\uee26\uee24\uee55\uea34\uee20\uee26\uee73\uea23\uee39\uee56\uee21\uee34", -1752178809, 255902714);
            "\u5737\u5f87\u5eef".length();
            final int n3 = 1;
            final Object[] array7 = { null };
            "\u5c45".length();
            array7[0] = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(1501111475, -1789519336, "\u3092", 922906749, 1660386854);
            array6[n3] = StyleUtils.gray(array7);
            commandSender.sendMessage(StyleUtils.red(array6));
        }
        return true;
    }
    
    @EventHandler(priority = EventPriority.LOW)
    public void onDamage(final EntityDamageEvent entityDamageEvent) {
        final Entity entity = entityDamageEvent.getEntity();
        if (entity instanceof Player && Events.GODS.contains(((Player)entity).getUniqueId())) {
            entityDamageEvent.setCancelled(true);
        }
    }
    
    @EventHandler
    public void handlejoinEvent(final PlayerJoinEvent playerJoinEvent) {
        final Player player = playerJoinEvent.getPlayer();
        final String name = player.getName();
        final String string = player.getUniqueId().toString();
        final String \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(995266094, -1063810766, "\u46f1", -631162913, 327579231);
        final CharSequence[] elements = new CharSequence[4];
        "\u634a\u5542\u4fb3".length();
        "\u5660\u602a\u603c\u6e15\u5803".length();
        elements[0] = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(-1505595446, 248078966, "\u5b0c\u5b06\u5b02\u5b19\u5b04\u5b49", 876449261, -951657644);
        "\u6d39\u671b".length();
        "\u5f42\u5319".length();
        elements[1] = name;
        "\u6d76".length();
        "\u70cc".length();
        "\u5138\u6258\u674a\u60d9".length();
        elements[2] = string;
        "\u5890\u54a4\u60f3\u53d2\u55b7".length();
        "\u6f83\u560b\u56b1".length();
        "\u5dfb\u6546".length();
        elements[3] = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(422685, 486043850, "\u768f\u768d\u769d\u769e\u76a0\u7681\u768e\u768b", 2114172337, 608682214);
        Mplas.getInstance().getJoinLog().set(String.join(\u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b, elements), (Object)LocalDateTime.now().toString());
        Mplas.getInstance().saveJoinLog();
    }
    
    @EventHandler
    public void handlequitEvent(final PlayerQuitEvent playerQuitEvent) {
        final Player player = playerQuitEvent.getPlayer();
        final String name = player.getName();
        final String string = player.getUniqueId().toString();
        final String \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(16844051, -1282764985, "\u94ed", 501968894, -2135068374);
        final CharSequence[] elements = new CharSequence[4];
        "\u5a14\u517b\u558a".length();
        "\u69a6\u579f\u6dea".length();
        "\u5e84".length();
        elements[0] = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(967719585, -286694220, "\ub48f\ub486\ub496\ub489\ub4c5", -1821482906, 1484557038);
        "\u6c00\u6739\u5c23\u4e4e\u6999".length();
        "\u5e3d\u592a\u5285\u5b1f\u5696".length();
        "\u58c2\u6371\u6f2d\u6b56".length();
        "\u533e\u6163".length();
        elements[1] = name;
        "\u5e74\u65da\u6df4\u67fa".length();
        "\u6061\u6719".length();
        "\u5d8a".length();
        "\u5afe\u6f35\u5803\u4fd4\u6e5d".length();
        "\u5a83".length();
        elements[2] = string;
        "\u5a1b\u6e89\u4f22\u5bd0".length();
        "\u51ef".length();
        "\u570a\u555f\u5167\u6449".length();
        elements[3] = \u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(-1285783367, 1366131105, "\u5789\u5789\u579b\u579e\u57a5\u5787\u5790\u5781", 160280940, -263919630);
        Mplas.getInstance().getQuitLog().set(String.join(\u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b, elements), (Object)LocalDateTime.now().toString());
        Mplas.getInstance().saveQuitLog();
    }
    
    @EventHandler
    public void handledeathEvent(final PlayerDeathEvent playerDeathEvent) {
        playerDeathEvent.getPlayer();
        playerDeathEvent.setDeathMessage(\u5393\u60a4\u6fe5\u57d7\u674f\u7036\u54cd\u5147\u5fb4\u6abd\u70dd\u552c\u53f0\u5789\u6195\u4ed7\u570a\u6fe2\u5ff9\u6d77\u5159\u62d6\u69ab\u5034\u61d1\u4f6d\u60e6\u6e79\u6159\u5689\u6555\u5f98\u5808\u516e\u5ecf\u5396\u5d0e\u58e2\u50bb\u7126\u582b(260445551, -1071970170, "", -534937325, 1852139877));
    }
    
    public static int ColonialObfuscator_\u6849\u6224\u52a8\u6f77\u6e7c\u5851\u675b\u65ac\u6e4e\u65ec\u6d6b\u5c52\u6bab\u51f1\u64af\u5696\u6838\u5c63\u57c0\u5246\u67b5\u59c4\u703b\u4fd1\u70a2\u6e0e\u6e9b\u7017\u6395\u5daa\u6ac1\u4f65\u5f8f\u62ef\u64d4\u5ba3\u6333\u6863\u649a\u5ae9\u6cd9(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
