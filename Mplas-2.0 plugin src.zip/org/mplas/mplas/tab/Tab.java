package org.mplas.mplas.tab;

import net.kyori.adventure.text.*;
import org.mplas.mplas.Companents.*;
import org.bukkit.*;
import org.mplas.mplas.*;
import org.bukkit.entity.*;
import org.mplas.mplas.Commands.Others.*;
import org.bukkit.plugin.*;
import java.util.*;

public class Tab
{
    public static int ColonialObfuscator_\u57df\u5b91\u66ed\u4e57\u59f7\u6d14\u618f\u6c78\u5f32\u6c9e\u6cee\u5431\u6e16\u573b\u5c95\u6870\u65a5\u7030\u54d9\u4ed9\u4e8b\u5428\u570c\u665b\u66a7\u655f\u5653\u6d3d\u63db\u5311\u6950\u5a66\u5f02\u6b99\u50a4\u5c26\u6fae\u61ea\u6919\u6ac3\u5013(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
