package org.mplas.mplas;

import org.bukkit.plugin.java.*;
import cloud.commandframework.paper.*;
import org.bukkit.configuration.file.*;
import net.kyori.adventure.text.minimessage.*;
import org.bukkit.configuration.*;
import java.io.*;
import org.mplas.mplas.Commands.Times.*;
import org.mplas.mplas.Commands.Bans.*;
import org.mplas.mplas.Commands.Bans.Check.*;
import org.mplas.mplas.Commands.Others.Others.*;
import org.mplas.mplas.Commands.Others.troll.*;
import org.mplas.mplas.Commands.Weather.*;
import org.mplas.mplas.Commands.Warp.*;
import org.mplas.mplas.Commands.Others.*;
import org.bukkit.command.*;
import java.util.function.*;
import cloud.commandframework.*;
import cloud.commandframework.execution.*;
import org.mplas.mplas.Events.*;
import org.mplas.mplas.Commands.Spawn.*;
import org.bukkit.plugin.*;
import java.text.*;
import io.papermc.paper.event.player.*;
import net.kyori.adventure.text.serializer.plain.*;
import org.mplas.mplas.Companents.*;
import net.kyori.adventure.text.*;
import org.bukkit.event.*;
import org.bukkit.event.player.*;
import org.bukkit.scheduler.*;
import java.util.*;
import org.bukkit.*;
import org.bukkit.potion.*;
import org.bukkit.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.inventory.*;
import org.bukkit.entity.*;

public class Mplas extends JavaPlugin implements Listener, CommandExecutor, TabCompleter
{
    public Mplas() {
        this.teleportRequests = new HashMap<Player, Player>();
        this.teleportToggle = new HashMap<Player, Boolean>();
        this.teleportCooldowns = new HashMap<Player, Long>();
        this.playerPreviousLocations = new HashMap<Player, Location>();
        this.teleportRequestTimes = new HashMap<Player, Long>();
        this.currentMessageIndex = 1;
        this.afkTasks = new HashMap<Player, BukkitTask>();
        this.lastActivity = new HashMap<Player, Long>();
        this.hiddenPlayers = new HashMap<Player, Long>();
        this.hideDurationInSeconds = 60L;
        this.itemAmountMap = new HashMap<Item, Integer>();
        this.maxItemsInRadius = 10;
        this.maxRadius = 5;
        this.ignoreFile = new File(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-37229220, -724220082, "\udfda\udfe9\udff2\udfec\udfe2\udfe1\udff5\udfa3\udfe3\udff0\udfe9\udfe8\udffd\udfb2\udff7\udfeb\udff8\udfe7\udfd6\u8c75\u8b6c\u8875\u8301\ubc3e", 333095205, -1767320354));
        this.ignoreConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(this.ignoreFile);
    }
    
    public void removeExpiredBans() {
        final long currentTimeMillis = System.currentTimeMillis();
        "\u52be\u6d07\u661a\u640f\u6f97".length();
        final ArrayList<String> list = new ArrayList<String>();
        for (final String s : this.bannedPlayersConfig.getKeys(false)) {
            final long long1 = this.bannedPlayersConfig.getLong(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s), 0L);
            if (long1 > 0L && currentTimeMillis >= long1) {
                list.add(s);
                "\u6476\u69ba".length();
                "\u55e1".length();
                "\u6472".length();
            }
        }
        final Iterator<Object> iterator2 = list.iterator();
        while (iterator2.hasNext()) {
            this.bannedPlayersConfig.set((String)iterator2.next(), (Object)null);
        }
        this.saveBanConfig();
    }
    
    public void onLoad() {
        "\u621e".length();
        "\u620b".length();
        "\u692b\u605d\u5ad7\u6ecb\u56c3".length();
        this.bannedPlayersFile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(184973835, -644754803, "\ufbf8\ufbda\ufbd9\ufbd4\ufb92\ufbc3\ufbdc\ufbd1", -370341016, 197154872));
        if (!this.bannedPlayersFile.exists()) {
            this.saveResource(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(425594764, -342566294, "\ued45\ued67\ued64\ued69\ued37\ued66\ued79\ued74", 2114079020, -1518374495), false);
        }
        this.bannedPlayersConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(this.bannedPlayersFile);
    }
    
    public void onEnable() {
        this.getServer().getScheduler().scheduleSyncRepeatingTask((Plugin)this, this::checkHiddenPlayers, 0L, 20L);
        "\u59eb\u52ea\u57f7".length();
        "\u623d\u6ac8\u5ba7\u4f30\u5df1".length();
        Mplas.instance = this;
        Bukkit.getScheduler().runTaskTimer((Plugin)this, this::removeExpiredMutes, 600L, 600L);
        "\u6df9\u5c65\u4f85\u4f1b\u56b3".length();
        Bukkit.getScheduler().runTaskTimer((Plugin)this, this::removeExpiredBanIPs, 600L, 600L);
        "\u5ab8\u6472\u6559".length();
        Bukkit.getScheduler().runTaskTimer((Plugin)this, this::removeExpiredBans, 600L, 600L);
        "\u6ea2\u6e13".length();
        "\u59f1\u672b".length();
        "\u58dc\u597d".length();
        "\u6b13\u6407\u5fca\u6055\u6ea2".length();
        "\u69ae\u5410".length();
        "\u5fee\u61eb\u63f7\u5e1c\u6ecb".length();
        "\u6688".length();
        this.nearFile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(85612959, 25634125, "\u61c5\u61fd\u61fb\u61e8\u61c5\u61f9\u61fc\u61f3\u61d9\u61f4\u61ff\u61a6\u61f6\u61f5\u61f7", 1736650959, 2101161461));
        if (!this.nearFile.exists()) {
            this.saveResource(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1902896637, -541278485, "\u5b48\u5b6e\u5b6a\u5b7b\u5b68\u5b52\u5b55\u5b58\u5b74\u5b57\u5b5e\u5b05\u5b5b\u5b5e\u5b5e", -1380977636, -1182796689), false);
        }
        this.nearConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(this.nearFile);
        "\u5c86".length();
        "\u681a\u4f69".length();
        this.mutedPlayersFile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1125052772, 1314254776, "\ud691\ud6bc\ud6a4\ud6a7\ud6c8\ud685\ud6d9\ud6c1\ud6e4", -49897028, 1188456927));
        if (!this.mutedPlayersFile.exists()) {
            this.saveResource(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1470356994, 1131508007, "\uef50\uef7d\uef69\uef6a\uef79\uef34\uef6c\uef74\uef55", -123065386, -211184527), false);
        }
        "\u68c7\u5199\u509f\u6599".length();
        "\u694a\u5048".length();
        "\u5150\u522c".length();
        final File file = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-743630867, -1768099716, "\ua0a0\ua082\ua081\ua08c\ua08d\ua092\ua0c7\ua09c\ua0a4\ua089", 1654305616, 546305103));
        if (!file.exists()) {
            this.saveResource(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(257501920, 235483125, "\u6f69\u6f4b\u6f54\u6f59\u6f5c\u6f43\u6f12\u6f49\u6f7d\u6f50", 254037614, 1496392764), false);
        }
        this.bannedIpConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(file);
        "\u60bf\u67cf\u4fdb\u5d05".length();
        "\u56a9".length();
        "\u51a9\u547c".length();
        final File file2 = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1617628856, -364508459, "\uff2f\uff0f\uff0e\uff05\uff45\uff16\uff0b\uff08", -1546396639, -883173187));
        if (!file2.exists()) {
            this.saveResource(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1951779256, -613117400, "\uc497\uc4b7\uc4b6\uc4bd\uc4fd\uc4ae\uc4b3\uc4a0", 1277407913, 108712560), false);
        }
        this.bannedPlayersConfig = (FileConfiguration)YamlConfiguration.loadConfiguration(file2);
        this.registerCommandManager();
        this.registerCommands();
        this.registerEvents();
        this.saveDefaultConfig();
        this.printToConsole(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(266904799, -1029010682, "\u5eef\u5ede\u5ed2\u5ed4\u5ed5\u5e9a\u5e80\u5e8c\u5ee7\u5ec6\u5ea7\u5ea5\u5eac\u5ea0\u5eb3\u5eed\u5ebc\u5ea0\u5eca\u0d0f\u0a69\u0934\u0217\u3d5f\u37f2\u3e51\u304e\u3c2b\u0fab", -2042775370, -1298019925));
        "\u6f94\u6279\u6c35\u53d5".length();
        this.banipFile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1475638154, -947453483, "\ufc9f\ufca3\ufca2\ufcad\ufcaa\ufcb3\ufce4\ufcbd\ufc8b\ufca8", 1712250639, -169824739));
        this.banipLog = (FileConfiguration)YamlConfiguration.loadConfiguration(this.banipFile);
        "\u69be\u4e3e\u5839".length();
        "\u53e7".length();
        this.mutedFile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1547270511, 1332872017, "\ub2c2\ub2ef\ub2f3\ub2f0\ub2e3\ub2ae\ub2fe\ub2e6\ub2c7", -1284399630, -1037675232));
        this.mutedLog = (FileConfiguration)YamlConfiguration.loadConfiguration(this.mutedFile);
        "\u6239\u58aa\u5bac\u684b".length();
        this.joinfile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1406257942, 1288574153, "\uf8b8\uf892\uf896\uf895\uf8d5\uf886\uf89b\uf898", -2043629327, 1332832323));
        this.joinLog = (FileConfiguration)YamlConfiguration.loadConfiguration(this.joinfile);
        "\u6a22\u5559".length();
        "\u5095\u54d0\u5e94\u6989".length();
        this.quitfile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-376616487, -2027736900, "\u4f4e\u4f61\u4f7f\u4f62\u4f38\u4f17\u4f0a\u4f05", -827930821, -1005915870));
        this.quitLog = (FileConfiguration)YamlConfiguration.loadConfiguration(this.quitfile);
        "\u5539\u6fda\u6b57\u64b6\u6f11".length();
        "\u6d3c".length();
        "\u69d3\u675d\u6398\u620f".length();
        this.spawnfile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1227712542, -1163408434, "\ua5af\ua58f\ua59c\ua58a\ua593\ua5d3\ua58d\ua597\ua5b4", 1862961767, -282627116));
        this.spawnLog = (FileConfiguration)YamlConfiguration.loadConfiguration(this.spawnfile);
        "\u6182\u6e9b\u5097\u6d9f\u5bf2".length();
        "\u5d85".length();
        "\u5595\u60a7\u6405".length();
        this.automfile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1964482806, -258103774, "\u4944\u4973\u4970\u496b\u4969\u4977\u496a\u492d\u4958\u497e\u497a", -677054425, -1451378795));
        this.automLog = (FileConfiguration)YamlConfiguration.loadConfiguration(this.automfile);
        "\u61cd\u6508\u6d1a\u60cf\u6cac".length();
        "\u5b3d\u52c8\u6b9e\u5ae2\u50e0".length();
        "\u67b9\u6528\u53fc".length();
        this.warpfile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-424032619, -449214585, "\ub3f9\ub3c0\ub3d1\ub3d7\ub389\ub3da\ub3c7\ub3f4", -1338422311, -585123578));
        this.warpLog = (FileConfiguration)YamlConfiguration.loadConfiguration(this.warpfile);
        "\u535e\u500e".length();
        "\u5c8f\u6df5".length();
        "\u5fdc\u6abe".length();
        this.chatFile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1773486399, 554780578, "\u195a\u197c\u1975\u1962\u193e\u196f\u1970\u197d", -339674224, 954721399));
        this.ChatLog = (FileConfiguration)YamlConfiguration.loadConfiguration(this.chatFile);
        "\u58dd\u6f5b\u6dd3".length();
        "\u62ff".length();
        "\u6af7\u4f15\u5067".length();
        this.ignorefile = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2103374751, -1472938694, "\ufbf4\ufbd5\ufbde\ufba3\ufbbe\ufbad\ufbef\ufbb2\ufb84\ufbab", -2145174595, -700878536));
        this.ignoreLog = (FileConfiguration)YamlConfiguration.loadConfiguration(this.ignorefile);
        if (!this.automfile.exists()) {
            this.automLog.set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(760995694, 18279692, "\u15ff\u15df\u15d2\u15d1\u15df\u15de\u15d6", -254661709, 858328072), (Object)true);
            this.automLog.set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2117372571, 695471795, "\ufe8a\ufea2\ufeb9\ufea6\ufe89\ufe9e\ufe88\ufe80\ufeac", 1632240732, 2065924404), (Object)10);
            this.automLog.createSection(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1610345829, -1647850389, "\ua72a\ua70f\ua715\ua717\ua707\ua707\ua70a\ua710", -1835890202, 1968500754));
            "\u6691\u62db\u50b7\u5318".length();
            "\u7032\u6de6\u6823\u6b0f".length();
            this.automLog.set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1201193603, 273339800, "\u8d11\u8d34\u8d2e\u8d2c\u8d3c\u8d3c\u8d31\u8d2b\u8d56\u8d65", 396089318, -371346884), (Object)List.of(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2101093525, 1693534157, "\uddcc\uddba\udda3\uddb2\udda8\udde9\ud9f5\ud996\ud9ca\ud99a\udde3\ud990\ud9e1\ud985\ud9f2\ud9e1\ud98c\uddf0\ud9ca\u8a09\u8d27\u8e6a\u8509\uba46\ub0a6\ub977\ub77f\ubb1b\u8cc1\ubfc6\u8c8e\uba11\u8cf4\u80f4\ub991\u814a\u84d5\ub3e8\u8f07\ub22d\ub5f9", 256213766, -219364845)));
            this.automLog.set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1727346128, -1607026506, "\u8b92\u8b89\u8b9d\u8b9d\u8b8f\u8b89\u8b82\u8b9a\u8be5\u8bdb", -1150431649, -2096838523), (Object)List.of(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1002041150, 707295694, "\u54b6\u54c0\u54c9\u54d8\u54c2\u5483\u5095\u50fc\u50a0\u5083\u50f2\u548b\u50ef\u5085\u508a\u50e9\u5086\u50e8\u50f4\u0722\u046d\u0725\u0c48\u3373\u39e3\u3043\u3a10\u321c\u01b4\u32dc\u01fd\u3735\u01d5\u0dda\u34dd\u0c2b\u0dd2\u3ecd\u023f\u3b06\u38a1\u3777\u3870\u3a37\u0afd\u21dd\u01f0\u35b3\u040a\u0d5d\u0f2c\u399f\u3788\u0440\u307a\u243a\u3f0e\u0902\u35ec\u3397\u0ad5\u347b\u399b\u36df\u32b8\u3a64\u036f\u335c\u36b4\u08e9\u00f3\u36b0\u023d\u363a\u3b34\u39f7\u3b19\u31de\u31b5\u0876\u3c2c\u084a\u3965\u312d\u07be\u3193\u3e6c\u04b7Q\u34a7\u0e7f\u0409\u3f77\u05f2\u3fa4\u39aa\u0fb8\u0956\u0e7f\u0c5b\u0954\u3fe6", -238913650, 822495819)));
            this.saveAutomLog();
        }
        this.saveAutomLog();
        this.saveJoinLog();
        this.saveChatLog();
        this.saveQuitLog();
        this.saveChatLog();
        this.saveBansLog();
        this.saveignoreLog();
        this.savelogs();
        this.saveSpawnLog();
        this.saveDefaultConfig();
        this.getChatLog().options().copyDefaults(true);
        "\u55d6\u6920".length();
        "\u6e5e\u61af\u65ce\u6820".length();
        "\u4f8e\u5898\u6e08\u5e8e\u6caf".length();
        "\u63dd\u5e7f\u6c16".length();
        "\u5ee5\u6533".length();
        if (!this.getChatLog().contains(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1554664503, -1369976446, "\u9dda\u9df5\u9de2\u9ded\u9de0\u9df9\u9dec\u9deb\u9dc2\u9dfb", 2044522350, 603647791))) {
            this.getChatLog().set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-440683651, 1001675115, "\ufc13\ufc3e\ufc37\ufc3e\ufc31\ufc2a\ufc39\ufc20\ufc0b\ufc30", 686222505, -1585644926), (Object)true);
            this.saveChatLog();
        }
        if (!this.getChatLog().contains(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1921280183, 1502471562, "\u01ad\u0183\u018b\u018b\u0184\u018d\u0181\u0184\u01b1\u01b6\u0198\u0199\u0199\u0185\u0184\u0196", -976417342, -853769859))) {
            this.getChatLog().set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-326694849, -2009032021, "\u12a7\u1289\u1299\u1299\u1296\u129f\u129b\u129e\u12ab\u12ac\u128a\u128b\u128b\u1297\u128e\u129c", -1994986866, -539923822), (Object)100);
            this.saveChatLog();
        }
        this.modifyChat = this.getChatLog().getBoolean(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-577936243, -621773034, "\u85b3\u859a\u8593\u859e\u8591\u8586\u8595\u8590\u85bb\u8584", 1511836547, -263367291));
        this.localChatRadius = this.getChatLog().getDouble(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1422535838, -1505429168, "\u3805\u382d\u3823\u3821\u382c\u382b\u3829\u382e\u3819\u3818\u3830\u3833\u3831\u3833\u382c\u383c", 1083948163, 1672457883), 100.0);
        this.getChatLog().options().copyDefaults();
        "\u68ca".length();
        "\u6dbc\u50e7".length();
        "\u6dd1".length();
        "\u5a17\u4f5a\u6e0c".length();
        this.getChatLog().options().copyDefaults(true);
        "\u6a75".length();
        "\u6022\u537d\u5b5d".length();
        "\u6af6\u6983\u6b40".length();
        this.saveChatLog();
        this.automsgEnabled = this.getAutomLog().getBoolean(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1642135841, 1920080119, "\u5279\u525f\u5254\u5255\u5259\u5256\u5250", 1226749810, 1253702907), false);
        this.automsgInterval = this.getAutomLog().getInt(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1121568660, -1863766123, "\ude8b\udea1\udeb8\udea1\udeb0\udea5\udeb1\udeb7\ude9d", -428901887, 1496363847), 10);
        if (this.automsgEnabled) {
            Bukkit.getScheduler().runTaskTimer((Plugin)this, this::sendNextMessageAutomatically, 1L, (long)(this.automsgInterval * 20));
            "\u6007".length();
            "\u56ce\u522a".length();
            "\u5c08\u6059\u583a\u676a".length();
        }
    }
    
    public void sendNextMessageAutomatically() {
        if (!this.automsgEnabled) {
            return;
        }
        final ConfigurationSection configurationSection = this.automLog.getConfigurationSection(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(924083929, -1288730460, "\u4572\u4557\u4541\u4543\u4557\u4557\u455e\u4544", -49929824, 1883671169));
        if (configurationSection == null) {
            return;
        }
        final String value = String.valueOf(this.currentMessageIndex);
        if (configurationSection.contains(value)) {
            final List stringList = configurationSection.getStringList(value);
            if (!stringList.isEmpty()) {
                final Iterator<String> iterator = stringList.iterator();
                while (iterator.hasNext()) {
                    Bukkit.broadcast(MiniMessage.miniMessage().deserialize((Object)iterator.next()));
                    "\u5da3".length();
                    "\u5668\u653b\u58a5\u61e4".length();
                    "\u6f45\u6e55\u5426\u5424\u6faa".length();
                }
            }
            "\u5aa5".length();
            "\u6612".length();
            this.currentMessageIndex = ColonialObfuscator_\u6857\u50b3\u5d74\u63a8\u5385\u4fbd\u6ba7\u4f4d\u6f1c\u5ba0\u65c4\u6c86\u5035\u5219\u5212\u5c22\u565f\u604f\u54fc\u52bd\u6905\u6e61\u690c\u538f\u667f\u4f2f\u6d29\u6c7a\u6bfd\u6a74\u67cd\u59df\u4ee6\u5686\u5c3c\u5364\u6818\u6216\u5a9c\u593d\u68fa(this.currentMessageIndex, 1);
        }
        else {
            this.currentMessageIndex = 1;
        }
    }
    
    public FileConfiguration getJoinLog() {
        return this.joinLog;
    }
    
    public FileConfiguration getChatLog() {
        return this.ChatLog;
    }
    
    public FileConfiguration getAutomLog() {
        return this.automLog;
    }
    
    public FileConfiguration getSpawnLog() {
        return this.spawnLog;
    }
    
    public FileConfiguration getQuitLog() {
        return this.quitLog;
    }
    
    public FileConfiguration getWarpLog() {
        return this.warpLog;
    }
    
    public void savelogs() {
        this.getConfig().options().copyDefaults(true);
        "\u6fac\u632e\u5060\u590a".length();
        "\u6e9c\u5eef\u69ea\u4ede".length();
        this.saveConfig();
    }
    
    public void saveJoinLog() {
        try {
            this.joinLog.save(this.joinfile);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void saveignoreLog() {
        try {
            this.ignoreLog.save(this.ignorefile);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void saveBansLog() {
        try {
            this.bansLog.save(this.bansfile);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void saveChatLog() {
        try {
            this.ChatLog.save(this.chatFile);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void saveWarpLog() {
        try {
            this.warpLog.save(this.warpfile);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void saveAutomLog() {
        try {
            this.automLog.save(this.automfile);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void saveQuitLog() {
        try {
            this.quitLog.save(this.quitfile);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void saveSpawnLog() {
        try {
            this.spawnLog.save(this.spawnfile);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void onDisable() {
        try {
            this.mutedPlayersConfig.save(this.mutedPlayersFile);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
        final Iterator<BukkitTask> iterator = this.afkTasks.values().iterator();
        while (iterator.hasNext()) {
            iterator.next().cancel();
        }
        this.afkTasks.clear();
        this.lastActivity.clear();
        try {
            this.bannedPlayersConfig.save(this.bannedPlayersFile);
        }
        catch (IOException ex2) {
            ex2.printStackTrace();
        }
    }
    
    public void registerCommands() {
        final PluginCommand pluginCommand = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1577135084, -1346555841, "\u5308\u532a\u532b\u5337", 1505283865, -700413981));
        "\u6a7c".length();
        "\u6a75\u5a6a\u5a37".length();
        "\u564a\u6a05\u6cb7".length();
        "\u6f95\u63b5".length();
        pluginCommand.setExecutor((CommandExecutor)new Bolt());
        final PluginCommand pluginCommand2 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(93337226, -1785454440, "\u00d0\u00ed\u00f4\u00f8\u00ff\u00fe\u00eb\u00f5\u00d2", 1174857162, -1620643031));
        "\u559d\u5d23\u5f85".length();
        pluginCommand2.setExecutor((CommandExecutor)new Broadcast());
        final PluginCommand pluginCommand3 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-750705477, -1568923812, "\u12a5\u1280\u1297", 2032229401, -1529907842));
        "\u6a96\u7083".length();
        "\u6612\u6476\u5042\u5a28\u6d6f".length();
        "\u5b85\u5e1d\u5067".length();
        "\u5095\u5063".length();
        pluginCommand3.setExecutor((CommandExecutor)new Fly());
        final PluginCommand pluginCommand4 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1007617566, -835324298, "\u8701\u8724", 3451561, 1570233828));
        "\u6dfa\u620f\u70db".length();
        "\u6870\u67b2".length();
        "\u6a40\u69a0".length();
        pluginCommand4.setExecutor((CommandExecutor)new Gamemodes());
        final PluginCommand pluginCommand5 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1915160249, -175649818, "\u72d7\u72ff\u72e8\u72e8\u72e9", 1010752051, 1385850251));
        "\u6e43\u6f06\u6062".length();
        pluginCommand5.setExecutor((CommandExecutor)new Speed());
        final PluginCommand pluginCommand6 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1142287396, 235872294, "\u1bc6\u1b98\u1b9e\u1b93", -1835048385, -842484272));
        "\u69ef\u62c3\u6b4c\u583c\u5bec".length();
        pluginCommand6.setExecutor((CommandExecutor)new Heal());
        final PluginCommand pluginCommand7 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2028369758, -848966395, "\u22e8\u22c7\u22d2\u22d4\u22c9\u22d3", -1838682870, -1710060959));
        "\u622e\u5c9f\u6edc\u6757".length();
        "\u6f7c\u6a4c\u703b".length();
        pluginCommand7.setExecutor((CommandExecutor)new getpos());
        final PluginCommand pluginCommand8 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1245254473, 684454563, "\u121f\u1231\u1231\u1232", -417840876, -727665980));
        "\u62f2\u60d1\u58e0\u4f31".length();
        "\u68e9\u59e4\u546b\u6d7b\u6ceb".length();
        pluginCommand8.setExecutor((CommandExecutor)new Feed());
        final PluginCommand pluginCommand9 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2009112304, -363402884, "\u14f3\u14c3\u14c3", 1988866358, -1763889777));
        "\u629c\u5d3d\u6cda".length();
        "\u67d0".length();
        "\u63e6\u617d\u5b77\u6794".length();
        pluginCommand9.setExecutor((CommandExecutor)new ext());
        final PluginCommand pluginCommand10 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1695121076, 1768735855, "\u35b7\u3590\u3599", -201161815, -1097921311));
        "\u7103\u6dfa\u5f1f".length();
        "\u7057".length();
        pluginCommand10.setExecutor((CommandExecutor)new Events());
        final PluginCommand pluginCommand11 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2083244517, 2114908159, "\u2b2e\u2b1e\u2b1e\u2b11\u2b01", 2093043694, 1098628362));
        "\u6584".length();
        pluginCommand11.setExecutor((CommandExecutor)new Mplasplugin(this));
        final PluginCommand pluginCommand12 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(781506545, -247812755, "\u5cfc\u5cc2\u5c32\u5c29", -480481410, -532264661));
        "\u68b7\u6906\u5406".length();
        "\u58d2\u66c2\u6b65\u53c9".length();
        pluginCommand12.setExecutor((CommandExecutor)new Veip());
        final PluginCommand pluginCommand13 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(273307961, -2005338496, "\ueed1\ueee5\ueef0\ueef9\ueefa\ueef4\ueef8", 1637374919, 291248777));
        "\u66b7\u6372\u5daa\u6312\u6dfc".length();
        pluginCommand13.setExecutor((CommandExecutor)new Reload());
        final PluginCommand pluginCommand14 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1319790739, 1931193780, "\u360b\u3633\u3636\u36d6", -1374851971, 299605872));
        "\u4f58\u5045\u509f\u5e91\u5f12".length();
        "\u5550\u6bf0".length();
        pluginCommand14.setExecutor((CommandExecutor)new Burn());
        final PluginCommand pluginCommand15 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-363072867, -1304054753, "\u771a\u7735\u773b\u7731\u7739\u7732\u7735", 997465026, 1402677874));
        "\u5c99".length();
        "\u6373".length();
        "\u6b8e\u66e4\u6e9a".length();
        "\u5cc5\u6f55".length();
        pluginCommand15.setExecutor((CommandExecutor)new Kickall());
        final PluginCommand pluginCommand16 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(436281928, 1494382586, "\u7c79\u7c56\u7c57\u7c55\u7c5a\u7c51\u7c56", -1117164718, -1205321039));
        "\u5b06\u648f\u5940".length();
        "\u5364\u5795".length();
        "\u51c2\u583c".length();
        "\u6c20".length();
        pluginCommand16.setExecutor((CommandExecutor)new KillAll());
        final PluginCommand pluginCommand17 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2060320820, -1427466193, "\u784a\u786c\u7876", 1830290247, -35971895));
        "\u5e57\u5aa6\u5e92\u6553".length();
        "\u613b\u70d0".length();
        pluginCommand17.setExecutor((CommandExecutor)new EditTimes());
        final PluginCommand pluginCommand18 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1289189561, -911045449, "\u440a\u4423\u4412\u441a\u441f\u4417\u4417\u4407", 1142888094, -505633100));
        "\u66d8\u5cfe\u682e\u6156\u562c".length();
        pluginCommand18.setExecutor((CommandExecutor)new EditTimes());
        final PluginCommand pluginCommand19 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(275929291, 2005689302, "\u1d32\u1d18\u1d16\u1d1b\u1d79", 361326524, -598982210));
        "\u6670\u5403".length();
        pluginCommand19.setExecutor((CommandExecutor)new EditTimes());
        final PluginCommand pluginCommand20 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1935382255, -1901654032, "\ue652\ue666\ue67e\ue66c", -75578727, -2009547291));
        "\u68f4\u54da\u573d\u5885".length();
        "\u5e92\u6e5a\u52a2".length();
        "\u6932\u708c\u53e5\u6040".length();
        pluginCommand20.setExecutor((CommandExecutor)new EditTimes());
        final PluginCommand pluginCommand21 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(950682127, -1694951195, "\u989a\u98b5\u9883\u9889", -1115714658, -234862138));
        "\u6055\u61d1\u585a\u57f3".length();
        "\u4fa9\u6ba5\u54f5".length();
        "\u6ec7\u523d\u700b".length();
        pluginCommand21.setExecutor((CommandExecutor)new kick());
        final PluginCommand pluginCommand22 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(154055473, -216662547, "\u3000\u3022\u3039\u302c\u3025\u3020\u3026\u302a", -1238154924, 177946541));
        "\u6c88\u5a1d\u6554".length();
        "\u60e3".length();
        pluginCommand22.setExecutor((CommandExecutor)new fireball_custom());
        final PluginCommand pluginCommand23 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-925514059, -1509186496, "\ub872\ub856\ub85e\ub85b\ub84c\ub859\ub85b\ub844\ub870\ub859", 1907612137, 812385096));
        "\u6a4c\u687d".length();
        "\u578b\u60b5".length();
        "\u4f6e\u644d".length();
        "\u58ec".length();
        pluginCommand23.setExecutor((CommandExecutor)new EnderChest());
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(870197684, -1104441593, "\u9643\u966d\u9662", 170712268, -119346147)).setExecutor((CommandExecutor)this);
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1427617046, 91958622, "\uda5d\uda73\uda7c\uda79\uda6e", -1285565676, 420769500)).setExecutor((CommandExecutor)this);
        final PluginCommand pluginCommand24 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-408676304, 2126579803, "\u7989\u79b3\u79a2\u79a5\u79b7", -2063803149, -40913615));
        "\u685c\u650a\u4fea\u6e96\u5b83".length();
        "\u5a4c\u5821\u5914".length();
        "\u5c10".length();
        pluginCommand24.setExecutor((CommandExecutor)new Craft());
        final PluginCommand pluginCommand25 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1309220799, -1394448822, "\u6c33\u6c1f\u6c1d\u6c1a\u6c03\u6c0e", -724943668, -1797204264));
        "\u6623\u550e".length();
        "\u5e06".length();
        "\u6323\u6b51\u6460".length();
        pluginCommand25.setExecutor((CommandExecutor)new Online());
        final PluginCommand pluginCommand26 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2437363, -906796256, "\u1bab\u1b81\u1b85\u1b82\u1b96\u1b90", -911200050, -789608606));
        "\u6c7c\u6a7c\u67de\u5026".length();
        pluginCommand26.setExecutor((CommandExecutor)new Invsee());
        final PluginCommand pluginCommand27 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(487898478, 1977198254, "\uea58\uea7e\uea77\uea73\uea79", -1474732086, 428519026));
        "\u6138\u6928\u6de8\u4eda".length();
        "\u5460\u653b\u6a55\u520b".length();
        "\u5c05".length();
        pluginCommand27.setExecutor((CommandExecutor)new check(this));
        final PluginCommand pluginCommand28 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-402335714, -756178272, "\u57ff\u57c9\u57c8\u57c1\u57ce\u57ce\u57c9", -2058890714, 1213726545));
        "\u6022\u6692\u59b1\u66be".length();
        "\u5b14\u58a5\u6df9".length();
        "\u5cfb".length();
        pluginCommand28.setExecutor((CommandExecutor)new uncheck(this));
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1362282249, -1193837751, "\ue1e4\ue1cb\ue1d8", -1330228733, -1026363282)).setExecutor((CommandExecutor)this);
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1115335481, 186797174, "\u540d\u5422\u5431\u5433\u5433\u543d\u5421\u542b", -1612721581, -1739824858)).setExecutor((CommandExecutor)this);
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1558648915, -1362942972, "\u1adc\u1af5\u1ae0\u1ae0\u1ae0\u1ae9\u1ad3\u1ad9\u1af0", 794375770, 1470230296)).setExecutor((CommandExecutor)this);
        final PluginCommand pluginCommand29 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1681176560, -1564671278, "\ub704\ub726\ub72f\ub729\ub724\ub739\ub735\ub721\ub716\ub731\ub72c\ub725\ub731\ub72b", -225903348, -902954774));
        "\u70c8".length();
        "\u5d7a\u5eff\u5b52".length();
        "\u6ab2\u5ba0".length();
        pluginCommand29.setExecutor((CommandExecutor)new Inventory());
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1085264482, 1664145684, "\uc79b\uc7b0\uc7b2\uc791\uc78d", -1672133091, 352810299)).setExecutor((CommandExecutor)this);
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(932043732, -110504715, "\u4454\u447d\u446c\u4463\u447d", -1370965460, -1490030226)).setExecutor((CommandExecutor)this);
        final PluginCommand pluginCommand30 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1572612073, 1940127198, "\u771d\u7739\u773f\u7730\u772a\u772f\u772b\u7720", 790681325, 1587772394));
        "\u5afc\u5ca0\u4f8b\u581f".length();
        "\u637c".length();
        "\u658b\u5dcf\u63ce\u5950".length();
        pluginCommand30.setExecutor((CommandExecutor)new Testing());
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-33064632, -376365815, "\u5a87\u5aac\u5aac", 486212442, -352371283)).setExecutor((CommandExecutor)this);
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-713875161, 1838061994, "\uf246\uf211\uf217\uf20c\uf204\uf204\uf206\uf201", 1739478463, -2135417021)).setExecutor((CommandExecutor)this);
        final PluginCommand pluginCommand31 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-23440074, 57534596, "\ucb01\ucb2b", -1214813679, 1626545300));
        "\u70d7".length();
        pluginCommand31.setExecutor((CommandExecutor)new TpHeight());
        final PluginCommand pluginCommand32 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-688135403, -1990386239, "\ua4f4\ua4dc\ua4c6\ua4df", -1385731113, 1214329296));
        "\u6c11\u69cb\u6824".length();
        "\u519b\u626d".length();
        pluginCommand32.setExecutor((CommandExecutor)new TpHeight());
        final PluginCommand pluginCommand33 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-238964796, -961925376, "\uecb6\uec97\uec95\uec8a\uec9d\uec89\uec82", 291007760, -760544958));
        "\u6239\u51cc\u5b11\u5934".length();
        pluginCommand33.setExecutor((CommandExecutor)new Compass());
        final PluginCommand pluginCommand34 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1921797103, 467702717, "\ude37\ude01\ude1b\ude17", -1065664830, -491403404));
        "\u6f18\u4ef3\u54f9\u514f\u6940".length();
        "\u5611\u674c\u6fcd\u6820".length();
        pluginCommand34.setExecutor((CommandExecutor)new Nuke(this));
        final PluginCommand pluginCommand35 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1927877953, -1860271983, "\u9716\u972d\u9729\u9720", -1017912894, -1963793612));
        "\u6268\u70b9\u6965\u50ec\u6cd2".length();
        "\u6a70\u530d\u599a\u62a9\u57fe".length();
        pluginCommand35.setExecutor((CommandExecutor)new Testing());
        final PluginCommand pluginCommand36 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-911076768, 1118522927, "\u140c\u143b\u1434\u142c\u1430\u143f\u142d\u1424\u140e\u142d", -783457429, -944887013));
        "\u556c\u6add\u575d".length();
        "\u58f0\u64bc".length();
        "\u6646\u6af8\u64eb\u7125\u59c8".length();
        "\u4fac\u5dea\u5c4b\u6abc\u5a20".length();
        pluginCommand36.setExecutor((CommandExecutor)new PlayerInfo());
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1794316582, 1464999689, "\ub6ce\ub6ee\ub6ee\ub6e6", -607505337, 2114028679)).setExecutor((CommandExecutor)this);
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-884669539, -1950620738, "\ua598\ua5b4\ua5b4\ua5b0", 1616814133, -743381585)).setExecutor((CommandExecutor)this);
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1680904838, 394567618, "\u53d1\u53f9\u53f9\u53f1", 710435075, -2010529717)).setExecutor((CommandExecutor)this);
        this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-241818493, 288392975, "\u1201\u122f\u1231\u123b", 823537870, 1179681122)).setExecutor((CommandExecutor)this);
        final PluginCommand pluginCommand37 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1694837999, 326139607, "\u0ab7\u0a9c\u0a8c\u0a84\u0a8c\u0a87\u0a89", -332455818, -1275164873));
        "\u4e80\u53d3".length();
        "\u60de\u6b74\u53df".length();
        "\u4ed4\u6f98".length();
        pluginCommand37.setExecutor((CommandExecutor)new suicide());
        final PluginCommand pluginCommand38 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-355293956, 1854979114, "\u3404\u3421\u3430\u3423\u3437\u342c\u343c\u342d\u3418", -761069396, -598004656));
        "\u6524\u6476\u54af\u4e9e".length();
        "\u4f7b\u5368\u6839\u65dd".length();
        pluginCommand38.setExecutor((CommandExecutor)new Meteorite(this));
        final PluginCommand pluginCommand39 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(841967978, 1268123295, "\u2b9b\u2b81\u2b81\u2b8a\u2b81\u2b89\u2ba4\u2b97\u2baa\u2b88\u2b8f\u2b96\u2b84\u2b9e\u2b9e\u2ba2", -700112303, -125344218));
        "\u4f55".length();
        "\u52ce\u7115\u4fb2\u56b8\u5a22".length();
        pluginCommand39.setExecutor((CommandExecutor)new ZombieApocalypse());
        final PluginCommand pluginCommand40 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(2126552456, -1662373270, "\u77d1\u77ff\u77fa\u77f6\u77e1\u77ec", -1800266123, -517618063));
        "\u5050\u6327\u5279".length();
        "\u4eda\u5970\u5116".length();
        "\u59ba\u688b".length();
        pluginCommand40.setExecutor((CommandExecutor)new Turrel(this));
        final PluginCommand pluginCommand41 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1814370511, -212418584, "\u9dfb\u9dfb\u9df4\u9dff\u9df6\u9df1\u9de2", -1899958861, -1934633111));
        "\u5716\u51a2".length();
        "\u69e4\u70ac\u53d0\u4f6b\u4f7b".length();
        "\u55a1\u58ce\u6b8a".length();
        "\u6d9a\u6cd8\u6e92\u6edf".length();
        pluginCommand41.setExecutor((CommandExecutor)new Enchant());
        final PluginCommand pluginCommand42 = this.getServer().getPluginCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(805949845, -1970198321, "\u6b7e\u6b78\u6b75\u6b7c\u6b7b\u6b72\u6b63\u6b5a\u6b53\u6b7f", 1360578852, 1116756742));
        "\u5cf8\u6f6e\u568a\u52ae\u6634".length();
        "\u6fa2\u5181\u52a2\u58cd\u5e5f".length();
        "\u6ea8".length();
        pluginCommand42.setExecutor((CommandExecutor)new EnchantAll());
        final PluginCommand command = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2087462976, -655906319, "\udcaa\udc83\udc9a", 739466713, 1435238258));
        "\u6e68\u5b0c\u56ee".length();
        "\u6561".length();
        "\u579d\u541b\u4e67".length();
        command.setExecutor((CommandExecutor)new EditWeathers());
        final PluginCommand command2 = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1601625664, -1124606767, "\u31f3\u31cf\u31c5\u31c6", -1529065407, -1755931502));
        "\u57dd\u6aac\u6a74".length();
        "\u62c0".length();
        command2.setExecutor((CommandExecutor)new EditWeathers());
        final PluginCommand command3 = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-166383677, -1561908835, "\ua849\ua87d\ua864\ua879\ua866", -590660497, -1929604536));
        "\u4e5d\u6b3e\u5ca0\u61ea".length();
        "\u66fa".length();
        command3.setExecutor((CommandExecutor)new EditWeathers());
        final PluginCommand command4 = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1226960629, -1143121888, "\u8e58\u8e63\u8e72\u8e77\u8e72\u8e65\u8e78\u8e6d", -1639162176, -876779907));
        "\u5717\u6d17".length();
        "\u624f\u5365\u6cfb\u5843\u636e".length();
        command4.setExecutor((CommandExecutor)new SetSpawn(this));
        final PluginCommand command5 = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1119403221, 2088571390, "\ua95c\ua970\ua979\ua960\ua978\ua96d\ua964", -2004544700, 2139232020));
        "\u6f24".length();
        "\u502f".length();
        "\u5a40".length();
        "\u6b6a\u563c\u65db\u6950\u6929".length();
        command5.setExecutor((CommandExecutor)new DelWarp(this));
        final PluginCommand command6 = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(3265306, 1648772656, "\ue77c\ue752\ue74f\ue75b\ue740", -1017352474, 387587200));
        "\u5baf\u6e39".length();
        "\u6b63\u6aee\u6278\u5e0a".length();
        command6.setExecutor((CommandExecutor)new Spawn(this));
        final PluginCommand command7 = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-406235156, -1274211512, "\ub411\ub42a\ub43f\ub43e\ub42a\ub43f\ub43a", -851134078, -1702475513));
        "\u7069\u5da1\u6de1\u508a\u6633".length();
        "\u5135".length();
        "\u542b\u6796".length();
        command7.setExecutor((CommandExecutor)new SetWarp(this));
        final PluginCommand command8 = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-104243714, 1419758319, "\u7e35\u7e0e\u7e19\u7e19", 1788307794, 1872789570));
        "\u59f4\u7023".length();
        "\u5085\u69c1".length();
        command8.setExecutor((CommandExecutor)new Warp(this));
        final PluginCommand command9 = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(614935573, -1036388555, "\u02a7\u0288\u0291\u0284", -555004054, 288855747));
        "\u5749".length();
        "\u67e4\u6dc5".length();
        "\u70ea\u531e".length();
        command9.setExecutor((CommandExecutor)new More());
        this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1288600808, -2022969967, "\uec3f\uec10", -2119103381, 2145743130)).setExecutor((CommandExecutor)this);
        final PluginCommand command10 = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-839448766, -466521885, "\u5063\u504b\u5044", 1709983209, 1190683145));
        "\u599f\u5ca9\u69fa\u700f".length();
        "\u70e1\u5fd8\u5cb2\u5c99\u5cae".length();
        "\u6613\u6ef1\u5788".length();
        "\u6802\u56d2\u65ce\u67c5\u5b38".length();
        command10.setExecutor((CommandExecutor)new Testing());
        final PluginCommand command11 = this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1844567033, 2129882141, "\ua29b\ua2a1\ua2b4\ua2a7\ua2b1\ua2ac", -1919503508, -2118932958));
        "\u5777".length();
        "\u5c67\u560d\u66da\u57ea\u5098".length();
        "\u6012\u6214\u5d62".length();
        command11.setExecutor((CommandExecutor)new Repair());
        this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-743317340, 1570088892, "\u6c6a\u6c41\u6c52\u6c5f\u6c52\u6c41\u6c5f", -719905487, 1830434420)).setExecutor((CommandExecutor)this);
        this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(565779247, 162970945, "\u2feb\u2fc2\u2fc1\u2fdb\u2fc4\u2fdc\u2fd3", 1214973314, 1334348848)).setExecutor((CommandExecutor)this);
        this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1322743092, 1600570072, "\u76ef\u76d5\u76df\u76c2\u76d0\u76db\u76dd", -982159805, 1013010575)).setExecutor((CommandExecutor)this);
        this.getCommand(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-660802347, 550272881, "\u541d\u5434\u542f\u5435\u542a\u5432\u5435", -742414290, 1145337760)).setTabCompleter((TabCompleter)this);
        "\u51e1".length();
        "\u5d95\u55ce\u5f6b\u676c".length();
        "\u6033\u65d4\u5cad\u6510".length();
        Bukkit.getPluginManager().registerEvents((Listener)new Vanish(this.commandManager), (Plugin)this);
    }
    
    public List<String> onTabComplete(final CommandSender commandSender, final Command command, final String s, final String[] array) {
        if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(96277252, 1799340773, "\u2548\u2574\u2480\u249f\u2480\u249e\u2490\u248d", -877304066, -2022206880)) && array.length == 2) {
            final String[] a = new String[9];
            "\u60b3\u60a8".length();
            "\u6569\u5f9c".length();
            a[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1888948992, 1751707982, "\u1af2\u1ada\u1a8c", -758565845, 2097990887);
            "\u682c\u5cfb".length();
            "\u69d8\u4fcf\u53e5\u5833\u5c67".length();
            "\u50d9\u6f69\u5a8d".length();
            a[1] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1797355767, 1904699023, "\ua785\ua7ad\ua7f9", -1050704694, 1865956677);
            "\u6ad3\u5947\u5bc3".length();
            "\u6767\u65b4\u582b".length();
            "\u50f4".length();
            "\u6dcc\u63c5\u5e25\u5ca6\u6dc8".length();
            a[2] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(406412560, 2145487643, "\u58b5\u58cb", -1652646634, 1874269148);
            "\u6bdb\u690f".length();
            "\u691f".length();
            a[3] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-466807373, -300321353, "\u6d66\u6d1c", -240938379, 590454629);
            "\u6128\u5671\u5339".length();
            "\u64ac".length();
            a[4] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-578161025, -2127984890, "\ucadd\ucafb\ucaa5", 1399352519, 297064209);
            "\u5080\u54e7\u50ed\u50d0\u5136".length();
            "\u6dbb\u5433\u5691".length();
            "\u5628\u4e57".length();
            a[5] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2001008659, 1087168530, "\ufc83\ufcf5", -1493164555, 161548027);
            "\u56ec\u5c15".length();
            "\u6781\u5621\u5e79".length();
            "\u4f7a".length();
            a[6] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1716892983, -31331797, "\u3aa8\u3a84\u3adb", -427205119, 553204677);
            "\u534f\u510a\u5440".length();
            "\u4e76".length();
            "\u65f7\u60f4\u6558\u5e2b\u6252".length();
            a[7] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(390349692, 200430325, "\ud1f0\ud1de\ud181", -1399496447, -1934057206);
            "\u5ed8\u4e2e\u7081".length();
            "\u704d\u6bb0\u5a31\u6c6c\u7023".length();
            "\u5473\u5072\u5df2\u5503".length();
            "\u6a06\u57a7\u5f27\u6364\u5e9e".length();
            a[8] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1358768617, 470252582, "\u8ab3\u8ac0", 1593232563, 1862865849);
            return Arrays.asList(a);
        }
        if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1209049390, -893484827, "\u56cf\u56f3\u56fb\u56e4\u5688\u568d\u5689", 1293912124, -1374683377)) && array.length == 2) {
            final String[] a2 = new String[9];
            "\u5d6b\u6122".length();
            "\u6aa1".length();
            a2[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1706195721, 1904382275, "\u78e5\u78f5\u78a3", -1024998113, -1462130626);
            "\u5b3d\u6206\u69d2".length();
            "\u61cb\u53c7".length();
            a2[1] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1980529319, -732960202, "\u3375\u335d\u3309", 976617930, -1279435358);
            "\u541e".length();
            "\u5b5a".length();
            "\u5b93\u69eb\u6dea\u5aeb\u5a7a".length();
            "\u6e05\u5334\u6fe3\u5e84\u650a".length();
            a2[2] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(676319362, -333215902, "\uf869\uf817", 499724710, -1940218277);
            "\u6775\u6cf6\u7026".length();
            "\u5171\u5a9a\u5cac\u57db\u594d".length();
            a2[3] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1204703584, -562803940, "\u9f7b\u9f03", 526212644, -849599343);
            "\u5abe\u502a".length();
            "\u599c\u6c32".length();
            a2[4] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1290378348, -1050729770, "\ue094\ue0bc\ue0e0", 1499753660, 1443902176);
            "\u6d3d".length();
            "\u6c7b\u5848".length();
            a2[5] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1853063771, 478257532, "\ub598\ub5ee", 890835725, -1045136834);
            "\u649f\u583e\u680d\u6216\u5764".length();
            "\u60ce\u70d8\u4ef6\u58bd\u4fe6".length();
            "\u4f07\u6f7c\u69e3\u5e7a\u5d9c".length();
            a2[6] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(403431797, -1621531748, "?\u0091\u00c0", 1754517510, 1232491040);
            "\u699e\u6fbe\u6f48\u512e".length();
            a2[7] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1148319422, -908184581, "\udf05\udf2b\udf74", -160324463, -1465467229);
            "\u4e47".length();
            "\u4f28\u6fb7\u585a\u671f\u5e7f".length();
            "\u50ec\u5cf1\u6a9e\u6f18\u66c1".length();
            a2[8] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1408172552, -1897832791, "\u7ca8\u7cd3", -2119172105, -2104680328);
            return Arrays.asList(a2);
        }
        if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-24180569, -782217935, "\ub5a1\ub588\ub58f\ub595\ub586\ub59e\ub59d", -433884540, -1534229884)) && array.length == 1) {
            "\u6ebe\u6a4b".length();
            "\u6094\u6779\u5411\u5552\u66fe".length();
            "\u5278\u6ad5\u637d".length();
            "\u5ddf\u4e7f\u6cb9\u5450\u6bf6".length();
            final ArrayList<String> list = new ArrayList<String>();
            final Iterator<World> iterator = (Iterator<World>)Bukkit.getWorlds().iterator();
            while (iterator.hasNext()) {
                list.add(iterator.next().getName());
                "\u6efc".length();
                "\u5ccb\u59e9\u6d12".length();
                "\u548d\u5822\u6905".length();
                "\u6cf1".length();
            }
            return list;
        }
        return null;
    }
    
    public void registerCommandManager() {
        final Function<CommandTree<CommandSender>, CommandExecutionCoordinator<CommandSender>> build = AsynchronousCommandExecutionCoordinator.builder().build();
        final Function<Object, Object> identity = Function.identity();
        try {
            "\u5fd2\u5213\u6738".length();
            this.commandManager = new PaperCommandManager<CommandSender>((Plugin)this, (Function<CommandTree<Object>, CommandExecutionCoordinator<Object>>)build, (Function<CommandSender, Object>)identity, (Function<Object, CommandSender>)identity);
        }
        catch (Exception ex) {
            this.getLogger().severe(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-733494321, -1399473940, "\u2301\u2304\u2711\u2370\u2309\u230b\u230b\u2302\u2359\u2378\u2713\u2319\u2325\u2331\u234e\u2324\u2330\u2327\u230a\u70bf\u77ec\u74d8\u7fc4\u40f0\u4a6d\u43ba\u4df6\u4589\u722b\u413f\u7267\u44ab\u7243\u7e42\u4720\u7fd4\u7e54\u4d4e\u71bd\u4c98\u4b56\u448d\u4b85\u4da7", -619431468, -1558223448));
        }
    }
    
    public void registerEvents() {
        final PluginManager pluginManager = this.getServer().getPluginManager();
        "\u705c\u5455".length();
        "\u621e\u6183\u6032".length();
        "\u570f".length();
        "\u70e3".length();
        pluginManager.registerEvents((Listener)new Events(), (Plugin)this);
        final PluginManager pluginManager2 = this.getServer().getPluginManager();
        "\u5475\u60e2\u639e".length();
        "\u57af\u5b45\u6f32\u6558\u65e5".length();
        "\u5b55\u558c".length();
        pluginManager2.registerEvents((Listener)new Invsee(), (Plugin)this);
        this.getServer().getPluginManager().registerEvents((Listener)this, (Plugin)this);
        final PluginManager pluginManager3 = this.getServer().getPluginManager();
        "\u6352".length();
        "\u5af1".length();
        "\u6899".length();
        pluginManager3.registerEvents((Listener)new PlayerEvents(), (Plugin)this);
        final PluginManager pluginManager4 = this.getServer().getPluginManager();
        "\u6bf3".length();
        "\u6803\u548e".length();
        pluginManager4.registerEvents((Listener)new FirstJoin(this), (Plugin)this);
    }
    
    public void printToConsole(final String s) {
        this.getServer().getConsoleSender().sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.WHITE, ChatColor.GRAY, s));
    }
    
    public boolean checkMuteStatus(final Player player) {
        final String name = player.getName();
        "\u7031\u68b8".length();
        "\u503e\u52e8".length();
        "\u700f\u5953\u6cbe\u685f".length();
        final File file = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(571649305, 365379964, "\ud6bd\ud690\ud674\ud677\ud664\ud629\ud671\ud669\ud648", 72689790, 1898844808));
        if (!file.exists()) {
            this.saveResource(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1131720085, 1724395185, "\uf6fc\uf6d7\uf6cd\uf6cc\uf6dd\uf68e\uf6d0\uf6ca\uf6e9", -139215925, 1863962173), false);
        }
        final ConfigurationSection configurationSection = ((FileConfiguration)YamlConfiguration.loadConfiguration(file)).getConfigurationSection(name);
        if (configurationSection != null) {
            final String string = configurationSection.getString(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-493136713, 2143872672, "\udd2c\udd18\udd19\udd0d\udd0c\udd19\udd21\udd16\udd30\udd16", 265000101, 176815016), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-632374324, -1093189446, "", -968315183, -9189319));
            final String string2 = configurationSection.getString(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1361499737, 65012119, "\u0ed5\u0eef\u0eeb\u0efb\u0e99\u0e9e", -293498564, -1478473706), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2072404738, -1686521769, "\u7180\u7182\u71f0\u71f7\u71fc\u7185\u7184\u71f3\u71dc\u75e7\u71fd\u7196\u71e1\u71f0\u71f9\u71e0\u75e1\u719e\u71c6\u220f\u252f\u2666\u2d73\u1225", -585722951, 1328136910));
            if (string.equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1629007285, 902190286, "\ud8ae\ud884\ud889\ud88e\ud89f\ud886\ud88b\ud881", -367960751, 2090632021))) {
                player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, ChatColor.BOLD, ChatColor.GRAY, ChatColor.GOLD, string2, ChatColor.GRAY, ChatColor.GOLD, \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(643200332, -1010351222, "\u2782\u2782\u278c\u27fd\u278b\u278b\u2783\u278b", 1315958518, 926546924), ChatColor.GRAY));
                return true;
            }
            try {
                "\u60c5\u6eb0".length();
                "\u5b1d\u6249".length();
                "\u5c69\u6a7c\u5393\u64ff".length();
                final long n = new SimpleDateFormat(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(265558342, -2129748610, "\uaa71\uaa5c\uaa12\uaa73\uaa71\uaa14\uaa44\uaa48\uaa68\uaa44\uaa1e\uaa64\uaa61\uaa02\uaa68\uaa7c\uaa33\uaa66\uaa4c", -1873620206, -349438596)).parse(string).getTime() - System.currentTimeMillis();
                if (n <= 0L) {
                    return false;
                }
                final long n2 = n / 1000L % 60L;
                final long n3 = n / 60000L % 60L;
                final long n4 = n / 3600000L % 24L;
                final long n5 = n / 86400000L;
                player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, ChatColor.BOLD, ChatColor.GRAY, ChatColor.GOLD, string2, ChatColor.GRAY, ChatColor.GOLD, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, (n5 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n5) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-849779056, 656002688, "", -1407254597, -1806592498), (n4 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n4) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-267778362, -178930955, "", -145474238, 1923640821), (n3 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n3) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2054475043, 231648155, "", 61138597, 2070547568), (n2 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n2) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1543698066, 1462780764, "", -2016456903, 142941490)), ChatColor.GRAY));
                return true;
            }
            catch (ParseException ex) {
                \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-769144801, 1280965461, "\u4c2a\u4c2d\u4c22\u4c29\u4c2c\u4c2f\u4c52\u4c63\u4c3e\u4c13", -62225959, -1290994969);
            }
        }
        return false;
    }
    
    @EventHandler
    public void onPlayerChat5(final AsyncChatEvent asyncChatEvent) {
        final Player player = asyncChatEvent.getPlayer();
        final String name = player.getName();
        if (this.checkMuteStatus(player)) {
            asyncChatEvent.setCancelled(true);
            return;
        }
        final Component message = asyncChatEvent.message();
        final String serialize = PlainTextComponentSerializer.plainText().serialize(message);
        final String substring = serialize.substring(1);
        if (this.modifyChat) {
            asyncChatEvent.setCancelled(true);
            if (serialize.startsWith(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(907785438, -586071209, "\ub630", -687814519, 70486354))) {
                final Object[] array = new Object[2];
                "\u603f".length();
                "\u61d7".length();
                array[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1043700897, -60608611, "\uc731\ue380", 1645616322, -1758835664);
                "\u59ed".length();
                "\u5001\u56c3".length();
                "\u52c1\u6ebe".length();
                final int n = 1;
                final Object[] array2 = new Object[3];
                "\u5815".length();
                "\u643f\u6aad\u5d70\u5256".length();
                "\u6a84\u6f3d\u6241\u7019".length();
                "\u5951".length();
                array2[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1727755417, 2011297568, "\u0e7c\u0eca", 486136802, -2118035745);
                "\u5f97".length();
                "\u6dd5\u6c34\u6559\u617f\u6e1a".length();
                "\u684d".length();
                "\u60bf\u56c0\u7075\u6cbc".length();
                array2[1] = name;
                "\u4e6e\u5f8c".length();
                "\u4e53\u674d".length();
                "\u60bc\u6f86\u6424".length();
                final int n2 = 2;
                final Object[] array3 = new Object[2];
                "\u6de6\u5de6\u6e3c".length();
                "\u5ce6\u660a".length();
                "\u6f54\u6340\u522d".length();
                array3[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-733885264, -318546978, "\uc41a\uc42d", -1457727778, 137659859);
                "\u650d\u694a".length();
                "\u6ce8\u6d2b".length();
                "\u623e\u4f04\u5692".length();
                "\u5789\u56cd\u6779\u5506".length();
                array3[1] = substring;
                array2[n2] = StyleUtils.gray(array3);
                array[n] = StyleUtils.gray(array2);
                Bukkit.broadcast(StyleUtils.gold(array));
                "\u6f3e\u650b\u64c5".length();
            }
            else {
                for (final Player player2 : Bukkit.getOnlinePlayers()) {
                    if (player2.getLocation().distance(player.getLocation()) <= this.localChatRadius) {
                        final Player player3 = player2;
                        final Object[] array4 = new Object[2];
                        "\u5f48\u5a89\u6ca7".length();
                        "\u6e5c\u51a3".length();
                        "\u5fd3\u5efe".length();
                        array4[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-583445837, 1011663892, "\u693f\u4df3", 148238292, 1281307854);
                        "\u7009".length();
                        "\u6762".length();
                        "\u5996\u5e0a\u60a5\u60d9\u6314".length();
                        final int n3 = 1;
                        final Object[] array5 = new Object[3];
                        "\u5e3b\u5f0d\u6eff".length();
                        "\u5346\u5b31\u5f9f\u5c0b".length();
                        array5[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1249179487, 1804647703, "\uca01\ucab7", 1082426526, 200604625);
                        "\u4e64\u5942".length();
                        "\u67ee\u4f15\u6cc9\u6465".length();
                        array5[1] = name;
                        "\u6abb\u51b2\u4ff3\u65bc".length();
                        "\u56ca\u4e5f".length();
                        "\u643c\u5763\u54c2".length();
                        final int n4 = 2;
                        final Object[] array6 = new Object[2];
                        "\u6486\u6251\u5108\u4fb8\u577d".length();
                        "\u4f16".length();
                        array6[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-518896103, -2057241253, "\u9dcb\u9dfc", -1012121198, 1142515554);
                        "\u5e69\u5368\u6e0b\u6ff9\u5142".length();
                        "\u70eb\u5621\u54be".length();
                        "\u6207".length();
                        "\u6640".length();
                        "\u59c6\u54a3\u56f5\u52f8\u6bb6".length();
                        array6[1] = message;
                        array5[n4] = StyleUtils.gray(array6);
                        array4[n3] = StyleUtils.gray(array5);
                        player3.sendMessage(StyleUtils.aqua(array4));
                    }
                }
            }
        }
    }
    
    @EventHandler
    public void onPlayerJoin(final PlayerLoginEvent playerLoginEvent) {
        final Player player = playerLoginEvent.getPlayer();
        if (this.bannedPlayersConfig.contains(player.getName())) {
            final String string = this.bannedPlayersConfig.getString(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, player.getName()), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2008704076, -2134480845, "", -857955585, -1047206738));
            final String string2 = this.bannedPlayersConfig.getString(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, player.getName()), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1724679816, 859906216, "\u2c25\u2c23\u2c51\u2c52\u2c59\u2c1c\u2c1d\u2c16\u2c39\u2806\u2c1c\u2c73\u2c04\u2c19\u2c10\u2c05\u2804\u2c7f\u2c27\u7fea\u78ca\u7b9f\u708a\u4fc0", -1604376101, -716003456));
            \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1352412050, 1584101837, "", -1707205547, 347824331);
            final String s = invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD);
            if (string.equals(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-172574180, 544183845, "\u08ff\u08d7\u08d8\u08d9\u08d6\u08cd\u08c2\u08c6", -152488980, 707270405))) {
                playerLoginEvent.disallow(PlayerLoginEvent.Result.KICK_BANNED, invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD, string2, s));
            }
        }
    }
    
    @EventHandler
    public void onPlayerLogin(final PlayerLoginEvent playerLoginEvent) {
        final Player player = playerLoginEvent.getPlayer();
        if (this.bannedPlayersConfig.contains(player.getName())) {
            final long long1 = this.bannedPlayersConfig.getLong(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, player.getName()), 0L);
            if (long1 > System.currentTimeMillis() || long1 == Long.MAX_VALUE) {
                final String string = this.bannedPlayersConfig.getString(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, player.getName()), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1787683561, -1631962873, "\u522a\u522c\u525e\u525d\u5256\u5223\u5222\u5229\u5206\u5639\u5223\u524c\u523b\u5256\u525f\u524a\u564b\u5230\u5268\u01a5\u0685\u05c0\u0ed5\u319f", -1602857165, -989715113));
                final long n = (long1 - System.currentTimeMillis()) / 1000L;
                \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-377777805, 1787549407, "", 1181417986, -454131538);
                String s;
                if (n > 0L) {
                    s = invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD, n / 86400L, ChatColor.GRAY, ChatColor.GOLD, n % 86400L / 3600L, ChatColor.GRAY, ChatColor.GOLD, n % 86400L % 3600L / 60L, ChatColor.GRAY);
                }
                else {
                    s = invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD);
                }
                playerLoginEvent.disallow(PlayerLoginEvent.Result.KICK_BANNED, invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD, string, s));
            }
        }
    }
    
    @EventHandler
    public void onPlayerTeleport(final PlayerTeleportEvent playerTeleportEvent) {
        final Player player = playerTeleportEvent.getPlayer();
        this.playerPreviousLocations.put(player, player.getLocation());
        "\u4f41\u62ef\u6ffb".length();
    }
    
    @EventHandler
    public void onPlayerToggleSneak(final PlayerToggleSneakEvent playerToggleSneakEvent) {
        final Player player = playerToggleSneakEvent.getPlayer();
        this.lastActivity.put(player, System.currentTimeMillis());
        "\u6e7c\u6e18\u644d".length();
        if (this.afkTasks.containsKey(player)) {
            player.setPlayerListName(player.getName());
            this.afkTasks.remove(player).cancel();
            Bukkit.broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, player.getName(), ChatColor.GRAY));
            "\u5ac3\u622a\u5865\u67ed\u51d2".length();
            "\u4fcf".length();
            "\u5c5b\u6ecd\u5c8f\u4f56\u695b".length();
            "\u67f3\u562a\u58e1".length();
        }
    }
    
    @EventHandler
    public void onPlayerMove(final PlayerMoveEvent playerMoveEvent) {
        final Player player = playerMoveEvent.getPlayer();
        this.lastActivity.put(player, System.currentTimeMillis());
        "\u6096\u5dec\u5a15\u6208\u5db5".length();
        "\u5dbe\u5e3e\u67c6\u675b".length();
        "\u53b6\u5474".length();
        "\u50f6\u5482\u6394".length();
        if (this.afkTasks.containsKey(player)) {
            player.setPlayerListName(player.getName());
            this.afkTasks.remove(player).cancel();
            Bukkit.broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, player.getName(), ChatColor.GRAY));
            "\u64b1".length();
        }
    }
    
    @EventHandler
    public void onPlayerToggleSprint(final PlayerToggleSprintEvent playerToggleSprintEvent) {
        final Player player = playerToggleSprintEvent.getPlayer();
        this.lastActivity.put(player, System.currentTimeMillis());
        "\u5422\u52bb\u7064\u6e54".length();
        "\u4e29\u601a\u6466\u5d0f\u596b".length();
        "\u6d67".length();
        "\u5bee\u4ff7\u5d7c\u66a9\u52cd".length();
        if (this.afkTasks.containsKey(player)) {
            player.setPlayerListName(player.getName());
            this.afkTasks.remove(player).cancel();
            Bukkit.broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, player.getName(), ChatColor.GRAY));
            "\u5cd7\u7126\u5ffa\u5109".length();
            "\u6f71".length();
            "\u4e86\u544b".length();
        }
    }
    
    @EventHandler
    public void onPlayerQuit(final PlayerQuitEvent playerQuitEvent) {
        final Player player = playerQuitEvent.getPlayer();
        if (this.afkTasks.containsKey(player)) {
            this.afkTasks.remove(player).cancel();
            Bukkit.broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, player.getName(), ChatColor.GRAY));
            "\u6332\u5684\u51fc\u6565\u5b97".length();
            "\u69dd".length();
        }
        this.lastActivity.remove(player);
        "\u5271\u57ab\u6efa".length();
    }
    
    @EventHandler
    public void onPlayerCommand(final PlayerCommandPreprocessEvent playerCommandPreprocessEvent) {
        final Player player = playerCommandPreprocessEvent.getPlayer();
        this.lastActivity.put(player, System.currentTimeMillis());
        "\u5e75\u510d\u6b19\u5b43\u69b9".length();
        if (this.afkTasks.containsKey(player)) {
            player.setPlayerListName(player.getName());
            this.afkTasks.remove(player).cancel();
            Bukkit.broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, player.getName(), ChatColor.GRAY));
            "\u5a95\u66c4\u6db8\u64f3".length();
        }
    }
    
    @EventHandler
    public void onPlayerChat(final PlayerChatEvent playerChatEvent) {
        final Player player = playerChatEvent.getPlayer();
        if (this.afkTasks.containsKey(player)) {
            player.setPlayerListName(player.getName());
            this.afkTasks.remove(player).cancel();
            this.lastActivity.put(player, System.currentTimeMillis());
            "\u519c\u55ef\u4e6d".length();
            Bukkit.broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, player.getName(), ChatColor.GRAY));
            "\u4f1e\u6cac".length();
            "\u5b81\u6baa\u7091\u6fc3\u5877".length();
            "\u669f".length();
        }
    }
    
    public void saveBanConfig() {
        try {
            this.bannedPlayersConfig.save(this.bannedPlayersFile);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public long parseBanTime(final String s) {
        long n = 1000L;
        if (s.endsWith(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(168848248, 658632625, "\u6411", 1520541403, -210010588))) {
            n = 86400000L;
        }
        else if (s.endsWith(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1452698631, -2089981254, "\u9a08", 1023181743, 417013553))) {
            n = 3600000L;
        }
        else if (s.endsWith(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(981205280, -1244399589, "\uf39a", 1016084288, 512507343))) {
            n = 60000L;
        }
        try {
            final int beginIndex = 0;
            final int length = s.length();
            final int n2 = 1;
            "\u6550\u6a1e\u6fd7\u63aa".length();
            "\u6ba3\u521e\u64ef".length();
            "\u69f5\u6213\u539e".length();
            "\u56db\u62d6\u6f87".length();
            return Long.parseLong(s.substring(beginIndex, length - n2)) * n;
        }
        catch (NumberFormatException ex) {
            return -1L;
        }
    }
    
    public String formatBanTime(final long n) {
        final long n2 = n / 1000L;
        return invokedynamic(makeConcatWithConstants:(JJJ)Ljava/lang/String;, n2 / 86400L, n2 % 86400L / 3600L, n2 % 86400L % 3600L / 60L);
    }
    
    public void banPlayer(final String s, final String s2, final long n) {
        final long long1 = this.bannedPlayersConfig.getLong(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s), 0L);
        final String s3 = s2.split(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1435725072, -139672774, "\u3f9f", 387078414, -66701512))[0];
        this.bannedPlayersConfig.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s), (Object)long1);
        this.bannedPlayersConfig.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s), (Object)s3);
        this.saveBanConfig();
        final Player player = Bukkit.getPlayer(s);
        if (player != null) {
            \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1339345019, 234936025, "", -1172263303, 688105675);
            final long n2 = (long1 - System.currentTimeMillis()) / 1000L;
            String s4;
            if (n2 > 0L) {
                s4 = invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD, n2 / 86400L, ChatColor.GRAY, ChatColor.GOLD, n2 % 86400L / 3600L, ChatColor.GRAY, ChatColor.GOLD, n2 % 86400L % 3600L / 60L, ChatColor.GRAY);
            }
            else {
                s4 = invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD);
            }
            player.kickPlayer(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD, s2, s4));
        }
    }
    
    public String calculateUnmuteTime(final String s) {
        final int beginIndex = 0;
        final int length = s.length();
        final int n = 1;
        "\u5f06\u5740\u5c97\u511c".length();
        final int int1 = Integer.parseInt(s.substring(beginIndex, length - n));
        final int length2 = s.length();
        final int n2 = 1;
        "\u5eb8\u6d2d\u501d".length();
        "\u519c".length();
        final char char1 = s.charAt(length2 - n2);
        final Calendar instance = Calendar.getInstance();
        switch (char1) {
            case 100: {
                instance.add(5, int1);
                break;
            }
            case 104: {
                instance.add(11, int1);
                break;
            }
            case 109: {
                instance.add(12, int1);
                break;
            }
        }
        "\u580e\u5f63\u6b33\u6890\u7012".length();
        return new SimpleDateFormat(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-170042106, 864628524, "\u796f\u7942\u790c\u796d\u796f\u790a\u794a\u7946\u7966\u794a\u7910\u796a\u796f\u790c\u7956\u7942\u790d\u7958\u7972", -2078559734, -421086872)).format(instance.getTime());
    }
    
    public String calculateUnmuteTimeFormatted(final String s) {
        final int beginIndex = 0;
        final int length = s.length();
        final int n = 1;
        "\u617c\u5ce2\u5462\u6069".length();
        final int int1 = Integer.parseInt(s.substring(beginIndex, length - n));
        final int length2 = s.length();
        final int n2 = 1;
        "\u507d\u5709\u681f\u50d6".length();
        "\u58d6".length();
        final char char1 = s.charAt(length2 - n2);
        String s2 = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1740543369, -2091295293, "", 1847349086, 2008529859);
        switch (char1) {
            case 100: {
                s2 = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(780066141, -249700691, "\u6f2f\u6f09\u6b18", -60102247, 1339261233);
                break;
            }
            case 104: {
                s2 = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1176934558, 15549243, "\u18f8\u1cbc", -1121579016, 568211293);
                break;
            }
            case 109: {
                s2 = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(684341937, -1068299928, "\u9145\u9162\u9165\u9576", 934991895, 1663663860);
                break;
            }
        }
        return invokedynamic(makeConcatWithConstants:(ILjava/lang/String;)Ljava/lang/String;, int1, s2);
    }
    
    public void removeExpiredMutes() {
        "\u5b60\u4f45".length();
        "\u520d\u6279".length();
        final File file = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(991979726, 2007248765, "\ud611\ud632\ud628\ud629\ud638\ud673\ud62d\ud637\ud614", 608804631, -1463939429));
        if (!file.exists()) {
            return;
        }
        final YamlConfiguration loadConfiguration = YamlConfiguration.loadConfiguration(file);
        for (final String s : ((FileConfiguration)loadConfiguration).getKeys(false)) {
            final String string = ((FileConfiguration)loadConfiguration).getConfigurationSection(s).getString(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(327328467, 1641868306, "\u5afc\u5aca\u5ac9\u5ad3\u5acc\u5adb\u5ae1\u5ad0\u5af0\u5ad4", -772072308, 526846087));
            if (string != null && this.isUnmuteTimeExpired(string)) {
                ((FileConfiguration)loadConfiguration).set(s, (Object)null);
            }
        }
        try {
            ((FileConfiguration)loadConfiguration).save(file);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public boolean isUnmuteTimeExpired(final String source) {
        "\u6895\u6e54\u5d35".length();
        "\u62e8\u632a\u6165\u6eaf".length();
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1280202429, -1211963442, "\u3987\u39b4\u39fc\u399f\u399f\u39fc\u39a2\u39ac\u398e\u39ac\u39f0\u3988\u398f\u39ea\u39be\u39a8\u39e5\u384e\u3862", 544284911, -1603622852));
        try {
            final Date parse = simpleDateFormat.parse(source);
            "\u6f51\u6c37\u517c".length();
            "\u5428\u58ee\u6eee\u50c1".length();
            "\u5972\u70e4\u542f\u6e01".length();
            "\u4f6f\u5db7\u5f49\u613b".length();
            "\u5a31".length();
            return new Date().after(parse);
        }
        catch (ParseException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public void saveBanIPsConfig() {
        try {
            this.banipLog.save(this.banipFile);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public String calculateUnbanTime(final String s) {
        final int beginIndex = 0;
        final int length = s.length();
        final int n = 1;
        "\u63f8\u6773".length();
        "\u6d69\u62c0".length();
        "\u4f41\u64cc\u5072".length();
        final int int1 = Integer.parseInt(s.substring(beginIndex, length - n));
        final int length2 = s.length();
        final int n2 = 1;
        "\u5816\u631c\u542c".length();
        "\u57d8\u5ac3\u673f\u6ef5".length();
        "\u59e2\u66f5\u54b8\u5b4c\u5ed7".length();
        "\u6d6f\u6c53\u689d\u6375".length();
        final char char1 = s.charAt(length2 - n2);
        final Calendar instance = Calendar.getInstance();
        switch (char1) {
            case 100: {
                instance.add(6, int1);
                break;
            }
            case 104: {
                instance.add(11, int1);
                break;
            }
            case 109: {
                instance.add(12, int1);
                break;
            }
        }
        "\u5e33\u50b5\u541e\u6032".length();
        "\u5aba\u4e43".length();
        "\u56e3\u6f5d".length();
        "\u6711\u6e8c".length();
        return new SimpleDateFormat(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1454087721, -2094272479, "\uf069\uf3ba\uf3f2\uf391\uf391\uf3f2\uf3ac\uf3a2\uf380\uf3a2\uf3fe\uf386\uf381\uf3e4\uf3b0\uf3a6\uf3eb\uf3a0\uf38c", 1491104255, 1361571769)).format(instance.getTime());
    }
    
    public void removeExpiredBanIPs() {
        "\u6791\u4fa7\u62ff\u67eb\u6333".length();
        final File file = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1312120653, -319988652, "\u6aae\u6a8c\u6a8f\u6a82\u6a8b\u6a94\u6ac1\u6a9a\u6aaa\u6a87", 1143602340, 33843907));
        if (!file.exists()) {
            return;
        }
        final YamlConfiguration loadConfiguration = YamlConfiguration.loadConfiguration(file);
        for (final String s : ((FileConfiguration)loadConfiguration).getKeys(false)) {
            final String string = ((FileConfiguration)loadConfiguration).getConfigurationSection(s).getString(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1434280445, 1954219513, "\u70ed\u70db\u70d3\u70d2\u70df\u70e3\u70d9\u70d1\u70f9", 1504617890, 340242813));
            if (string != null && this.isUnbanTimeExpired(string)) {
                ((FileConfiguration)loadConfiguration).set(s, (Object)null);
            }
        }
        try {
            ((FileConfiguration)loadConfiguration).save(file);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public boolean isUnbanTimeExpired(final String source) {
        "\u5cef".length();
        "\u5798\u622b".length();
        "\u6779\u59b2\u51dd\u5ae1\u5b6c".length();
        "\u596d\u567a\u69ff\u5274".length();
        final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(781980954, -110429757, "\ue5f7\ue5da\ue5ac\ue5cd\ue5cf\ue5aa\ue5f2\ue5fe\ue5de\ue5f2\ue5a0\ue5da\ue5df\ue5bc\ue5ee\ue5fa\ue5b5\ue5e0\ue5d2", 185106270, -1204521385));
        try {
            final Date parse = simpleDateFormat.parse(source);
            "\u61ed\u53c4\u5429\u60f1\u6651".length();
            "\u5a30\u7021\u616a\u52b4\u4e34".length();
            return new Date().after(parse);
        }
        catch (ParseException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public void handleIgnoreCommand(final Player player, final String anotherString) {
        if (player.getName().equalsIgnoreCase(anotherString)) {
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
            return;
        }
        final Player player2 = Bukkit.getPlayer(anotherString);
        if (player2 == null || !player2.isOnline()) {
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
            return;
        }
        final List stringList = this.ignoreConfig.getStringList(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, player.getName()));
        if (stringList.contains(player2.getName())) {
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, player2.getName(), ChatColor.GRAY, ChatColor.GRAY));
        }
        else {
            stringList.add(player2.getName());
            "\u70a9\u6e3c\u5239".length();
            "\u61b3\u646e\u4fef\u5e11\u561d".length();
            "\u5186\u5d67".length();
            this.ignoreConfig.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, player.getName()), (Object)stringList);
            this.saveIgnoreConfig();
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, player2.getName(), ChatColor.GRAY, ChatColor.GRAY));
        }
    }
    
    public void handleMessageCommand(final Player player, final String anotherString, final String[] array) {
        if (player.getName().equalsIgnoreCase(anotherString)) {
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
            return;
        }
        final Player player2 = Bukkit.getPlayer(anotherString);
        if (player2 != null && player2.isOnline()) {
            if (this.isIgnored(player2, player.getName())) {
                player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, ChatColor.GRAY, ChatColor.GRAY));
                return;
            }
            final boolean checkMuteStatus = this.checkMuteStatus(player);
            final boolean checkMuteStatus2 = this.checkMuteStatus(player2);
            if (checkMuteStatus || checkMuteStatus2) {
                player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, ChatColor.GRAY));
                return;
            }
            if (this.isIgnored(player, player2.getName())) {
                player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, ChatColor.GRAY));
                return;
            }
            "\u7090\u5d60\u5176\u59de\u6065".length();
            "\u6e50".length();
            "\u5190".length();
            final StringBuilder sb = new StringBuilder();
            for (int i = 1; i < array.length; i -= 26933, i += 26934) {
                sb.append(array[i]).append(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-214782706, 2136750097, "\u4746", 1578477192, -283151182));
                "\u6635\u5ea2".length();
                "\u5709\u69e4\u560e".length();
                "\u668b\u4ed4\u54d7\u69d8".length();
            }
            final String trim = sb.toString().trim();
            final Object[] array2 = new Object[2];
            "\u5ec6\u5c65\u512e".length();
            "\u56af\u5f38".length();
            "\u6c5b\u6eec".length();
            "\u5a79\u6bb0\u50b6\u6b54\u508a".length();
            array2[0] = player.getName();
            "\u5990\u70e1\u6b91".length();
            "\u6e74\u50b7\u5fad\u6d5e".length();
            "\u583c\u6e9f".length();
            final int n = 1;
            final Object[] array3 = new Object[3];
            "\u631d\u607f\u6969\u5fe0".length();
            "\u63a5\u60e7\u66d9".length();
            "\u6e11\u65f7\u572d\u5322".length();
            array3[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-494809629, -1975795665, "\u0d8d\u0daf\u0dbe\u0dbc", 103433517, -1270135537);
            "\u55d5\u6c98".length();
            "\u5cb2\u70a3\u5c4d".length();
            "\u61ae\u66d4".length();
            array3[1] = player2.getName();
            "\u6bc7\u552d\u6f9d".length();
            "\u65e1\u5d4e".length();
            "\u69ac".length();
            "\u7074\u6951".length();
            final int n2 = 2;
            final Object[] array4 = new Object[2];
            "\u6294\u6d01\u5095\u68ce".length();
            "\u5c40\u6a4a\u5acd".length();
            "\u6944\u694a\u6ed7".length();
            "\u6946".length();
            array4[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1941290049, -1408983647, "\uc5da\uc5ef", -697350167, 771251284);
            "\u6d4e".length();
            "\u5846\u65b5\u590b\u5ebd\u604e".length();
            "\u4ff5\u643c\u6378\u6a53".length();
            final int n3 = 1;
            final Object[] array5 = { null };
            "\u5f6b".length();
            array5[0] = trim;
            array4[n3] = StyleUtils.white(array5);
            array3[n2] = StyleUtils.gray(array4);
            array2[n] = StyleUtils.gray(array3);
            final Component gold = StyleUtils.gold(array2);
            player.sendMessage(gold);
            player2.sendMessage(gold);
        }
        else {
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
        }
    }
    
    public boolean isIgnored(final Player player, final String s) {
        return this.ignoreConfig.getStringList(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, player.getName())).contains(s);
    }
    
    public void saveIgnoreConfig() {
        try {
            this.ignoreConfig.save(this.ignoreFile);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public void handleUnignoreCommand(final Player player, final String anotherString) {
        final Player player2 = Bukkit.getPlayer(anotherString);
        if (player2 != null && player2.isOnline()) {
            if (player.getName().equalsIgnoreCase(anotherString)) {
                player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
                return;
            }
            final List stringList = this.ignoreConfig.getStringList(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, player.getName()));
            if (stringList.contains(anotherString)) {
                stringList.remove(anotherString);
                "\u53ac\u5941\u53be\u4ed2\u6587".length();
                "\u70d9".length();
                this.ignoreConfig.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, player.getName()), (Object)stringList);
                this.saveIgnoreConfig();
                player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, anotherString, ChatColor.GRAY, ChatColor.GRAY));
            }
            else {
                player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, anotherString, ChatColor.GRAY, ChatColor.GRAY));
            }
        }
        else {
            player.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
        }
    }
    
    public void checkHiddenPlayers() {
        this.hiddenPlayers.entrySet().removeIf(entry -> entry.getValue() <= System.currentTimeMillis());
        "\u5352\u6fa2\u5edd".length();
        "\u55a1\u5930\u5063".length();
        "\u6214".length();
    }
    
    public boolean isPlayerHidden(final Player key) {
        final Long n = this.hiddenPlayers.get(key);
        return n != null && n > System.currentTimeMillis();
    }
    
    public String getDirectionArrow(final Player player, final Player player2) {
        final String[] array = new String[8];
        "\u6abe\u5833".length();
        "\u6856\u4e5a\u689b\u55aa".length();
        array[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(658404525, 998881212, "\ue825", -1683679883, -186835055);
        "\u5db1\u6a9a\u6411\u699d".length();
        "\u6da2\u4f1d\u6aaf\u6d5a".length();
        array[1] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-34075893, 1673344868, "\ucd75", -301073423, -1886770383);
        "\u6800".length();
        "\u6dc0\u6d39\u53ab\u52bb".length();
        array[2] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(509180459, -1262655000, "\ub753", -1534556112, -1432023693);
        "\u5833\u66c0\u599e\u5ed6".length();
        array[3] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-984127891, -138626578, "\ua2bb", -574516435, -2097229888);
        "\u5ae6\u5b38\u5f8d\u6267\u5b85".length();
        array[4] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-852309501, 779011498, "\ub1c4", 804047504, 2031244591);
        "\u7001\u62b3\u570a\u6706".length();
        array[5] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-976450993, 524832379, "\u2c13", -503630759, -444793430);
        "\u63cf\u5f88".length();
        "\u4fd5\u4f4d\u6d2e\u63a6".length();
        array[6] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-79112601, -1198299646, "\u3257", -708248696, -1250011029);
        "\u5f82\u6455\u6c3c\u548a".length();
        "\u522e\u511b\u4ff7\u5dd4\u5f46".length();
        "\u6f02".length();
        array[7] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(158754482, -2095364719, "\ua3c3", -588445446, 565488065);
        final String[] array2 = array;
        final int n = (int)Math.round((player.getLocation().getDirection().angle(player2.getLocation().subtract(player.getLocation()).toVector()) + 3.141592653589793) / 0.7853981633974483 % 8.0);
        final double distance = player.getLocation().distance(player2.getLocation());
        final String \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1296007346, -448397403, "\ue2a5\ue283\ue2a0\ue2f5", -479914658, -285509770);
        final Object[] args = { null };
        "\u5ec6".length();
        "\u6721\u5e8a\u6599\u5cd8\u570b".length();
        args[0] = distance;
        return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, array2[n], String.format(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d, args));
    }
    
    public boolean onCommand(final CommandSender commandSender, final Command command, final String s, final String[] original) {
        if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1427541605, 951705409, "\ucbe3\ucbc3\ucbc5\ucbd6\ucbd4\ucbd3\ucbc6\ucbd2\ucbed\ucbda\ucbd9\ucbc8", -683868661, 967613215))) {
            if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1420029333, -1991389958, "\u7b92\u7ba2\u7a42\u7a4d\u7a5d\u7a06\u7a46\u7a4f\u7a66\u7a4e\u7a42", -1657529602, 687882285)) && !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1876014416, -1824647577, "\ubcc8\ubcf8\ubce4\ubceb\ubce7\ubcbc\ubcf7\ubcf0\ubcd0\ubcef\ubcea\ubce7\ubcf2\ubcf9\ubce5\ubcec\ubcf6\ubceb", 879346060, -1293409859))) {
                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
                return true;
            }
            if (!(commandSender instanceof Player)) {
                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED));
                return true;
            }
            final Player obj = (Player)commandSender;
            if (original.length < 4) {
                obj.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                return true;
            }
            double double1;
            double double2;
            double double3;
            try {
                double1 = Double.parseDouble(original[0]);
                double2 = Double.parseDouble(original[1]);
                double3 = Double.parseDouble(original[2]);
            }
            catch (NumberFormatException ex5) {
                obj.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY));
                return true;
            }
            int n = 0;
            Label_4633: {
                if (original.length > 3) {
                    try {
                        n = Integer.parseInt(original[3]);
                        break Label_4633;
                    }
                    catch (NumberFormatException ex6) {
                        obj.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY));
                        return true;
                    }
                }
                n = this.config.getInt(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1401377536, -442686006, "\u9316\u932e\u9329\u9324\u9338\u9306", 166744347, 1210206966), 100);
            }
            "\u58fb\u5d42\u4e83".length();
            "\u587d\u6f3f".length();
            "\u6e43\u52e3".length();
            final Location location = new Location(obj.getWorld(), double1, double2, double3);
            obj.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;ILorg/bukkit/ChatColor;DDD)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, n, ChatColor.GRAY, double1, double2, double3));
            int n2 = 0;
            for (final Player player : Bukkit.getOnlinePlayers()) {
                if (!player.equals(obj)) {
                    if (this.isPlayerHidden(player)) {
                        continue;
                    }
                    if (player.getLocation().distance(location) > n) {
                        continue;
                    }
                    obj.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.GOLD, player.getName(), ChatColor.GRAY, this.getDirectionArrow(obj, player)));
                    n2 -= 505;
                    n2 += 506;
                }
            }
            if (n2 == 0) {
                obj.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY));
            }
            else {
                obj.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;I)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, n2));
            }
            return true;
        }
        else if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1599433337, -1502786931, "\u9d42\u9d66\u9d60\u9d7f", -728761867, -158579602))) {
            if (!(commandSender instanceof Player)) {
                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED));
                return true;
            }
            final Player obj2 = (Player)commandSender;
            if (original.length == 1 && original[0].equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1809946488, -310323445, "\u7306\u733e\u7335\u733a\u7334\u7335", 2027747381, -464636799))) {
                if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1686386824, 973356577, "\u4bb8\u4b88\u4b94\u4b9b\u4b8f\u4bd4\u4b90\u4b99\u4bbc\u4b94\u4b94", -125196000, -672916497)) && !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1715623743, -838695394, "\uddde\uddec\uddf2\uddfb\udde9\uddb0\uddf9\uddc0\udde6\udddb\uddde\udddd\uddd3\uddc3\uddce\uddd1", 883279385, 1903834422))) {
                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
                    return true;
                }
                this.reloadConfig();
                this.nearConfig = this.getConfig();
                obj2.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD));
                return true;
            }
            else {
                if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1500537243, 1224794446, "\uaf06\uaf36\uaf2e\uaf21\uaf31\uaf6a\uaf22\uaf2b\uaf02\uaf2a\uaf2e", 1527281538, 1045014401)) && !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-971299053, 1918198463, "\ubfca\ubffa\ubfe6\ubfe9\ubfe5\ubfbe\ubff5\ubff2\ubfd2\ubfed", 1324337420, 155857732))) {
                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
                    return true;
                }
                int n3 = this.nearConfig.getInt(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-483653867, 1516239597, "\ub8b8\ub886\ub883\ub88c\ub88e\ub88e", 1728669196, -1203166339), 100);
                if (original.length > 0) {
                    try {
                        n3 = Integer.parseInt(original[0]);
                    }
                    catch (NumberFormatException ex7) {
                        obj2.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY));
                        return true;
                    }
                }
                obj2.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;ILorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, n3, ChatColor.GRAY));
                int n4 = 0;
                for (final Player player2 : Bukkit.getOnlinePlayers()) {
                    if (!player2.equals(obj2)) {
                        if (this.isPlayerHidden(player2)) {
                            continue;
                        }
                        if (obj2.getLocation().distance(player2.getLocation()) > n3) {
                            continue;
                        }
                        obj2.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.GOLD, player2.getName(), ChatColor.GRAY, this.getDirectionArrow(obj2, player2)));
                        n4 -= 27050;
                        n4 += 27051;
                    }
                }
                if (n4 == 0) {
                    obj2.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY));
                }
                else {
                    obj2.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;I)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, n4));
                }
                return true;
            }
        }
        else {
            if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1334487558, -1321480584, "\ufb53\ufb75\ufb75\ufb64\ufb7c\ufb7b\ufb71\ufb7c", -1003246910, -1145686590))) {
                if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1002384440, -737208410, "\u54cd\u54fb\u54e5\u54e8\u54fa\u555f\u5519\u5512\u5539\u5517\u5515", 2059298043, 1467878278)) && !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1358982767, -103868007, "\ud19a\ud1aa\ud1b6\ud1b9\ud1ad\ud1f6\ud1bd\ud1ba\ud192\ud1ad\ud1b0\ud1a3\ud1af\ud1bf", 1171419104, -1453340254))) {
                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED, ChatColor.GRAY));
                    return true;
                }
                if (!(commandSender instanceof Player)) {
                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED));
                    return true;
                }
                final Player key = (Player)commandSender;
                if (original.length >= 1) {
                    try {
                        this.hideDurationInSeconds = Long.parseLong(original[0]);
                    }
                    catch (NumberFormatException ex8) {
                        key.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED));
                        return true;
                    }
                }
                if (original.length >= 2) {
                    final Player player3 = Bukkit.getPlayer(original[1]);
                    if (player3 == null) {
                        key.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.RED));
                        return true;
                    }
                    this.hiddenPlayers.put(player3, System.currentTimeMillis() + this.hideDurationInSeconds * 1000L);
                    "\u5e47".length();
                    key.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, player3.getName(), ChatColor.GRAY, ChatColor.GOLD, this.hideDurationInSeconds, ChatColor.GRAY));
                }
                else {
                    this.hiddenPlayers.put(key, System.currentTimeMillis() + this.hideDurationInSeconds * 1000L);
                    "\u59b4".length();
                    "\u6a8a\u5143\u7023".length();
                    key.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, ChatColor.GRAY, ChatColor.GOLD, this.hideDurationInSeconds, ChatColor.GRAY));
                }
            }
            if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(623833883, 1034567165, "\u9a06\u9a23\u9a28\u9a29\u9a34\u9a3b", 2094845803, 1052220321))) {
                if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1217900072, 852792807, "\ua15c\ua16e\ua170\ua171\ua163\ua13a\ua17c\ua173\ua158\ua172\ua170", 276806021, 1866259656)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1855432541, 1195275635, "\u6411\u643f\u6421\u642c\u643e\u6463\u642d\u642d\u6406\u6425\u643d\u643a", 2064873359, 1168784992))) {
                    if (commandSender instanceof Player) {
                        if (original.length < 1) {
                            final Object[] array = new Object[2];
                            "\u5387\u5dfa\u6e25\u6b2f".length();
                            "\u60b3\u5776\u5912\u66ee".length();
                            "\u5cf2\u5bfe".length();
                            "\u68c9".length();
                            "\u667b\u543c\u66cf\u6611\u63a5".length();
                            array[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-227888129, 739650806, "\ud91d\ud967\ud91b\ud91a\ud91f\ud968\ud91a\ud91d\ud933\ud903\ud90b\ud91e\ud914\udd16\ud90f\ud91d\ud905\ud91b\ud93a\u8a8b\u8da6\u8a9d\u81e7", 894765895, 357124360);
                            "\u6676\u525a".length();
                            "\u6199".length();
                            final int n5 = 1;
                            final Object[] array2 = new Object[2];
                            "\u6990\u6731\u51d0".length();
                            array2[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(386394331, 1679571371, "\ue9e0\ue989\ue985\ue980\ue981\ue998\ue986\ue9c9\ue990\uedfd\uedd3\ued8c\uedf5\uede2\ue986", 209817877, -1253529111);
                            "\u6388\u5aaf\u68e2\u5e0e\u66e6".length();
                            "\u636d\u5b5f\u5a89\u5df5\u624b".length();
                            "\u5cbd\u630a\u5315\u4fac\u7002".length();
                            final int n6 = 1;
                            final Object[] array3 = { null };
                            "\u5bad\u691b\u6c00\u4f3c".length();
                            "\u6416\u5ce1\u6ac2".length();
                            array3[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(266135269, 629456981, "\u43b8", -2043482534, -1859679440);
                            array2[n6] = StyleUtils.gray(array3);
                            array[n5] = StyleUtils.gold(array2);
                            commandSender.sendMessage(StyleUtils.gray(array));
                            return false;
                        }
                        this.handleIgnoreCommand((Player)commandSender, original[0]);
                    }
                }
                else {
                    final Object[] array4 = new Object[2];
                    "\u649b\u6d94".length();
                    "\u5a4b".length();
                    "\u58cd\u6c80\u6210".length();
                    array4[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1747228066, 1582307449, "\uc2c8\uc6e6\uc2f4\uc2f4\uc283\uc6e4\uc2f2\uc2f6\uc2ad\uc6e3\uc2fb\uc296\uc2e7\uc2f4", 1087451872, 1531020911);
                    "\u676c".length();
                    final int n7 = 1;
                    final Object[] array5 = { null };
                    "\u5f67\u54e3\u5908\u5cb6\u5738".length();
                    "\u53dd".length();
                    array5[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1400400396, 2033170158, "\u9116", -2091489320, 2103498166);
                    array4[n7] = StyleUtils.gray(array5);
                    commandSender.sendMessage(StyleUtils.red(array4));
                }
                return true;
            }
            if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-731241870, 1267375661, "\u0174\u0151\u0147\u0145\u0159\u0159\u0150", -533945804, 1698963249))) {
                if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2083779773, 1557576599, "\ub186\ub1b6\ub1ae\ub1a1\ub1b1\ub1ea\ub192\ub19b\ub1b2\ub19a\ub19e", -2066543782, 1164380710)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-529806064, 734053310, "\uf8a4\uf896\uf888\uf881\uf893\uf8ca\uf880\uf8fa\uf8ce\uf8e0\uf8f7\uf8e5\uf8e0", -210806471, 112504605))) {
                    if (commandSender instanceof Player) {
                        if (original.length < 2) {
                            final Object[] array6 = new Object[2];
                            "\u6345\u63ab\u67a8\u5dc5".length();
                            array6[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1524164275, -2113882668, "\u3c64\u3c10\u3c6e\u3c6d\u3c66\u3c17\u3c67\u3c62\u3c4a\u3c64\u3c6e\u3c79\u3d8d\u3989\u3d92\u3d82\u3d9c\u3d8c\u3daf\u6e1c\u693f\u6e02\u657a", -2085165324, -1376947630);
                            "\u5621\u708d".length();
                            final int n8 = 1;
                            final Object[] array7 = new Object[2];
                            "\u5e4b\u6525".length();
                            "\u553a\u56ff\u5b0b\u6b26".length();
                            array7[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1271220544, 787230341, "\u73d9\u73b4\u73be\u73a4\u73a4\u73b2\u73bd\u73b5\u73d2\u7387\u77c1\u77e6\u7792\u77ff\u77f8\u738d\u73ea\u738f\u77d9\u2472\u2320\u2061\u2b79\u143b\u1eaa\u1708\u1945\u1140", -258635355, 6594005);
                            "\u66e2\u506a".length();
                            "\u4e5d\u592f".length();
                            final int n9 = 1;
                            final Object[] array8 = { null };
                            "\u51ce\u5feb\u56c7\u57c4\u598e".length();
                            "\u70d5".length();
                            "\u4e2d\u66e0".length();
                            array8[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-383075715, 1629867857, "\udca8", -338508031, 838430439);
                            array7[n9] = StyleUtils.gray(array8);
                            array6[n8] = StyleUtils.gold(array7);
                            commandSender.sendMessage(StyleUtils.gray(array6));
                            return false;
                        }
                        this.handleMessageCommand((Player)commandSender, original[0], original);
                    }
                    return true;
                }
                final Object[] array9 = new Object[2];
                "\u5b50\u534d".length();
                array9[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1650876977, -667700160, "\u7e3a\u7a14\u7e0a\u7e0a\u7e79\u7a1e\u7e0c\u7e08\u7e5f\u7a11\u7e15\u7e78\u7e0d\u7e1e", -449693498, -681470739);
                "\u57f4\u67a2\u6f4d".length();
                "\u6f59\u696e".length();
                final int n10 = 1;
                final Object[] array10 = { null };
                "\u5d37\u6a46\u68dd\u627b\u5d55".length();
                "\u4e98".length();
                "\u5f45".length();
                array10[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1318836063, -1269189798, "\u97ee", -1538116196, 520501739);
                array9[n10] = StyleUtils.gray(array10);
                commandSender.sendMessage(StyleUtils.red(array9));
                return true;
            }
            else if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-414849850, 911571428, "\ufd79\ufd4f\ufd4c\ufd40\ufd4b\ufd4c\ufd56\ufd4d", 1085566994, -1485041537))) {
                if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-840558371, -1282742788, "\ud14b\ud17b\ud167\ud168\ud164\ud13f\ud17b\ud172\ud15f\ud177\ud177", -775704788, -479296664)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-302146676, -1355742231, "\ubbe6\ubbd6\ubbce\ubbc1\ubbd1\ubb8a\ubb26\ubb31\ubb16\ubb34\ubb3e\ubb2d\ubb35\ubb33", -986083462, 1385999575))) {
                    if (commandSender instanceof Player) {
                        if (original.length < 1) {
                            final Object[] array11 = new Object[2];
                            "\u6053\u5067\u6daf".length();
                            "\u651d\u66b8".length();
                            array11[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-69137808, 586408774, "\u0828\u085e\u0822\u0827\u0822\u0851\u0823\u0828\u0806\u082a\u0822\u0833\u0839\u0c3f\u0826\u0808\u0810\u0802\u0823\u5b96\u5cbb\u5b84\u50fe", -973245487, -925985132);
                            "\u5152".length();
                            "\u5e84\u6ed5".length();
                            "\u6f14\u5cb5\u5b45".length();
                            final int n11 = 1;
                            final Object[] array12 = new Object[2];
                            "\u6ef6\u712d".length();
                            "\u60a4\u566a\u6103\u6d4f".length();
                            "\u6d1d\u6007\u5b3d\u632d\u6c13".length();
                            array12[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1314731019, -959557253, "\u8cf4\u8c83\u8c9c\u8c99\u8c95\u8c9a\u8c8c\u8c9d\u8caa\u8cc3\u8cbb\u88ea\u88c4\u88a6\u88d5\u88c5\u8cba", -176587638, -1278503582);
                            "\u65ee\u6e01".length();
                            "\u6f77".length();
                            "\u6f8d\u57aa\u7069\u532e".length();
                            "\u5647\u5b5a".length();
                            "\u6cf6".length();
                            final int n12 = 1;
                            final Object[] array13 = { null };
                            "\u51c3\u63f2\u6f31\u5409".length();
                            array13[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(433998666, -1949086158, "\ue2be", -911928868, -1704921480);
                            array12[n12] = StyleUtils.gray(array13);
                            array11[n11] = StyleUtils.gold(array12);
                            commandSender.sendMessage(StyleUtils.gray(array11));
                            return false;
                        }
                        this.handleUnignoreCommand((Player)commandSender, original[0]);
                    }
                    return true;
                }
                final Object[] array14 = new Object[2];
                "\u5b41\u5951\u712f".length();
                "\u6c2b\u6571".length();
                "\u61b3\u6e0c".length();
                array14[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1198669364, 1891013970, "\ua007\ua42b\ua03b\ua005\ua074\ua411\ua005\ua007\ua052\ua41e\ua004\ua067\ua010\ua001", 1340758173, 403789724);
                "\u53bc\u6e9a\u55db\u6fd8\u4f62".length();
                "\u5670\u4e45".length();
                "\u68f6".length();
                final int n13 = 1;
                final Object[] array15 = { null };
                "\u659c\u6f9f\u64ce\u57f9\u590c".length();
                array15[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1079646737, 1398970242, "\u7782", 413701517, -1683517440);
                array14[n13] = StyleUtils.gray(array15);
                commandSender.sendMessage(StyleUtils.red(array14));
                return true;
            }
            else if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1491796905, 972146787, "\uae21\uae13\uae19\uae04\uae16\uae15\uae13\uae1a\uae21", 823832295, -2114467013))) {
                if (commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-99970700, 818469868, "\u499c\u49ac\u49b0\u49bf\u49ab\u49f0\u49b4\u49bd\u49e8\u49c0\u49c0", 1309004728, 1186779282)) && !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1042808674, -1223664187, "\u804d\u807d\u8065\u806a\u807a\u8021\u807c\u8061\u8049\u8078\u8069\u8078\u8072\u8064\u8060", -692526334, -858177990))) {
                    final Object[] array16 = new Object[2];
                    "\u5a79".length();
                    "\u668d".length();
                    "\u5374".length();
                    array16[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(98558483, 236971615, "\uf5dd\uf1f3\uf5e5\uf5e5\uf596\uf1f1\uf5fb\uf5ff\uf5a8\uf1e6\uf5fa\uf597\uf5e2\uf5f1", -1616120182, -1384840325);
                    "\u55b7\u6796\u5fcd".length();
                    "\u6fa5\u5954".length();
                    "\u59cf\u50c8\u5e6d\u4f5e\u5f94".length();
                    "\u5d55\u6b47".length();
                    "\u61f0\u57c1\u5f13\u653a\u6579".length();
                    final int n14 = 1;
                    final Object[] array17 = { null };
                    "\u6bb9\u6cfe\u6ffc\u6ca1\u5680".length();
                    array17[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1162077201, -640902643, "\u690f", -1182701728, 749113327);
                    array16[n14] = StyleUtils.gray(array17);
                    commandSender.sendMessage(StyleUtils.red(array16));
                    return true;
                }
                if (original.length < 2) {
                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                    return true;
                }
                final String s2 = original[0];
                final String s3 = original[1];
                final String s4 = (original.length > 2) ? String.join(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-491281989, 569355759, "\ub1cd", 1611331996, 486753382), (CharSequence[])Arrays.copyOfRange(original, 2, original.length)) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-26642165, 1884873632, "\uf1e7\uf1e7\uf197\uf196\uf19b\uf1e0\uf1e3\uf1ea\uf1fb\uf5c2\uf1da\uf1b7\uf1c6\uf1d5\uf1de\uf1c9\uf5c6\uf1bb\uf1e1\ua22e\ua508\ua643\uad54\u921c", 823508504, 545509642);
                "\u5529\u5883\u592b\u6cf4\u691b".length();
                "\u6763\u4f2b\u572a".length();
                final File file = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-554256907, 1946015512, "\uee28\uee0a\uee09\uee04\uee05\uee1a\uee4f\uee14\uee1c\uee31", -1139443816, -137888909));
                if (!file.exists()) {
                    this.saveResource(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1932865648, 1416370116, "\u5408\u5428\u5429\u5422\u5425\u5438\u546f\u543a\u540c\u5423", -1932969455, 979744355), false);
                }
                final YamlConfiguration loadConfiguration = YamlConfiguration.loadConfiguration(file);
                String s5;
                if (s2.contains(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(603840042, -2043313164, "\uafbf", 734444918, 1459244922))) {
                    s5 = s2.replace(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1350341224, 1714400574, "\ud2f2", 729454918, 1558219647), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1136448936, 1102155700, "\u98cd", -596783938, 542838387));
                }
                else {
                    final Player player4 = commandSender.getServer().getPlayer(s2);
                    if (player4 == null) {
                        commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s2, ChatColor.GRAY));
                        return true;
                    }
                    s5 = player4.getAddress().getAddress().getHostAddress().replace(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1830953524, -151248696, "\u8242", 1262844004, -1213921457), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1885769247, -1722575648, "\u538f", -1613666531, -904212081));
                }
                final ConfigurationSection configurationSection = ((FileConfiguration)loadConfiguration).getConfigurationSection(s5);
                if (configurationSection != null) {
                    final String string = configurationSection.getString(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(903317916, -1550496259, "\u14e4\u14d2\u14de\u14df\u14de\u14e2\u14d4\u14dc\u14f0", 1667168628, 2006788551), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1281029117, -91902812, "", 337476608, -924704568));
                    if (!string.equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1823921567, -1073342690, "\uf67e\uf654\uf659\uf65e\uf64f\uf656\uf65b\uf651", -722834383, 393238753))) {
                        try {
                            "\u55fa\u5e5f\u54ac\u5a40\u5aa9".length();
                            "\u6848\u55ff\u5380".length();
                            "\u6949\u5dd3\u5639\u5f31\u5270".length();
                            final Date parse = new SimpleDateFormat(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1856071358, -846953549, "\u6f4a\u6f67\u6f2d\u6f4c\u6f4a\u6f2f\u6f73\u6f7f\u6f53\u6f7f\u6f21\u6f5b\u6f5a\u6f39\u6f6f\u6f7b\u6f08\u6f5d\u6f73", -1258162736, -1111982004)).parse(string);
                            final long currentTimeMillis = System.currentTimeMillis();
                            if (currentTimeMillis <= parse.getTime()) {
                                final long n15 = parse.getTime() - currentTimeMillis;
                                final long n16 = n15 / 1000L % 60L;
                                final long n17 = n15 / 60000L % 60L;
                                final long n18 = n15 / 3600000L % 24L;
                                final long n19 = n15 / 86400000L;
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s2, ChatColor.GRAY, ChatColor.GOLD, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, (n19 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n19) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1902921529, -1306523982, "", 196244589, -546298720), (n18 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n18) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1288266963, 506727946, "", 1519014599, 349140540), (n17 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n17) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-800338556, -831643855, "", 1834441777, -1916231180), (n16 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n16) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1472621105, -253439618, "", -785420786, 1896740918)), ChatColor.GRAY, ChatColor.GOLD, s4));
                                return true;
                            }
                        }
                        catch (ParseException ex9) {}
                    }
                    else {
                        commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s2, ChatColor.GRAY, ChatColor.GOLD, ChatColor.GRAY, ChatColor.GOLD, s4));
                    }
                }
                final ConfigurationSection section = ((FileConfiguration)loadConfiguration).createSection(s5);
                section.set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1490821058, 1499389789, "\u9e1b\u9e2f\u9e21\u9e2e\u9e21\u9e1f\u9e2b\u9e25\u9e0f", 199997125, 143648887), (Object)this.calculateUnbanTime(s3));
                section.set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(277160411, -2031535150, "\u1eb6\u1e8c\u1e88\u1e98\u1e82\u1e85", -201865496, -1851866522), (Object)s4);
                try {
                    ((FileConfiguration)loadConfiguration).save(file);
                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s2, ChatColor.GRAY, ChatColor.GOLD, this.calculateUnmuteTimeFormatted(s3), ChatColor.GRAY, ChatColor.GOLD, s4, ChatColor.GRAY));
                }
                catch (IOException ex) {
                    final Object[] array18 = { null };
                    "\u641c\u5c21\u4f44\u6a23".length();
                    "\u5773".length();
                    array18[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(486178212, 1767541936, "\u436b\u431b\u4367\u4365\u436a\u4367\u4318\u4379\u4350\u476e\u4375\u4317\u4360\u437a\u4372\u4362\u4768\u4369\u433a\u10fe\u13b4\u149b\u1f84\u20b9\u2a25\u23f2\u2dbf\u21a2\u120a\u2110\u1242\u2090\u126d\u1a7e\u2779\u1f8a\u1a6d\u2d6d\u158d", 1739298729, 797647242);
                    commandSender.sendMessage(StyleUtils.red(array18));
                    ex.printStackTrace();
                }
                return true;
            }
            else {
                if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1835413819, -435836341, "\u5d8f\u5da7\u5da9\u5daa\u5da5\u5da2\u5db2", 1770405871, -271189722))) {
                    if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1754853593, 1294577587, "\u258e\u25be\u25a2\u25ad\u25a1\u25fa\u25be\u25b7\u259a\u25b2\u25b2", -1755174900, -2048961850)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1609120523, 479182194, "\u0a70\u0a4e\u0a50\u0a5d\u0a4f\u0a12\u0a40\u0a55\u0a7b\u0a6a\u0a60\u0a77\u0a69", -2134672937, -629405170))) {
                        if (original.length < 1) {
                            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                            return true;
                        }
                        final String s6 = original[0];
                        final String replace = s6.replace(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1770861610, -1197650441, "\u1bf0", -814856536, 251667688), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(182886440, 977172925, "\u4724", 1437188029, -18210544));
                        if (!this.banipLog.contains(replace)) {
                            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s6, ChatColor.GRAY));
                            return true;
                        }
                        this.banipLog.set(replace, (Object)null);
                        this.saveBanIPsConfig();
                        commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s6, ChatColor.GRAY));
                    }
                    else {
                        final Object[] array19 = new Object[2];
                        "\u5a22".length();
                        "\u67a4\u6f23\u571e".length();
                        "\u5a82\u6591\u5dbe\u5c52".length();
                        "\u57be\u6f56\u6f3d".length();
                        "\u655b\u6c7b\u7077\u5bde".length();
                        array19[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1147475110, -1873208831, "\u2e20\u2a0c\u2e1c\u2e22\u2e53\u2a36\u2e22\u2e20\u2e75\u2a39\u2e23\u2e40\u2e37\u2e26", -625681891, -1931345658);
                        "\u5ca7\u61ab\u6f8b".length();
                        "\u5d4a\u607e\u6365".length();
                        "\u6501".length();
                        final int n20 = 1;
                        final Object[] array20 = { null };
                        "\u6df1\u6814\u66f2\u6a71".length();
                        "\u6426\u54e1\u5716\u6f0d\u5978".length();
                        array20[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1852549752, 541663486, "\u55ce", 697094047, -844164939);
                        array19[n20] = StyleUtils.gray(array20);
                        commandSender.sendMessage(StyleUtils.red(array19));
                    }
                    return true;
                }
                if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1161864834, -2006783321, "\uf2a3\uf293\uf29e\uf299\uf280", -692331665, 701851080))) {
                    if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(632184099, -35128107, "\ufaf6\ufac6\ufade\ufad1\ufac1\ufa9a\ufad2\ufadb\ufaf2\ufada\ufade", 1809818274, 1256847756)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-584310400, 935860371, "\u260e\u263c\u2622\u262b\u2639\u2660\u2625\u2624\u2609\u2620\u263c", 151363969, 1743765170))) {
                        if (original.length < 1) {
                            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                            return true;
                        }
                        final String s7 = original[0];
                        if (s7.contains(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-729082706, 376049966, "\u2cb5", -1673320720, -1388441688))) {
                            final String replace2 = s7.replace(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1679380455, 2092940769, "\u8ece", -1633196533, -816519856), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-912845379, -944048907, "\u91d0", -278163259, 681173057));
                            if (this.banipLog.contains(replace2)) {
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s7, ChatColor.GRAY));
                                return true;
                            }
                            this.banipLog.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, replace2), (Object)\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1019059184, -1629903446, "\u39a1\u398b\u3986\u3999\u3988\u3991\u399c\u399e", -1524588947, 173840825));
                            this.banipLog.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, replace2), (Object)\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(53224297, 1649763996, "\udb9f\udb9f\udbeb\udbea\udbe3\udb98\udb87\udb8e\udba3\udf9a\udb86\udbeb\udb9e\udb8d\udb8a\udb9d\udf9e\udbe3\udbbd\u8872\u8f50\u8c1b\u8730\ub878", 1382914122, -1046347138));
                            this.saveBanIPsConfig();
                            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s7, ChatColor.GRAY));
                        }
                        else {
                            final Player player5 = commandSender.getServer().getPlayer(s7);
                            if (player5 == null) {
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s7, ChatColor.GRAY));
                                return true;
                            }
                            final String hostAddress = player5.getAddress().getAddress().getHostAddress();
                            final String replace3 = hostAddress.replace(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1633768163, 621443589, "\u750c", 2113443130, -370854077), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-978300185, 1604471054, "\u199c", -1703165626, 1301922607));
                            if (this.banipLog.contains(replace3)) {
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s7, ChatColor.GRAY));
                                return true;
                            }
                            this.banipLog.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, replace3), (Object)\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-259011198, 2054590678, "\u0286\u02ac\u02a1\u02a6\u02b7\u02ae\u02a3\u02a9", -251595439, 1930275500));
                            this.banipLog.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, replace3), (Object)\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1806208286, 1477200565, "\ud36c\ud36c\ud300\ud301\ud308\ud373\ud374\ud37d\ud350\ud769\ud37d\ud310\ud365\ud376\ud379\ud36e\ud76d\ud310\ud376\u80b9\u879b\u84d0\u8fc3\ub08b", -192170162, 131639255));
                            this.saveBanIPsConfig();
                            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, hostAddress, ChatColor.GRAY, ChatColor.GOLD, s7, ChatColor.GRAY));
                        }
                    }
                    else {
                        final Object[] array21 = new Object[2];
                        "\u5803\u6f25\u6f20\u5704".length();
                        "\u574f".length();
                        "\u543f\u5daa\u6916".length();
                        "\u61c7\u62b2\u7122".length();
                        array21[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-860315607, -1875290878, "\u46fd\u42d5\u46c5\u46c7\u46b6\u42cf\u46db\u46dd\u4688\u42c0\u46da\u46b5\u46c2\u46df", 694008907, 1153043453);
                        "\u52de\u5cd7".length();
                        "\u5212\u6fac\u5cc3\u50e7\u5454".length();
                        final int n21 = 1;
                        final Object[] array22 = { null };
                        "\u6276\u541b\u518a\u5795\u6a27".length();
                        "\u6982\u6a00\u550c".length();
                        "\u55e0\u5ad7\u5433\u6a9b".length();
                        "\u6331\u5bd6\u6dec\u5fd8".length();
                        array22[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(88442009, 1163329342, "\u3558", 1898265241, -18975740);
                        array21[n21] = StyleUtils.gray(array22);
                        commandSender.sendMessage(StyleUtils.red(array21));
                    }
                    return true;
                }
                if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1767859195, -1589345721, "\u741d\u742b\u7423\u7422\u742f", 275246786, -160004949))) {
                    if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-150116900, 104128049, "\u4924\u4914\u4908\u4907\u4913\u4948\u490c\u4905\u4930\u4918\u4918", -212224088, -834648753)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(789171638, 250719331, "\u531b\u532b\u5333\u533c\u532c\u5377\u532b\u533c\u5310\u533f\u5333", -1296138494, -227652126))) {
                        if (original.length < 1) {
                            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                            return true;
                        }
                        final String s8 = original[0];
                        if (this.bannedPlayersConfig.contains(s8)) {
                            this.bannedPlayersConfig.set(s8, (Object)null);
                            this.saveBanConfig();
                            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s8, ChatColor.GRAY));
                            return true;
                        }
                        commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s8, ChatColor.GRAY));
                    }
                    else {
                        final Object[] array23 = new Object[2];
                        "\u7024\u7132".length();
                        "\u6584".length();
                        "\u55ec\u6d68".length();
                        array23[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1509994664, 1382838196, "\u12d0\u16fc\u12ec\u12f2\u1283\u16e6\u12f2\u12f0\u12a5\u16e9\u12f3\u1290\u12e7\u12f6", -704857779, 1248431889);
                        "\u5407\u6589\u5aad\u5ebd".length();
                        "\u5b8f\u6df4".length();
                        final int n22 = 1;
                        final Object[] array24 = { null };
                        "\u6cba".length();
                        array24[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1064068964, -501419705, "\u7769", -1622670971, -901848915);
                        array23[n22] = StyleUtils.gray(array24);
                        commandSender.sendMessage(StyleUtils.red(array23));
                    }
                }
                if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-559118083, 1968235642, "\u2548\u257c\u257d\u2579\u2578\u256d", 1693083693, 1977360852))) {
                    if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-396918935, -1934508579, "\u4ea0\u4e96\u4e88\u4e85\u4e97\u4ed2\u4e94\u4e9f\u4eb4\u4e9a\u4e98", -743694453, 1547015089)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-49379316, -1286672506, "\u3cf4\u3cc6\u3cd8\u3cd9\u3ccb\u3c92\u3cc0\u3cd1\u3cf0\u3cc6\u3cc2\u3cff", 1758035925, -909368187))) {
                        if (original.length < 1) {
                            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                            return true;
                        }
                        final String s9 = original[0];
                        "\u5a00\u5bcc\u6a2e".length();
                        final File file2 = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(622373172, -1977542213, "\u34aa\u3485\u349f\u349a\u348b\u34c4\u349a\u34fc\u34df", -234684487, 2116910002));
                        if (!file2.exists()) {
                            this.saveResource(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1711598648, 1247582310, "\uddd9\uddf6\uddec\udde9\uddf8\uddb7\udde9\uddef\uddcc", -703420439, -1216344512), false);
                        }
                        final YamlConfiguration loadConfiguration2 = YamlConfiguration.loadConfiguration(file2);
                        if (((FileConfiguration)loadConfiguration2).getConfigurationSection(s9) != null) {
                            ((FileConfiguration)loadConfiguration2).set(s9, (Object)null);
                            try {
                                ((FileConfiguration)loadConfiguration2).save(file2);
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s9, ChatColor.GRAY));
                            }
                            catch (IOException ex2) {
                                final Object[] array25 = { null };
                                "\u6123\u54b6\u500d".length();
                                array25[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(49304607, 1330674915, "\u845a\u842a\u8456\u8454\u845b\u8456\u8429\u8468\u8441\u807f\u8464\u8406\u8471\u846b\u8463\u8473\u8079\u8478\u842b\ud7ef\ud4a5\ud38a\ud895\ue7c8\ued54\ue483\ueace\ue6d3\ud57b\ue661\ud533\ue7e1\ud51c\udd0f\ue008\ud8fb\udd1c\uea1c\ud2fc", 203566361, 338593251);
                                commandSender.sendMessage(StyleUtils.red(array25));
                                ex2.printStackTrace();
                            }
                            return true;
                        }
                        commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s9, ChatColor.GRAY));
                    }
                    return true;
                }
                if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(13341711, -1468757951, "\u38ef\u38d3\u38db\u38c4\u38df\u38c1\u38cb\u38d6", -149671256, -454027714))) {
                    if (commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(548922719, 643314236, "\u5120\u516e\u5170\u517d\u516f\u5132\u5174\u517f\u5154\u5172\u5170", -1227088321, 1093441618)) && !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1459712823, -1612187605, "\ua93d\ua90d\ua911\ua91e\ua902\ua959\ua908\ua915\ua939\ua908\ua912\ua918\ua900\ua900", 138117412, 1560978219))) {
                        final Object[] array26 = new Object[2];
                        "\u4f18\u6b2c\u5731".length();
                        "\u4e74\u68cf\u656e\u671d".length();
                        "\u59f2\u577f\u6de7".length();
                        array26[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1782235358, 1611272942, "\ufd84\uf9a8\ufdb8\ufdbe\ufdcf\uf9aa\ufdbe\ufda4\ufdf1\uf9bd\ufda7\ufdcc\ufdbb\ufdaa", -1115326679, -955687683);
                        "\u5c2c\u5bc3\u65e8\u567f".length();
                        final int n23 = 1;
                        final Object[] array27 = { null };
                        "\u6d87".length();
                        "\u54bb\u60f0".length();
                        array27[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-200434111, 1217459758, "\u93aa", 1194588982, -1715339119);
                        array26[n23] = StyleUtils.gray(array27);
                        commandSender.sendMessage(StyleUtils.red(array26));
                        return true;
                    }
                    if (original.length < 2) {
                        commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                        return true;
                    }
                    final String s10 = original[0];
                    final String s11 = original[1];
                    final String s12 = (original.length > 2) ? String.join(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1317309116, -1194269089, "\u7361", -1541323683, -918463556), (CharSequence[])Arrays.copyOfRange(original, 2, original.length)) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1165233084, 110312196, "\u4320\u4322\u4350\u4357\u435c\u4325\u4324\u4333\u431c\u4727\u433d\u4356\u4321\u4330\u4339\u4320\u4721\u435e\u4306\u10cf\u17ef\u14a6\u1fb3\u20c5", 215439881, -1496044081);
                    "\u5b32\u5481\u510a\u53de".length();
                    "\u62d1\u610f\u5e7d".length();
                    "\u5679\u6e46\u4efa\u60db".length();
                    "\u6f88\u4e7b\u5d1e\u6b1d".length();
                    final File file3 = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(943679682, 532588965, "\u69dd\u69f2\u69e8\u69ed\u69fc\u69b3\u69ed\u69eb\u69c8", -1980189687, -2073617251));
                    if (!file3.exists()) {
                        this.saveResource(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(964807437, -239844479, "\u9cad\u9c80\u9c9c\u9c9f\u9c8c\u9cc1\u9ca1\u9cb9\u9c98", -1502324838, -399621227), false);
                    }
                    final YamlConfiguration loadConfiguration3 = YamlConfiguration.loadConfiguration(file3);
                    final ConfigurationSection configurationSection2 = ((FileConfiguration)loadConfiguration3).getConfigurationSection(s10);
                    if (configurationSection2 != null) {
                        final String string2 = configurationSection2.getString(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1397532937, 1237764181, "\ufb66\ufb56\ufb57\ufb4f\ufb4e\ufb57\ufb6f\ufb5c\ufb7a\ufb58", 1819009123, 2128446865), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1843129527, 278291739, "", 5819748, -2109454778));
                        if (!string2.equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(32968237, 2110433778, "\udce3\udcc9\udcc4\udcdb\udcca\udcd3\udcde\udcdc", -923309331, -1480453634))) {
                            try {
                                "\u6e3f\u63bf\u69bb".length();
                                "\u6ce3\u6296\u65a7\u5e5e".length();
                                final Date parse2 = new SimpleDateFormat(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(919468365, 2095245953, "\u370d\u3720\u376a\u370b\u3775\u3710\u374c\u3740\u3764\u3748\u3716\u376c\u3765\u3706\u3750\u3744\u370f\u375a\u3774", 315395132, -1808226086)).parse(string2);
                                final long currentTimeMillis2 = System.currentTimeMillis();
                                if (currentTimeMillis2 <= parse2.getTime()) {
                                    final long n24 = parse2.getTime() - currentTimeMillis2;
                                    final long n25 = n24 / 1000L % 60L;
                                    final long n26 = n24 / 60000L % 60L;
                                    final long n27 = n24 / 3600000L % 24L;
                                    final long n28 = n24 / 86400000L;
                                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s10, ChatColor.GRAY, ChatColor.GOLD, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, (n28 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n28) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(468332168, -1964714093, "", 2073772726, 1744184953), (n27 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n27) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1590156242, -853644537, "", -434419261, 1201622924), (n26 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n26) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-380362848, -382995121, "", 1981824194, -1319534869), (n25 > 0L) ? invokedynamic(makeConcatWithConstants:(J)Ljava/lang/String;, n25) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1820817710, 966431168, "", -1544074688, 1838036400)), ChatColor.GRAY, ChatColor.GOLD, s12));
                                    return true;
                                }
                            }
                            catch (ParseException ex10) {}
                        }
                    }
                    final ConfigurationSection section2 = ((FileConfiguration)loadConfiguration3).createSection(s10);
                    section2.set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-213108910, -57058689, "\uf9a5\uf991\uf990\uf984\uf985\uf990\uf9a8\uf99f\uf9b9\uf99f", 1309295429, 996005883), (Object)this.calculateUnmuteTime(s11));
                    section2.set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1564257201, -2064286397, "\u738c\u73b8\u73be\u73ac\u73b0\u73b1", -433489225, 1811800056), (Object)s12);
                    try {
                        ((FileConfiguration)loadConfiguration3).save(file3);
                        this.getServer().broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s10, ChatColor.GRAY, ChatColor.GOLD, this.calculateUnmuteTimeFormatted(s11), ChatColor.GRAY, ChatColor.GOLD, s12, ChatColor.GRAY));
                        "\u54f5\u5f4b\u64b4\u6cb6".length();
                        "\u7047\u6d37\u6ac0".length();
                        "\u6c12".length();
                        "\u5b9a".length();
                    }
                    catch (IOException ex3) {
                        final Object[] array28 = { null };
                        "\u5ff1\u5f7d\u5230\u6c70\u647c".length();
                        "\u593d\u6c2a\u6c71".length();
                        "\u61fc\u5c99".length();
                        "\u5f94\u6c3a".length();
                        array28[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1304880795, 204038199, "\u2e1b\u2e69\u2e0b\u2e0f\u2e02\u2e0d\u2e74\u2e0b\u2e20\u2a1c\u2e09\u2e6d\u2e18\u2e00\u2e0e\u2e10\u2a18\u2e1b\u2e36\u7df4\u7ebc\u7991\u7288\u4dcb\u4755\u4e80\u40c3\u4cd8\u7f72\u4c6a\u7f3e\u4de2\u7f1d\u770c\u4a15\u72e0\u7705\u4007\u78e1", -1400200146, -1287649083);
                        commandSender.sendMessage(StyleUtils.red(array28));
                        ex3.printStackTrace();
                    }
                    return true;
                }
                else if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1465674488, 114419596, "\u56f6\u56c3\u56c2\u56d1", 1022424232, 238604532))) {
                    if (commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1489121015, -593813731, "\u8422\u8410\u840e\u8407\u8415\u844c\u840a\u841d\u8436\u841c\u841e", -23329175, 175197297)) && !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1943055153, -1762797662, "\u5be9\u5bd9\u5bc9\u5bc6\u5bd6\u5b8d\u5bc1\u5bd5\u5bf4\u5bc9", 1293035846, -867569172))) {
                        final Object[] array29 = new Object[2];
                        "\u611b\u6801\u62b8".length();
                        array29[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(320318788, 2041838460, "\uf019\uf437\uf025\uf025\uf052\uf435\uf023\uf027\uf07c\uf432\uf02a\uf047\uf036\uf025", 1885641200, -668058703);
                        "\u7111\u590f\u5fce\u6878\u62f9".length();
                        "\u5d8e\u704d\u6bc1\u6c60\u5832".length();
                        final int n29 = 1;
                        final Object[] array30 = { null };
                        "\u54a2\u6b45\u6317\u5d69\u5b43".length();
                        array30[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2066654912, -1005282760, "\ua973", 1573435312, 1735974361);
                        array29[n29] = StyleUtils.gray(array30);
                        commandSender.sendMessage(StyleUtils.red(array29));
                        return true;
                    }
                    if (original.length < 1) {
                        commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                        return true;
                    }
                    final String s13 = original[0];
                    final String s14 = (original.length > 1) ? String.join(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1634648744, 2121639820, "\u4719", 1015788154, 1585156132), (CharSequence[])Arrays.copyOfRange(original, 1, original.length)) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1335667460, -692713068, "\ude85\ude87\udef5\udef2\udef9\ude80\ude81\ude86\udea9\uda92\ude88\udee3\ude94\ude85\ude8c\ude85\uda84\udefb\udea3\u8d6a\u8a4a\u8903\u8216\ubd50", 773578049, 1914002162);
                    "\u6841\u62e1\u6c93\u55a7".length();
                    "\u66b7\u571f\u63e0".length();
                    "\u6465\u6bd4".length();
                    final File file4 = new File(this.getDataFolder(), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-402402531, -18952309, "\u9744\u9769\u9775\u9776\u9765\u9728\u9778\u9760\u9741", 2126846674, -156987090));
                    if (!file4.exists()) {
                        this.saveResource(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1295825081, 1047873795, "\ud2ea\ud2c5\ud2df\ud2c2\ud2d3\ud29c\ud2c2\ud2dc\ud2ff", 21158157, 1390544269), false);
                    }
                    final YamlConfiguration loadConfiguration4 = YamlConfiguration.loadConfiguration(file4);
                    final ConfigurationSection configurationSection3 = ((FileConfiguration)loadConfiguration4).getConfigurationSection(s13);
                    if (configurationSection3 != null) {
                        final String string3 = configurationSection3.getString(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1110230231, 223312774, "\u236f\u235b\u235a\u233e\u233f\u232a\u2312\u2325\u2303\u2325", -1660385731, 646309323), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1463030647, -2064048316, "", 1697071786, -1052081167));
                        if (string3.equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(563848190, 706653381, "\u49fc\u49d6\u49db\u49dc\u49cd\u49d4\u49d9\u49a3", 953175609, 895224017))) {
                            commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s13, ChatColor.GRAY, ChatColor.GOLD, ChatColor.GRAY));
                            return true;
                        }
                        try {
                            "\u6e74\u59aa\u5f4d".length();
                            "\u6d2d\u7040\u5efb\u572a".length();
                            final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1912672154, 818344977, "\u70de\u70fd\u70b5\u70d6\u70d6\u70b5\u70eb\u70e5\u70c7\u70d5\u7089\u70f1\u70f6\u7093\u70c7\u70d1\u709c\u70c7\u70eb", -658075817, -348388315));
                            final Date parse3 = simpleDateFormat.parse(string3);
                            if (System.currentTimeMillis() <= parse3.getTime()) {
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s13, ChatColor.GRAY, ChatColor.GOLD, simpleDateFormat.format(parse3), ChatColor.GRAY, ChatColor.GOLD, s14));
                                return true;
                            }
                        }
                        catch (ParseException ex11) {}
                    }
                    final ConfigurationSection section3 = ((FileConfiguration)loadConfiguration4).createSection(s13);
                    section3.set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-417096982, 1547162332, "\u6ccd\u6cfb\u6cf8\u6ce2\u6cdd\u6cca\u6cf0\u6cc1\u6ce1\u6cc5", 1740695644, 1855638673), (Object)\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(225551512, -1070454131, "\u46d5\u46fd\u46f2\u46f3\u46e4\u46ff\u46f0\u46f4", -700330752, 66520559));
                    section3.set(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1980513764, 1047302684, "\u1b02\u1b38\u1b20\u1b30\u1b2e\u1b29", -117300914, -78157187), (Object)s14);
                    try {
                        ((FileConfiguration)loadConfiguration4).save(file4);
                        this.getServer().broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s13, ChatColor.GRAY, ChatColor.GOLD, ChatColor.GRAY, ChatColor.GOLD, s14, ChatColor.GRAY));
                        "\u58c9\u5e6c".length();
                        "\u6cb9\u5448\u67bc\u69fe".length();
                    }
                    catch (IOException ex4) {
                        final Object[] array31 = { null };
                        "\u55b2".length();
                        "\u6024".length();
                        "\u6ffa".length();
                        array31[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1723703854, 31724727, "\u19d6\u19a4\u19da\u19de\u19d7\u19d8\u19a5\u19da\u19fd\u1dc1\u19d8\u19bc\u19cd\u19d5\u19df\u19c1\u1dd5\u19d6\u1987\u4a45\u4909\u4e24\u4539\u7a7a\u70e8\u793d\u7772\u7b69\u48c7\u7bdf\u488f\u7a53\u4890\u4081\u7d84\u4571\u4090\u7792\u4f70", -48366848, 1582518291);
                        commandSender.sendMessage(StyleUtils.red(array31));
                        ex4.printStackTrace();
                    }
                    return true;
                }
                else {
                    if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1946122763, -400075919, "\u831f\u8323\u832f\u8330\u8320\u8325\u835d", -1631067846, 389434216))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1011954206, -429847348, "\u112c\u111c\u1100\u110f\u1103\u1158\u111c\u1115\u1138\u1110\u1110", 541793100, 1358181532)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1518226197, 985121147, "\u2233\u227d\u2263\u226e\u227c\u2221\u2272\u226d\u2247\u2278\u226f\u227c\u2274", -1888078017, 1105370956))) {
                            if (original.length < 2) {
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                                return true;
                            }
                            final String s15 = original[0];
                            final long banTime = this.parseBanTime(original[1]);
                            if (banTime <= 0L) {
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, ChatColor.GRAY, ChatColor.GOLD, ChatColor.GRAY, ChatColor.GOLD, ChatColor.GRAY));
                                return true;
                            }
                            if (this.bannedPlayersConfig.contains(s15)) {
                                final long long1 = this.bannedPlayersConfig.getLong(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s15), 0L);
                                if (long1 > System.currentTimeMillis()) {
                                    final long n30 = (long1 - System.currentTimeMillis()) / 1000L;
                                    final long n31 = n30 / 86400L;
                                    final long n32 = n30 % 86400L / 3600L;
                                    final long n33 = n30 % 86400L % 3600L / 60L;
                                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s15, ChatColor.GRAY));
                                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, n31, ChatColor.GRAY, ChatColor.GOLD, n32, ChatColor.GRAY, ChatColor.GOLD, n33, ChatColor.GRAY));
                                    return true;
                                }
                            }
                            final String s16 = (original.length >= 3) ? String.join(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(288944386, -2134060142, "\u1b46", 1129215019, -1237234274), (CharSequence[])Arrays.copyOfRange(original, 2, original.length)) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1635290395, -1942783067, "\ubc67\ubc61\ubc13\ubc10\ubc1b\ubc5e\ubc5f\ubc54\ubc7b\ub844\ubc5e\ubc31\ubc46\ubc5b\ubc52\ubc47\ub846\ubc3d\ubc65\uefa8\ue888\uebdd\ue0c8\udf82", 160848347, -1369434276);
                            this.bannedPlayersConfig.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s15), (Object)(System.currentTimeMillis() + banTime));
                            this.bannedPlayersConfig.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s15), (Object)s16);
                            this.saveBanConfig();
                            final String formatBanTime = this.formatBanTime(banTime);
                            final Player player6 = Bukkit.getPlayer(s15);
                            if (player6 != null) {
                                player6.kickPlayer(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD, s16, ChatColor.RED, ChatColor.GOLD, formatBanTime));
                            }
                            this.getServer().broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s15, ChatColor.GRAY, ChatColor.GOLD, formatBanTime, ChatColor.GRAY, ChatColor.GOLD, s16, ChatColor.GRAY));
                            "\u6384".length();
                            return true;
                        }
                        else {
                            final Object[] array32 = new Object[2];
                            "\u5298\u6a28\u6904\u70c8\u5248".length();
                            "\u5870\u7140\u695d".length();
                            "\u509c".length();
                            array32[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(2101019105, 1866222593, "\u1045\u1469\u1079\u1067\u1016\u1473\u1067\u1065\u1030\u147c\u1066\u1005\u1072\u1063", 1607482925, -1068275736);
                            "\u6b31\u6438\u4f20".length();
                            "\u652e\u5c8b".length();
                            final int n34 = 1;
                            final Object[] array33 = { null };
                            "\u541d\u630d\u50e3\u6b17".length();
                            "\u66a9\u61ce".length();
                            array33[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1991284223, -1007744716, "\ua370", 599906762, 1035868653);
                            array32[n34] = StyleUtils.gray(array33);
                            commandSender.sendMessage(StyleUtils.red(array32));
                        }
                    }
                    if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1978487399, 1999346630, "\u5d94\u5dba\u5db1", 272637722, -975801104))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1127819215, -1826587465, "\ue10a\ue13a\ue122\ue12d\ue13d\ue166\ue13e\ue137\ue11e\ue136\ue132", -992755062, 932608214)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1663265363, 1169759374, "\uc02f\uc01f\uc003\uc00c\uc010\uc04b\uc00c\uc003\uc028", -1708201356, -908221610))) {
                            if (original.length < 1) {
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                                return true;
                            }
                            final String s17 = original[0];
                            if (this.bannedPlayersConfig.contains(s17)) {
                                final String string4 = this.bannedPlayersConfig.getString(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s17), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1087539728, -1424045982, "", -672165729, 177438520));
                                if (string4.equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1649057077, 1977303058, "\u55a5\u558f\u5582\u55fd\u55ec\u55f5\u55f8\u55fa", 750356029, -825364114))) {
                                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s17, ChatColor.GRAY));
                                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD));
                                    return true;
                                }
                                final long long2 = Long.parseLong(string4);
                                if (long2 > System.currentTimeMillis()) {
                                    final long n35 = (long2 - System.currentTimeMillis()) / 1000L;
                                    final long n36 = n35 / 86400L;
                                    final long n37 = n35 % 86400L / 3600L;
                                    final long n38 = n35 % 86400L % 3600L / 60L;
                                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s17, ChatColor.GRAY));
                                    commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, n36, ChatColor.GRAY, ChatColor.GOLD, n37, ChatColor.GRAY, ChatColor.GOLD, n38, ChatColor.GRAY));
                                    return true;
                                }
                            }
                            if (this.bannedPlayersConfig.contains(s17)) {
                                final long n39 = (this.bannedPlayersConfig.getLong(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s17), 0L) - System.currentTimeMillis()) / 1000L;
                                final long n40 = n39 / 86400L;
                                final long n41 = n39 % 86400L / 3600L;
                                final long n42 = n39 % 86400L % 3600L / 60L;
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s17, ChatColor.GRAY));
                                commandSender.sendMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;JLorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, n40, ChatColor.GRAY, ChatColor.GOLD, n41, ChatColor.GRAY, ChatColor.GOLD, n42, ChatColor.GRAY));
                                return true;
                            }
                            final String s18 = (original.length >= 2) ? String.join(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1546630094, -1811019951, "\u0ac9", 689742460, 31187893), (CharSequence[])Arrays.copyOfRange(original, 1, original.length)) : \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(364567960, 1665658247, "\uaef8\uaefa\uae88\uae87\uae8c\uaef5\uaef4\uaefb\uaed4\uaaef\uaef5\uae86\uaef1\uaee0\uaee9\uaef8\uaaf9\uae86\uaede\ufd1f\ufa3f\uf976\uf263\ucd2d", 1309116837, 1653084956);
                            this.bannedPlayersConfig.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s17), (Object)\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1719061272, 2098844198, "\u7d7e\u7d56\u7d59\u7d58\u7d47\u7d5c\u7d53\u7d57", 630325748, -793994645));
                            this.bannedPlayersConfig.set(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, s17), (Object)s18);
                            this.saveBanConfig();
                            final Player player7 = Bukkit.getPlayer(s17);
                            if (player7 != null) {
                                player7.kickPlayer(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.RED, ChatColor.GOLD, s18));
                            }
                            this.getServer().broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.GRAY, ChatColor.GOLD, s17, ChatColor.GRAY, ChatColor.GOLD, s18));
                            "\u5895\u5074\u7014".length();
                            "\u5675".length();
                            return true;
                        }
                        else {
                            final Object[] array34 = new Object[2];
                            "\u53a9\u5379\u6886\u69c7\u707b".length();
                            "\u580e\u5156\u57f7".length();
                            array34[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1579619899, 972975043, "\u3d37\u3907\u3d17\u3d15\u3d64\u3905\u3d11\u3d17\u3d42\u3902\u3d18\u3d77\u3d00\u3d15", 1063874959, -36058402);
                            "\u5a27\u6139\u6f25".length();
                            "\u7022\u62fd\u62d8".length();
                            "\u5d4a\u62b5\u67ad\u5754\u53f3".length();
                            "\u5308".length();
                            final int n43 = 1;
                            final Object[] array35 = { null };
                            "\u6df8\u503c\u70cd\u5248\u590b".length();
                            "\u6a85\u4f66\u70ea".length();
                            "\u5fdd".length();
                            array35[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1017660275, 435800786, "\uce65", -680889558, 1622330226);
                            array34[n43] = StyleUtils.gray(array35);
                            commandSender.sendMessage(StyleUtils.red(array34));
                        }
                    }
                    if (!(commandSender instanceof Player)) {
                        final Object[] array36 = new Object[2];
                        "\u4fde\u62c5\u5c0a\u6787\u573f".length();
                        "\u5d68\u5cf7\u5036".length();
                        "\u6c4c\u6bbd\u51e9".length();
                        array36[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(603494113, 825955887, "\uf5d0\uf592\uf593\uf1f2\uf5ee\uf5ec\uf5e5\uf5e5\uf5c4\uf5e1\uf591\uf1e0\uf5fd\uf5ee\uf5e7\uf5f8\uf5ff\uf1fd\uf5cb\ua608\ua122\ua26f\ua908\u9647\u9cab\u9507\u9b49\u9758\ua48c\u979f\ua0a3\u9205\ua4e8\ua8ee\u91f8\ua90f\uace3\u9ffd\ua714\u9a4f\u99e7\u922a\u9d28\u9f61\uafd8\u80e7\ua0d9\u948b\ua541\uac35\uae2c\u9891", -366374752, 169337296);
                        "\u4e28\u5059".length();
                        "\u6471\u6d63\u6277".length();
                        "\u5d4c\u5812\u6c7c\u6865\u57cd".length();
                        "\u68d9\u60b6\u628a\u6b2f".length();
                        final int n44 = 1;
                        final Object[] array37 = { null };
                        "\u6347\u6362".length();
                        "\u61a0\u57a7\u6f66\u53eb\u5f65".length();
                        array37[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(693015586, -846592064, "\u0271", -103994391, 1017625112);
                        array36[n44] = StyleUtils.gray(array37);
                        commandSender.sendMessage(StyleUtils.red(array36));
                        return true;
                    }
                    final Player key2 = (Player)commandSender;
                    if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1485253530, -1124477623, "\u4500\u4528\u4527", 1060373417, 757811108))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-88029736, -842824224, "\ua69f\ua6ad\ua6b3\ua682\ua690\ua6c9\ua68f\ua680\ua6ab\ua681\ua683", -1265824867, -1277629164)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(27885062, 1629981847, "\uab38\uab0a\uab14\uab15\uab07\uab5e\uab18\uab15\uab3a", -1561094731, -1253585870))) {
                            if (this.afkTasks.containsKey(key2)) {
                                key2.setPlayerListName(key2.getName());
                                this.afkTasks.remove(key2).cancel();
                                this.lastActivity.put(key2, System.currentTimeMillis());
                                "\u552c\u51af\u5ae5".length();
                                Bukkit.broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, key2.getName(), ChatColor.GRAY));
                                "\u629b".length();
                                "\u69b9\u69f4\u5366\u6d3d\u6f31".length();
                                "\u51c6\u551f\u6466".length();
                            }
                            else {
                                key2.setPlayerListName(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, key2.getName(), ChatColor.GRAY));
                                "\u4ef0\u5322\u566e\u66f7\u568b".length();
                                this.afkTasks.put(key2, new BukkitRunnable().runTaskLater((Plugin)getInstance(), 20L));
                                "\u5db1\u5eea\u599e\u63da\u5345".length();
                                "\u6695\u545f\u5243".length();
                                "\u70a6".length();
                                "\u70a9\u7122\u6807\u6231".length();
                                "\u5d37\u6a7f".length();
                                Bukkit.broadcastMessage(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;Lorg/bukkit/ChatColor;)Ljava/lang/String;, ChatColor.GOLD, key2.getName(), ChatColor.GRAY));
                                "\u6d78".length();
                            }
                        }
                        else {
                            final Object[] array38 = new Object[2];
                            "\u7002\u599d\u6347\u57f3\u67d3".length();
                            "\u5fd2".length();
                            "\u5831\u565e\u6aeb\u694b".length();
                            array38[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1966229446, -1976154112, "\u32d1\u36f9\u32e9\u32eb\u329a\u36e3\u32f7\u32f1\u32a4\u36ec\u32f6\u3299\u32ee\u32f3", -1859663829, -1584991908);
                            "\u6266\u5056\u5b95\u6c38".length();
                            final int n45 = 1;
                            final Object[] array39 = { null };
                            "\u5cb9\u5a04\u6979\u70c1\u7005".length();
                            "\u6d85\u6d05\u5d1f\u5f89\u6621".length();
                            "\u5c02\u60c4\u5529\u6412\u52a6".length();
                            array39[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-619557820, 261248289, "\ua70c", 1820562133, -1090769698);
                            array38[n45] = StyleUtils.gray(array39);
                            commandSender.sendMessage(StyleUtils.red(array38));
                        }
                    }
                    if (original[0].equals(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(2104417477, -1763833877, "\u8af4\u8ace\u8ac3\u8ac2\u8ace\u8acd", 1516279306, 872597473))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-930378912, -1695734970, "\u6ad7\u6ae5\u6afb\u6af2\u6ae0\u6ab9\u6aff\u6af8\u6ad3\u6af9\u6afb", -1950638399, 792222750)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-33433468, 1739486331, "\ub810\ub83e\ub820\ub82d\ub83f\ub862\ub837\ub82e\ub805\ub824\ub82f\ub83a", 1357339663, -1156101938))) {
                            this.reloadConfig();
                            final Player player8 = key2;
                            final Object[] array40 = new Object[2];
                            "\u4ee4".length();
                            "\u6565\u5802\u5079".length();
                            "\u5c8c\u6dd0\u70d7".length();
                            "\u6aa5".length();
                            array40[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-825113834, 970405506, "\ua0c3\ua0c8\ua0c1\ua0c6\ua0cd\ua0cc\ua4d8\ua0c5\ua0ed\ua0b6\ua0c6\ua0d0\ua0d0\ua0cc\ua0b3\ua093\ua0f5\ua0e3", -2096960111, -1937720166);
                            "\u57aa\u5386".length();
                            "\u5803".length();
                            "\u50dc".length();
                            final int n46 = 1;
                            final Object[] array41 = { null };
                            "\u5c7e\u6d8c\u55c7".length();
                            "\u6e7b".length();
                            "\u5f23".length();
                            array41[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1209689555, -1046157951, "\u4b2b", -265230418, -242363573);
                            array40[n46] = StyleUtils.gray(array41);
                            player8.sendMessage(StyleUtils.gold(array40));
                        }
                        else {
                            final Object[] array42 = new Object[2];
                            "\u639f\u5439\u68e3\u670e".length();
                            "\u6678\u57fb\u68f3\u54d5".length();
                            array42[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(48137281, -1064741013, "\ub9f2\ubddc\ub9d2\ub9d2\ub9a1\ubdc6\ub9d4\ub9d0\ub987\ubdc9\ub9dd\ub9b0\ub9c5\ub9d6", -1886682418, 1171057782);
                            "\u55e8\u6f25\u55ea\u64ba\u644b".length();
                            "\u4fc7\u55fd\u5bb9".length();
                            final int n47 = 1;
                            final Object[] array43 = { null };
                            "\u6f21".length();
                            "\u6a94".length();
                            "\u58ed\u6b69\u64c5\u57ae\u5ae6".length();
                            array43[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-362653056, 681801873, "\ufad1", -1270041724, -2058065114);
                            array42[n47] = StyleUtils.gray(array43);
                            commandSender.sendMessage(StyleUtils.red(array42));
                        }
                    }
                    if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-580939645, -1162361969, "\u2529\u2500", -1452082388, 342986046))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1352000531, -1478187034, "\u5a8a\u5ab4\u5aaa\u5aa7\u5ab5\u5ae8\u5aae\u5aa5\u5a8e\u5ab8\u5aba", -1152160601, 1409518088)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(844786988, -413106497, "\ufb33\ufb03\ufb1f\ufb10\ufb04\ufb5f\ufb0e\ufb06", 1145035912, 665203718))) {
                            if (original.length != 1) {
                                final Player player9 = key2;
                                final Object[] array44 = new Object[2];
                                "\u6069\u606b\u6d44\u636d\u5aed".length();
                                "\u6a74\u5708\u60b0\u576a\u6494".length();
                                array44[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(221864856, 249013191, "\u370c\u377a\u3706\u373b\u373e\u374d\u373f\u3741\u3719\u374c\u373e\u332d", -1148224803, 271157717);
                                "\u5ce1\u60b9\u66be\u54e6".length();
                                "\u70e6\u6d40\u5bc2\u650c\u70a7".length();
                                "\u5269\u676b\u5ca1\u5610".length();
                                final int n48 = 1;
                                final Object[] array45 = new Object[2];
                                "\u5113\u5fc2\u6fab\u66fb".length();
                                array45[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-774706434, 955385685, "\uc11a\uc138\uc167\uc161\uc133", -1686970910, -1682247376);
                                "\u5dac\u630d\u5ab3\u5e27\u55a6".length();
                                "\u5764\u5087".length();
                                final int n49 = 1;
                                final Object[] array46 = { null };
                                "\u67ae\u54a1\u5ad7\u60bc".length();
                                "\u6863\u640d".length();
                                "\u6d3e\u4fdd\u6782\u62a0\u632b".length();
                                array46[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1072414315, 1612885806, "\u68d4\u68f0\u68ce\u68c7\u68df\u68c7\u68d9\u68c4\u689a", -54601895, 506941742);
                                array45[n49] = StyleUtils.gray(array46);
                                array44[n48] = StyleUtils.gold(array45);
                                player9.sendMessage(StyleUtils.gray(array44));
                                return false;
                            }
                            final Player player10 = Bukkit.getPlayer(original[0]);
                            if (player10 == null) {
                                final Object[] array47 = new Object[2];
                                "\u51ad\u5352\u56e0\u6ca5".length();
                                "\u7055\u5ffb\u679b".length();
                                "\u6f96\u65cd\u5202\u5f8a".length();
                                array47[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(2125989298, -189935837, "\u022c\u022a\u0259\u0225\u021f\u0603\u0215\u0211\u0620\u0211\u021b\u0200\u0204\u0214\u021d", 928965916, 1951345146);
                                "\u636c\u585f\u5208".length();
                                final int n50 = 1;
                                final Object[] array48 = { null };
                                "\u5cd9\u5395\u6975".length();
                                "\u6b66\u5ebd".length();
                                "\u5a4d\u579d\u5cc4\u5fbe\u60d5".length();
                                "\u60c7\u6e0e".length();
                                "\u6917\u578a\u6dee\u4ece".length();
                                array48[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-987326220, 241372859, "\u249c", 1010486128, -273057343);
                                array47[n50] = StyleUtils.gray(array48);
                                commandSender.sendMessage(StyleUtils.red(array47));
                                return false;
                            }
                            key2.teleport(player10.getLocation());
                            "\u6cdf\u6d9f\u5e92\u5f37\u68cc".length();
                            "\u6a3f\u5b10\u6468\u52bd\u6245".length();
                            final Player player11 = key2;
                            final Object[] array49 = new Object[2];
                            "\u57fe".length();
                            "\u5748\u522a\u5a9d".length();
                            array49[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1302289508, 1299497885, "\uf110\uf15a\uf533\uf122\uf158\uf128\uf122\uf534\uf174\uf121\uf12a\uf134\uf139\uf12f\uf152\uf146\uf126\uf15c\uf10e\ua2ba\ua5ea\ua6ad\uadbb\u96ea\u9869\u95d8\u9f80\u939a\ua049\u932c\ua07a\u96c5\ua449", 417491103, -1097727449);
                            "\u5c7a".length();
                            "\u65dd\u5839\u54ae".length();
                            "\u62e7\u6b42\u651e".length();
                            final int n51 = 1;
                            final Object[] array50 = { null };
                            "\u6fa6\u5811".length();
                            array50[0] = player10.getName();
                            array49[n51] = StyleUtils.gold(array50);
                            player11.sendMessage(StyleUtils.gray(array49));
                            return true;
                        }
                        else {
                            final Object[] array51 = new Object[2];
                            "\u65cd\u6cbb".length();
                            array51[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-647126899, 1798358770, "\u34b1\u309f\u3491\u3491\u34e2\u3085\u3497\u3493\u34c4\u308a\u349e\u34f3\u3486\u3495", -1554994834, -1670971456);
                            "\u5f17\u62fe".length();
                            final int n52 = 1;
                            final Object[] array52 = { null };
                            "\u52e5\u6d13\u5f46".length();
                            array52[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1073690750, 712414299, "\u5587", -328949430, -1099323530);
                            array51[n52] = StyleUtils.gray(array52);
                            commandSender.sendMessage(StyleUtils.red(array51));
                        }
                    }
                    if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-810841168, -1466620216, "\u446f\u4438\u443d\u4425\u4438\u4426\u4427", 111241407, -1765047905))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1186021289, -1939001429, "\ub72e\ub71e\ub70e\ub701\ub711\ub74a\ub70a\ub703\ub72a\ub702\ub73e", -69743786, -1901761452)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1301001153, 1048422831, "\u673f\u670f\u671f\u6710\u6700\u675b\u670e\u6706\u6721\u6715\u67f3\u67ff\u67f2", -236702090, 217298167))) {
                            if (original.length != 1) {
                                final Object[] array53 = new Object[3];
                                "\u5dcd\u6684\u58ae".length();
                                "\u53ee\u6249".length();
                                "\u59b1\u6648\u6032\u5bf3\u5638".length();
                                "\u60e8\u6a56".length();
                                array53[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-675492814, -609431235, "\u97e4\u9796\u97ea\u97eb\u97ee\u9791\u97e3\u97e4\u97ca\u97e2\u97ea\u97ff\u97f5\u9395", -735041229, -726292605);
                                "\u5285".length();
                                "\u4fad\u7030\u5fe0\u6e9a\u6189".length();
                                "\u60e3\u60ed\u6d1e\u6d84".length();
                                "\u6d39\u5097\u6830\u535e\u6e29".length();
                                final int n53 = 1;
                                final Object[] array54 = { null };
                                "\u56c9\u5369\u5516".length();
                                "\u620b".length();
                                "\u5b75\u6153\u5b8d\u671b".length();
                                "\u64c7\u567f\u4f1e\u5268\u6fe0".length();
                                array54[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1984854986, 1540742893, "\u7657\u767b\u7622\u7626\u7621\u7639\u762d\u763d\u7617\u7661\u761f\u7603\u763c\u7636\u762b\u7635\u7616", -786869305, 3899604);
                                array53[n53] = StyleUtils.gold(array54);
                                "\u6428\u6dd8\u7062".length();
                                "\u6087\u67a5\u51fb\u6467".length();
                                final int n54 = 2;
                                final Object[] array55 = { null };
                                "\u63ad\u61d6\u6131".length();
                                "\u680f\u6a8b".length();
                                "\u5281\u6674\u557c\u4e87".length();
                                array55[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1809410389, 1499762505, "\u07dc", 1967535522, -520344578);
                                array53[n54] = StyleUtils.gray(array55);
                                commandSender.sendMessage(StyleUtils.gray(array53));
                                return true;
                            }
                            final World world = Bukkit.getWorld(original[0]);
                            if (world == null) {
                                final Player player12 = key2;
                                final Object[] array56 = new Object[2];
                                "\u566f".length();
                                array56[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(951430264, -1177425848, "\ub415\ub41c\ub464\ub006\ub415\ub41b\ub005\ub414\ub43d\ub418\ub412\ub401\ub410", -744578652, -884976162);
                                "\u700c\u679c\u68cc".length();
                                "\u6797\u5d06\u67f7".length();
                                "\u6e90\u6915".length();
                                "\u5b23\u6564".length();
                                final int n55 = 1;
                                final Object[] array57 = { null };
                                "\u6a52\u54f6".length();
                                "\u5a5b\u52a5".length();
                                "\u6032".length();
                                array57[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1865269023, 112843658, "\uf6c9", -1668103875, -65383677);
                                array56[n55] = StyleUtils.gray(array57);
                                player12.sendMessage(StyleUtils.red(array56));
                                return true;
                            }
                            key2.teleport(world.getSpawnLocation());
                            "\u5935\u6c8f\u5dae".length();
                            "\u5b0d\u57e2\u6122\u5706".length();
                            final Player player13 = key2;
                            final Object[] array58 = new Object[2];
                            "\u64ff\u52f4".length();
                            array58[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(2110751162, -1613743226, "\u7dd6\u7ac1", -1837148125, 916604854);
                            "\u6d1c\u5a75\u6344\u5f9c".length();
                            "\u6bf2\u501d\u654b".length();
                            final int n56 = 1;
                            final Object[] array59 = new Object[2];
                            "\u6d48\u5375\u5fac\u5394".length();
                            "\u5376\u699c\u4e47\u70b2\u68f4".length();
                            "\u64cc".length();
                            "\u6e4f\u5e8e\u700c".length();
                            array59[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1569936492, 447642864, "\u5b1e\u5ba8\u5b37\u5f07\u5f5c\u5b31\u5f54\u5f2f\u5f01\u5f23\u5f2a\u5f39\u5f42\u5f51\u5f36\u5f5a\u5f3c\u5f2c\u5f04\u0cb3\u0b95\u0cb2\u03ce\u38e4\u3663\u3fc2\u31fc\u3995\u0a2d", -1089323102, 2134330435);
                            "\u6d9e\u6f65\u6eec\u6976".length();
                            "\u55f6".length();
                            final int n57 = 1;
                            final Object[] array60 = { null };
                            "\u6eb5\u5632\u5a81\u5944".length();
                            array60[0] = world.getName();
                            array59[n57] = StyleUtils.gold(array60);
                            array58[n56] = StyleUtils.gray(array59);
                            player13.sendMessage(StyleUtils.gold(array58));
                        }
                        else {
                            final Object[] array61 = new Object[2];
                            "\u63c4".length();
                            "\u5230\u6e14\u5cf1\u6c52\u5f08".length();
                            array61[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-306478109, -1534980230, "\udafa\uded4\udaca\udaca\udab9\udede\udacc\udac8\uda9f\uded1\udaf5\uda98\udaed\udafe", -1692774122, 1961362197);
                            "\u6bd7\u6efa".length();
                            "\u58aa\u636d\u5208\u6d92\u6d32".length();
                            final int n58 = 1;
                            final Object[] array62 = { null };
                            "\u644f\u6167\u6a24\u6e06".length();
                            "\u59d3\u56bf\u5b9e\u585e".length();
                            "\u4f0e\u6275".length();
                            "\u5b1e\u4e68\u6e5e\u6351\u700b".length();
                            array62[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-31284963, -821158238, "\u70a1", -209419967, 1914457661);
                            array61[n58] = StyleUtils.gray(array62);
                            commandSender.sendMessage(StyleUtils.red(array61));
                        }
                    }
                    if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(537490415, 740763904, "\uab02\uab29\uab3a\uab4f\uab42\uab51\uab4f", -59867203, -1605923225))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(866579919, -122014657, "\udfd6\udfe8\udff6\udffb\udfe9\udfb4\udff2\udff9\udfd2\udfe4\udfe6", 803939047, -2115355409)) || commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1259691115, -80303617, "\u9cb5\u9c85\u9c99\u9c96\u9c82\u9cd9\u9c88\u9c80\u9cad\u9c88\u9c82\u9c87\u9c91", -26075288, 217871975))) {
                            if (original.length != 1) {
                                final Object[] array63 = new Object[3];
                                "\u560b\u5383".length();
                                "\u5195\u6cf9\u58e8".length();
                                "\u59fc\u6c94\u5fc9\u563f\u6497".length();
                                array63[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1392017256, -661641929, "\ua95e\ua92a\ua954\ua957\ua95c\ua92d\ua95d\ua958\ua970\ua95e\ua954\ua943\ua957\uad49", 1876714084, -632132914);
                                "\u557e\u68f8\u5913".length();
                                "\u511b\u697c\u52df".length();
                                final int n59 = 1;
                                final Object[] array64 = { null };
                                "\u6fe4\u5db8\u6d29".length();
                                "\u6634\u60d1".length();
                                array64[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1253758196, -986665491, "\ub948\ub968\ub931\ub931\ub920\ub92d\ub929\ub93c\ub909\ub962\ub91c\ub903\ub938\ub926\ub93d\ub92b\ub926\ub917", 1681365537, 321299947);
                                array63[n59] = StyleUtils.gold(array64);
                                "\u6292\u6092\u5b5e\u6d6f\u62a4".length();
                                "\u5728\u556e\u5d90".length();
                                final int n60 = 2;
                                final Object[] array65 = { null };
                                "\u6bcf\u6037\u51c4".length();
                                "\u52c5".length();
                                "\u5f8f".length();
                                array65[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(814864252, -928149528, "\u38a0", 1083258440, 1306613278);
                                array63[n60] = StyleUtils.gray(array65);
                                commandSender.sendMessage(StyleUtils.gray(array63));
                                return true;
                            }
                            final Player player14 = Bukkit.getPlayer(original[0]);
                            if (player14 == null) {
                                final Object[] array66 = new Object[2];
                                "\u6c8b".length();
                                "\u5a2b\u57e4".length();
                                array66[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(927505754, -624459537, "\u7bf6\u7bf2\u7b83\u7bf9\u7bfd\u7fe3\u7bf7\u7bfd\u7fca\u7bf9\u7bf1\u7bec\u7be6\u7bf4\u7bff", 1764253585, 1942830473);
                                "\u5870".length();
                                "\u6c86\u6afe".length();
                                final int n61 = 1;
                                final Object[] array67 = { null };
                                "\u5983\u5c4c\u5dec\u524d".length();
                                "\u6c16\u683c\u5969".length();
                                "\u55ff".length();
                                "\u5daf\u62e3\u5f92\u6a6f\u5e45".length();
                                array67[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1408136907, 1201665714, "\u3d70", 440386636, -2133424423);
                                array66[n61] = StyleUtils.gray(array67);
                                commandSender.sendMessage(StyleUtils.red(array66));
                                return true;
                            }
                            player14.teleport(key2.getLocation());
                            "\u579f\u6d37\u6334\u5075".length();
                            final Player player15 = key2;
                            final Object[] array68 = new Object[2];
                            "\u562c\u7084\u6f70".length();
                            "\u68f7\u647b\u50b1\u5cda\u6c46".length();
                            array68[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1266963997, 1636238608, "\u34b2\u34b4\u34c3\u34bf\u34b9\u30a5", -84048062, -1209604954);
                            "\u5b05\u5acd\u63ac".length();
                            final int n62 = 1;
                            final Object[] array69 = new Object[2];
                            "\u673f\u4fd2".length();
                            "\u6d48\u59f6\u6f19\u50f6\u653a".length();
                            "\u53b4\u4ec5\u5a8f\u6238\u67b8".length();
                            array69[0] = player14.getName();
                            "\u63e4\u58e1".length();
                            "\u6855\u5d24\u6ebf".length();
                            final int n63 = 1;
                            final Object[] array70 = { null };
                            "\u58ba\u5024\u6c5b\u63e7\u70b2".length();
                            "\u682e\u4eec\u63bf\u52e4\u5426".length();
                            "\u59fd\u61d2\u5721\u6088".length();
                            array70[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(928221709, 591939894, "\ud9c6\udd89\uddf2\uddfe\uddf2\uddfe\uddf0\udd82\udda0\uddf6\udd75\udd19\udd10\udd03\udd0b\ud902\udd00\ud906\udd36\u8e8e\u89d2\u8e83", -1710717834, -1593139480);
                            array69[n63] = StyleUtils.gray(array70);
                            array68[n62] = StyleUtils.gold(array69);
                            player15.sendMessage(StyleUtils.gray(array68));
                        }
                        else {
                            final Object[] array71 = new Object[2];
                            "\u64a5\u56a0\u517d\u5805".length();
                            array71[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-444568338, 1395172249, "\u1703\u132b\u173b\u1739\u1748\u1331\u1725\u1723\u1776\u133e\u1724\u174b\u173c\u1721", 933152875, 164631679);
                            "\u51a9\u5f26".length();
                            "\u6aa0\u5e99\u6c4e\u500d\u53cc".length();
                            final int n64 = 1;
                            final Object[] array72 = { null };
                            "\u6a07\u561e\u56e0\u54fa".length();
                            "\u5fbf\u6df8".length();
                            array72[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2077798929, 110840229, "\ue629", -377603155, -881534548);
                            array71[n64] = StyleUtils.gray(array72);
                            commandSender.sendMessage(StyleUtils.red(array71));
                        }
                    }
                    if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-517168632, 1548079698, "\uee88\ueea3\ueea5\ueeba\ueeb2\ueeb6\ueeb4\ueeaf", -761533399, 1665757900))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1825152933, 1643793390, "\u2c1b\u2c2b\u2c37\u2c38\u2c24\u2c7f\u2c3b\u2c32\u2c1f\u2c37\u2c37", -703261420, -501420694)) || !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1883854570, -660996344, "\uff94\uffa6\uffb8\uffb1\uffa3\ufffa\uffa9\uff9f\uffb9\uff8c\uff81\uff95\uff99\uff83", 520185113, 674286781))) {
                            final Object[] array73 = new Object[2];
                            "\u58f9\u70f5\u6480\u6808\u5348".length();
                            "\u6702".length();
                            "\u6dcf\u5233\u5feb".length();
                            "\u6672\u5a01\u6f1e\u6c19".length();
                            array73[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-640014943, -1974121798, "\u377f\u3353\u3743\u377d\u370c\u3369\u377d\u377f\u372a\u3366\u377c\u371f\u3768\u3779", 1179094621, 1357435481);
                            "\u6947\u5906".length();
                            final int n65 = 1;
                            final Object[] array74 = { null };
                            "\u6ee6\u5c98".length();
                            "\u6a4c\u5103\u5229\u5a61".length();
                            "\u631e\u550d\u536e\u5abf\u5276".length();
                            array74[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-227056450, -1051476146, "\ub1ae", 1839300159, 1946162179);
                            array73[n65] = StyleUtils.gray(array74);
                            commandSender.sendMessage(StyleUtils.red(array73));
                            return true;
                        }
                        final boolean booleanValue = this.teleportToggle.getOrDefault(key2, true);
                        this.teleportToggle.put(key2, !booleanValue);
                        "\u5ca6\u59e3".length();
                        "\u5fb3".length();
                        "\u5858\u6325".length();
                        "\u6634\u4ed0\u6a03\u6826\u64a6".length();
                        "\u5dea\u59bb\u6008\u647c\u5466".length();
                        if (booleanValue) {
                            final Player player16 = key2;
                            final Object[] array75 = new Object[2];
                            "\u52b1\u6c81\u5331\u6f6c\u5f8d".length();
                            "\u711f\u6896\u65a4".length();
                            "\u5d17\u58b9\u708a".length();
                            array75[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1011431014, -166435619, "\uf3d9\uf3ad\uf7c6", 799797024, -1344555537);
                            "\u5915".length();
                            "\u6932\u6124".length();
                            "\u680f\u51c2\u6389".length();
                            "\u6ab3\u6d0b\u6cb6".length();
                            final int n66 = 1;
                            final Object[] array76 = new Object[2];
                            "\u6535\u63bd".length();
                            "\u6fa9".length();
                            "\u5519".length();
                            array76[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1340275217, 2006374923, "\u84fc\u84ad\u84d5\u84d6\u84a5\u84aa\u84de\u84d1\u84ce\u80fa", -1186554920, -1750285123);
                            "\u5f60".length();
                            "\u5a26\u58f3\u58ae\u5b93\u4fce".length();
                            final int n67 = 1;
                            final Object[] array77 = { null };
                            "\u6f8b\u610c\u7123\u5386".length();
                            "\u6a75\u56fe\u5a84".length();
                            "\u6156\u62a4\u51f2\u5d65".length();
                            "\u6d2e".length();
                            array77[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-586912781, -365186989, "\uf496\uf4b5\uf4be\uf4b1\uf4b3\uf4bf\uf4bd\uf4bc\uf4e1\uf4cc\uf4c7\uf0bf\uf4da\uf4be\uf4b3\uf4d7\uf4c7\uf4d8\uf48a\ua734\ua014\ua32c\ua832\u9704\u9985\u9438\u9e62\u9616\ua5c2\u96d9\ua58f\u9741", 1754287281, 388458486);
                            array76[n67] = StyleUtils.gray(array77);
                            array75[n66] = StyleUtils.gold(array76);
                            player16.sendMessage(StyleUtils.gray(array75));
                        }
                        else {
                            final Player player17 = key2;
                            final Object[] array78 = new Object[2];
                            "\u52d2".length();
                            "\u5be7\u64e1\u52eb".length();
                            "\u5632\u6979\u6a1f".length();
                            array78[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-70822741, -399881485, "\u68b7\u68c5\u6cac", -1305769317, -1235159003);
                            "\u6943\u6f5e\u6447".length();
                            "\u612d\u61cf\u6488\u6e86\u6d69".length();
                            "\u4e46\u6971\u62d6\u65cc\u6b99".length();
                            "\u5fea".length();
                            "\u68ab\u66a6\u5544".length();
                            final int n68 = 1;
                            final Object[] array79 = new Object[2];
                            "\u59da".length();
                            "\u4e92".length();
                            "\u5d57".length();
                            "\u5964\u598b\u4ed9\u4eca\u6e6c".length();
                            array79[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-552360276, 1180909065, "\u62f6\u62d3\u62d6\u62a1\u62aa\u62d3\u62d7\u62d8\u66e0", 863213586, 1639278128);
                            "\u61d9\u5626\u662f\u4faf\u70f4".length();
                            "\u6f52\u6665\u6790".length();
                            final int n69 = 1;
                            final Object[] array80 = { null };
                            "\u6fb9\u581d\u6f27\u5d1c\u525f".length();
                            array80[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-245809342, -719614804, "\u7a9a\u7abb\u7abe\u7ab7\u7ab7\u7ab9\u7abd\u7ab2\u7aed\u7ac2\u7ad7\u7ea9\u7ace\u7aa8\u7aa3\u7ab9\u7aab\u7ab6\u7aea\u2952\u2e70\u2d4a\u2652\u196a\u17e9\u1a56\u1032\u1840\u2b96\u188f\u2bdf\u190f", -177120634, -246769789);
                            array79[n69] = StyleUtils.gray(array80);
                            array78[n68] = StyleUtils.gold(array79);
                            player17.sendMessage(StyleUtils.gray(array78));
                        }
                        return true;
                    }
                    else if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1803338997, -1886632542, "\ua3f6\ua3df\ua3ca", 57913378, 366056116))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-769059177, -1556797596, "\uf88d\uf8bd\uf8dd\uf8d2\uf8c2\uf899\uf8d9\uf8d0\uf8f9\uf8d1\uf8dd", 1075472574, -2121883154)) || !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-225850628, 1178171854, "\ue6f4\ue6c4\ue6d8\ue6d7\ue6c3\ue698\ue6c9\ue6c1\ue6fc", 959125856, 1247890568))) {
                            final Object[] array81 = new Object[2];
                            "\u5241\u5e0f\u605a".length();
                            "\u5bde\u5f11\u5899\u6162\u6192".length();
                            array81[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1408828762, 1165558529, "\u1f5c\u1b72\u1f60\u1f60\u1f1f\u1b78\u1f6e\u1f6a\u1f39\u1b77\u1f6f\u1f02\u1f6b\u1f78", -97867868, -2100053309);
                            "\u680c\u5c5b".length();
                            final int n70 = 1;
                            final Object[] array82 = { null };
                            "\u50a2\u703a\u6ed9".length();
                            "\u6388\u54d8".length();
                            "\u5d49\u57b8\u5128\u6364".length();
                            "\u6120\u63ff\u5d84".length();
                            array82[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1865658311, -1773228651, "\ubae0", 509811080, 410952024);
                            array81[n70] = StyleUtils.gray(array82);
                            commandSender.sendMessage(StyleUtils.red(array81));
                            return true;
                        }
                        if (original.length != 1) {
                            final Player player18 = key2;
                            final Object[] array83 = new Object[2];
                            "\u5534\u67ff".length();
                            "\u622b\u6262\u4f0a\u54f3\u5fe7".length();
                            "\u634b".length();
                            array83[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1309622274, -1057572624, "\ub423\ub457\ub429\ub42a\ub421\ub450\ub420\ub425\ub40d\ub423\ub429\ub43e\ub5ca\ub1d4\ub1cf", 2125201652, -639219586);
                            "\u4ef9\u5052".length();
                            "\u66a8\u5fb4".length();
                            "\u67d1\u6ddf\u5730\u6339".length();
                            "\u5e47\u6a8e\u6940\u696c\u69b9".length();
                            "\u550a\u69ec\u6873\u70b7\u5e48".length();
                            final int n71 = 1;
                            final Object[] array84 = new Object[2];
                            "\u6bbb\u6eeb\u61ad\u53ff".length();
                            array84[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-726474939, 908543988, "\u9663\u9615\u9611\u9602\u964d", -464424652, 1308721034);
                            "\u53a8\u6178\u708f\u5e2c\u50c7".length();
                            "\u5ca2\u69ac".length();
                            "\u5357".length();
                            final int n72 = 1;
                            final Object[] array85 = { null };
                            "\u6eb2\u6433\u5129\u59c7".length();
                            "\u6a1f\u696e\u6e4f\u6c76".length();
                            array85[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1743540996, 1015151847, "\u238d\u23d9\u23f0\u23e0\u23ed\u23f1\u23e4\u23f9\u23f4\u23a6", 714278341, -614500816);
                            array84[n72] = StyleUtils.gray(array85);
                            array83[n71] = StyleUtils.gold(array84);
                            player18.sendMessage(StyleUtils.gray(array83));
                            return true;
                        }
                        final Player player19 = getInstance().getServer().getPlayer(original[0]);
                        if (key2.getName().equalsIgnoreCase(player19.getName())) {
                            final Object[] array86 = new Object[2];
                            "\u61cf".length();
                            "\u5de9\u66cc\u61c3\u5d86".length();
                            "\u56ae\u6fbd\u6103\u6421".length();
                            array86[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(841460078, 680074006, "\u07dd\u07af\u03c6\u07db\u07d3\u03ce\u07db\u07d7\u07fd\u07d4\u07a6\u07c1\u03d3\u07c2\u07bd\u07d6\u07b3\u07d9\u07f7\u5445\u536d\u5021\u5f2d\u6400\u6e9e\u6732\u690d\u6562\u56bd\u61ff\u56cc\u607b\u5698\u5a9f\u63fe\u5b02\u5a8f\u69e0\u5561\u6840\u6f80", -2112914173, -225260297);
                            "\u6f09\u61ac\u5e1d".length();
                            "\u5812\u6a09\u51fb".length();
                            "\u6db6\u668e".length();
                            final int n73 = 1;
                            final Object[] array87 = { null };
                            "\u56d7\u5a71\u60eb\u6448".length();
                            "\u6495\u630e\u5437".length();
                            array87[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(517033185, -1304292198, "\u6956", 1700877447, -87726648);
                            array86[n73] = StyleUtils.gray(array87);
                            commandSender.sendMessage(StyleUtils.red(array86));
                            return false;
                        }
                        if (!this.teleportToggle.getOrDefault(player19, true)) {
                            final Player player20 = key2;
                            final Object[] array88 = new Object[2];
                            "\u5394\u6d92".length();
                            array88[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(2029747915, 852142150, "\u8de6\u89c8\u8dd4\u8ddd\u8dac\u8dd4\u8dc7\u8dc1\u89f1\u8dc3\u8dbc\u8dd6\u8dd2\u8db6\u8db2\u8dd4\u8dc4\u8dae\u89ef\ude37\ud910\uda52\ud102\uee30\ue4aa\ued71\ue335\uef54\udc80\uefe3\udcbf", 1884763146, -2085393663);
                            "\u6025\u5df7\u5952".length();
                            "\u50ab\u6517\u6792\u5876".length();
                            "\u6ac2\u6b6a\u6d91\u6c9d".length();
                            final int n74 = 1;
                            final Object[] array89 = { null };
                            "\u5499\u5bf5\u4fe9\u5185\u6233".length();
                            array89[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1179689099, 1733114372, "\u23e0", 1030838462, 2017714611);
                            array88[n74] = StyleUtils.gray(array89);
                            player20.sendMessage(StyleUtils.red(array88));
                            return true;
                        }
                        if (player19 == null) {
                            final Player player21 = key2;
                            final Object[] array90 = new Object[2];
                            "\u6c54\u7014\u66e9".length();
                            "\u5cf9\u5659\u5924".length();
                            array90[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1762608844, -704076759, "\u283e\u2838\u284b\u2837\u282d\u2c31\u2827\u2823\u2c12\u2823\u2829\u2832\u2836\u2826\u282f", 10900268, 211393964);
                            "\u6761".length();
                            "\u605c\u70eb".length();
                            "\u5331".length();
                            "\u53ed\u5b53\u6a05".length();
                            final int n75 = 1;
                            final Object[] array91 = { null };
                            "\u66a3\u5171\u67ab\u555d".length();
                            "\u6abd\u5a7a\u5de0".length();
                            "\u6b26\u644d".length();
                            "\u7070\u5acc".length();
                            array91[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1963415282, 761501575, "\u2086", 662185010, -412105300);
                            array90[n75] = StyleUtils.gray(array91);
                            player21.sendMessage(StyleUtils.red(array90));
                            return true;
                        }
                        this.teleportRequests.put(player19, key2);
                        "\u59f3\u64b9\u6684".length();
                        "\u6ad3\u6a5a".length();
                        "\u4ffe\u5d2c\u6227\u5e69".length();
                        this.teleportRequestTimes.put(player19, System.currentTimeMillis());
                        "\u5507\u5f77\u6cf0\u5d15\u6665".length();
                        "\u4f53".length();
                        final Player player22 = player19;
                        final Object[] array92 = new Object[2];
                        "\u6078\u5278".length();
                        "\u6b7a\u610d".length();
                        array92[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(950985947, 1309132086, "\u1f04\u1f02\u1f7d\u1f01\u1f07\u1b1b", 379956182, -628846236);
                        "\u611c\u525b\u58fd\u52ad\u4e7c".length();
                        "\u4fe9\u7023\u4ed3\u5aed".length();
                        "\u6b72\u6347\u6e5e\u6cdd".length();
                        final int n76 = 1;
                        final Object[] array93 = new Object[2];
                        "\u5a77\u5536\u5da0".length();
                        array93[0] = key2.getName();
                        "\u593c\u55c0\u621b\u4edd\u61de".length();
                        "\u5b78".length();
                        "\u56f9\u5011\u5938\u67cc".length();
                        "\u4f23\u6dad\u6984".length();
                        final int n77 = 1;
                        final Object[] array94 = new Object[3];
                        "\u5022\u65fe\u6820\u6768".length();
                        "\u54b0\u5894\u6f44".length();
                        array94[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-807697213, 713284345, "\u54c2\u5174\u510d\u5174\u5106\u5171\u551a\u510e\u5536\u5106\u5101\u511d\u5506\u5173\u5107\u511f\u510b\u5103\u512e\u02e8\u05b8\u0688\u0d90\u32d4\u3841\u31e8\u3fda\u33c5h\u337d\u044e\u36be\b\u0c4b\u3529\u0daf\u0836\u3f4b\u03ca\u3e95\u392a\u3685\u3d93", -597764865, 44555876);
                        "\u5a73\u5830\u6270".length();
                        "\u7045\u6d3f\u6e81\u52e1".length();
                        final int n78 = 1;
                        final Object[] array95 = { null };
                        "\u684d\u565a\u67f8\u5c2e".length();
                        "\u5d65\u4f67\u53be".length();
                        "\u6739\u57d3\u66b7".length();
                        "\u54c5".length();
                        array95[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-703672033, 1856661177, "\u578b\u57ff\u57f9\u57d4\u57d6\u57d2\u57dd\u57c2\u57e4\u579e", 1791117853, -261576100);
                        array94[n78] = StyleUtils.runCommand(StyleUtils.gold(array95), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-237618696, 1621930900, "\ue9cf\ue9b9\ue9bd\ue9ae\ue9a2\ue9a4\ue9a9\ue9b0\ue990", 2012677028, -64069525));
                        "\u4ff3\u67b8".length();
                        "\u4f94\u5958".length();
                        "\u6fae\u6d52\u5603\u5192\u6ffe".length();
                        "\u543c\u54b5".length();
                        final int n79 = 2;
                        final Object[] array96 = new Object[3];
                        "\u5c08".length();
                        "\u6ee1\u55c3\u6c57\u5086".length();
                        "\u6a68".length();
                        array96[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1466662643, 389104034, "\uc574\uc55a\uc559\uc143", 1474329644, 857767308);
                        "\u69df\u655d\u53e1".length();
                        final int n80 = 1;
                        final Object[] array97 = { null };
                        "\u62cf".length();
                        "\u6732\u7135\u5dcd\u6d88\u54e4".length();
                        array97[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1329725388, -887548988, "\u51d4\u51ac\u51aa\u51bb\u51b9\u51bb\u51bd\u51be\u519a\u51c1", 1359465655, 1796640511);
                        array96[n80] = StyleUtils.runCommand(StyleUtils.gold(array97), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(178275820, 1570375069, "\u53b7\u53c1\u53c5\u53d6\u53ea\u53ee\u53ea\u53eb\u53c9\u53ec", 1608446108, -1809325258));
                        "\u664f\u62b7\u5ce8\u537d".length();
                        "\u4f1f\u5b80".length();
                        "\u5512\u6986".length();
                        final int n81 = 2;
                        final Object[] array98 = { null };
                        "\u5b06".length();
                        "\u6a70\u697d\u6b6c".length();
                        array98[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-392791921, 1785790976, "\u844d", -150243802, 1789495433);
                        array96[n81] = StyleUtils.gray(array98);
                        array94[n79] = StyleUtils.gray(array96);
                        array93[n77] = StyleUtils.gray(array94);
                        array92[n76] = StyleUtils.gold(array93);
                        player22.sendMessage(StyleUtils.gray(array92));
                        final Player player23 = key2;
                        final Object[] array99 = new Object[2];
                        "\u63c1\u51a7".length();
                        "\u6afb\u59a9\u61d0\u51a0".length();
                        array99[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(2090030538, -144621280, "\u46e1\u46eb\u46e8\u4695\u46e9\u4690\u42fe\u46ef\u46c2\u42fe\u4687\u46e2\u46e9\u46f6\u46f9\u46ec\u468a\u4694\u46c4\u1508\u1226\u111c\u1e14\u2532\u2fd5\u260d\u284c\u242f\u178f\u249b\u17c1\u210d\u13fd\u1be6\u2280\u1a72\u1fe0\u28e4\u146e\u2d2a", 116305702, 1141242233);
                        "\u6b82\u60bd".length();
                        final int n82 = 1;
                        final Object[] array100 = new Object[2];
                        "\u6658\u53c2\u5d02\u5d4c\u6347".length();
                        "\u6817".length();
                        "\u6fad\u5376".length();
                        array100[0] = player19.getName();
                        "\u53c4\u5935".length();
                        "\u5882\u675c\u6c35\u68b5".length();
                        final int n83 = 1;
                        final Object[] array101 = { null };
                        "\u6b79\u568b".length();
                        array101[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(663991323, 1860751633, "\ubb28", 1322177562, -1621816747);
                        array100[n83] = StyleUtils.gray(array101);
                        array99[n82] = StyleUtils.gold(array100);
                        player23.sendMessage(StyleUtils.gray(array99));
                        return true;
                    }
                    else if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1633271077, 971005321, "\ue2f5\ue2de\ue2cd\ue2c3\ue2c3\ue2c1\ue2dd\ue2d3", 474796357, 1760023339))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1253441802, 751051636, "\u5bce\u5bfc\u5be2\u5beb\u5bf9\u5ba0\u5be6\u5be1\u5bca\u5be0\u5be2", -1022806255, -2117261)) || !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1253074510, -1317918444, "\u8da8\u8d9a\u8d84\u8d8d\u8d9f\u8dc6\u8d95\u8d93\u8da0\u8d8c\u8d89\u8d9b\u8d89\u8d9e", 224824305, 1008224557))) {
                            final Object[] array102 = new Object[2];
                            "\u535a".length();
                            "\u5e24\u57b7\u6d1f".length();
                            "\u616e\u6be5\u6dd6\u69fb\u5314".length();
                            "\u6028\u52d0\u591e\u6489".length();
                            array102[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1466762574, 995565908, "\ub9bb\ubd97\ub987\ub999\ub9e8\ubd8d\ub999\ub99b\ub9ce\ubd82\ub998\ub9fb\ub98c\ub99d", -646430803, 126179728);
                            "\u5ab3\u6ef8\u4ebe\u5353".length();
                            "\u7100\u5d24\u671b".length();
                            "\u5e8c\u50b3".length();
                            final int n84 = 1;
                            final Object[] array103 = { null };
                            "\u59ff\u6aa0\u60f5\u6e0a".length();
                            "\u7039\u5b67\u6d7d".length();
                            "\u6c80\u6fd2\u5505\u54ae\u4e84".length();
                            array103[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(404949292, -603193644, "\uae20", 686183868, -2050094074);
                            array102[n84] = StyleUtils.gray(array103);
                            commandSender.sendMessage(StyleUtils.red(array102));
                            return true;
                        }
                        final Player player24 = this.teleportRequests.remove(key2);
                        final Long n85 = this.teleportRequestTimes.remove(key2);
                        if (player24 == null || n85 == null) {
                            final Player player25 = key2;
                            final Object[] array104 = new Object[2];
                            "\u5778\u7143\u5e9e\u5841".length();
                            "\u5c84\u56c1".length();
                            "\u5f67\u70bb\u58fc\u6ee0".length();
                            "\u640d\u58fe".length();
                            array104[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2000232468, 1333121475, "\ue86e\uec40\ue856\ue856\ue825\uec42\ue858\ue85c\ue80b\uec45\ue851\ue844\ue84e\ue820\ue843\ue828\ue84f\ue85f\uec67\ubbc0\ubc9d\ubbc1\ub4cd\u8b82\u8117\u88bc\u86f0\u8ae2\ub93e\u8a21\ub8ff\u8e4d\ub8de\ub4ab", 834690274, 673693379);
                            "\u5dc8\u6900".length();
                            final int n86 = 1;
                            final Object[] array105 = { null };
                            "\u563c".length();
                            "\u62d5".length();
                            array105[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(684119517, 907564333, "\u7d04", -447938848, -2083650698);
                            array104[n86] = StyleUtils.gray(array105);
                            player25.sendMessage(StyleUtils.red(array104));
                            return true;
                        }
                        if (System.currentTimeMillis() - n85 > 60000L) {
                            final Player player26 = key2;
                            final Object[] array106 = new Object[2];
                            "\u6ee6\u687b\u6c3b".length();
                            array106[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1034277279, -677050796, "\u5dae\u5da4\u5dab\u5dd6\u5dae\u5dd7\u59bd\u5dac\u5d8d\u59b1\u5dd4\u5db1\u5dbe\u5da1\u5daa\u5dbf\u5de5\u5dfb\u5da7\u0e6b\u0941\u0a7b\u0577\u3e57\u34b9\u3d1f\u332a\u3f36", 380716880, 1504720543);
                            "\u6b60\u5c94\u519d\u6858\u54a3".length();
                            final int n87 = 1;
                            final Object[] array107 = { null };
                            "\u696a\u6d55".length();
                            "\u59da\u5f04\u53e3\u5b5a".length();
                            "\u5e92".length();
                            array107[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(439546283, 538665349, "\u2fde", 132875684, 581646902);
                            array106[n87] = StyleUtils.gray(array107);
                            player26.sendMessage(StyleUtils.red(array106));
                            return true;
                        }
                        this.playerPreviousLocations.put(key2, key2.getLocation());
                        "\u576c\u4f85\u55b8\u65c3\u6918".length();
                        "\u6943\u6984\u6e59".length();
                        player24.teleport(key2.getLocation());
                        "\u6bc9\u6e0b\u67f8".length();
                        "\u6fbf\u618d\u6b65\u50db\u57b6".length();
                        final Player player27 = player24;
                        final Object[] array108 = new Object[2];
                        "\u62b0\u53d8\u556e".length();
                        "\u5692\u54da\u5bbd".length();
                        "\u5559\u6cd6".length();
                        array108[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1270800976, -677099635, "\u2b09\u2b0f\u2b78\u2b04\u2b02\u2f1e", -541336462, 1929926397);
                        "\u57b1".length();
                        "\u64e6\u57d0\u6842\u6996\u7105".length();
                        "\u6607\u6c77\u5025\u5d47".length();
                        final int n88 = 1;
                        final Object[] array109 = new Object[2];
                        "\u68a5".length();
                        array109[0] = key2.getName();
                        "\u58aa".length();
                        "\u7060\u66ec\u56b1".length();
                        "\u5bd9\u5124\u6ba6\u62e8\u69bd".length();
                        "\u5720\u70ee\u55af".length();
                        final int n89 = 1;
                        final Object[] array110 = { null };
                        "\u54ab".length();
                        "\u5d44\u50a9".length();
                        "\u56f8".length();
                        array110[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-178028213, 408314065, "\u8359\u876d\u8710\u8768\u876d\u8727\u875a\u834f\u877f\u8757\u872a\u8352\u8742\u875a\u8756\u873f\u875b\u873e\u8373\ud4d6\ud389\ud4cb\udbc9\ue484\uee13\ue7be\ue9f4\ue5e4\ud63a\ue52b\ud60b\ue0bb\ud62a\uda59\ue755", 1277061659, -517338949);
                        array109[n89] = StyleUtils.gray(array110);
                        array108[n88] = StyleUtils.gold(array109);
                        player27.sendMessage(StyleUtils.gray(array108));
                        final Player player28 = key2;
                        final Object[] array111 = new Object[2];
                        "\u554f".length();
                        "\u5c2e\u6d9d".length();
                        array111[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(960935836, -736759269, "\ubadd\ubaa9\ubec2\ubadf\ubaa6\ubad8\ubad6\ubaa8\uba00\uba2f\ube30\uba35\uba33\uba2d\uba53\uba39\uba52\ube2f\uba1c\ue9ab\ueaef\uedc1\ue6d4\ud9e2\ud36b\udac4\ud487\ud8ea\ueb4e\ud821\ueb07\uddbd\ueb2a\ue347\ude38\ue6c5\ue74f\ud457\ue8ab\ud5ff\ud27b\udda9\ud2a2\ud485", -2002652808, -433583501);
                        "\u5941".length();
                        "\u6c49".length();
                        final int n90 = 1;
                        final Object[] array112 = new Object[2];
                        "\u5c99\u5ef3".length();
                        "\u637a".length();
                        array112[0] = player24.getName();
                        "\u6315".length();
                        final int n91 = 1;
                        final Object[] array113 = { null };
                        "\u67a7\u5811\u66a4".length();
                        "\u5cb0\u50e9\u6653\u67ed\u5c04".length();
                        array113[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1669594311, -1668485734, "\uabc0", 364069372, 2114976515);
                        array112[n91] = StyleUtils.gray(array113);
                        array111[n90] = StyleUtils.gold(array112);
                        player28.sendMessage(StyleUtils.gray(array111));
                        return true;
                    }
                    else if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1673931521, 1043597751, "\ud981\ud9a8\ud9b9\ud9b9\ud945\ud94c\ud94a\ud940\ud96d", 1009515900, 1681586562))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(648761724, 209626203, "\u1bc0\u1bfe\u1be0\u1bed\u1bff\u1ba2\u1be4\u1bef\u1bc4\u1bd2\u1bd0", 757834071, 1315983262)) || !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-163319359, -849616726, "\ue67a\ue648\ue656\ue65f\ue64d\ue614\ue647\ue641\ue672\ue65e\ue659\ue642\ue648\ue65d\ue657", 303861297, 119240974))) {
                            final Object[] array114 = new Object[2];
                            "\u5202\u687f\u63f3".length();
                            "\u5c5d\u51ee\u5560\u5d40".length();
                            "\u5aae\u5737\u5e5c\u6dd9".length();
                            array114[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-114843041, -1516889624, "\u76d0\u72fe\u76e8\u76e8\u769b\u72fc\u76f6\u76f2\u76a5\u72eb\u76f7\u769a\u76ef\u76fc", -996085622, 1471756685);
                            "\u5429".length();
                            "\u530d\u6377\u6017\u6a7e\u6b1c".length();
                            final int n92 = 1;
                            final Object[] array115 = { null };
                            "\u6397".length();
                            array115[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1177495900, 1808377329, "\ufcd8", 948226633, -1961474650);
                            array114[n92] = StyleUtils.gray(array115);
                            commandSender.sendMessage(StyleUtils.red(array114));
                            return true;
                        }
                        final Player player29 = this.teleportRequests.remove(key2);
                        if (player29 == null) {
                            final Player player30 = key2;
                            final Object[] array116 = new Object[2];
                            "\u65f0".length();
                            "\u6bed\u68a7\u6410\u6aca".length();
                            "\u5204\u6a6b".length();
                            "\u6a9a".length();
                            array116[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1922846764, -1744154461, "\ue07a\ue454\ue07a\ue07a\ue009\ue46e\ue07c\ue078\ue02f\ue461\ue07d\ue068\ue062\ue00c\ue077\ue01c\ue07b\ue06b\ue44b\ub3ec\ub4b1\ub3ed\ubce9\u83a6\u8933\u8098\u8edc\u82ce\ub112\u820d\ub12b\u8799\ub10a\ubd7f", -75414562, -1296783541);
                            "\u4e58\u6858\u51e2\u633a\u5cad".length();
                            "\u6831\u609b\u54e2".length();
                            "\u4f79\u4e80".length();
                            final int n93 = 1;
                            final Object[] array117 = { null };
                            "\u64f2\u65af\u70ac".length();
                            "\u69bf".length();
                            array117[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(630229521, 1729437220, "\ub1dc", 2146315954, -623178951);
                            array116[n93] = StyleUtils.gray(array117);
                            player30.sendMessage(StyleUtils.red(array116));
                        }
                        else {
                            final Player player31 = key2;
                            final Object[] array118 = new Object[2];
                            "\u6f03".length();
                            "\u6f8e\u68e1\u5d03\u7036".length();
                            array118[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(437667611, -76308373, "\u51d2\u5198\u55f1\u51ef\u5193\u51eb\u51e3\u51e8\u51c9\u51ee\u51e8\u51fb\u55e4\u51e4\u51e0\u51f9\u519c\u51e0\u51b3\u066a\u0525\u0662\u0912\u324a\u38a4\u3101\u3f4f\u3354\u00f5\u3390\u00c0\u3674\u00ed\u0c6e\u357b\u0996\u0866\u3f1c\u078b\u3eb6\u3979\u36d2\u39af\u3b9e\u0b5d\u2464", -1637620897, 1392267692);
                            "\u68eb\u64d4\u6eba\u6a7b".length();
                            "\u63b3".length();
                            "\u64fa".length();
                            "\u6e56\u7138".length();
                            final int n94 = 1;
                            final Object[] array119 = new Object[2];
                            "\u6dd5".length();
                            "\u5426\u6b6c".length();
                            array119[0] = key2.getName();
                            "\u650b\u66d4\u5815\u6ee7\u5bd3".length();
                            final int n95 = 1;
                            final Object[] array120 = { null };
                            "\u5206\u5acd\u6fdc\u54e6\u692e".length();
                            "\u54cd".length();
                            "\u654c\u5378".length();
                            "\u6b15".length();
                            array120[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1392907005, 1291301100, "\u0206", 930655608, -1121645299);
                            array119[n95] = StyleUtils.gray(array120);
                            array118[n94] = StyleUtils.gold(array119);
                            player31.sendMessage(StyleUtils.gray(array118));
                            final Player player32 = player29;
                            final Object[] array121 = new Object[2];
                            "\u5d95\u5242".length();
                            "\u51b2".length();
                            "\u6ec7".length();
                            array121[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1103409337, 2076602856, "\u55d5\u55d3\u55ac\u55d0\u55d6\u51ca", -838354026, 1635593033);
                            "\u5e44\u68e7".length();
                            "\u67aa\u534a\u6d41".length();
                            final int n96 = 1;
                            final Object[] array122 = new Object[2];
                            "\u59c4\u5489\u5d01".length();
                            "\u6361\u5883\u59d5\u600b".length();
                            "\u6b5f\u6bc1\u6b62\u5858".length();
                            array122[0] = key2.getName();
                            "\u5742\u6c6d".length();
                            "\u615f".length();
                            "\u5c97".length();
                            final int n97 = 1;
                            final Object[] array123 = new Object[2];
                            "\u5f6a\u510b\u6dfc\u64ce".length();
                            array123[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1164801757, -327673540, "\u6703\u6330\u6348\u6332\u6331\u6332\u6336\u633f\u631c\u672b\u633a\u632a\u6357\u672e\u6304\u6317\u6300\u6363\u6337\u30f2\u33c3\u3492\u3ff1\u04d9\u0a20\u03f2\u0dba\u01a7\u320f\u0113\u3221\u04e7\u3278\u3e0d\u0716\u3fe1", 487163730, -1740337197);
                            "\u575b\u69aa".length();
                            "\u5803\u632e\u5f2f".length();
                            final int n98 = 1;
                            final Object[] array124 = { null };
                            "\u6510".length();
                            "\u6d6c\u56a0\u52ee\u5f85\u4fe3".length();
                            array124[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(993566206, -1384249635, "\ub540", 1523653038, -427673681);
                            array123[n98] = StyleUtils.gray(array124);
                            array122[n97] = StyleUtils.gray(array123);
                            array121[n96] = StyleUtils.gold(array122);
                            player32.sendMessage(StyleUtils.gray(array121));
                        }
                        return true;
                    }
                    else if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(51394493, -1403395889, "\ub921\ub90a\ub90e", 1408199948, -1788804242))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(503237981, -682831496, "\u6816\u6824\u683a\u6833\u6821\u6878\u683e\u68c9\u68e2\u68c8\u68ca", 1673765753, -681519260)) || !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-120021116, -1055711358, "\u5fbb\u5f8b\u5f9b\u5f94\u5f84\u5fdf\u5f8c\u5f86\u5fa2", -2139152538, -246234891))) {
                            final Object[] array125 = new Object[2];
                            "\u5dd0\u6d1b\u58d0\u6b14".length();
                            array125[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1462157468, -953829253, "\u2d02\u292c\u2d22\u2d22\u2d51\u2936\u2d24\u2d20\u2d77\u2939\u2d2d\u2d40\u2d35\u2d26", -1665210066, -991315797);
                            "\u51ad\u6c54\u53e8\u5da4\u5027".length();
                            "\u6731\u62c7\u676f".length();
                            final int n99 = 1;
                            final Object[] array126 = { null };
                            "\u633c\u5f98".length();
                            array126[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(269124954, -1584325607, "\u806a", -111579799, 842626082);
                            array125[n99] = StyleUtils.gray(array126);
                            commandSender.sendMessage(StyleUtils.red(array125));
                            return true;
                        }
                        if (this.teleportCooldowns.containsKey(key2)) {
                            final long n100 = this.teleportCooldowns.get(key2) + 10000L - System.currentTimeMillis();
                            if (n100 > 0L) {
                                final Player player33 = key2;
                                final Object[] array127 = new Object[2];
                                "\u645e\u59d5\u52fd\u65c7".length();
                                array127[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1975292298, -1768539783, "\ubd5d\ubd53\ubd5b\ubd55\ubd5d\ubd5b\ubd5e\ubcd6\ubc83\ub8b8\ubca8\ubcc0\ubcbb\ub8bd", -242201351, 184001271);
                                "\u5a3f\u6e5b\u6b8b\u55b7".length();
                                "\u6b13\u6e83\u6fe4".length();
                                final int n101 = 1;
                                final Object[] array128 = new Object[3];
                                "\u560c".length();
                                "\u6334\u6c64".length();
                                "\u5144\u5e86\u6cb2\u700e\u5ec2".length();
                                array128[0] = n100 / 1000L;
                                "\u669a\u6690".length();
                                "\u615e".length();
                                "\u61ab\u51a6".length();
                                "\u5756\u6f13".length();
                                array128[1] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1110282827, -1011433330, "\u546d\u5027\u5051\u505e\u5027\u5041\u5041", 1489459275, 1304863102);
                                "\u516d\u504c\u4faa".length();
                                "\u518b\u5355\u645f".length();
                                "\u661d".length();
                                "\u5933\u4f74".length();
                                final int n102 = 2;
                                final Object[] array129 = { null };
                                "\u4f8a\u66d5\u6cc8".length();
                                "\u665a\u61ee".length();
                                array129[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1233901515, -1314432164, "\u3a34\u3a13\u3a66\u3a11\u3a16\u3e04\u3a6d\u3a16\u3a23\u3e13\u3a0e\u3a16\u3a1d\u3e16\u3a0f\u3a62\u3a08\u3a15\u3a3e\u69f3\u6edc\u6d99\u66f7\u59cd\u5318\u5ab3\u509d\u5894\u6b36\u5829\u6b75\u5dbc\u6b54\u6720\u5a22\u66c2\u6356\u5455\u68ae\u558b\u564f", -1911718584, -994324585);
                                array128[n102] = StyleUtils.red(array129);
                                array127[n101] = StyleUtils.gold(array128);
                                player33.sendMessage(StyleUtils.red(array127));
                                return true;
                            }
                        }
                        this.teleportCooldowns.put(key2, System.currentTimeMillis());
                        "\u6ae6".length();
                        "\u5274\u554e\u6583\u5150".length();
                        "\u632c\u5723\u6a06".length();
                        "\u65c9\u6bfa".length();
                        final World world2 = key2.getWorld();
                        "\u5b91\u6390\u5c8b\u5680\u6898".length();
                        "\u6600\u544b".length();
                        final Random random = new Random();
                        key2.sendTitle(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-484670162, 1638482366, "\u8469\u84d4\u80e0\u80c3\u80c7\u80b8\u80cc\u84da\u80e6\u80c3\u80bc\u80ad\u80da\u84d5\u84d0", 382999534, -1615569933), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1590758401, 1105119027, "", 634289495, -18801997), 10, 70, 20);
                        for (int i = 0; i < 10; i += 23861, i -= 23860) {
                            final double n103 = key2.getLocation().getX() + random.nextDouble() * 10000.0;
                            final double n104 = 5000.0;
                            "\u5e2a\u6ec2".length();
                            "\u52fd\u6612".length();
                            final double a = n103 - n104;
                            final double n105 = key2.getLocation().getZ() + random.nextDouble() * 10000.0;
                            final double n106 = 5000.0;
                            "\u4fcf\u58d0".length();
                            "\u6d12\u5c92".length();
                            "\u55fa\u65c5\u5459\u6710".length();
                            final double a2 = n105 - n106;
                            final double a3 = ColonialObfuscator_\u6857\u50b3\u5d74\u63a8\u5385\u4fbd\u6ba7\u4f4d\u6f1c\u5ba0\u65c4\u6c86\u5035\u5219\u5212\u5c22\u565f\u604f\u54fc\u52bd\u6905\u6e61\u690c\u538f\u667f\u4f2f\u6d29\u6c7a\u6bfd\u6a74\u67cd\u59df\u4ee6\u5686\u5c3c\u5364\u6818\u6216\u5a9c\u593d\u68fa(world2.getHighestBlockYAt((int)a, (int)a2), 1);
                            final Block block = world2.getBlockAt((int)a, (int)a3, (int)a2);
                            if (block.getType() != Material.LAVA && block.getType() != Material.CAVE_AIR) {
                                "\u6fbc\u5985\u5cea\u6ade\u6890".length();
                                final Location location2 = new Location(world2, a, a3, a2);
                                this.playerPreviousLocations.put(key2, key2.getLocation());
                                "\u5c64\u623e\u61b2\u50f6\u66ed".length();
                                key2.teleport(location2);
                                "\u4e40\u57b6\u6e33".length();
                                "\u5ba8\u6bb1\u66a4\u6ba2\u6a6f".length();
                                "\u4ee4\u5327\u5bb4".length();
                                "\u5aee\u5d7a\u6e7c\u60d2\u5988".length();
                                world2.playSound(location2, Sound.ENTITY_FIREWORK_ROCKET_BLAST, 30.0f, 1.0f);
                                world2.spawnParticle(Particle.EXPLOSION_LARGE, location2, 1);
                                final Player player34 = key2;
                                "\u63ad\u6705".length();
                                "\u6469".length();
                                "\u6623".length();
                                "\u55ae\u5468\u5700\u57db\u6057".length();
                                player34.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 40, 0));
                                "\u564e\u6064\u65cf\u5807".length();
                                "\u5037".length();
                                final Player player35 = key2;
                                "\u6c25\u55ea\u5b07\u53e3\u6111".length();
                                player35.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 40, 0));
                                "\u6a14".length();
                                key2.sendTitle(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1915298685, -546044313, "\u7909\u79b6\u7da2\u7db4\u7dcc\u7dcc\u7db2\u7db1\u7d97\u7db4\u7dce\u79ad\u7dc8\u7dac\u7da1\u7dbd\u7dad\u7db2\u7de0\u2e56\u2976\u2a4e\u2150\u1e19\u10f5", -873713339, 1447596620), invokedynamic(makeConcatWithConstants:(JJJ)Ljava/lang/String;, Math.round(a), Math.round(a3), Math.round(a2)), 10, 70, 20);
                                return true;
                            }
                        }
                        final Player player36 = key2;
                        final Object[] array130 = new Object[2];
                        "\u58dd".length();
                        "\u680c\u575b\u5e66".length();
                        array130[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1537334250, -812304873, "\uce9a\uce9f\uca8a\uceeb\uce9a\uce98\uce98\uce91\uced2\ucef3\uca98\uce97\uce9b\uce83\ucef9\uce97\uca9b\uce98\uceb7\u9d07\u9a22\u9915\u927d\uad3e\ua75f\uae86\ua0c4\ua8c2\u9f78\uac6c\u9f48\ua98f\u9f12\u970f\uaa7a\u92f4\u9768\ua407\u9c92\ua1c2\ua616\ua9ce\ua6c5\ua4f3\u9442\ubf6f\u9b3b\uaf14\u9ec3\u97c9", 1153661800, 133192785);
                        "\u6268\u4ebf".length();
                        "\u5fcd\u6ff4\u544f\u506c".length();
                        "\u682f\u4f03\u6528\u57e9\u532f".length();
                        final int n107 = 1;
                        final Object[] array131 = { null };
                        "\u6e4c\u5e0a\u5d40\u559b\u59d4".length();
                        "\u67d9\u5eae\u4e2d\u5e6b".length();
                        array131[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-423129677, -603604923, "\ub5ec", 455300929, 1281677113);
                        array130[n107] = StyleUtils.gray(array131);
                        player36.sendMessage(StyleUtils.red(array130));
                        return true;
                    }
                    else if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1006540633, 630189234, "\u9fed\u9fc4\u9fb8\u9fa5\u9fbb", 1892805182, -1771179535))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1608180372, -909148265, "\u14bb\u148b\u148b\u1484\u1494\u14cf\u148f\u1486\u14af\u1487\u148b", 1065001774, 1903220032)) || !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1477075433, 1772894175, "\uebe0\uebde\uebc0\uebcd\uebdf\ueb82\uebd1\uebdb\uebf9\uebf4\uebed", -730340009, -632268625))) {
                            final Object[] array132 = new Object[2];
                            "\u51e0".length();
                            "\u660c".length();
                            "\u5b7e\u6ae1\u642a".length();
                            array132[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-173799973, -536866197, "\uf970\ufd5c\uf94c\uf942\uf933\ufd56\uf942\uf940\uf915\ufd59\uf943\uf930\uf947\uf956", 1114354149, 612195141);
                            "\u5513".length();
                            "\u505b".length();
                            "\u5a70\u6405\u6c39".length();
                            final int n108 = 1;
                            final Object[] array133 = { null };
                            "\u590a".length();
                            "\u5bf9\u5261".length();
                            "\u6b0b".length();
                            array133[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1871092233, -64155320, "\u5ff9", -1621887330, 1007297092);
                            array132[n108] = StyleUtils.gray(array133);
                            commandSender.sendMessage(StyleUtils.red(array132));
                            return true;
                        }
                        if (original.length != 3) {
                            final Player player37 = key2;
                            final Object[] array134 = new Object[2];
                            "\u6ed8\u5866\u6a6e".length();
                            "\u70b1\u639e".length();
                            "\u5066".length();
                            array134[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1385212618, 593689096, "\u0e3d\u0e4b\u0e37\u0e32\u0e37\u0e44\u0e36\u0e3d\u0e13\u0e3f\u0e37\u0e26\u0e2c\u0a30\u0a29", -2123828047, -1979821591);
                            "\u4ef8\u51f6".length();
                            "\u5c36\u6609".length();
                            "\u6f57\u67d1\u544f\u5b2e\u5fc5".length();
                            "\u67d3".length();
                            "\u4e3a\u6787\u6a3a\u5061\u5367".length();
                            final int n109 = 1;
                            final Object[] array135 = { null };
                            "\u5ba9\u6611\u64ee\u6800\u6d2b".length();
                            "\u5dce".length();
                            array135[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(766118435, 1604629306, "\u767b\u760d\u7609\u760b\u761a\u7600\u7658\u7648\u7628\u7642\u765b\u7655\u7609\u765f\u7640\u7648\u7612\u764a", 2104287396, 901918634);
                            array134[n109] = StyleUtils.gold(array135);
                            player37.sendMessage(StyleUtils.gray(array134));
                            return true;
                        }
                        try {
                            final double double4 = Double.parseDouble(original[0]);
                            final double double5 = Double.parseDouble(original[1]);
                            final double double6 = Double.parseDouble(original[2]);
                            this.playerPreviousLocations.put(key2, key2.getLocation());
                            "\u63bb\u6018\u6edb".length();
                            "\u62e8".length();
                            final Player player38 = key2;
                            "\u6c9e\u60ae\u5aa8\u5cc1".length();
                            player38.teleport(new Location(key2.getWorld(), double4, double5, double6));
                            "\u5bae\u6c47\u52ff\u5f16".length();
                            final Player player39 = key2;
                            final Object[] array136 = new Object[2];
                            "\u55b1".length();
                            "\u5d3c\u660a\u648c\u5853\u5889".length();
                            array136[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(935464442, -1754431620, "\u9d5d\u9d29\u994e\u9d2e\u9d5b\u9d53\u9d52\u9d54\u9d75\u9d27\u9d3e\u9d56\u9d2b\u9d44\u9d4d\u9d5b\u9d48\u9d57\u9d0c\ucebb\ucd87\ucad6\uc1bd\ufa95\uf414\ufdb5\uf38b\uffe6\ucc30\uff21\ucc70\ufab9\ucc26\uc02c\ufd2a", 781852966, -680211796);
                            "\u5305\u5fdf\u5a8a\u5525\u63ba".length();
                            "\u6901\u50f4\u5a75".length();
                            "\u6c96\u587c\u5165".length();
                            "\u64f5\u5d70\u702d\u5c09\u6ad3".length();
                            "\u4fc7\u6fe9\u6ace".length();
                            final int n110 = 1;
                            final Object[] array137 = new Object[4];
                            "\u597d\u7114\u5564\u6ca0\u5305".length();
                            "\u6443".length();
                            "\u5bab\u6342\u522e".length();
                            array137[0] = double4;
                            "\u4eca".length();
                            "\u5c4c\u5e5a\u5683\u6b73\u68e5".length();
                            array137[1] = double5;
                            "\u61aa".length();
                            array137[2] = double6;
                            "\u6505".length();
                            "\u5702\u6084\u526f\u5d21".length();
                            final int n111 = 3;
                            final Object[] array138 = { null };
                            "\u67f3\u68e0\u53a1\u7061".length();
                            array138[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-773251893, -1966564559, "\u830d", 1915944094, 889124875);
                            array137[n111] = StyleUtils.gray(array138);
                            array136[n110] = StyleUtils.gold(array137);
                            player39.sendMessage(StyleUtils.gray(array136));
                        }
                        catch (NumberFormatException ex12) {
                            final Player player40 = key2;
                            final Object[] array139 = new Object[2];
                            "\u669e\u51b3\u6d52".length();
                            "\u6b59\u6086\u5772\u628e\u6faa".length();
                            "\u6b65\u5ee8\u6662\u5b5d\u58c9".length();
                            array139[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1976275019, 1406510448, "\u883c\u8839\u8836\u8830\u8850\u8823\u8827\u8853\u8808\u8852\u882b\u8c2c\u883f\u882a\u882b\u8841\u8829\u8839\u8812\udba5\udc7b\udf3e", -880563604, 2083984181);
                            "\u69d5".length();
                            "\u57cb\u51ff".length();
                            final int n112 = 1;
                            final Object[] array140 = { null };
                            "\u6a29\u599c\u5c02\u4f04\u664c".length();
                            array140[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1676454063, 1280892873, "\u1d21", -1505723153, -1121457868);
                            array139[n112] = StyleUtils.gray(array140);
                            player40.sendMessage(StyleUtils.red(array139));
                        }
                        return true;
                    }
                    else if (command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1545442548, -2127644906, "\u0613\u063a\u0637\u0638\u063a", 2143745774, -1786434352))) {
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2040653636, 792903873, "\ua7d3\ua7e3\ua7ff\ua7f0\ua7e4\ua7bf\ua7fb\ua7f2\ua7d7\ua7ff\ua7ff", 1930912304, 2014584240)) || !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-112198043, -1072572558, "\uf389\uf3bb\uf3a5\uf354\uf346\uf31f\uf34c\uf342\uf371\uf352\uf357", 1192792957, -1463531059))) {
                            final Object[] array141 = new Object[2];
                            "\u6c4c\u64f3\u50f8".length();
                            "\u5682\u598e\u5ebf".length();
                            "\u5597\u6317\u62ff".length();
                            array141[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1931116459, 1563096503, "\u6ac3\u6eed\u6afb\u6afb\u6a88\u6eef\u6b05\u6b01\u6b56\u6f18\u6b04\u6b69\u6b1c\u6b0f", -441658630, 2093430341);
                            "\u4f05\u5623\u5799\u648a".length();
                            "\u51fb\u53af".length();
                            "\u624f\u500f\u6d07".length();
                            final int n113 = 1;
                            final Object[] array142 = { null };
                            "\u50e3\u6986\u6ad3\u4f4b\u6eae".length();
                            array142[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1932774658, -1971990202, "\ub642", 1833704874, 1984251954);
                            array141[n113] = StyleUtils.gray(array142);
                            commandSender.sendMessage(StyleUtils.red(array141));
                            return true;
                        }
                        for (final Player player41 : Bukkit.getOnlinePlayers()) {
                            if (player41 != key2) {
                                player41.teleport(key2.getLocation());
                                "\u4efe\u6de4\u61ac\u5d9d\u6e5a".length();
                                "\u5733\u6e1d".length();
                            }
                        }
                        final Player player42 = key2;
                        final Object[] array143 = { null };
                        "\u6d6f\u5879\u5029\u711e".length();
                        "\u51c4".length();
                        "\u6a0c\u5e4f\u67d5\u574c".length();
                        "\u637d\u625e\u4f14\u5bd8\u54c1".length();
                        array143[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1246872338, 440467513, "\u6e25\u6e59\u6e2f\u6a3e\u6e26\u6e29\u6e53\u6e2f\u6e09\u6e25\u6a38\u6e4e\u6e3e\u6e23\u6e2e\u6e0e\u6e15\u6e75\u6e5b\u3d9d\u3ab7\u3987\u32eb\u0ddf\u074b\u0eec\u00da\u08a4\u3f1e\u081b\u3f5b\u0983\u3f60\u377c", -356874287, 1202794126);
                        player42.sendMessage(StyleUtils.gray(array143));
                        return true;
                    }
                    else {
                        if (!command.getName().equalsIgnoreCase(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1326199108, 806806325, "\ueed9\ueee9\ueee9\ueee1", 332295343, -603107290))) {
                            return false;
                        }
                        if (!commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(645503438, 655225807, "\ueeb2\uee9c\uee82\uee8f\uee9d\ueec0\uee86\uee8d\ueea6\uee80\uee82", -1957604881, 1236129138)) || !commandSender.hasPermission(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-110609627, -1525984154, "\u92ff\u92cd\u92d3\u92da\u92c8\u9291\u92d4\u92d5\u92f5\u92d3", -1377296271, 1280695779))) {
                            final Object[] array144 = new Object[2];
                            "\u6f4f\u62e9\u5b83".length();
                            array144[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1605176372, 367079335, "\u2066\u2448\u2026\u2026\u2055\u2432\u2020\u2024\u2073\u243d\u2029\u2044\u2031\u2022", 1745233726, -571006805);
                            "\u5e46\u5f34\u5f7f".length();
                            "\u5ae8\u57b5".length();
                            final int n114 = 1;
                            final Object[] array145 = { null };
                            "\u6a1d\u68bd\u6d77\u65d1\u6d2d".length();
                            array145[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1179137112, -1791685351, "\u5676", 1614786657, 609755332);
                            array144[n114] = StyleUtils.gray(array145);
                            commandSender.sendMessage(StyleUtils.red(array144));
                            return true;
                        }
                        final Location location3 = this.playerPreviousLocations.get(key2);
                        if (location3 == null) {
                            final Player player43 = key2;
                            final Object[] array146 = new Object[2];
                            "\u5797\u6439\u6ce0".length();
                            "\u5157\u520f\u6095\u62bb\u69e1".length();
                            array146[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(958252047, -79907259, "\u65c1\u61ef\u65f9\u65f9\u658a\u61ed\u65f7\u65f3\u65a4\u61ea\u65f6\u659b\u65eb\u65fb\u65b9\u65d2\u65bd\u65ab\u65fd\u364b\u3502\u3251\u393e\u060f\u0c9b\u0540\u0b78\u076b", -469221870, -523883015);
                            "\u6f64\u7094\u5115\u6a73\u57e9".length();
                            "\u5d6b\u5fdb\u58aa".length();
                            final int n115 = 1;
                            final Object[] array147 = { null };
                            "\u5726\u6752\u4fc6\u5466".length();
                            "\u56e5".length();
                            "\u525e".length();
                            array147[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-816282369, 1014215297, "\u0a29", -1735164989, 623855606);
                            array146[n115] = StyleUtils.gray(array147);
                            player43.sendMessage(StyleUtils.red(array146));
                            return true;
                        }
                        key2.teleport(location3);
                        "\u6639\u6b64\u5bae\u5507\u7099".length();
                        "\u56f1".length();
                        final Player player44 = key2;
                        final Object[] array148 = { null };
                        "\u585a\u6e3c\u6844\u57b6\u6d6c".length();
                        "\u5671\u5d65\u4e95\u54bd\u5baa".length();
                        array148[0] = \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-624390864, 725622125, "\ufe05\ufe71\ufa1e\ufe0e\ufe0b\ufe78\ufe02\ufe70\ufe28\ufe07\ufe7d\ufe62\ufa0b\ufe07\ufe17\ufa13\ufe14\ufe77\ufe28\uad93\uaabc\ua98f\ua296\u9da4\u9735\u9e9d\u94b5\u9cb9\uaf1a\u9c0e\uafad\u9917\uaf84\ua3f1\u9efb", 115267938, -711347349);
                        player44.sendMessage(StyleUtils.gray(array148));
                        return true;
                    }
                }
            }
        }
    }
    
    @EventHandler
    public void onItemSpawn(final ItemSpawnEvent itemSpawnEvent) {
        final Item entity = itemSpawnEvent.getEntity();
        final int amount = entity.getItemStack().getAmount();
        this.itemAmountMap.put(entity, amount);
        "\u6fad\u5c1d\u5186\u6223".length();
        "\u602d\u554d\u611c\u4e27\u4f91".length();
        "\u693c\u545f\u5c28\u5926".length();
        this.updateItemName(entity, amount);
        this.optimizeItems();
    }
    
    @EventHandler
    public void onItemMerge(final ItemMergeEvent itemMergeEvent) {
        final Item target = itemMergeEvent.getTarget();
        final Item entity = itemMergeEvent.getEntity();
        final int colonialObfuscator_\u6857\u50b3\u5d74\u63a8\u5385\u4fbd\u6ba7\u4f4d\u6f1c\u5ba0\u65c4\u6c86\u5035\u5219\u5212\u5c22\u565f\u604f\u54fc\u52bd\u6905\u6e61\u690c\u538f\u667f\u4f2f\u6d29\u6c7a\u6bfd\u6a74\u67cd\u59df\u4ee6\u5686\u5c3c\u5364\u6818\u6216\u5a9c\u593d\u68fa = ColonialObfuscator_\u6857\u50b3\u5d74\u63a8\u5385\u4fbd\u6ba7\u4f4d\u6f1c\u5ba0\u65c4\u6c86\u5035\u5219\u5212\u5c22\u565f\u604f\u54fc\u52bd\u6905\u6e61\u690c\u538f\u667f\u4f2f\u6d29\u6c7a\u6bfd\u6a74\u67cd\u59df\u4ee6\u5686\u5c3c\u5364\u6818\u6216\u5a9c\u593d\u68fa(this.itemAmountMap.getOrDefault(target, 0), this.itemAmountMap.getOrDefault(entity, 0));
        this.itemAmountMap.put(target, colonialObfuscator_\u6857\u50b3\u5d74\u63a8\u5385\u4fbd\u6ba7\u4f4d\u6f1c\u5ba0\u65c4\u6c86\u5035\u5219\u5212\u5c22\u565f\u604f\u54fc\u52bd\u6905\u6e61\u690c\u538f\u667f\u4f2f\u6d29\u6c7a\u6bfd\u6a74\u67cd\u59df\u4ee6\u5686\u5c3c\u5364\u6818\u6216\u5a9c\u593d\u68fa);
        "\u5d98\u67c1".length();
        "\u4f87".length();
        "\u6efd\u5f0e\u5946\u5d5c\u585e".length();
        "\u5cb5".length();
        this.itemAmountMap.remove(entity);
        "\u6c76\u6a38\u6a31\u4e38\u5a72".length();
        this.updateItemName(target, colonialObfuscator_\u6857\u50b3\u5d74\u63a8\u5385\u4fbd\u6ba7\u4f4d\u6f1c\u5ba0\u65c4\u6c86\u5035\u5219\u5212\u5c22\u565f\u604f\u54fc\u52bd\u6905\u6e61\u690c\u538f\u667f\u4f2f\u6d29\u6c7a\u6bfd\u6a74\u67cd\u59df\u4ee6\u5686\u5c3c\u5364\u6818\u6216\u5a9c\u593d\u68fa);
        this.optimizeItems();
    }
    
    public void updateItemName(final Item item, final int n) {
        final String formatItemName = this.formatItemName(item.getItemStack(), n);
        if (this.getConfig().getBoolean(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1271364554, -630712991, "\uf921\uf931\uf920\uf92a\uf92a\uf971\uf907\uf930\uf913\uf927\uf903\uf924\uf92b\uf92e", -681559124, -711545812), true)) {
            item.setCustomName(invokedynamic(makeConcatWithConstants:(Lorg/bukkit/ChatColor;Ljava/lang/String;)Ljava/lang/String;, ChatColor.GRAY, formatItemName));
            item.setCustomNameVisible(true);
        }
        else {
            item.setCustomName(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-888088690, -1200251240, "", 2001530981, -1310860297));
            item.setCustomNameVisible(false);
        }
    }
    
    public String formatItemName(final ItemStack itemStack, final int n) {
        final String s = (itemStack.hasItemMeta() && itemStack.getItemMeta().hasDisplayName()) ? itemStack.getItemMeta().getDisplayName() : null;
        if (s != null) {
            return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Lorg/bukkit/ChatColor;I)Ljava/lang/String;, s, ChatColor.GOLD, n);
        }
        final String[] split = itemStack.getType().toString().replace(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1861346459, 1638432990, "\u7489", -1483073343, 1463486481), \u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-2062199275, 1984075136, "\u3711", 104531826, -16911467)).split(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(1296587617, 1571650388, "\udf9c", -1219308669, -966382519));
        "\u5da6\u65d6\u52eb\u4f2a".length();
        "\u5ea0\u6576".length();
        "\u6e09\u55b7".length();
        final StringBuilder sb = new StringBuilder();
        final String[] array = split;
        for (int length = array.length, i = 0; i < length; i += 32571, i -= 32570) {
            final String s2 = array[i];
            if (!s2.isEmpty()) {
                sb.append(s2.substring(0, 1).toUpperCase()).append(s2.substring(1).toLowerCase()).append(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-1066856207, -1431586468, "\ub0db", 2016440125, 1472296488));
                "\u6c57".length();
            }
        }
        return invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Lorg/bukkit/ChatColor;I)Ljava/lang/String;, sb.toString().trim(), ChatColor.GOLD, n);
    }
    
    public void optimizeItems() {
        for (final Item item : this.findItemsToRemove()) {
            this.itemAmountMap.remove(item);
            "\u62c4\u520c\u5b6b\u6ad7".length();
            "\u4f15\u575c\u5a35\u5abe\u6f1e".length();
            "\u671f".length();
            "\u4f6d\u64d2".length();
            item.setCustomName(\u5627\u576c\u5133\u4f49\u5fce\u5912\u59f2\u5c41\u589e\u70cc\u5d4a\u632a\u5aa8\u5ce1\u666b\u5ec1\u5c72\u64f5\u6d9a\u6380\u4e55\u6912\u57fe\u650c\u6205\u5f97\u60bb\u5e43\u5cd5\u4f27\u6b30\u6237\u679a\u6d47\u69fb\u680e\u666a\u59d7\u6523\u5888\u683d(-933628648, 1221716858, "", -1115701691, -1466466973));
        }
    }
    
    public List<Item> findItemsToRemove() {
        "\u6e16\u4e48\u5b20".length();
        "\u6be0\u6dbc".length();
        "\u5de4".length();
        final ArrayList<Object> list = new ArrayList<Object>();
        for (final Item item : this.itemAmountMap.keySet()) {
            if (this.countNearbyItems(item) > this.maxItemsInRadius) {
                list.add(item);
                "\u5bd6".length();
                "\u6521\u68aa\u67da".length();
                "\u5713\u62a0".length();
                "\u6a45\u64e7\u6ca8\u5ae7\u5364".length();
                "\u621b\u67ce\u64a7\u54f8\u6b93".length();
            }
        }
        return (List<Item>)list.subList(0, Math.min(this.maxItemsInRadius, list.size()));
    }
    
    public int countNearbyItems(final Item item) {
        int n = 0;
        for (final Entity entity : item.getNearbyEntities((double)this.maxRadius, (double)this.maxRadius, (double)this.maxRadius)) {
            if (entity instanceof Item && this.itemAmountMap.containsKey(entity)) {
                n += 17360;
                n -= 17359;
            }
        }
        return n;
    }
    
    public static int ColonialObfuscator_\u6857\u50b3\u5d74\u63a8\u5385\u4fbd\u6ba7\u4f4d\u6f1c\u5ba0\u65c4\u6c86\u5035\u5219\u5212\u5c22\u565f\u604f\u54fc\u52bd\u6905\u6e61\u690c\u538f\u667f\u4f2f\u6d29\u6c7a\u6bfd\u6a74\u67cd\u59df\u4ee6\u5686\u5c3c\u5364\u6818\u6216\u5a9c\u593d\u68fa(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
