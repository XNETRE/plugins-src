package io.leangen.geantyref;

import java.lang.reflect.*;
import java.lang.annotation.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class AnnotatedTypeImpl implements AnnotatedType
{
    public AnnotatedTypeImpl(final Type type) {
        this(type, new Annotation[0]);
    }
    
    public AnnotatedTypeImpl(final Type obj, final Annotation[] array) {
        this.type = Objects.requireNonNull(obj);
        this.annotations = new LinkedHashMap<Class<? extends Annotation>, Annotation>();
        for (int length = array.length, i = 0; i < length; i -= 15420, i += 15421) {
            final Annotation annotation = array[i];
            this.annotations.put(annotation.annotationType(), annotation);
        }
    }
    
    @Override
    public Type getType() {
        return this.type;
    }
    
    @Override
    public <T extends Annotation> T getAnnotation(final Class<T> clazz) {
        return (T)this.annotations.get(clazz);
    }
    
    @Override
    public Annotation[] getAnnotations() {
        return this.annotations.values().toArray(new Annotation[0]);
    }
    
    @Override
    public Annotation[] getDeclaredAnnotations() {
        return this.getAnnotations();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AnnotatedType)) {
            return false;
        }
        final AnnotatedType annotatedType = (AnnotatedType)o;
        return this.getType().equals(annotatedType.getType()) && Arrays.equals(this.getAnnotations(), annotatedType.getAnnotations());
    }
    
    @Override
    public int hashCode() {
        return 127 * this.getType().hashCode() ^ Arrays.hashCode(this.getAnnotations());
    }
    
    @Override
    public String toString() {
        "\u6f86\u5e10\u6248\u63ae\u5d8c".length();
        "\u59de\u53b6".length();
        return this.annotationsString() + GenericTypeReflector.getTypeName(this.type);
    }
    
    public String annotationsString() {
        String s;
        if (this.annotations.isEmpty()) {
            s = \u5101\u5386\u620c\u510d\u6c3b\u6b16\u62bd\u51b2\u5998\u59cb\u4ff4\u5d7e\u686d\u4e94\u6cc0\u6320\u6a05\u5a64\u6d03\u548e\u56b7\u6b5c\u6253\u6588\u70cc\u574b\u539a\u6a9c\u520a\u6df5\u68e4\u5766\u5045\u63bb\u63d2\u6b46\u5de4\u64b6\u59c5\u6891\u5944(-1172771072, 312401093, "", 718935558, -505228765);
        }
        else {
            "\u4e32\u60d3".length();
            "\u6a96\u6398\u620a".length();
            s = this.annotations.values().stream().map((Function<? super Annotation, ?>)Annotation::toString).collect((Collector<? super Object, ?, String>)Collectors.joining(\u5101\u5386\u620c\u510d\u6c3b\u6b16\u62bd\u51b2\u5998\u59cb\u4ff4\u5d7e\u686d\u4e94\u6cc0\u6320\u6a05\u5a64\u6d03\u548e\u56b7\u6b5c\u6253\u6588\u70cc\u574b\u539a\u6a9c\u520a\u6df5\u68e4\u5766\u5045\u63bb\u63d2\u6b46\u5de4\u64b6\u59c5\u6891\u5944(-709725944, -1538521768, "\u3a3f\u3a10", -385746137, -835341017))) + \u5101\u5386\u620c\u510d\u6c3b\u6b16\u62bd\u51b2\u5998\u59cb\u4ff4\u5d7e\u686d\u4e94\u6cc0\u6320\u6a05\u5a64\u6d03\u548e\u56b7\u6b5c\u6253\u6588\u70cc\u574b\u539a\u6a9c\u520a\u6df5\u68e4\u5766\u5045\u63bb\u63d2\u6b46\u5de4\u64b6\u59c5\u6891\u5944(-96118110, -1761367086, "\u873a", -868991728, -1779348679);
        }
        return s;
    }
    
    public String typesString(final AnnotatedType[] array) {
        return Arrays.stream(array).map((Function<? super AnnotatedType, ?>)Object::toString).collect((Collector<? super Object, ?, String>)Collectors.joining(\u5101\u5386\u620c\u510d\u6c3b\u6b16\u62bd\u51b2\u5998\u59cb\u4ff4\u5d7e\u686d\u4e94\u6cc0\u6320\u6a05\u5a64\u6d03\u548e\u56b7\u6b5c\u6253\u6588\u70cc\u574b\u539a\u6a9c\u520a\u6df5\u68e4\u5766\u5045\u63bb\u63d2\u6b46\u5de4\u64b6\u59c5\u6891\u5944(-1963481055, 1144660180, "\u1ab2\u1a93", 642379844, -342531476)));
    }
    
    public static int ColonialObfuscator_\u538a\u6af5\u6c9f\u669d\u639f\u632e\u61f6\u6f71\u559e\u5e85\u635b\u54f4\u6637\u500c\u5115\u6dea\u685d\u60ec\u6bd8\u6692\u6247\u562e\u555d\u6a2d\u5a77\u69dd\u66e8\u632e\u584c\u608c\u6dda\u5361\u5d96\u52c9\u61a4\u4ef9\u591e\u54c1\u5ec7\u64b1\u5750(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
