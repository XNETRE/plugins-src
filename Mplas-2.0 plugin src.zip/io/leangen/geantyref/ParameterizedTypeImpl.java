package io.leangen.geantyref;

import java.lang.reflect.*;
import java.util.*;

public class ParameterizedTypeImpl implements ParameterizedType
{
    public ParameterizedTypeImpl(final Class<?> rawType, final Type[] actualTypeArguments, final Type ownerType) {
        this.rawType = rawType;
        this.actualTypeArguments = actualTypeArguments;
        this.ownerType = ownerType;
    }
    
    @Override
    public Type getRawType() {
        return this.rawType;
    }
    
    @Override
    public Type[] getActualTypeArguments() {
        return this.actualTypeArguments;
    }
    
    @Override
    public Type getOwnerType() {
        return this.ownerType;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof ParameterizedType)) {
            return false;
        }
        final ParameterizedType parameterizedType = (ParameterizedType)o;
        return this == parameterizedType || (Objects.equals(this.ownerType, parameterizedType.getOwnerType()) && Objects.equals(this.rawType, parameterizedType.getRawType()) && Arrays.equals(this.actualTypeArguments, parameterizedType.getActualTypeArguments()));
    }
    
    @Override
    public int hashCode() {
        return Arrays.hashCode(this.actualTypeArguments) ^ Objects.hashCode(this.ownerType) ^ Objects.hashCode(this.rawType);
    }
    
    @Override
    public String toString() {
        "\u4e53\u6c0e\u554b".length();
        "\u6670".length();
        "\u595d".length();
        final StringBuilder sb = new StringBuilder();
        String str = this.rawType.getName();
        if (this.ownerType != null) {
            sb.append(GenericTypeReflector.getTypeName(this.ownerType)).append('.');
            "\u5cdc\u6467\u593c".length();
            String s;
            if (this.ownerType instanceof ParameterizedType) {
                "\u67de\u5778".length();
                s = ((Class)((ParameterizedType)this.ownerType).getRawType()).getName() + '$';
            }
            else {
                "\u5d7e\u6ab6".length();
                "\u6021\u524a".length();
                "\u60b6".length();
                s = ((Class)this.ownerType).getName() + '$';
            }
            final String prefix = s;
            if (str.startsWith(prefix)) {
                str = str.substring(prefix.length());
            }
        }
        sb.append(str);
        "\u6910\u5e92\u6c3c\u658a\u5283".length();
        "\u5d0f\u6797\u4e5f\u5e69".length();
        if (this.actualTypeArguments.length != 0) {
            sb.append('<');
            "\u682f\u63f0".length();
            "\u6ad9\u5484\u63de".length();
            for (int i = 0; i < this.actualTypeArguments.length; i += 2510, i -= 2509) {
                final Type type = this.actualTypeArguments[i];
                if (i != 0) {
                    sb.append(\u57cb\u68c9\u6eb9\u59ba\u4e4f\u6513\u69e0\u5442\u6fc0\u662a\u5e5b\u52cb\u5796\u6429\u5fdd\u5f09\u6149\u6c89\u5cf4\u5775\u53bc\u4e49\u4e88\u574d\u5776\u593a\u565a\u5a23\u6ae5\u5051\u5d0b\u542d\u6734\u64c8\u631e\u5002\u4f49\u6fd2\u6069\u52dc\u6a99(1328733672, 945611465, "\ub9d7\ub9f6", 491101268, 108665549));
                    "\u5c1b\u5cd3\u5959\u5a8c\u60ac".length();
                    "\u5346\u6b2b\u580d".length();
                    "\u6ceb\u5861\u62d9\u6d57".length();
                }
                sb.append(GenericTypeReflector.getTypeName(type));
                "\u6cbe\u5fa9\u550c".length();
                "\u6b65\u6c29\u665e\u6abc\u6833".length();
                "\u537b".length();
            }
            sb.append('>');
            "\u5255\u51e8".length();
            "\u5838\u70b5".length();
        }
        return sb.toString();
    }
    
    public static int ColonialObfuscator_\u6916\u66e4\u57b8\u58ae\u61dc\u52e7\u6409\u6a43\u5a8f\u52d4\u708f\u56fe\u705e\u5d09\u5bc8\u6255\u69d3\u644f\u6ea3\u6dde\u59ef\u6a87\u59c9\u5e5c\u66e5\u6132\u69c8\u5457\u7108\u6323\u712d\u62c5\u7073\u5b90\u60ef\u562d\u6094\u6f47\u6ec9\u5a0d\u5d1b(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
