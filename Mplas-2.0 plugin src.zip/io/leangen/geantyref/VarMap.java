package io.leangen.geantyref;

import java.lang.annotation.*;
import java.util.*;
import java.util.function.*;
import java.lang.reflect.*;

public class VarMap
{
    public VarMap() {
        this.map = new HashMap<TypeVariable, AnnotatedType>();
    }
    
    public VarMap(AnnotatedParameterizedType obj) {
        this.map = new HashMap<TypeVariable, AnnotatedType>();
        do {
            final Class clazz = (Class)((ParameterizedType)obj.getType()).getRawType();
            final AnnotatedType[] annotatedActualTypeArguments = obj.getAnnotatedActualTypeArguments();
            final TypeVariable[] typeParameters = clazz.getTypeParameters();
            if (annotatedActualTypeArguments.length != typeParameters.length) {
                throw new IllegalStateException(\u5008\u673f\u5c01\u4ff9\u5fff\u4ea9\u65b6\u5429\u5cdf\u7081\u6531\u51e2\u6e28\u589d\u6d53\u67a6\u6dd7\u6511\u64ae\u59cc\u65ab\u67fd\u5561\u5506\u5a0a\u528c\u56a5\u66c7\u5d42\u640e\u5293\u693b\u70aa\u4ede\u5700\u52c4\u62b7\u5da4\u5cca\u5373\u674b(200765667, -1558750389, "\u8b50\u8b43\u8b4c\u8b35\u8b72\u8b78\u8b6e\u8b77\u8b5e\u8b3e\u8b6f\u8b7e\u8b70\u8b76\u8b30\u8b59", 1042956573, -1587617294) + obj + \u5008\u673f\u5c01\u4ff9\u5fff\u4ea9\u65b6\u5429\u5cdf\u7081\u6531\u51e2\u6e28\u589d\u6d53\u67a6\u6dd7\u6511\u64ae\u59cc\u65ab\u67fd\u5561\u5506\u5a0a\u528c\u56a5\u66c7\u5d42\u640e\u5293\u693b\u70aa\u4ede\u5700\u52c4\u62b7\u5da4\u5cca\u5373\u674b(-1338317776, 549920327, "\uc31c\uc34c\uc305\uc31d\uc348\uc307\uc30b\uc30a\uc32a\uc307\uc31d\uc315\uc30e\uc318\uc308\uc317\uc309\uc35b\uc36f\ua8f8\u9273\uac11\u9a90\u9952\ua206\uac3c", 1130823072, -256916267) + annotatedActualTypeArguments.length + \u5008\u673f\u5c01\u4ff9\u5fff\u4ea9\u65b6\u5429\u5cdf\u7081\u6531\u51e2\u6e28\u589d\u6d53\u67a6\u6dd7\u6511\u64ae\u59cc\u65ab\u67fd\u5561\u5506\u5a0a\u528c\u56a5\u66c7\u5d42\u640e\u5293\u693b\u70aa\u4ede\u5700\u52c4\u62b7\u5da4\u5cca\u5373\u674b(-1739641182, -70398262, "\u5c07\u5c69\u5c78\u5c69\u5c7b\u5c67\u5c66\u5c7f\u5c47\u5c6e\u5c38\u5c65\u5c65\u5c6b\u5c6f\u5c64\u5c7a\u5c61\u5c09\u379e\u0d07\u3375", -1776902871, -1585635035) + typeParameters.length);
            }
            for (int i = 0; i < annotatedActualTypeArguments.length; i += 5261, i -= 5260) {
                this.add(typeParameters[i], annotatedActualTypeArguments[i]);
            }
            final Type ownerType = ((ParameterizedType)obj.getType()).getOwnerType();
            obj = ((ownerType instanceof ParameterizedType) ? ((AnnotatedParameterizedType)GenericTypeReflector.annotate(ownerType)) : null);
        } while (obj != null);
    }
    
    public VarMap(final ParameterizedType parameterizedType) {
        this((AnnotatedParameterizedType)GenericTypeReflector.annotate(parameterizedType));
    }
    
    public VarMap(final TypeVariable[] array, final AnnotatedType[] array2) {
        this.map = new HashMap<TypeVariable, AnnotatedType>();
        this.addAll(array, array2);
    }
    
    public void add(final TypeVariable typeVariable, final AnnotatedType annotatedType) {
        this.map.put(typeVariable, annotatedType);
        "\u5a62".length();
        "\u5960\u6e09".length();
    }
    
    public void addAll(final TypeVariable[] array, final AnnotatedType[] array2) {
        if (!VarMap.$assertionsDisabled && array.length != array2.length) {
            "\u4e27\u5f0d\u6cfb\u53c4\u5f37".length();
            "\u57fb\u6f6e\u5e98".length();
            final AssertionError assertionError = new AssertionError();
            "\u6b65\u6b7f".length();
            "\u5c84\u6c7e\u6706".length();
            "\u5f68\u55aa\u51a0\u4f7d\u6cd6".length();
            "\u6617\u697f\u5422".length();
            throw assertionError;
        }
        for (int i = 0; i < array.length; i -= 17102, i += 17103) {
            this.map.put(array[i], array2[i]);
            "\u6bb7\u5f40".length();
        }
    }
    
    public AnnotatedType map(final AnnotatedType annotatedType) {
        return this.map(annotatedType, MappingMode.EXACT);
    }
    
    public AnnotatedType map(final AnnotatedType obj, final MappingMode mappingMode) {
        if (obj.getType() instanceof Class) {
            return GenericTypeReflector.updateAnnotations(obj, ((Class)obj.getType()).getAnnotations());
        }
        if (obj instanceof AnnotatedTypeVariable) {
            final TypeVariable obj2 = (TypeVariable)obj.getType();
            if (this.map.containsKey(obj2)) {
                final TypeVariable typeVariable2 = this.map.keySet().stream().filter(typeVariable -> typeVariable.equals(obj2)).findFirst().get();
                final Annotation[][] array = new Annotation[4][];
                "\u5ff9\u5343".length();
                "\u5748\u5e77\u6a3a".length();
                "\u66bc\u4eb9".length();
                "\u5a65\u6e58\u58be\u5ea2\u53cd".length();
                array[0] = obj.getAnnotations();
                "\u6e17\u6874".length();
                array[1] = obj2.getAnnotations();
                "\u5e9d\u52de\u6496\u6da9".length();
                array[2] = this.map.get(obj2).getAnnotations();
                "\u599a\u6fae\u5ae0".length();
                array[3] = typeVariable2.getAnnotations();
                return GenericTypeReflector.updateAnnotations(this.map.get(obj2), GenericTypeReflector.merge(array));
            }
            if (mappingMode.equals(MappingMode.ALLOW_INCOMPLETE)) {
                final AnnotatedTypeVariable annotatedTypeVariable = (AnnotatedTypeVariable)obj;
                final AnnotatedType[] map = this.map(annotatedTypeVariable.getAnnotatedBounds(), mappingMode);
                final Annotation[][] array2 = new Annotation[2][];
                "\u6854\u54ae\u6a08\u5918\u6617".length();
                "\u6726\u67a5\u610e\u5bc8".length();
                "\u6945\u70c2\u696f\u5e39\u684c".length();
                "\u6ad0\u5e98\u53c8".length();
                array2[0] = annotatedTypeVariable.getAnnotations();
                "\u6d44\u6339\u5666\u51df\u700e".length();
                array2[1] = obj2.getAnnotations();
                final Annotation[] merge = GenericTypeReflector.merge(array2);
                "\u6117\u5b6c".length();
                "\u4fd5\u67e5\u7005\u6767\u64d6".length();
                final TypeVariableImpl typeVariableImpl = new TypeVariableImpl<Object>(obj2, merge, map);
                "\u6d1e\u65f0".length();
                "\u692a\u62a6\u629c\u5a0a".length();
                return new AnnotatedTypeVariableImpl(typeVariableImpl, merge);
            }
            "\u67bc\u5021\u70f9".length();
            "\u51ff".length();
            "\u5b57\u53df\u6ee9\u63b4\u67aa".length();
            "\u4fbe\u62ab\u5ed9\u5e42".length();
            final UnresolvedTypeVariableException ex = new UnresolvedTypeVariableException(obj2);
            "\u5267\u6c31".length();
            "\u50f1\u661e\u688b\u50ab\u62b7".length();
            "\u5f96\u5ea8\u6bb5".length();
            throw ex;
        }
        else {
            if (obj instanceof AnnotatedParameterizedType) {
                final AnnotatedParameterizedType annotatedParameterizedType = (AnnotatedParameterizedType)obj;
                final ParameterizedType parameterizedType = (ParameterizedType)annotatedParameterizedType.getType();
                final Class clazz = (Class)parameterizedType.getRawType();
                final AnnotatedType[] array3 = new AnnotatedType[clazz.getTypeParameters().length];
                for (int i = 0; i < array3.length; i += 17077, i -= 17076) {
                    array3[i] = GenericTypeReflector.updateAnnotations(this.map(annotatedParameterizedType.getAnnotatedActualTypeArguments()[i], mappingMode), clazz.getTypeParameters()[i].getAnnotations());
                }
                final Type[] array4 = Arrays.stream(array3).map((Function<? super AnnotatedType, ?>)AnnotatedType::getType).toArray(Type[]::new);
                final Type type = (parameterizedType.getOwnerType() == null) ? null : this.map(GenericTypeReflector.annotate(parameterizedType.getOwnerType()), mappingMode).getType();
                "\u6b50\u64c4\u6717\u4f41".length();
                final ParameterizedTypeImpl parameterizedTypeImpl = new ParameterizedTypeImpl((Class<?>)parameterizedType.getRawType(), array4, type);
                "\u70f1\u5057\u580b\u6ec4\u5d13".length();
                "\u4e9f\u6ef7".length();
                final ParameterizedTypeImpl parameterizedTypeImpl2 = parameterizedTypeImpl;
                final Annotation[][] array5 = new Annotation[2][];
                "\u649c\u5260".length();
                "\u5db5\u6429\u6bfa\u6dcf\u5b3b".length();
                "\u695b\u4f4e".length();
                array5[0] = annotatedParameterizedType.getAnnotations();
                "\u6da7".length();
                "\u4e88\u5de9".length();
                array5[1] = clazz.getAnnotations();
                return new AnnotatedParameterizedTypeImpl(parameterizedTypeImpl2, GenericTypeReflector.merge(array5), array3);
            }
            if (obj instanceof AnnotatedWildcardType) {
                final AnnotatedWildcardType annotatedWildcardType = (AnnotatedWildcardType)obj;
                final AnnotatedType[] map2 = this.map(annotatedWildcardType.getAnnotatedUpperBounds(), mappingMode);
                final AnnotatedType[] map3 = this.map(annotatedWildcardType.getAnnotatedLowerBounds(), mappingMode);
                Type[] upperBounds;
                if (map2 == null || map2.length == 0) {
                    upperBounds = ((WildcardType)annotatedWildcardType.getType()).getUpperBounds();
                }
                else {
                    upperBounds = Arrays.stream(map2).map((Function<? super AnnotatedType, ?>)AnnotatedType::getType).toArray(Type[]::new);
                }
                "\u5c90".length();
                "\u6ca8\u55ec".length();
                "\u6352\u6ac8".length();
                "\u7023\u6670\u70db\u4fa3\u606a".length();
                "\u6538\u4f1b\u6905\u6913\u5451".length();
                final WildcardTypeImpl wildcardTypeImpl = new WildcardTypeImpl(upperBounds, Arrays.stream(map3).map((Function<? super AnnotatedType, ?>)AnnotatedType::getType).toArray(Type[]::new));
                "\u5721\u65e6\u5c51\u500b\u6ae2".length();
                "\u6798\u5026".length();
                return new AnnotatedWildcardTypeImpl(wildcardTypeImpl, annotatedWildcardType.getAnnotations(), map3, map2);
            }
            if (obj instanceof AnnotatedArrayType) {
                return AnnotatedArrayTypeImpl.createArrayType(this.map(((AnnotatedArrayType)obj).getAnnotatedGenericComponentType(), mappingMode), obj.getAnnotations());
            }
            "\u6f5d".length();
            "\u5010".length();
            final RuntimeException ex2 = new RuntimeException(\u5008\u673f\u5c01\u4ff9\u5fff\u4ea9\u65b6\u5429\u5cdf\u7081\u6531\u51e2\u6e28\u589d\u6d53\u67a6\u6dd7\u6511\u64ae\u59cc\u65ab\u67fd\u5561\u5506\u5a0a\u528c\u56a5\u66c7\u5d42\u640e\u5293\u693b\u70aa\u4ede\u5700\u52c4\u62b7\u5da4\u5cca\u5373\u674b(-1141902006, 794827459, "\u7f68\u7f66\u7f7f\u7f2f\u7f66\u7f66\u7f72\u7f7c\u7f57\u7f71\u7f7c\u7f63\u7f7e\u7f7c\u7f7e\u7f3a\u7f3a\u7f69\u7f49\u1480\u2e10\u103d\u26f1\u25cd\u1ec2", 1224407145, 388655237) + obj.getClass() + \u5008\u673f\u5c01\u4ff9\u5fff\u4ea9\u65b6\u5429\u5cdf\u7081\u6531\u51e2\u6e28\u589d\u6d53\u67a6\u6dd7\u6511\u64ae\u59cc\u65ab\u67fd\u5561\u5506\u5a0a\u528c\u56a5\u66c7\u5d42\u640e\u5293\u693b\u70aa\u4ede\u5700\u52c4\u62b7\u5da4\u5cca\u5373\u674b(-1725433563, 1534876391, "\u9ff3\u9fd0", -1887503781, 1081984521) + obj + \u5008\u673f\u5c01\u4ff9\u5fff\u4ea9\u65b6\u5429\u5cdf\u7081\u6531\u51e2\u6e28\u589d\u6d53\u67a6\u6dd7\u6511\u64ae\u59cc\u65ab\u67fd\u5561\u5506\u5a0a\u528c\u56a5\u66c7\u5d42\u640e\u5293\u693b\u70aa\u4ede\u5700\u52c4\u62b7\u5da4\u5cca\u5373\u674b(-1829046179, -254600780, "\u0cc9", 1474989369, -865771405));
            "\u6f53\u589a".length();
            "\u5c3f".length();
            throw ex2;
        }
    }
    
    public AnnotatedType[] map(final AnnotatedType[] array) {
        return this.map(array, MappingMode.EXACT);
    }
    
    public AnnotatedType[] map(final AnnotatedType[] array, final MappingMode mappingMode) {
        final AnnotatedType[] array2 = new AnnotatedType[array.length];
        for (int i = 0; i < array.length; i -= 25943, i += 25944) {
            array2[i] = this.map(array[i], mappingMode);
        }
        return array2;
    }
    
    public Type[] map(final Type[] array) {
        return Arrays.stream(this.map(Arrays.stream(array).map(type -> GenericTypeReflector.annotate(type, false)).toArray(AnnotatedType[]::new))).map((Function<? super AnnotatedType, ?>)AnnotatedType::getType).toArray(Type[]::new);
    }
    
    public Type map(final Type type) {
        return this.map(GenericTypeReflector.annotate(type)).getType();
    }
    
    public static int ColonialObfuscator_\u5a1b\u6f1d\u5a62\u504d\u5fae\u5595\u6dbe\u4ed8\u5b1b\u5ad5\u5af8\u6e80\u6554\u4e57\u62aa\u7017\u6a9c\u6263\u6212\u551b\u5d60\u55b3\u6041\u6698\u6dc4\u5b8d\u5589\u613d\u68d1\u4e27\u5c72\u519f\u664a\u60c2\u58e1\u5a5a\u584d\u600d\u5c68\u6dd3\u5cd4(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
