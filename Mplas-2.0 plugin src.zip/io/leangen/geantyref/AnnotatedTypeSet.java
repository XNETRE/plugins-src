package io.leangen.geantyref;

import java.lang.reflect.*;
import java.util.function.*;
import java.util.stream.*;
import java.util.*;

public class AnnotatedTypeSet<E extends AnnotatedType> implements Set<E>
{
    public AnnotatedTypeSet() {
        this((Set)new HashSet());
    }
    
    public AnnotatedTypeSet(final Set<E> inner) {
        this.inner = inner;
    }
    
    @Override
    public int size() {
        return this.inner.size();
    }
    
    @Override
    public boolean isEmpty() {
        return this.inner.isEmpty();
    }
    
    @Override
    public boolean contains(final Object o) {
        return o instanceof AnnotatedType && this.inner.contains(GenericTypeReflector.toCanonical(o));
    }
    
    @Override
    public Iterator<E> iterator() {
        return this.inner.iterator();
    }
    
    @Override
    public Object[] toArray() {
        return this.inner.toArray();
    }
    
    @Override
    public <T> T[] toArray(final T[] array) {
        return this.inner.toArray(array);
    }
    
    @Override
    public boolean add(final E e) {
        return this.inner.add(GenericTypeReflector.toCanonical(e));
    }
    
    @Override
    public boolean remove(final Object o) {
        return o instanceof AnnotatedType && this.inner.remove(GenericTypeReflector.toCanonical(o));
    }
    
    @Override
    public boolean containsAll(final Collection<?> collection) {
        return this.inner.containsAll(this.canonical(collection));
    }
    
    @Override
    public boolean addAll(final Collection<? extends E> collection) {
        return this.inner.addAll(collection.stream().map(annotatedType -> GenericTypeReflector.toCanonical(annotatedType, Function.identity())).collect((Collector<? super Object, ?, Collection<? extends E>>)Collectors.toList()));
    }
    
    @Override
    public boolean retainAll(final Collection<?> collection) {
        return this.inner.retainAll(this.canonical(collection));
    }
    
    @Override
    public boolean removeAll(final Collection<?> collection) {
        return this.inner.removeAll(this.canonical(collection));
    }
    
    @Override
    public void clear() {
        this.inner.clear();
    }
    
    public Collection<?> canonical(final Collection<?> collection) {
        return collection.stream().map(annotatedType -> (annotatedType instanceof AnnotatedType) ? GenericTypeReflector.toCanonical(annotatedType) : annotatedType).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList());
    }
    
    public static int ColonialObfuscator_\u551a\u6e2c\u5d01\u5150\u567d\u6df2\u677b\u54fa\u647f\u540f\u5f09\u511a\u6b24\u5d48\u6321\u6727\u698d\u70a6\u60d3\u6c94\u56a4\u5e2f\u515d\u6daa\u5df7\u4e65\u617c\u5b76\u5b86\u50a9\u6b14\u5dd8\u69a3\u5234\u6425\u4e63\u65c1\u5499\u5a22\u5f48\u60e6(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
