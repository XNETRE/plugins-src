package io.leangen.geantyref;

import java.lang.reflect.*;

public interface AnnotatedCaptureType extends AnnotatedType
{
    AnnotatedType[] getAnnotatedUpperBounds();
    
    AnnotatedType[] getAnnotatedLowerBounds();
    
    AnnotatedTypeVariable getAnnotatedTypeVariable();
    
    AnnotatedWildcardType getAnnotatedWildcardType();
    
    void setAnnotatedUpperBounds(final AnnotatedType[] p0);
}
