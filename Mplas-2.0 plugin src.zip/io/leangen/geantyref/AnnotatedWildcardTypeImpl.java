package io.leangen.geantyref;

import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.*;

public class AnnotatedWildcardTypeImpl extends AnnotatedTypeImpl implements AnnotatedWildcardType
{
    public AnnotatedWildcardTypeImpl(final WildcardType wildcardType, final Annotation[] array, AnnotatedType[] lowerBounds, AnnotatedType[] upperBounds) {
        super(wildcardType, array);
        if (lowerBounds == null || lowerBounds.length == 0) {
            lowerBounds = new AnnotatedType[0];
        }
        if (upperBounds == null || upperBounds.length == 0) {
            upperBounds = new AnnotatedType[] { GenericTypeReflector.annotate(Object.class) };
        }
        validateBounds(wildcardType, lowerBounds, upperBounds);
        this.lowerBounds = lowerBounds;
        this.upperBounds = upperBounds;
    }
    
    @Override
    public AnnotatedType[] getAnnotatedLowerBounds() {
        return this.lowerBounds;
    }
    
    @Override
    public AnnotatedType[] getAnnotatedUpperBounds() {
        return this.upperBounds;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof AnnotatedWildcardType && super.equals(o) && GenericTypeReflector.typeArraysEqual(this.lowerBounds, ((AnnotatedWildcardType)o).getAnnotatedLowerBounds()) && GenericTypeReflector.typeArraysEqual(this.upperBounds, ((AnnotatedWildcardType)o).getAnnotatedUpperBounds());
    }
    
    @Override
    public int hashCode() {
        return 127 * super.hashCode() ^ ColonialObfuscator_\u6d66\u5a57\u639b\u50b2\u65d9\u54b4\u5d0d\u5067\u5f00\u6fa3\u5890\u68ce\u4e39\u644b\u6f81\u51bf\u69c2\u6ce7\u5c37\u5893\u5706\u55de\u62a6\u700f\u6d35\u70d2\u5ab7\u5d8c\u6b56\u6265\u5561\u6a35\u50b1\u59be\u69da\u680c\u6500\u686e\u6c7e\u65fe\u5658(GenericTypeReflector.hashCode(this.lowerBounds), GenericTypeReflector.hashCode(this.upperBounds));
    }
    
    @Override
    public String toString() {
        if (this.lowerBounds.length > 0) {
            "\u5d82\u5a7a".length();
            "\u5237\u51c7\u54c4".length();
            "\u5166".length();
            return this.annotationsString() + \u6d3a\u616a\u6bb4\u6423\u5465\u4fa7\u6c70\u6922\u644a\u558d\u5e90\u6e9a\u54a4\u5d8b\u5847\u620d\u6721\u4f4e\u5c45\u627d\u69fd\u5e44\u5935\u50b1\u6192\u5990\u54dd\u61db\u6dc0\u5568\u55e0\u5c6f\u532c\u59b7\u6b11\u62e4\u6db8\u607d\u6192\u4e36\u4f86(-632679936, -1183559780, "\ubae4\ubad6\uba85\uba81\uba82\uba91\uba8d\ubad3", 2124128960, -755219004) + this.typesString(this.lowerBounds);
        }
        if (this.upperBounds.length == 0 || this.upperBounds[0].getType() == Object.class) {
            "\u4e81\u68cd\u5ed8\u5747".length();
            "\u5b71".length();
            "\u5161\u6ca8\u60fc\u5c3a".length();
            return this.annotationsString() + \u6d3a\u616a\u6bb4\u6423\u5465\u4fa7\u6c70\u6922\u644a\u558d\u5e90\u6e9a\u54a4\u5d8b\u5847\u620d\u6721\u4f4e\u5c45\u627d\u69fd\u5e44\u5935\u50b1\u6192\u5990\u54dd\u61db\u6dc0\u5568\u55e0\u5c6f\u532c\u59b7\u6b11\u62e4\u6db8\u607d\u6192\u4e36\u4f86(1585901771, 914350581, "\u615a", 1018053716, -1537199028);
        }
        "\u5e51\u70c7\u6cf5".length();
        "\u56b6\u713c".length();
        return this.annotationsString() + \u6d3a\u616a\u6bb4\u6423\u5465\u4fa7\u6c70\u6922\u644a\u558d\u5e90\u6e9a\u54a4\u5d8b\u5847\u620d\u6721\u4f4e\u5c45\u627d\u69fd\u5e44\u5935\u50b1\u6192\u5990\u54dd\u61db\u6dc0\u5568\u55e0\u5c6f\u532c\u59b7\u6b11\u62e4\u6db8\u607d\u6192\u4e36\u4f86(-461426558, -1222711037, "\uf665\uf655\uf612\uf633\uf63f\uf62a\uf628\uf628\uf61d\uf660", -290140003, 1310392069) + this.typesString(this.upperBounds);
    }
    
    public static int ColonialObfuscator_\u6d66\u5a57\u639b\u50b2\u65d9\u54b4\u5d0d\u5067\u5f00\u6fa3\u5890\u68ce\u4e39\u644b\u6f81\u51bf\u69c2\u6ce7\u5c37\u5893\u5706\u55de\u62a6\u700f\u6d35\u70d2\u5ab7\u5d8c\u6b56\u6265\u5561\u6a35\u50b1\u59be\u69da\u680c\u6500\u686e\u6c7e\u65fe\u5658(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
