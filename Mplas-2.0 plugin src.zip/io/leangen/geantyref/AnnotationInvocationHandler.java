package io.leangen.geantyref;

import java.lang.annotation.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.*;

public class AnnotationInvocationHandler implements Annotation, InvocationHandler, Serializable
{
    public AnnotationInvocationHandler(final Class<? extends Annotation> annotationType, final Map<String, Object> map) throws AnnotationFormatException {
        final Class<?>[] interfaces = annotationType.getInterfaces();
        if (annotationType.isAnnotation() && interfaces.length == 1 && interfaces[0] == Annotation.class) {
            this.annotationType = annotationType;
            this.values = Collections.unmodifiableMap((Map<? extends String, ?>)normalize(annotationType, map));
            this.hashCode = this.calculateHashCode();
            return;
        }
        throw new AnnotationFormatException(annotationType.getName() + \u52fe\u5d7a\u6258\u6985\u5203\u6dcd\u621f\u675e\u5302\u6f87\u64c8\u6fe6\u5597\u6d6e\u5ffc\u5502\u5f93\u5ba6\u6f44\u6cf6\u6cca\u5afd\u6a54\u643b\u5623\u4e45\u5fb9\u6e6c\u606f\u5140\u5348\u5bac\u5986\u544a\u5307\u51d6\u560b\u712d\u636e\u4f3f\u55ca(-1468923953, 1248410263, "\u30ec\u3088\u3092\u30c3\u308b\u308c\u309c\u30c4\u30a9\u308a\u30c3\u3090\u309e\u308f\u308f\u3080\u3091\u3098\u30ab\u5c3b\u5087\u68eb\u5a55\u640a\u599c\u7fc6", -809144160, 334136695));
    }
    
    @Override
    public Object invoke(final Object o, final Method method, final Object[] args) throws Throwable {
        if (this.values.containsKey(method.getName())) {
            return this.values.get(method.getName());
        }
        return method.invoke(this, args);
    }
    
    @Override
    public Class<? extends Annotation> annotationType() {
        return this.annotationType;
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!this.annotationType.isInstance(obj)) {
            return false;
        }
        final Annotation obj2 = (Annotation)this.annotationType.cast(obj);
        for (final Map.Entry<String, Object> entry : this.values.entrySet()) {
            final Object value = entry.getValue();
            Object invoke;
            try {
                invoke = obj2.annotationType().getMethod(entry.getKey(), (Class<?>[])new Class[0]).invoke(obj2, new Object[0]);
            }
            catch (ReflectiveOperationException cause) {
                "\u6a68".length();
                final RuntimeException ex = new RuntimeException(cause);
                "\u6d0b\u6e65\u6847\u6f3a".length();
                throw ex;
            }
            if (!Objects.deepEquals(value, invoke)) {
                return false;
            }
        }
        return true;
    }
    
    @Override
    public int hashCode() {
        return this.hashCode;
    }
    
    @Override
    public String toString() {
        "\u6eb5".length();
        final StringBuilder sb = new StringBuilder();
        sb.append('@').append(this.annotationType.getName()).append('(');
        "\u5fea\u5c8c".length();
        "\u69cd\u6f4b\u5d64\u6e69".length();
        for (final String str : new TreeSet<Object>(this.values.keySet())) {
            String str2;
            if (this.values.get(str).getClass().isArray()) {
                final Object[] a = { null };
                "\u6dfc".length();
                "\u70b8\u6299\u7127\u5d49".length();
                "\u6aa2\u6903\u6465".length();
                a[0] = this.values.get(str);
                str2 = Arrays.deepToString(a).replaceAll(\u52fe\u5d7a\u6258\u6985\u5203\u6dcd\u621f\u675e\u5302\u6f87\u64c8\u6fe6\u5597\u6d6e\u5ffc\u5502\u5f93\u5ba6\u6f44\u6cf6\u6cca\u5afd\u6a54\u643b\u5623\u4e45\u5fb9\u6e6c\u606f\u5140\u5348\u5bac\u5986\u544a\u5307\u51d6\u560b\u712d\u636e\u4f3f\u55ca(195698527, 1408684923, "\uc385\uc3aa\uc3ad\uc3a8\uc3b1", -732781108, 63679088), \u52fe\u5d7a\u6258\u6985\u5203\u6dcd\u621f\u675e\u5302\u6f87\u64c8\u6fe6\u5597\u6d6e\u5ffc\u5502\u5f93\u5ba6\u6f44\u6cf6\u6cca\u5afd\u6a54\u643b\u5623\u4e45\u5fb9\u6e6c\u606f\u5140\u5348\u5bac\u5986\u544a\u5307\u51d6\u560b\u712d\u636e\u4f3f\u55ca(816195847, 208130242, "\u57e3", 1908201695, 2060351201)).replaceAll(\u52fe\u5d7a\u6258\u6985\u5203\u6dcd\u621f\u675e\u5302\u6f87\u64c8\u6fe6\u5597\u6d6e\u5ffc\u5502\u5f93\u5ba6\u6f44\u6cf6\u6cca\u5afd\u6a54\u643b\u5623\u4e45\u5fb9\u6e6c\u606f\u5140\u5348\u5bac\u5986\u544a\u5307\u51d6\u560b\u712d\u636e\u4f3f\u55ca(-1158453672, -1865443414, "\ua32c\ua301\ua378", 148800212, 496685076), \u52fe\u5d7a\u6258\u6985\u5203\u6dcd\u621f\u675e\u5302\u6f87\u64c8\u6fe6\u5597\u6d6e\u5ffc\u5502\u5f93\u5ba6\u6f44\u6cf6\u6cca\u5afd\u6a54\u643b\u5623\u4e45\u5fb9\u6e6c\u606f\u5140\u5348\u5bac\u5986\u544a\u5307\u51d6\u560b\u712d\u636e\u4f3f\u55ca(1121313452, 2045489434, "\u593c", 1627447903, 486271179));
            }
            else {
                str2 = this.values.get(str).toString();
            }
            sb.append(str).append('=').append(str2).append(\u52fe\u5d7a\u6258\u6985\u5203\u6dcd\u621f\u675e\u5302\u6f87\u64c8\u6fe6\u5597\u6d6e\u5ffc\u5502\u5f93\u5ba6\u6f44\u6cf6\u6cca\u5afd\u6a54\u643b\u5623\u4e45\u5fb9\u6e6c\u606f\u5140\u5348\u5bac\u5986\u544a\u5307\u51d6\u560b\u712d\u636e\u4f3f\u55ca(1581391460, -1783734129, "\ub885\ub8a6", 1112402725, 2009214244));
            "\u51e9".length();
            "\u6609".length();
            "\u50ca\u58d1\u551a\u5817\u59f7".length();
            "\u61e7".length();
        }
        if (this.values.size() > 0) {
            final StringBuilder sb2 = sb;
            final int length = sb.length();
            final int n = 2;
            "\u5f49\u5759\u65dc\u5907\u50a5".length();
            "\u6fee\u6eb0\u5d02\u6743".length();
            sb2.delete(length - n, sb.length());
            "\u57c4".length();
        }
        sb.append(\u52fe\u5d7a\u6258\u6985\u5203\u6dcd\u621f\u675e\u5302\u6f87\u64c8\u6fe6\u5597\u6d6e\u5ffc\u5502\u5f93\u5ba6\u6f44\u6cf6\u6cca\u5afd\u6a54\u643b\u5623\u4e45\u5fb9\u6e6c\u606f\u5140\u5348\u5bac\u5986\u544a\u5307\u51d6\u560b\u712d\u636e\u4f3f\u55ca(-1546097340, -228859820, "\u88fb", -746448114, -729080177));
        "\u5b4f\u500e\u674d\u609d".length();
        "\u5ac7".length();
        return sb.toString();
    }
    
    public int calculateHashCode() {
        int colonialObfuscator_\u55f5\u6fef\u6b50\u6d9b\u53d3\u527f\u58f7\u68e0\u5399\u62b8\u4e82\u6a58\u68e2\u645f\u5c4b\u6d01\u4fe8\u6c89\u6c2e\u7133\u6275\u53c5\u6a50\u56c6\u66b5\u61b1\u5ed3\u5a40\u5e5e\u57b7\u67d0\u50f8\u5f23\u568f\u576b\u5903\u50b6\u6114\u6d0c\u6404\u653e = 0;
        for (final Map.Entry<String, Object> entry : this.values.entrySet()) {
            colonialObfuscator_\u55f5\u6fef\u6b50\u6d9b\u53d3\u527f\u58f7\u68e0\u5399\u62b8\u4e82\u6a58\u68e2\u645f\u5c4b\u6d01\u4fe8\u6c89\u6c2e\u7133\u6275\u53c5\u6a50\u56c6\u66b5\u61b1\u5ed3\u5a40\u5e5e\u57b7\u67d0\u50f8\u5f23\u568f\u576b\u5903\u50b6\u6114\u6d0c\u6404\u653e = ColonialObfuscator_\u55f5\u6fef\u6b50\u6d9b\u53d3\u527f\u58f7\u68e0\u5399\u62b8\u4e82\u6a58\u68e2\u645f\u5c4b\u6d01\u4fe8\u6c89\u6c2e\u7133\u6275\u53c5\u6a50\u56c6\u66b5\u61b1\u5ed3\u5a40\u5e5e\u57b7\u67d0\u50f8\u5f23\u568f\u576b\u5903\u50b6\u6114\u6d0c\u6404\u653e(colonialObfuscator_\u55f5\u6fef\u6b50\u6d9b\u53d3\u527f\u58f7\u68e0\u5399\u62b8\u4e82\u6a58\u68e2\u645f\u5c4b\u6d01\u4fe8\u6c89\u6c2e\u7133\u6275\u53c5\u6a50\u56c6\u66b5\u61b1\u5ed3\u5a40\u5e5e\u57b7\u67d0\u50f8\u5f23\u568f\u576b\u5903\u50b6\u6114\u6d0c\u6404\u653e, 127 * entry.getKey().hashCode() ^ this.calculateHashCode(entry.getValue()));
        }
        return colonialObfuscator_\u55f5\u6fef\u6b50\u6d9b\u53d3\u527f\u58f7\u68e0\u5399\u62b8\u4e82\u6a58\u68e2\u645f\u5c4b\u6d01\u4fe8\u6c89\u6c2e\u7133\u6275\u53c5\u6a50\u56c6\u66b5\u61b1\u5ed3\u5a40\u5e5e\u57b7\u67d0\u50f8\u5f23\u568f\u576b\u5903\u50b6\u6114\u6d0c\u6404\u653e;
    }
    
    public int calculateHashCode(final Object o) {
        if (!o.getClass().isArray()) {
            return o.hashCode();
        }
        if (o instanceof Object[]) {
            return Arrays.hashCode((Object[])o);
        }
        if (o instanceof byte[]) {
            return Arrays.hashCode((byte[])o);
        }
        if (o instanceof short[]) {
            return Arrays.hashCode((short[])o);
        }
        if (o instanceof int[]) {
            return Arrays.hashCode((int[])o);
        }
        if (o instanceof long[]) {
            return Arrays.hashCode((long[])o);
        }
        if (o instanceof char[]) {
            return Arrays.hashCode((char[])o);
        }
        if (o instanceof float[]) {
            return Arrays.hashCode((float[])o);
        }
        if (o instanceof double[]) {
            return Arrays.hashCode((double[])o);
        }
        if (o instanceof boolean[]) {
            return Arrays.hashCode((boolean[])o);
        }
        return Objects.hashCode(o);
    }
    
    public static int ColonialObfuscator_\u55f5\u6fef\u6b50\u6d9b\u53d3\u527f\u58f7\u68e0\u5399\u62b8\u4e82\u6a58\u68e2\u645f\u5c4b\u6d01\u4fe8\u6c89\u6c2e\u7133\u6275\u53c5\u6a50\u56c6\u66b5\u61b1\u5ed3\u5a40\u5e5e\u57b7\u67d0\u50f8\u5f23\u568f\u576b\u5903\u50b6\u6114\u6d0c\u6404\u653e(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
