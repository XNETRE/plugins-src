package io.leangen.geantyref;

import java.lang.annotation.*;
import java.util.stream.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.function.*;

public class AnnotatedCaptureTypeImpl extends AnnotatedTypeImpl implements AnnotatedCaptureType
{
    public AnnotatedCaptureTypeImpl(final AnnotatedWildcardType annotatedWildcardType, final AnnotatedTypeVariable annotatedTypeVariable) {
        this(new CaptureTypeImpl((WildcardType)annotatedWildcardType.getType(), (TypeVariable<?>)annotatedTypeVariable.getType()), annotatedWildcardType, annotatedTypeVariable);
    }
    
    public AnnotatedCaptureTypeImpl(final CaptureType captureType, final AnnotatedWildcardType annotatedWildcardType, final AnnotatedTypeVariable annotatedTypeVariable) {
        this(captureType, annotatedWildcardType, annotatedTypeVariable, null, null);
    }
    
    public AnnotatedCaptureTypeImpl(final CaptureType captureType, final AnnotatedWildcardType annotatedWildcardType, final AnnotatedTypeVariable annotatedTypeVariable, final AnnotatedType[] array, final Annotation[] array2) {
        this(captureType, annotatedWildcardType, annotatedTypeVariable, annotatedWildcardType.getAnnotatedLowerBounds(), array, array2);
    }
    
    public AnnotatedCaptureTypeImpl(final CaptureType type, final AnnotatedWildcardType wildcard, final AnnotatedTypeVariable variable, final AnnotatedType[] lowerBounds, final AnnotatedType[] upperBounds, final Annotation[] array) {
        super(type, (array != null) ? array : Stream.concat((Stream<?>)Arrays.stream((T[])wildcard.getAnnotations()), (Stream<?>)Arrays.stream((T[])variable.getAnnotations())).toArray(Annotation[]::new));
        this.type = type;
        this.wildcard = wildcard;
        this.variable = variable;
        this.lowerBounds = lowerBounds;
        this.upperBounds = upperBounds;
        this.declaredAnnotations = Stream.concat((Stream<?>)Arrays.stream((T[])wildcard.getDeclaredAnnotations()), (Stream<?>)Arrays.stream((T[])variable.getDeclaredAnnotations())).toArray(Annotation[]::new);
    }
    
    public void init(final VarMap varMap) {
        "\u713b\u5178\u57f5\u562d".length();
        "\u4f68\u5e50\u5d7d\u4f9b\u5bbf".length();
        final ArrayList list = new ArrayList((Collection<? extends E>)Arrays.asList(varMap.map(this.variable.getAnnotatedBounds())));
        final List<AnnotatedType> list2 = Arrays.asList(this.wildcard.getAnnotatedUpperBounds());
        if (list2.size() > 0 && list2.get(0).getType() == Object.class) {
            list.addAll(list2.subList(1, list2.size()));
            "\u4efe\u67c7\u6c5e\u63aa\u5c56".length();
            "\u625f\u6399".length();
            "\u5ca1\u5ea4\u6e77\u63d1\u69f9".length();
        }
        else {
            list.addAll(list2);
            "\u543e\u63b0\u5454\u61dd".length();
            "\u5267\u58dd\u5e46\u6006".length();
            "\u530b\u6a3d\u68ce\u5c2e".length();
        }
        this.upperBounds = new AnnotatedType[list.size()];
        list.toArray(this.upperBounds);
        "\u4e77\u6db0\u55c0".length();
        "\u5406\u6184\u624f\u6061".length();
        "\u5d52\u51f7\u6836\u6fe5".length();
        "\u53bd\u5f96\u5ed9\u6efc".length();
        ((CaptureTypeImpl)this.type).init(varMap);
    }
    
    @Override
    public Annotation[] getDeclaredAnnotations() {
        return this.declaredAnnotations;
    }
    
    @Override
    public AnnotatedType[] getAnnotatedUpperBounds() {
        if (!AnnotatedCaptureTypeImpl.$assertionsDisabled && this.upperBounds == null) {
            "\u680a\u6b75".length();
            "\u6292".length();
            "\u6538\u534d\u561d\u50a6\u50ed".length();
            final AssertionError assertionError = new AssertionError();
            "\u614c\u6aa4\u5b24\u55e6".length();
            "\u637f\u57eb\u6b89\u5091\u6ef1".length();
            throw assertionError;
        }
        return this.upperBounds.clone();
    }
    
    @Override
    public void setAnnotatedUpperBounds(final AnnotatedType[] array) {
        this.upperBounds = array;
        this.type.setUpperBounds(Arrays.stream(array).map((Function<? super AnnotatedType, ?>)AnnotatedType::getType).toArray(Type[]::new));
    }
    
    @Override
    public AnnotatedType[] getAnnotatedLowerBounds() {
        return this.lowerBounds.clone();
    }
    
    @Override
    public AnnotatedTypeVariable getAnnotatedTypeVariable() {
        return this.variable;
    }
    
    @Override
    public AnnotatedWildcardType getAnnotatedWildcardType() {
        return this.wildcard;
    }
    
    public static int ColonialObfuscator_\u6014\u695b\u62e9\u513e\u5c4a\u4efa\u56d3\u5780\u5782\u53c5\u61d4\u619f\u5b4a\u565b\u5835\u6c2e\u68c1\u5f4e\u6713\u5344\u553e\u5a79\u693c\u638b\u579d\u6dfb\u6cc2\u5d2e\u6553\u5a25\u57a1\u6408\u6136\u51b3\u6026\u586d\u5df8\u6a8e\u69d7\u5b23\u6ab7(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
