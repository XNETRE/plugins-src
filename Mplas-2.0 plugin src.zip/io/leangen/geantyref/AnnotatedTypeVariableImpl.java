package io.leangen.geantyref;

import java.lang.annotation.*;
import java.lang.reflect.*;

public class AnnotatedTypeVariableImpl extends AnnotatedTypeImpl implements AnnotatedTypeVariable
{
    public AnnotatedTypeVariableImpl(final TypeVariable<?> typeVariable) {
        this(typeVariable, typeVariable.getAnnotations());
    }
    
    public AnnotatedTypeVariableImpl(final TypeVariable<?> typeVariable, final Annotation[] array) {
        super(typeVariable, array);
        AnnotatedType[] annotatedBounds = typeVariable.getAnnotatedBounds();
        if (annotatedBounds == null || annotatedBounds.length == 0) {
            annotatedBounds = new AnnotatedType[0];
        }
        this.annotatedBounds = annotatedBounds;
    }
    
    public void init(final AnnotatedType[] annotatedBounds) {
        "\u67f0\u6e08".length();
        "\u523f\u5c5e\u63fa\u6d4f\u6639".length();
        this.type = new TypeVariableImpl<Object>((TypeVariable<?>)this.type, this.getAnnotations(), annotatedBounds);
        this.annotatedBounds = annotatedBounds;
    }
    
    @Override
    public AnnotatedType[] getAnnotatedBounds() {
        return this.annotatedBounds.clone();
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof AnnotatedTypeVariable && super.equals(o);
    }
    
    @Override
    public String toString() {
        "\u620e\u5756".length();
        "\u60cc\u5d09\u699d\u514f".length();
        "\u683d\u5cff\u5c0c\u53fd".length();
        "\u5f92\u4f28".length();
        return this.annotationsString() + ((TypeVariable)this.type).getName();
    }
    
    public static int ColonialObfuscator_\u5911\u617b\u5c03\u5666\u56be\u6535\u4f18\u5992\u5f77\u5370\u6b00\u64f3\u58d6\u691d\u5cf9\u6c77\u598c\u57f4\u6125\u702f\u6dc9\u5b24\u54d6\u6412\u5e52\u6924\u6e37\u6409\u572d\u6628\u66b1\u5eec\u555d\u6528\u5f33\u50cb\u597e\u6779\u52c3\u6d99\u5b8a(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
