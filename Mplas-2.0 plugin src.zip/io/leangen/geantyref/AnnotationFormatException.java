package io.leangen.geantyref;

public class AnnotationFormatException extends Exception
{
    public AnnotationFormatException() {
    }
    
    public AnnotationFormatException(final String message) {
        super(message);
    }
    
    public static int ColonialObfuscator_\u702d\u4fba\u6de1\u5563\u6ccc\u5d4a\u5a22\u62a8\u53da\u5b7b\u56e1\u4f43\u70ae\u6031\u5e57\u5a4f\u5311\u5cf0\u5e14\u640d\u6443\u6176\u59af\u5b7b\u6d0a\u6f8d\u5966\u5785\u6c4b\u6096\u6fec\u6c45\u62f1\u6d1e\u4e8a\u668d\u704b\u50e5\u535c\u5707\u5fed(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
