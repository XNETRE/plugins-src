package io.leangen.geantyref;

import java.lang.annotation.*;
import java.util.function.*;
import java.util.*;
import java.lang.reflect.*;

public class TypeFactory
{
    public static int ColonialObfuscator_\u52ab\u65c4\u58f0\u688e\u558a\u665d\u673d\u5b14\u56ec\u696c\u64a3\u4e9d\u5c5d\u51c8\u70cf\u5237\u55ef\u5bb2\u6ce4\u6feb\u6066\u4f6d\u6f9e\u6c2e\u54ba\u62a3\u6d65\u55f3\u698e\u65ec\u5fe3\u5569\u6220\u5c1a\u5cf6\u5b42\u65b3\u7030\u5b48\u5450\u6ec4(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
