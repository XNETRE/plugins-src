package io.leangen.geantyref;

import java.lang.annotation.*;
import java.lang.reflect.*;
import java.util.*;
import java.util.function.*;
import java.util.stream.*;

public class TypeVariableImpl<D extends GenericDeclaration> implements TypeVariable<D>
{
    public TypeVariableImpl(final TypeVariable<D> typeVariable, final AnnotatedType[] array) {
        this(typeVariable, typeVariable.getAnnotations(), array);
    }
    
    public TypeVariableImpl(final TypeVariable<D> obj, final Annotation[] array, final AnnotatedType[] bounds) {
        Objects.requireNonNull(obj);
        this.genericDeclaration = obj.getGenericDeclaration();
        this.name = obj.getName();
        this.annotations = new HashMap<Class<? extends Annotation>, Annotation>();
        for (int length = array.length, i = 0; i < length; i -= 20384, i += 20385) {
            final Annotation annotation = array[i];
            this.annotations.put(annotation.annotationType(), annotation);
        }
        if (bounds == null || bounds.length == 0) {
            throw new IllegalArgumentException(\u519d\u4ee5\u54aa\u5c78\u5e92\u537c\u59c8\u5ac6\u5dd1\u5d14\u6278\u5931\u59e3\u6fc2\u6f0a\u7115\u4e67\u56d5\u5c45\u6086\u6eff\u6fd2\u6bb0\u6cb8\u5720\u5750\u571c\u5a6f\u6567\u4fa3\u56fb\u5031\u58b2\u6e91\u6024\u5da7\u6ee7\u54f2\u6459\u56ea\u68b1(1563490817, 44634481, "\uf977\uf964\uf96b\uf960\uf977\uf936\uf972\uf960\uf944\uf96d\uf93c\uf962\uf962\uf934\uf976\uf971\uf93f\uf96d\uf948\uadd4\u9283\u9d07\u9236\ua1f4\uac84\uad8f\ua25c\u90df\uaf74\u90a9\ua9f4\uafc8\u9dd8\ub68e\u903e\uaa32\uac27\ua15b\ua71b\ua132\ua5c7\u9594\u975e\u93c2\u9306\ua540\u88b9\u9662\u93c4\ua252\ua137\u9c7c\u89b3\u9d9c\uaee8\u9893\uad75\ua08c\u9116\u9bd0\ua94d\ua85a\uafa3\ua233\ub795\u90e6\uac8d\u9d5b\uaa83\ua97c\u9c95\uab42\u97e7\u898c\u9f4a\u9962\u91c2\u88e7\uafcd\u9275\u8935\uae71\u9055", -921321619, 183545213));
        }
        this.bounds = bounds;
    }
    
    @Override
    public Type[] getBounds() {
        return Arrays.stream(this.bounds).map((Function<? super AnnotatedType, ?>)AnnotatedType::getType).toArray(Type[]::new);
    }
    
    @Override
    public D getGenericDeclaration() {
        return this.genericDeclaration;
    }
    
    @Override
    public String getName() {
        return this.name;
    }
    
    @Override
    public AnnotatedType[] getAnnotatedBounds() {
        return this.bounds;
    }
    
    @Override
    public <T extends Annotation> T getAnnotation(final Class<T> clazz) {
        return (T)this.annotations.get(clazz);
    }
    
    @Override
    public Annotation[] getAnnotations() {
        return this.annotations.values().toArray(new Annotation[0]);
    }
    
    @Override
    public Annotation[] getDeclaredAnnotations() {
        return this.getAnnotations();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o instanceof TypeVariable) {
            final TypeVariable typeVariable = (TypeVariable)o;
            return Objects.equals(this.genericDeclaration, typeVariable.getGenericDeclaration()) && Objects.equals(this.name, typeVariable.getName());
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return this.genericDeclaration.hashCode() ^ this.name.hashCode();
    }
    
    @Override
    public String toString() {
        "\u59d5\u4f8b\u6244".length();
        "\u5ae8\u540e\u5892\u5bac\u6594".length();
        return this.annotationsString() + this.getName();
    }
    
    public String annotationsString() {
        String s;
        if (this.annotations.isEmpty()) {
            s = \u519d\u4ee5\u54aa\u5c78\u5e92\u537c\u59c8\u5ac6\u5dd1\u5d14\u6278\u5931\u59e3\u6fc2\u6f0a\u7115\u4e67\u56d5\u5c45\u6086\u6eff\u6fd2\u6bb0\u6cb8\u5720\u5750\u571c\u5a6f\u6567\u4fa3\u56fb\u5031\u58b2\u6e91\u6024\u5da7\u6ee7\u54f2\u6459\u56ea\u68b1(-1445033206, -821826933, "", -1206949696, -1733930205);
        }
        else {
            "\u5fcb\u54d4".length();
            "\u597b".length();
            s = this.annotations.values().stream().map((Function<? super Annotation, ?>)Annotation::toString).collect((Collector<? super Object, ?, String>)Collectors.joining(\u519d\u4ee5\u54aa\u5c78\u5e92\u537c\u59c8\u5ac6\u5dd1\u5d14\u6278\u5931\u59e3\u6fc2\u6f0a\u7115\u4e67\u56d5\u5c45\u6086\u6eff\u6fd2\u6bb0\u6cb8\u5720\u5750\u571c\u5a6f\u6567\u4fa3\u56fb\u5031\u58b2\u6e91\u6024\u5da7\u6ee7\u54f2\u6459\u56ea\u68b1(-1404559425, -385997623, "\u02f7\u02d4", -128359235, -959947437))) + \u519d\u4ee5\u54aa\u5c78\u5e92\u537c\u59c8\u5ac6\u5dd1\u5d14\u6278\u5931\u59e3\u6fc2\u6f0a\u7115\u4e67\u56d5\u5c45\u6086\u6eff\u6fd2\u6bb0\u6cb8\u5720\u5750\u571c\u5a6f\u6567\u4fa3\u56fb\u5031\u58b2\u6e91\u6024\u5da7\u6ee7\u54f2\u6459\u56ea\u68b1(-1434955149, 1582543320, "\u3c00", -1123103625, 864818111);
        }
        return s;
    }
    
    public static int ColonialObfuscator_\u685e\u5daf\u50c0\u5e27\u61c3\u61dd\u709a\u6315\u5c3c\u542a\u59a3\u59b9\u5f2b\u59e1\u5d6a\u56c3\u6e32\u5791\u6b04\u5075\u5fec\u6c99\u6a72\u6d9c\u67aa\u7107\u5656\u4ec2\u5b37\u584e\u5f86\u6ba8\u6d82\u5e23\u5714\u70c9\u5e62\u52c8\u577b\u5690\u6c54(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
