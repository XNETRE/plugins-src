package io.leangen.geantyref;

import java.lang.reflect.*;
import java.util.*;

public class CaptureTypeImpl implements CaptureType
{
    public CaptureTypeImpl(final WildcardType wildcard, final TypeVariable<?> variable) {
        this.wildcard = wildcard;
        this.variable = variable;
        this.lowerBounds = wildcard.getLowerBounds();
    }
    
    public void init(final VarMap varMap) {
        "\u513a\u645c".length();
        final ArrayList list = new ArrayList((Collection<? extends E>)Arrays.asList(varMap.map(this.variable.getBounds())));
        final List<Type> list2 = Arrays.asList(this.wildcard.getUpperBounds());
        if (list2.size() > 0 && list2.get(0) == Object.class) {
            list.addAll(list2.subList(1, list2.size()));
            "\u4e71\u5c3a\u668a\u6a53\u61cd".length();
            "\u53fe\u712d\u67a4\u5147\u68ac".length();
            "\u6efe\u5bcb\u6545\u584c\u5dec".length();
        }
        else {
            list.addAll(list2);
            "\u502e\u667c\u5a6d".length();
            "\u5c5b\u53cf\u6e10\u5d1a".length();
            "\u5b49".length();
            "\u5b91\u50d1\u51de\u6cd4".length();
        }
        this.upperBounds = new Type[list.size()];
        list.toArray(this.upperBounds);
        "\u5c80\u4f63\u5706\u6c22".length();
        "\u6f91".length();
    }
    
    @Override
    public Type[] getLowerBounds() {
        return this.lowerBounds.clone();
    }
    
    @Override
    public Type[] getUpperBounds() {
        if (!CaptureTypeImpl.$assertionsDisabled && this.upperBounds == null) {
            "\u6510\u5d50".length();
            final AssertionError assertionError = new AssertionError();
            "\u5420\u59df\u5e7e\u4e41".length();
            "\u6cbf".length();
            throw assertionError;
        }
        return this.upperBounds.clone();
    }
    
    @Override
    public void setUpperBounds(final Type[] upperBounds) {
        this.upperBounds = upperBounds;
    }
    
    @Override
    public TypeVariable<?> getTypeVariable() {
        return this.variable;
    }
    
    @Override
    public WildcardType getWildcardType() {
        return this.wildcard;
    }
    
    @Override
    public String toString() {
        "\u4ea4\u5084\u713d\u62ec".length();
        "\u6edd".length();
        "\u50da\u710d\u6e6f\u6ba4".length();
        return \u53f0\u5173\u6809\u6e24\u5386\u63c4\u64c3\u4ead\u6759\u4e82\u5d56\u5dd7\u6147\u63fa\u5111\u5378\u552e\u7029\u6e9d\u5f78\u61a1\u6520\u6bfa\u68c7\u5faf\u631e\u56be\u62cd\u6a66\u61b7\u5802\u6f19\u50bb\u5921\u6cf3\u5d17\u5895\u6a7e\u6975\u6faa\u69b8(-571759757, 699839589, "\u41aa\u4185\u4194\u4192\u4195\u4194\u4188\u41c1\u41b2\u4197\u41d6", 1226261992, -556330124) + this.wildcard;
    }
    
    public static int ColonialObfuscator_\u4f2e\u52b9\u59b0\u5e75\u4ff0\u5192\u70f0\u58f0\u69c3\u6530\u4fd2\u639a\u7115\u5668\u6182\u6fc9\u5f40\u6ff3\u6883\u56cb\u538e\u6852\u5e76\u5531\u6c4f\u5984\u5b1c\u5550\u519a\u5bee\u6c15\u567c\u6be0\u5180\u6c91\u6a42\u57f7\u562d\u6f89\u5d78\u65d0(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
