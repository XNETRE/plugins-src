package io.leangen.geantyref;

import java.lang.reflect.*;
import java.util.*;

public class WildcardTypeImpl implements WildcardType
{
    public WildcardTypeImpl(final Type[] upperBounds, final Type[] lowerBounds) {
        if (upperBounds.length == 0) {
            throw new IllegalArgumentException(\u584e\u62e5\u534c\u612d\u59d8\u6107\u569b\u533d\u683d\u6409\u50c5\u6ad2\u6528\u6428\u61fb\u5fe1\u5c03\u5aac\u6ff8\u5bf4\u5c81\u5326\u5e62\u70aa\u6f8d\u6391\u70b6\u64b6\u504e\u6b12\u5050\u51db\u5504\u70e1\u5fd4\u672f\u5820\u55fe\u5723\u6726\u550f(13665524, 643454638, "\udf14\udf03\udf0c\udf1b\udf0c\udf41\udf05\udf13\udf37\udf1a\udf4b\udf19\udf19\udf53\udf11\udf12\udf5c\udf0a\udf2f\u8a0a\u8b6c\u8bff\ub7ae\ub6d4\ub33b\u8b1d\uaf7e\u826a\u9085\u90de\u88ab\u879c\ubcba\u8ead\u85a2\ub325\ub276\ubc7c\ub1c8\u807c\u893d\ubfcf\u8aab\ubd78\ub62c\u8670\u91ef\u8c92\u844b\ub87a\ub303\u80b8\ub72a\u8760\u86c5\u8b88\u80e9\u87e4\u81ff\u8585\ub377\ubd82\ubbf2\uaf78\ubd8b\u8900\u890c\ubdbb\u83bd\u8b86\u810b\uba17\ubcc7\ub43b\ubf9d\ub5b4\ub5f5\uafc7\u8c04\uaf91\ubdfd\u869d\u837a\u9166\u8f1b\u8276\u8a9e\u8742\ube68\u8e39\ubae6\ub5f9\u8417\ubcc3\u8077", 848888611, 612830842));
        }
        this.upperBounds = upperBounds;
        this.lowerBounds = lowerBounds;
    }
    
    @Override
    public Type[] getUpperBounds() {
        return this.upperBounds.clone();
    }
    
    @Override
    public Type[] getLowerBounds() {
        return this.lowerBounds.clone();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof WildcardType)) {
            return false;
        }
        final WildcardType wildcardType = (WildcardType)o;
        return Arrays.equals(this.getLowerBounds(), wildcardType.getLowerBounds()) && Arrays.equals(this.getUpperBounds(), wildcardType.getUpperBounds());
    }
    
    @Override
    public int hashCode() {
        return Arrays.hashCode(this.getLowerBounds()) ^ Arrays.hashCode(this.getUpperBounds());
    }
    
    @Override
    public String toString() {
        if (this.lowerBounds.length > 0) {
            "\u6af3\u55ff".length();
            "\u5f6a".length();
            "\u7099\u547d".length();
            return \u584e\u62e5\u534c\u612d\u59d8\u6107\u569b\u533d\u683d\u6409\u50c5\u6ad2\u6528\u6428\u61fb\u5fe1\u5c03\u5aac\u6ff8\u5bf4\u5c81\u5326\u5e62\u70aa\u6f8d\u6391\u70b6\u64b6\u504e\u6b12\u5050\u51db\u5504\u70e1\u5fd4\u672f\u5820\u55fe\u5723\u6726\u550f(-333808238, -1261421948, "\uf91d\uf92d\uf97c\uf97e\uf97b\uf96a\uf974\uf914", 1513542041, -1053855762) + GenericTypeReflector.getTypeName(this.lowerBounds[0]);
        }
        if (this.upperBounds[0] == Object.class) {
            return \u584e\u62e5\u534c\u612d\u59d8\u6107\u569b\u533d\u683d\u6409\u50c5\u6ad2\u6528\u6428\u61fb\u5fe1\u5c03\u5aac\u6ff8\u5bf4\u5c81\u5326\u5e62\u70aa\u6f8d\u6391\u70b6\u64b6\u504e\u6b12\u5050\u51db\u5504\u70e1\u5fd4\u672f\u5820\u55fe\u5723\u6726\u550f(101721752, -520596764, "\uc47d", 1097426320, 2104219117);
        }
        "\u6bfc\u5d27\u69ff\u60ac\u52bd".length();
        "\u5158\u5f87\u5705".length();
        "\u53e0".length();
        return \u584e\u62e5\u534c\u612d\u59d8\u6107\u569b\u533d\u683d\u6409\u50c5\u6ad2\u6528\u6428\u61fb\u5fe1\u5c03\u5aac\u6ff8\u5bf4\u5c81\u5326\u5e62\u70aa\u6f8d\u6391\u70b6\u64b6\u504e\u6b12\u5050\u51db\u5504\u70e1\u5fd4\u672f\u5820\u55fe\u5723\u6726\u550f(-1628516552, -1979709662, "\ub1f0\ub1c2\ub187\ub198\ub18a\ub19d\ub19d\ub19b\ub1a8\ub1d7", 1323967692, 931093850) + GenericTypeReflector.getTypeName(this.upperBounds[0]);
    }
    
    public static int ColonialObfuscator_\u6301\u54c1\u5a61\u6eba\u5ebc\u7072\u7068\u521b\u70a1\u691c\u54ba\u5dd8\u509e\u5449\u582c\u5208\u530c\u50ec\u6f48\u6205\u5ec5\u61dd\u6aff\u655d\u5ffb\u67f1\u68cb\u5bcc\u68ec\u534e\u7039\u5fb3\u4fbc\u6e6c\u6604\u5a72\u63ba\u70d2\u58a2\u6b20\u6503(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
