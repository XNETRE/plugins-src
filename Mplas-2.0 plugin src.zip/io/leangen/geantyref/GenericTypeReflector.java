package io.leangen.geantyref;

import java.lang.annotation.*;
import java.io.*;
import java.lang.reflect.*;
import java.util.function.*;
import java.util.stream.*;
import java.util.*;

public class GenericTypeReflector
{
    public static int ColonialObfuscator_\u69d6\u4fb1\u5f8b\u67ab\u6994\u5866\u5af5\u524c\u6197\u63d7\u554e\u5f0b\u5613\u68be\u6c2e\u5ff8\u68d6\u705f\u613d\u6b09\u58b1\u53b0\u6fd8\u506d\u62ef\u654d\u6284\u596a\u68ce\u6a12\u6f7e\u564f\u5e07\u6869\u6d31\u6f46\u649c\u6753\u5545\u6bcb\u609d(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
