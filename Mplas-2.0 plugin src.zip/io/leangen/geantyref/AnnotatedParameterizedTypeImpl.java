package io.leangen.geantyref;

import java.lang.annotation.*;
import java.lang.reflect.*;

public class AnnotatedParameterizedTypeImpl extends AnnotatedTypeImpl implements AnnotatedParameterizedType
{
    public AnnotatedParameterizedTypeImpl(final ParameterizedType parameterizedType, final Annotation[] array, final AnnotatedType[] typeArguments) {
        super(parameterizedType, array);
        this.typeArguments = typeArguments;
    }
    
    @Override
    public AnnotatedType[] getAnnotatedActualTypeArguments() {
        return this.typeArguments;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof AnnotatedParameterizedType && super.equals(o) && GenericTypeReflector.typeArraysEqual(this.typeArguments, ((AnnotatedParameterizedType)o).getAnnotatedActualTypeArguments());
    }
    
    @Override
    public int hashCode() {
        return 127 * super.hashCode() ^ GenericTypeReflector.hashCode(this.typeArguments);
    }
    
    @Override
    public String toString() {
        final ParameterizedType parameterizedType = (ParameterizedType)this.type;
        String str = GenericTypeReflector.getTypeName(parameterizedType.getRawType());
        "\u65c2\u55e6\u5db9".length();
        "\u55c0\u5466\u66b6\u5e5e".length();
        final StringBuilder sb = new StringBuilder();
        if (parameterizedType.getOwnerType() != null) {
            sb.append(GenericTypeReflector.getTypeName(parameterizedType.getOwnerType())).append('.');
            "\u5f4a\u612a\u50dc\u624f".length();
            "\u556c\u6081\u580b\u63c4".length();
            "\u5755\u58b0\u68e2".length();
            "\u5425\u5e0a\u6b4c\u5d67\u6771".length();
            String s;
            if (parameterizedType.getOwnerType() instanceof ParameterizedType) {
                "\u6333\u5fb9\u4ee0".length();
                "\u4f67\u6fd1\u51c3\u641a\u6339".length();
                "\u5b43".length();
                s = ((Class)((ParameterizedType)parameterizedType.getOwnerType()).getRawType()).getName() + '$';
            }
            else {
                "\u6a8f\u5a9a\u53c1\u6aaa".length();
                "\u54d7\u6165".length();
                "\u641a\u5572\u66e6\u5d68".length();
                "\u6c84\u5993\u507a".length();
                s = ((Class)parameterizedType.getOwnerType()).getName() + '$';
            }
            final String prefix = s;
            if (str.startsWith(prefix)) {
                str = str.substring(prefix.length());
            }
        }
        sb.append(str);
        "\u5dda\u6db1\u6542\u654e".length();
        "\u7006\u689f\u60b6".length();
        "\u69ee\u5a33\u5d0f".length();
        "\u5064\u5d9a\u6a37\u53be\u66c5".length();
        return this.annotationsString() + sb.toString() + \u6c2b\u6ec5\u5e02\u6735\u5393\u61bf\u5779\u59a8\u5c3d\u712f\u59fb\u5acf\u56f6\u548f\u5da5\u6f31\u7099\u5d1c\u63c4\u55a0\u6994\u4f9d\u5625\u59a7\u5edc\u638e\u5c75\u659d\u6b81\u621f\u5bf2\u6e6e\u5557\u62a3\u6724\u64aa\u57cd\u58a3\u6582\u60f2\u6b85(-646551165, 366108877, "\u768f", -145252872, 1943986758) + this.typesString(this.typeArguments) + \u6c2b\u6ec5\u5e02\u6735\u5393\u61bf\u5779\u59a8\u5c3d\u712f\u59fb\u5acf\u56f6\u548f\u5da5\u6f31\u7099\u5d1c\u63c4\u55a0\u6994\u4f9d\u5625\u59a7\u5edc\u638e\u5c75\u659d\u6b81\u621f\u5bf2\u6e6e\u5557\u62a3\u6724\u64aa\u57cd\u58a3\u6582\u60f2\u6b85(-1947323293, 1794751831, "\ub0a5", -1035138321, 1830236931);
    }
    
    public static int ColonialObfuscator_\u6c72\u5817\u6a57\u6a12\u51eb\u606c\u7085\u66fc\u5e14\u6601\u60cd\u4e69\u5532\u63e8\u6abe\u6fa1\u59a1\u5a97\u6680\u713c\u684b\u552f\u5b9e\u57b7\u5f29\u67ab\u6e01\u587d\u5f59\u70a4\u5763\u5e02\u64cb\u6c4e\u6560\u5f93\u69fc\u4e39\u5fee\u65f6\u4f4b(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
