package io.leangen.geantyref;

import java.lang.reflect.*;
import java.lang.annotation.*;

public class AnnotatedArrayTypeImpl extends AnnotatedTypeImpl implements AnnotatedArrayType
{
    public AnnotatedArrayTypeImpl(final Type type, final Annotation[] array, final AnnotatedType componentType) {
        super(type, array);
        this.componentType = componentType;
    }
    
    @Override
    public AnnotatedType getAnnotatedGenericComponentType() {
        return this.componentType;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof AnnotatedArrayType && super.equals(o) && ((AnnotatedArrayType)o).getAnnotatedGenericComponentType().equals(this.componentType);
    }
    
    @Override
    public int hashCode() {
        return 127 * super.hashCode() ^ this.componentType.hashCode();
    }
    
    @Override
    public String toString() {
        "\u5d9c\u69c8\u6744\u57f7".length();
        "\u53c9\u5960\u6192\u50c7".length();
        return this.componentType.toString() + \u4e30\u580e\u6a2f\u54ec\u4f95\u6197\u6b52\u5a9c\u5e17\u57b0\u596b\u6927\u5a52\u5215\u6208\u60bd\u6ca2\u4f98\u65e4\u69d5\u5a8e\u5620\u62f7\u6385\u5138\u6e32\u5e1f\u639c\u5c1e\u5875\u64b8\u546d\u56b9\u6889\u63a9\u4f53\u6800\u6848\u5bd5\u6671\u54b9(1164223441, 693891541, "\ub60a", 730146874, -370226089) + this.annotationsString() + \u4e30\u580e\u6a2f\u54ec\u4f95\u6197\u6b52\u5a9c\u5e17\u57b0\u596b\u6927\u5a52\u5215\u6208\u60bd\u6ca2\u4f98\u65e4\u69d5\u5a8e\u5620\u62f7\u6385\u5138\u6e32\u5e1f\u639c\u5c1e\u5875\u64b8\u546d\u56b9\u6889\u63a9\u4f53\u6800\u6848\u5bd5\u6671\u54b9(-939446885, 491631746, "\u97ab\u9780", 2036991130, -1151792592);
    }
    
    public static int ColonialObfuscator_\u5eb8\u4f4c\u6746\u6c49\u6651\u707c\u4ed7\u571b\u6b33\u6076\u5173\u5d64\u5b7e\u7017\u6cea\u51e8\u5f56\u5efc\u6369\u575a\u7104\u4f62\u64d7\u6b66\u55aa\u5dfc\u5392\u5e99\u6411\u676d\u630e\u602c\u6fd1\u50bf\u68fe\u5435\u6b30\u6bea\u6426\u56b2\u5c38(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
