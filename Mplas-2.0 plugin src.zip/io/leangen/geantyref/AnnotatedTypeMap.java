package io.leangen.geantyref;

import java.lang.reflect.*;
import java.util.stream.*;
import java.util.*;
import java.util.function.*;

public class AnnotatedTypeMap<K extends AnnotatedType, V> implements Map<K, V>
{
    public AnnotatedTypeMap() {
        this((Map)new HashMap());
    }
    
    public AnnotatedTypeMap(final Map<K, V> map) {
        Objects.requireNonNull(map);
        if (!map.isEmpty()) {
            throw new IllegalArgumentException(\u539c\u68b7\u607a\u59f7\u5846\u599a\u626f\u5218\u57b1\u5417\u5ab9\u6b75\u6069\u52b2\u5ad5\u6540\u6efd\u55e0\u4f73\u503f\u6eb8\u6eca\u654a\u5ea3\u65fa\u6603\u546e\u6d53\u5ac1\u6945\u5393\u6f12\u5258\u59f7\u6a49\u6cb0\u5ce1\u5dfc\u6060\u64fb\u545a(528608843, -1391541227, "\u0a81\u0a90\u0a9d\u0ada\u0a8c\u0a88\u0a9e\u0a8b\u0948\u0969\u096f\u097c\u0939\u0965\u0968\u096d\u0929\u0978\u094e\u6d05\u67bd\u6cb1\u69f3\u6ab1\u6521\u5192\u6f49\u56ff\u6b93\u5e1a", -1366810120, -1505689296));
        }
        this.inner = map;
    }
    
    @Override
    public int size() {
        return this.inner.size();
    }
    
    @Override
    public boolean isEmpty() {
        return this.inner.isEmpty();
    }
    
    @Override
    public boolean containsKey(final Object o) {
        return o instanceof AnnotatedType && this.inner.containsKey(GenericTypeReflector.toCanonical(o));
    }
    
    @Override
    public boolean containsValue(final Object o) {
        return this.inner.containsValue(o);
    }
    
    @Override
    public V get(final Object o) {
        return (o instanceof AnnotatedType) ? this.inner.get(GenericTypeReflector.toCanonical(o)) : null;
    }
    
    @Override
    public V put(final K k, final V v) {
        return this.inner.put(GenericTypeReflector.toCanonical(k), v);
    }
    
    @Override
    public V remove(final Object o) {
        return (o instanceof AnnotatedType) ? this.inner.remove(GenericTypeReflector.toCanonical(o)) : null;
    }
    
    @Override
    public void putAll(final Map<? extends K, ? extends V> map) {
        final AbstractMap.SimpleEntry<Object, V> simpleEntry;
        this.inner.putAll((Map<? extends K, ? extends V>)map.entrySet().stream().map(entry -> {
            // new(java.util.AbstractMap.SimpleEntry.class)
            "\u6b2a\u5ee7\u6505".length();
            "\u6be3".length();
            "\u65ad\u5401".length();
            new AbstractMap.SimpleEntry(GenericTypeReflector.toCanonical((Object)entry.getKey()), entry.getValue());
            return simpleEntry;
        }).collect(Collectors.toMap((Function<? super Object, ?>)AbstractMap.SimpleEntry::getKey, (Function<? super Object, ?>)AbstractMap.SimpleEntry::getValue)));
    }
    
    @Override
    public void clear() {
        this.inner.clear();
    }
    
    @Override
    public Set<K> keySet() {
        return this.inner.keySet();
    }
    
    @Override
    public Collection<V> values() {
        return this.inner.values();
    }
    
    @Override
    public Set<Entry<K, V>> entrySet() {
        return this.inner.entrySet();
    }
    
    @Override
    public boolean equals(final Object o) {
        return this.inner.equals(o);
    }
    
    @Override
    public int hashCode() {
        return this.inner.hashCode();
    }
    
    @Override
    public V getOrDefault(final Object o, final V defaultValue) {
        return (o instanceof AnnotatedType) ? this.inner.getOrDefault(GenericTypeReflector.toCanonical(o), defaultValue) : defaultValue;
    }
    
    @Override
    public void forEach(final BiConsumer<? super K, ? super V> action) {
        this.inner.forEach(action);
    }
    
    @Override
    public void replaceAll(final BiFunction<? super K, ? super V, ? extends V> function) {
        this.inner.replaceAll(function);
    }
    
    @Override
    public V putIfAbsent(final K k, final V value) {
        return this.inner.putIfAbsent(GenericTypeReflector.toCanonical(k), value);
    }
    
    @Override
    public boolean remove(final Object o, final Object value) {
        return o instanceof AnnotatedType && this.inner.remove(GenericTypeReflector.toCanonical(o), value);
    }
    
    @Override
    public boolean replace(final K k, final V oldValue, final V newValue) {
        return this.inner.replace(GenericTypeReflector.toCanonical(k), oldValue, newValue);
    }
    
    @Override
    public V replace(final K k, final V value) {
        return this.inner.replace(GenericTypeReflector.toCanonical(k), value);
    }
    
    @Override
    public V computeIfAbsent(final K k, final Function<? super K, ? extends V> mappingFunction) {
        return this.inner.computeIfAbsent(GenericTypeReflector.toCanonical(k), mappingFunction);
    }
    
    @Override
    public V computeIfPresent(final K k, final BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
        return this.inner.computeIfPresent(GenericTypeReflector.toCanonical(k), remappingFunction);
    }
    
    @Override
    public V compute(final K k, final BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
        return this.inner.compute(GenericTypeReflector.toCanonical(k), remappingFunction);
    }
    
    @Override
    public V merge(final K k, final V value, final BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
        return this.inner.merge(GenericTypeReflector.toCanonical(k), value, remappingFunction);
    }
    
    public static int ColonialObfuscator_\u5373\u59ed\u5b38\u6bd0\u6ba8\u529b\u68e7\u6e9d\u6f73\u50ec\u6d63\u6c3b\u6c73\u6a5f\u5d10\u59f8\u6410\u6889\u6fec\u682e\u6cc9\u51e3\u6da3\u6e87\u6745\u53c8\u52fa\u5fd5\u5fe0\u68f9\u54a6\u6172\u6cd5\u5165\u64fd\u6404\u6d9e\u704c\u4eeb\u5220\u6123(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
