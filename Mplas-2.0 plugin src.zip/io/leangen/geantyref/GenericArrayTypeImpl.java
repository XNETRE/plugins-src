package io.leangen.geantyref;

import java.lang.reflect.*;
import java.util.*;

public class GenericArrayTypeImpl implements GenericArrayType
{
    public GenericArrayTypeImpl(final Type componentType) {
        this.componentType = componentType;
    }
    
    @Override
    public Type getGenericComponentType() {
        return this.componentType;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof GenericArrayType && Objects.equals(this.componentType, ((GenericArrayType)o).getGenericComponentType());
    }
    
    @Override
    public int hashCode() {
        return Objects.hashCode(this.componentType);
    }
    
    @Override
    public String toString() {
        "\u5b7e\u5c3a\u639a\u5c24".length();
        "\u517d\u6035\u6a5f\u6218\u5aca".length();
        "\u631c\u59d0\u5687\u5e63\u5946".length();
        return this.componentType + \u6586\u68e4\u5785\u635f\u69a7\u5bc5\u682b\u6f46\u4ead\u61d8\u607b\u6610\u5a24\u6aeb\u6958\u5ff9\u634e\u6705\u51ce\u5e07\u6da9\u6a1a\u634f\u5ed3\u69f9\u6127\u5ce7\u59d8\u5e89\u51f8\u5fb2\u6f99\u5951\u5a87\u6029\u6f4d\u545c\u5571\u58a2\u5fe6\u5e99(601708843, 1313503024, "\u77c0\u77e5", 2092743479, -1516051724);
    }
    
    public static int ColonialObfuscator_\u709f\u6685\u6800\u5ddb\u52c6\u5d0d\u5ace\u6373\u6ef1\u50ed\u70f2\u6e93\u5770\u5662\u6aed\u6df4\u636c\u7085\u7083\u6612\u62c7\u66cf\u5cbf\u7032\u5dab\u6624\u58c6\u5f82\u502a\u6326\u51b2\u5049\u642f\u60fd\u5a45\u4ff0\u5dff\u6de7\u4f35\u63b6\u6bd6(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
