package io.leangen.geantyref;

import java.util.*;
import java.util.function.*;
import java.lang.reflect.*;

public abstract class TypeVisitor
{
    public TypeVisitor() {
        this.varCache = new IdentityHashMap<TypeVariable, AnnotatedTypeVariable>();
        this.captureCache = new HashMap<AnnotatedCaptureCacheKey, AnnotatedType>();
    }
    
    public AnnotatedType visitParameterizedType(final AnnotatedParameterizedType annotatedParameterizedType) {
        return GenericTypeReflector.replaceParameters(annotatedParameterizedType, Arrays.stream(annotatedParameterizedType.getAnnotatedActualTypeArguments()).map(annotatedType -> GenericTypeReflector.transform(annotatedType, this)).toArray(AnnotatedType[]::new));
    }
    
    public AnnotatedType visitWildcardType(final AnnotatedWildcardType annotatedWildcardType) {
        final AnnotatedType[] array = Arrays.stream(annotatedWildcardType.getAnnotatedLowerBounds()).map(annotatedType -> GenericTypeReflector.transform(annotatedType, this)).toArray(AnnotatedType[]::new);
        final AnnotatedType[] array2 = Arrays.stream(annotatedWildcardType.getAnnotatedUpperBounds()).map(annotatedType2 -> GenericTypeReflector.transform(annotatedType2, this)).toArray(AnnotatedType[]::new);
        "\u53bb\u5d31\u50b1\u63ba".length();
        "\u5f77".length();
        Type[] array4 = null;
        if (array2.length > 0) {
            final Type[] array3 = Arrays.stream(array2).map((Function<? super AnnotatedType, ?>)AnnotatedType::getType).toArray(Type[]::new);
        }
        else {
            array4 = new Type[] { null };
            "\u4f92\u526c\u5fcf\u5d1c".length();
            "\u6a78\u564d\u50c1\u5cad".length();
            array4[0] = Object.class;
        }
        final WildcardTypeImpl wildcardTypeImpl = new WildcardTypeImpl(array4, Arrays.stream(array).map((Function<? super AnnotatedType, ?>)AnnotatedType::getType).toArray(Type[]::new));
        "\u5a23\u5a6e\u550d".length();
        "\u5700".length();
        return new AnnotatedWildcardTypeImpl(wildcardTypeImpl, annotatedWildcardType.getAnnotations(), array, array2);
    }
    
    public AnnotatedType visitVariable(final AnnotatedTypeVariable annotatedTypeVariable) {
        final TypeVariable typeVariable = (TypeVariable)annotatedTypeVariable.getType();
        if (this.varCache.containsKey(typeVariable)) {
            return this.varCache.get(typeVariable);
        }
        "\u6378\u54b7\u628d\u7035".length();
        "\u5cdc\u54c4\u6080\u59c1\u5b94".length();
        "\u4e99\u6bcb\u6367\u6a6a\u70ca".length();
        final AnnotatedTypeVariableImpl annotatedTypeVariableImpl = new AnnotatedTypeVariableImpl(typeVariable, annotatedTypeVariable.getAnnotations());
        this.varCache.put(typeVariable, annotatedTypeVariableImpl);
        "\u4e96".length();
        "\u58b7\u5327\u6ad8".length();
        "\u5c55\u6165".length();
        annotatedTypeVariableImpl.init(Arrays.stream(annotatedTypeVariable.getAnnotatedBounds()).map(annotatedType -> GenericTypeReflector.transform(annotatedType, this)).toArray(AnnotatedType[]::new));
        return annotatedTypeVariableImpl;
    }
    
    public AnnotatedType visitArray(final AnnotatedArrayType annotatedArrayType) {
        final AnnotatedType transform = GenericTypeReflector.transform(annotatedArrayType.getAnnotatedGenericComponentType(), this);
        "\u6422\u6068\u5037\u519f\u53e7".length();
        return new AnnotatedArrayTypeImpl(GenericArrayTypeImpl.createArrayType(transform.getType()), annotatedArrayType.getAnnotations(), transform);
    }
    
    public AnnotatedType visitCaptureType(final AnnotatedCaptureType annotatedCaptureType) {
        "\u5799\u59aa\u5c19\u564e".length();
        "\u533a\u5cd3\u65fe\u6e86".length();
        "\u53d1\u53d7\u63f3\u6023\u70e1".length();
        final AnnotatedCaptureCacheKey annotatedCaptureCacheKey = new AnnotatedCaptureCacheKey(annotatedCaptureType);
        if (this.captureCache.containsKey(annotatedCaptureCacheKey)) {
            return this.captureCache.get(annotatedCaptureCacheKey);
        }
        AnnotatedType[] annotatedLowerBounds = annotatedCaptureType.getAnnotatedLowerBounds();
        if (annotatedLowerBounds != null) {
            annotatedLowerBounds = Arrays.stream(annotatedLowerBounds).map(annotatedType -> GenericTypeReflector.transform(annotatedType, this)).toArray(AnnotatedType[]::new);
        }
        final AnnotatedType[] array = Arrays.stream(annotatedCaptureType.getAnnotatedUpperBounds()).map(annotatedType2 -> GenericTypeReflector.transform(annotatedType2, this)).toArray(AnnotatedType[]::new);
        "\u5350\u5ccb".length();
        "\u532c\u6bff\u5922".length();
        "\u6fff\u6391".length();
        final AnnotatedCaptureTypeImpl annotatedCaptureTypeImpl = new AnnotatedCaptureTypeImpl((CaptureType)annotatedCaptureType.getType(), annotatedCaptureType.getAnnotatedWildcardType(), annotatedCaptureType.getAnnotatedTypeVariable(), annotatedLowerBounds, array, annotatedCaptureType.getAnnotations());
        this.captureCache.put(annotatedCaptureCacheKey, annotatedCaptureTypeImpl);
        "\u5b9c\u712e\u622b".length();
        "\u5065".length();
        return annotatedCaptureTypeImpl;
    }
    
    public AnnotatedType visitClass(final AnnotatedType annotatedType) {
        return annotatedType;
    }
    
    public AnnotatedType visitUnmatched(final AnnotatedType annotatedType) {
        return annotatedType;
    }
    
    public static int ColonialObfuscator_\u68f5\u4eca\u59f4\u66e0\u54a8\u67d6\u6f92\u5c50\u6cbc\u657d\u66cc\u63fb\u56c0\u6130\u5024\u4e8b\u6ab4\u5ba8\u60c7\u50c6\u6147\u6a5a\u5ec6\u6140\u5ac3\u6899\u55ce\u5cf3\u50a6\u674e\u5d87\u5611\u6806\u658a\u6c1e\u4e33\u6508\u6464\u63d9\u640e\u6b01(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
