package io.leangen.geantyref;

import java.lang.reflect.*;

public interface CaptureType extends Type
{
    Type[] getUpperBounds();
    
    void setUpperBounds(final Type[] p0);
    
    Type[] getLowerBounds();
    
    TypeVariable<?> getTypeVariable();
    
    WildcardType getWildcardType();
}
