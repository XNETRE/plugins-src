package io.leangen.geantyref;

import java.lang.reflect.*;

public abstract class TypeToken<T>
{
    public TypeToken() {
        this.type = this.extractType();
    }
    
    public TypeToken(final AnnotatedType type) {
        this.type = type;
    }
    
    public Type getType() {
        return this.type.getType();
    }
    
    public AnnotatedType getAnnotatedType() {
        return this.type;
    }
    
    public AnnotatedType getCanonicalType() {
        return GenericTypeReflector.toCanonical(this.type);
    }
    
    public AnnotatedType extractType() {
        final AnnotatedType annotatedSuperclass = this.getClass().getAnnotatedSuperclass();
        if (!(annotatedSuperclass instanceof AnnotatedParameterizedType)) {
            "\u5190\u6b79".length();
            "\u6a28\u5cf4".length();
            "\u582d\u4e64\u4fca\u6f6c\u618a".length();
            final RuntimeException ex = new RuntimeException(\u5cbe\u6d21\u54ed\u5aa5\u52f6\u5685\u583f\u59d8\u5c6c\u6db2\u6ec3\u60de\u5642\u6f96\u6eaa\u5e37\u51f9\u5329\u54ea\u5e1d\u63ac\u6497\u6581\u5a69\u7129\u58b7\u6630\u68cc\u6298\u54df\u4eab\u6748\u628d\u5034\u4ef5\u5813\u5ac1\u6b58\u5bda\u5f6d\u66c3(282849428, -1564773288, "\ucfb0\ucfba\ucfa2\ucfb7\ucfbc\ucfbf\ucfb9\ucff1\ucfa9\ucfa8\ucfa6\ucfa1\ucf91\ucfbb\ucfbe\ucfa4\ucf8b\ucfc2\ucff7\ua806\ubfc4\uafb4\u9bde\u9c88\u8008\u911d\ua370\ua3c0\u9545\ua082\ubef5\u81f6\u98c8\ua301\u9120\uaf4b\uacd4\u94c9\u9f3c\u9cfe\u803c\u99dc\u9e24\u91aa\ua549\uad56\ua031", 989738896, -464683802));
            "\u53f9\u604a\u5725\u6fc2\u5e84".length();
            "\u651a\u6371\u5394".length();
            "\u5a0f\u665b\u5656\u5dc4".length();
            throw ex;
        }
        final AnnotatedParameterizedType annotatedParameterizedType = (AnnotatedParameterizedType)annotatedSuperclass;
        if (((ParameterizedType)annotatedParameterizedType.getType()).getRawType() != TypeToken.class) {
            "\u6613\u7092".length();
            "\u59c4\u5caa\u54f7\u6b4e\u54b3".length();
            "\u6a5b".length();
            "\u5f96\u588b\u6bec".length();
            final RuntimeException ex2 = new RuntimeException(\u5cbe\u6d21\u54ed\u5aa5\u52f6\u5685\u583f\u59d8\u5c6c\u6db2\u6ec3\u60de\u5642\u6f96\u6eaa\u5e37\u51f9\u5329\u54ea\u5e1d\u63ac\u6497\u6581\u5a69\u7129\u58b7\u6630\u68cc\u6298\u54df\u4eab\u6748\u628d\u5034\u4ef5\u5813\u5ac1\u6b58\u5bda\u5f6d\u66c3(-679147293, 811113801, "\u8e48\u8e42\u8e5a\u8e4f\u8e7c\u8e7f\u8e79\u8e31\u8e61\u8e60\u8e6e\u8e69\u8e51\u8e7b\u8e7e\u8e64\u8e73\u8e3a\u8e0f\ue9fe\ufe24\uee54\uda3e\udd68\uc1f7\ud0ec\ue28f\ue22e\ud4af\ue170\uff00\uc04f\ud964\ue2e5\ud0d0\ueea2\ued91\ud5d7\ude39\uddac\uc101\ud8c0\udf39\ud0b3\ue478\uec4b\ue129\ue5e9\ue26a", 1739826012, 1251588276));
            "\u5ba5\u567e\u64c1\u5c39\u6773".length();
            throw ex2;
        }
        return annotatedParameterizedType.getAnnotatedActualTypeArguments()[0];
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof TypeToken && GenericTypeReflector.equals(this.type, ((TypeToken)o).type);
    }
    
    @Override
    public int hashCode() {
        return this.type.hashCode();
    }
    
    public static int ColonialObfuscator_\u6a7b\u6aaa\u5d73\u55f0\u577f\u6fb6\u663d\u70fb\u605f\u64f1\u5321\u5572\u6d0a\u595d\u6d19\u6e96\u55bf\u579d\u547f\u5cf9\u6e7d\u595a\u51cc\u6a59\u70df\u6f94\u5866\u540c\u5243\u5cf3\u552c\u5dc5\u6615\u6297\u5dcb\u5770\u4e33\u70dd\u636b\u536e\u5a62(final int n, final int n2) {
        return ((n | n2) << 1) + ~(n ^ n2) + 1;
    }
}
